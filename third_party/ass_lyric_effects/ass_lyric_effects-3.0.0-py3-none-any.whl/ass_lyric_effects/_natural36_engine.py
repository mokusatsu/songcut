"""Vendored Natural Effects v7 engine for Advanced SubStation Alpha lyrics.

This file is an internal vendoring of the Natural Effects v7 ``core.py``.  It
intentionally retains the historical definitions and the final v7 override
block at the bottom of the source so seed fallbacks, transition recipes, and
the 36-effect/68-variant catalogue stay byte-compatible with the source
package.  The host package supplies the canonical grapheme splitter at call
time; the Natural renderer itself keeps the complete lyric fixed and reveals
it with sweep/radial/flash clips while local particles follow deterministic
phenomenon-specific paths.
"""
from __future__ import annotations
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, replace
from enum import Enum
import math
import random
import re
import unicodedata
from typing import Any

class EffectError(ValueError):
    """Base error raised for invalid input or unsupported combinations."""

class EffectParameterError(EffectError):
    """Raised when an effect-specific parameter is invalid."""

class Effect(str, Enum):
    RAIN_VEIL = 'rain_veil'
    DRIZZLE_MIST = 'drizzle_mist'
    CLOUDBURST = 'cloudburst'
    CREPUSCULAR_RAYS = 'crepuscular_rays'
    SNOWFALL_DEPTH = 'snowfall_depth'
    BLIZZARD_WHITEOUT = 'blizzard_whiteout'
    DIAMOND_DUST = 'diamond_dust'
    HAILSTORM = 'hailstorm'
    FROST_BLOOM = 'frost_bloom'
    ICE_CRACK = 'ice_crack'
    AVALANCHE = 'avalanche'
    MORNING_MIST = 'morning_mist'
    SEA_OF_CLOUDS = 'sea_of_clouds'
    GENTLE_BREEZE = 'gentle_breeze'
    GUST_FRONT = 'gust_front'
    WHIRLWIND = 'whirlwind'
    TORNADO = 'tornado'
    SANDSTORM = 'sandstorm'
    HEAT_HAZE = 'heat_haze'
    OCEAN_SWELL = 'ocean_swell'
    BREAKING_WAVE = 'breaking_wave'
    RISING_TIDE = 'rising_tide'
    WATERFALL = 'waterfall'
    RIVER_CURRENT = 'river_current'
    WHIRLPOOL = 'whirlpool'
    LAVA_FLOW = 'lava_flow'
    EMBER_DRIFT = 'ember_drift'
    RAINBOW_ARCH = 'rainbow_arch'
    CHERRY_BLOSSOM_STORM = 'cherry_blossom_storm'
    FALLING_LEAVES = 'falling_leaves'
    FIREFLY_NIGHT = 'firefly_night'
    BIOLUMINESCENT_TIDE = 'bioluminescent_tide'
    METEOR_SHOWER = 'meteor_shower'
    SOLAR_ECLIPSE = 'solar_eclipse'
    MOONLIGHT_CLOUDS = 'moonlight_clouds'
    SUNRISE_HORIZON = 'sunrise_horizon'

class Direction(str, Enum):
    LEFT_TO_RIGHT = 'left_to_right'
    RIGHT_TO_LEFT = 'right_to_left'
    TOP_TO_BOTTOM = 'top_to_bottom'
    BOTTOM_TO_TOP = 'bottom_to_top'
    CLOCKWISE = 'clockwise'
    COUNTERCLOCKWISE = 'counterclockwise'
    HORIZONTAL = 'horizontal'
    VERTICAL = 'vertical'
    CENTER_OUT = 'center_out'
    EDGES_IN = 'edges_in'
    INWARD = 'inward'
    OUTWARD = 'outward'
    ABOVE = 'above'
    BELOW = 'below'

class Phase(str, Enum):
    ODD_FIRST = 'odd_first'
    EVEN_FIRST = 'even_first'

# Stable v6 ordinals are retained for deterministic seed fallbacks. Four
# effects were removed in v7 and Spring Breeze was reordered, but unaffected
# effects must render byte-for-byte identically when their explicit parameters
# are unchanged.
_LEGACY_EFFECT_NUMBERS: dict[Effect, int] = {
    Effect.RAIN_VEIL: 1,
    Effect.DRIZZLE_MIST: 2,
    Effect.CLOUDBURST: 4,
    Effect.RAINBOW_ARCH: 7,
    Effect.CREPUSCULAR_RAYS: 8,
    Effect.SNOWFALL_DEPTH: 9,
    Effect.BLIZZARD_WHITEOUT: 10,
    Effect.DIAMOND_DUST: 11,
    Effect.HAILSTORM: 12,
    Effect.FROST_BLOOM: 13,
    Effect.ICE_CRACK: 15,
    Effect.AVALANCHE: 16,
    Effect.MORNING_MIST: 17,
    Effect.SEA_OF_CLOUDS: 18,
    Effect.GENTLE_BREEZE: 19,
    Effect.GUST_FRONT: 20,
    Effect.WHIRLWIND: 21,
    Effect.TORNADO: 22,
    Effect.SANDSTORM: 23,
    Effect.HEAT_HAZE: 24,
    Effect.OCEAN_SWELL: 25,
    Effect.BREAKING_WAVE: 26,
    Effect.RISING_TIDE: 27,
    Effect.WATERFALL: 28,
    Effect.RIVER_CURRENT: 29,
    Effect.WHIRLPOOL: 30,
    Effect.LAVA_FLOW: 31,
    Effect.EMBER_DRIFT: 32,
    Effect.CHERRY_BLOSSOM_STORM: 33,
    Effect.FALLING_LEAVES: 34,
    Effect.FIREFLY_NIGHT: 35,
    Effect.BIOLUMINESCENT_TIDE: 36,
    Effect.METEOR_SHOWER: 37,
    Effect.SOLAR_ECLIPSE: 38,
    Effect.MOONLIGHT_CLOUDS: 39,
    Effect.SUNRISE_HORIZON: 40,
}

def _legacy_effect_number(effect: Effect) -> int:
    return _LEGACY_EFFECT_NUMBERS[effect]

@dataclass(frozen=True)
class EffectSpec:
    name_en: str
    name_ja: str
    category_en: str
    category_ja: str
    description_en: str
    description_ja: str
    default_params: Mapping[str, Any]
    categorical_params: Mapping[str, tuple[str, ...]]
    context_required: bool = True
CARDINAL_HORIZONTAL = (Direction.LEFT_TO_RIGHT.value, Direction.RIGHT_TO_LEFT.value)
ROTATIONS = (Direction.CLOCKWISE.value, Direction.COUNTERCLOCKWISE.value)
RADIAL = (Direction.CENTER_OUT.value, Direction.EDGES_IN.value)
EFFECT_SPECS: dict[Effect, EffectSpec] = {Effect.RAIN_VEIL: EffectSpec('Rain Veil', '雨幕', 'Rain, light and storm', '雨・光・嵐', 'Cloud layers, near and far rain, puddle glow, expanding ripples and splash crowns form a deep rain scene.', '雲層、遠近二層の雨脚、水面光、広がる波紋、着弾の飛沫を重ね、奥行きのある雨空間を作ります。', {'direction': Direction.LEFT_TO_RIGHT, 'density': 56, 'speed': 820, 'slant': 70, 'ripples': 12, 'seed': 101}, {'direction': CARDINAL_HORIZONTAL}), Effect.DRIZZLE_MIST: EffectSpec('Drizzle Mist', '霧雨', 'Rain, light and storm', '雨・光・嵐', 'Fine diagonal drizzle drifts through translucent mist while condensation beads gather around the lyric.', '半透明の霧を細い斜めの雨が漂い、歌詞の周囲には結露の粒が静かに集まります。', {'direction': Direction.LEFT_TO_RIGHT, 'density': 54, 'speed': 420, 'mist_bands': 5, 'beads': 18, 'seed': 211}, {'direction': CARDINAL_HORIZONTAL}), Effect.CLOUDBURST: EffectSpec('Cloudburst', '驟雨', 'Rain, light and storm', '雨・光・嵐', 'Heavy cloud banks release a dense vertical curtain with foreground sheets, ground spray and a fast water surge.', '厚い雲塊から高密度の雨幕、前景の水膜、地面の飛沫、素早い水流を一気に放ちます。', {'direction': Direction.LEFT_TO_RIGHT, 'density': 88, 'speed': 1100, 'clouds': 5, 'splashes': 16, 'seed': 401}, {'direction': CARDINAL_HORIZONTAL}), Effect.RAINBOW_ARCH: EffectSpec('Rainbow Arch', '虹', 'Rain, light and storm', '雨・光・嵐', 'Seven luminous arcs bloom behind the lyric while droplets and refracted sparkles drift across the scene.', '七色の発光アーチが歌詞の背後に咲き、雨粒と屈折した輝きが周囲を流れます。', {'direction': Direction.LEFT_TO_RIGHT, 'bands': 7, 'radius': 330, 'thickness': 11, 'sparkles': 18}, {'direction': CARDINAL_HORIZONTAL}), Effect.CREPUSCULAR_RAYS: EffectSpec('Crepuscular Rays', '薄明光線', 'Rain, light and storm', '雨・光・嵐', 'Clouds open to reveal broad fan-shaped light shafts filled with slowly drifting illuminated dust.', '雲の切れ間から幅の異なる扇状の光芒が差し込み、照らされた微粒子がゆっくり漂います。', {'direction': Direction.LEFT_TO_RIGHT, 'rays': 9, 'dust': 38, 'opening': 220, 'seed': 809}, {'direction': CARDINAL_HORIZONTAL}), Effect.SNOWFALL_DEPTH: EffectSpec('Snowfall in Depth', '奥行きの降雪', 'Snow and ice', '雪・氷', 'Tiny distant snow, soft middle flakes and large rotating foreground crystals create layered winter depth.', '遠景の細雪、中景の柔らかな雪片、回転する前景結晶を重ね、冬の奥行きを作ります。', {'direction': Direction.LEFT_TO_RIGHT, 'far_flakes': 44, 'near_flakes': 18, 'drift': 70, 'seed': 907}, {'direction': CARDINAL_HORIZONTAL}), Effect.BLIZZARD_WHITEOUT: EffectSpec('Blizzard Whiteout', '吹雪', 'Snow and ice', '雪・氷', 'Fast horizontal snow streaks, curling gust bands and intermittent whiteout partially veil a strongly outlined lyric.', '高速の横雪、巻き込む風の帯、断続的なホワイトアウトが、濃い輪郭の歌詞を部分的に覆います。', {'direction': Direction.LEFT_TO_RIGHT, 'streaks': 70, 'gust_bands': 5, 'whiteout': 55, 'seed': 1009}, {'direction': CARDINAL_HORIZONTAL}), Effect.DIAMOND_DUST: EffectSpec('Diamond Dust', 'ダイヤモンドダスト', 'Snow and ice', '雪・氷', 'Vertical light pillars reveal floating ice crystals that flash in white, cyan and pale rainbow hues.', '縦の光柱の中に浮遊する氷晶を置き、白、シアン、淡い虹色へ瞬間的にきらめかせます。', {'direction': Direction.LEFT_TO_RIGHT, 'crystals': 46, 'pillars': 5, 'sparkle_cycles': 2.2, 'seed': 1103}, {'direction': CARDINAL_HORIZONTAL}), Effect.HAILSTORM: EffectSpec('Hailstorm', '雹', 'Snow and ice', '雪・氷', 'Hard ice pellets fall at several depths, rebound from an invisible ground plane and trigger sharp impact rings.', '硬い氷粒が複数の奥行きで落下し、見えない地面で跳ね返り、鋭い衝撃波紋を生みます。', {'direction': Direction.LEFT_TO_RIGHT, 'pellets': 48, 'bounce': 70, 'impacts': 12, 'seed': 1201}, {'direction': CARDINAL_HORIZONTAL}), Effect.FROST_BLOOM: EffectSpec('Frost Bloom', '霜華', 'Snow and ice', '雪・氷', 'Branching frost crystals grow sequentially from the lyric frame, then glitter and recede along the same structure.', '歌詞枠から枝分かれする霜結晶が順に成長し、きらめいた後、同じ構造をたどって消えます。', {'direction': Direction.CENTER_OUT, 'branches': 18, 'depth': 3, 'reach': 115, 'seed': 1301}, {'direction': RADIAL}), Effect.ICE_CRACK: EffectSpec('Ice Crack', '氷裂', 'Snow and ice', '雪・氷', 'A translucent ice pane forms behind the lyric as cracks propagate, shard edges flash and fragments loosen.', '歌詞の背後に薄い氷面を作り、亀裂を伝播させ、破片の縁を光らせながら緩ませます。', {'direction': Direction.CENTER_OUT, 'branches': 12, 'depth': 3, 'shards': 18, 'seed': 1501}, {'direction': RADIAL}), Effect.AVALANCHE: EffectSpec('Avalanche', '雪崩', 'Snow and ice', '雪・氷', 'A sweeping snow mass crosses beneath the lyric with rolling powder clouds, thrown chunks and a trailing haze.', '雪塊が歌詞の下を横切り、巻き上がる粉雪雲、飛散する雪片、後方の霞を伴います。', {'direction': Direction.LEFT_TO_RIGHT, 'powder': 38, 'distance': 1800, 'debris': 26, 'seed': 1601}, {'direction': CARDINAL_HORIZONTAL}), Effect.MORNING_MIST: EffectSpec('Morning Mist', '朝霧', 'Wind and atmosphere', '風・大気', 'Several broad, soft fog banks move at different speeds so the lyric slowly emerges and submerges in depth.', '幅広く柔らかな霧の層を異なる速度で動かし、歌詞が奥行きの中で現れたり沈んだりします。', {'direction': Direction.LEFT_TO_RIGHT, 'bands': 7, 'drift': 130, 'opacity': 125, 'seed': 1709}, {'direction': CARDINAL_HORIZONTAL}), Effect.SEA_OF_CLOUDS: EffectSpec('Sea of Clouds', '雲海', 'Wind and atmosphere', '風・大気', 'Parallax cloud banks roll below and around the lyric while distant peaks and a bright upper sky establish scale.', '視差を持つ雲の層が歌詞の下と周囲を流れ、遠い峰と明るい上空で広がりを作ります。', {'direction': Direction.LEFT_TO_RIGHT, 'layers': 5, 'cloudlets': 18, 'drift': 90, 'seed': 1801}, {'direction': CARDINAL_HORIZONTAL}), Effect.GENTLE_BREEZE: EffectSpec('Gentle Breeze', 'そよ風', 'Wind and atmosphere', '風・大気', 'Fine airflow ribbons pass through bending grass silhouettes while light seeds float lazily around the lyric.', '細い気流のリボンがしなる草影を抜け、軽い種子が歌詞の周囲をゆっくり漂います。', {'direction': Direction.LEFT_TO_RIGHT, 'streamlines': 12, 'grass_blades': 20, 'seeds': 14, 'seed': 1901}, {'direction': CARDINAL_HORIZONTAL}), Effect.GUST_FRONT: EffectSpec('Gust Front', '突風', 'Wind and atmosphere', '風・大気', 'A compressed pressure arc strikes the lyric, followed by fast streaks, tumbling debris and a short whole-line recoil.', '圧縮された気圧弧が歌詞へ衝突し、高速の風線、回転する微片、字幕全体の短い反動が続きます。', {'direction': Direction.LEFT_TO_RIGHT, 'streaks': 34, 'debris': 20, 'displacement': 26, 'seed': 2003}, {'direction': CARDINAL_HORIZONTAL}), Effect.WHIRLWIND: EffectSpec('Whirlwind', 'つむじ風', 'Wind and atmosphere', '風・大気', 'Layered dust spirals, floor rings and orbiting fragments circle the lyric, rise, loosen and fall away.', '多層の塵旋、地面の輪、周回する光片が歌詞を囲み、上昇し、ほどけて消えていきます。', {'direction': Direction.CLOCKWISE, 'particles': 46, 'turns': 2.1, 'radius': 250, 'seed': 2101}, {'direction': ROTATIONS}), Effect.TORNADO: EffectSpec('Tornado', '竜巻', 'Wind and atmosphere', '風・大気', 'Stacked rotating rings build a tapering funnel beneath a storm cap while debris orbits at changing radii.', '積層した回転輪で先細りの漏斗雲を作り、上部の雲蓋と半径が変化する飛散物を加えます。', {'direction': Direction.CLOCKWISE, 'rings': 14, 'debris': 34, 'width': 330, 'seed': 2203}, {'direction': ROTATIONS}), Effect.SANDSTORM: EffectSpec('Sandstorm', '砂嵐', 'Wind and atmosphere', '風・大気', 'Dense grains at three depths, broad ochre sheets and moving dune shadows sweep across a heat-lit lyric.', '三段階の奥行きを持つ砂粒、幅広い黄土色の砂膜、移動する砂丘影が歌詞を横切ります。', {'direction': Direction.LEFT_TO_RIGHT, 'grains': 92, 'bands': 6, 'speed': 560, 'seed': 2309}, {'direction': CARDINAL_HORIZONTAL}), Effect.HEAT_HAZE: EffectSpec('Heat Haze', '陽炎', 'Wind and atmosphere', '風・大気', 'A hot horizon, rising translucent wisps and offset lyric slices create a mirage-like refractive shimmer.', '熱い地平線、立ち上る透明な揺らぎ、位置をずらした字幕帯で蜃気楼のような屈折を作ります。', {'direction': Direction.LEFT_TO_RIGHT, 'bands': 8, 'distortion': 14, 'wisps': 16, 'seed': 2401}, {'direction': CARDINAL_HORIZONTAL}), Effect.OCEAN_SWELL: EffectSpec('Ocean Swell', '海のうねり', 'Water, fire and earth', '水・火・大地', 'Several translucent wave bodies travel at different speeds while foam glints and the whole lyric gently floats.', '半透明の波面を異なる速度で重ね、泡の反射を散らし、歌詞全体を穏やかに浮かせます。', {'direction': Direction.LEFT_TO_RIGHT, 'layers': 4, 'amplitude': 48, 'wavelength': 360, 'foam': 24}, {'direction': CARDINAL_HORIZONTAL}), Effect.BREAKING_WAVE: EffectSpec('Breaking Wave', '砕ける波', 'Water, fire and earth', '水・火・大地', 'A curling crest sweeps across the lyric stage and breaks into layered foam, airborne spray and retreating water.', '巻き上がる波頭が歌詞領域を横切り、多層の泡、空中の飛沫、引いていく水へ砕けます。', {'direction': Direction.LEFT_TO_RIGHT, 'crest': 260, 'spray': 42, 'foam': 30, 'seed': 2609}, {'direction': CARDINAL_HORIZONTAL}), Effect.RISING_TIDE: EffectSpec('Rising Tide', '満ち潮', 'Water, fire and earth', '水・火・大地', 'A moving waterline rises through the lyric, separating dry and submerged colour treatments with surface glints.', '動く水位線が歌詞を通過し、水上と水中で異なる色処理を行い、表面の反射光を添えます。', {'level': 110, 'surge': 95, 'glints': 20, 'seed': 2707}, {}), Effect.WATERFALL: EffectSpec('Waterfall', '滝', 'Water, fire and earth', '水・火・大地', 'Multiple vertical streams descend behind the lyric and burst into low mist, splash fans and suspended droplets.', '複数の縦流が歌詞の背後を落ち、下部で霧、扇状の飛沫、浮遊する水滴へ砕けます。', {'streams': 16, 'mist': 36, 'splashes': 24, 'seed': 2801}, {}), Effect.RIVER_CURRENT: EffectSpec('River Current', '川の流れ', 'Water, fire and earth', '水・火・大地', 'Curved ribbons weave around the lyric as foam flecks and glints follow separate current lanes.', '曲線の流線が歌詞を縫うように進み、泡片と反射光が別々の流路をたどります。', {'direction': Direction.LEFT_TO_RIGHT, 'ribbons': 7, 'foam': 26, 'speed': 300, 'seed': 2903}, {'direction': CARDINAL_HORIZONTAL}), Effect.WHIRLPOOL: EffectSpec('Whirlpool', '渦潮', 'Water, fire and earth', '水・火・大地', 'Concentric spiral water lines tighten around the lyric while foam particles accelerate toward the centre.', '同心の渦線が歌詞の周囲で締まり、泡粒が中心へ向かって加速します。', {'direction': Direction.CLOCKWISE, 'rings': 11, 'foam': 34, 'turns': 2.0, 'seed': 3001}, {'direction': ROTATIONS}), Effect.LAVA_FLOW: EffectSpec('Lava Flow', '溶岩流', 'Water, fire and earth', '水・火・大地', 'Glowing channels crawl beneath the lyric through a dark cracked crust, throwing sparks and heat distortion upward.', '暗い亀裂地面の下を発光する溶岩流が進み、火花と熱の揺らぎを上方へ放ちます。', {'direction': Direction.LEFT_TO_RIGHT, 'channels': 5, 'cracks': 22, 'embers': 26, 'seed': 3109}, {'direction': CARDINAL_HORIZONTAL}), Effect.EMBER_DRIFT: EffectSpec('Ember Drift', '火の粉', 'Water, fire and earth', '水・火・大地', 'Layered smoke drifts behind the lyric while glowing embers rise on curved paths and occasional flares blossom.', '多層の煙が歌詞の背後を流れ、発光する火の粉が曲線上昇し、ときどき大きな火花が開きます。', {'direction': Direction.LEFT_TO_RIGHT, 'embers': 52, 'smoke_bands': 5, 'flares': 8, 'seed': 3203}, {'direction': CARDINAL_HORIZONTAL}), Effect.CHERRY_BLOSSOM_STORM: EffectSpec('Cherry Blossom Storm', '桜吹雪', 'Season and cosmos', '季節・宇宙', 'Petals at several depths spiral across a pink atmospheric wash while a dark branch anchors the scene.', '複数の奥行きの花びらが桃色の霞を旋回し、暗い枝影が画面に基準を与えます。', {'direction': Direction.CLOCKWISE, 'petals': 54, 'gusts': 4, 'seed': 3301}, {'direction': ROTATIONS}), Effect.FALLING_LEAVES: EffectSpec('Falling Leaves', '落葉', 'Season and cosmos', '季節・宇宙', 'Autumn leaves tumble at different depths, collect below the lyric and are lifted into one last ground swirl.', '秋色の葉が奥行き別に回転落下し、歌詞下部に積もり、最後に地表の渦へ巻き上がります。', {'direction': Direction.LEFT_TO_RIGHT, 'leaves': 40, 'tumble': 3.0, 'ground_swirl': 18, 'seed': 3407}, {'direction': CARDINAL_HORIZONTAL}), Effect.FIREFLY_NIGHT: EffectSpec('Firefly Night', '蛍', 'Season and cosmos', '季節・宇宙', 'Soft grass silhouettes frame independently pulsing fireflies, curved light trails and a moonless blue-black night.', '柔らかな草影の中で蛍が独立に明滅し、曲線の光跡を残す月のない青黒い夜を作ります。', {'direction': Direction.CLOCKWISE, 'fireflies': 30, 'glow_radius': 10, 'trails': 12, 'seed': 3503}, {'direction': ROTATIONS}), Effect.BIOLUMINESCENT_TIDE: EffectSpec('Bioluminescent Tide', '夜光虫', 'Season and cosmos', '季節・宇宙', 'Dark waves ignite with cyan-blue foam and thousands-like clusters of tiny glowing plankton around the lyric.', '暗い波がシアンブルーの泡と無数に見える微細な発光粒子で点灯し、歌詞を包みます。', {'direction': Direction.LEFT_TO_RIGHT, 'wave_layers': 3, 'sparks': 46, 'foam': 28, 'seed': 3607}, {'direction': CARDINAL_HORIZONTAL}), Effect.METEOR_SHOWER: EffectSpec('Meteor Shower', '流星群', 'Season and cosmos', '季節・宇宙', 'A deep star field surrounds a radiant point from which meteors of varied length, speed and brightness streak past.', '奥行きある星空と放射点を作り、長さ、速度、明るさの異なる流星を次々に走らせます。', {'direction': Direction.LEFT_TO_RIGHT, 'meteors': 30, 'stars': 55, 'radiant_spread': 240, 'seed': 3701}, {'direction': CARDINAL_HORIZONTAL}), Effect.SOLAR_ECLIPSE: EffectSpec('Solar Eclipse', '日食', 'Season and cosmos', '季節・宇宙', 'A dark disc crosses a luminous sun, revealing corona spikes, emerging stars and a brief diamond-ring flash.', '暗い円盤が発光する太陽を横切り、コロナの光条、現れる星、短いダイヤモンドリングを見せます。', {'direction': Direction.LEFT_TO_RIGHT, 'corona_rays': 28, 'stars': 24, 'ring_scale': 150}, {'direction': CARDINAL_HORIZONTAL}), Effect.MOONLIGHT_CLOUDS: EffectSpec('Moonlight Through Clouds', '雲間の月光', 'Season and cosmos', '季節・宇宙', 'Cloud layers pass before a bright moon, opening and closing pale shafts that selectively illuminate the lyric.', '雲の層が明月の前を通過し、淡い光柱を開閉して歌詞を選択的に照らします。', {'direction': Direction.LEFT_TO_RIGHT, 'cloud_layers': 6, 'beams': 7, 'stars': 28, 'seed': 3907}, {'direction': CARDINAL_HORIZONTAL}), Effect.SUNRISE_HORIZON: EffectSpec('Sunrise Horizon', '日の出', 'Season and cosmos', '季節・宇宙', 'A layered dawn sky brightens as the sun rises through low mist, sending long rays across the lyric stage.', '多層の夜明け空が明るくなり、低い霧を抜けて太陽が昇り、長い光線を歌詞領域へ送ります。', {'direction': Direction.LEFT_TO_RIGHT, 'rays': 12, 'mist_bands': 5, 'glow_layers': 6}, {'direction': CARDINAL_HORIZONTAL})}
EFFECT_NAMES_EN: dict[Effect, str] = {effect: spec.name_en for effect, spec in EFFECT_SPECS.items()}
EFFECT_NAMES_JA: dict[Effect, str] = {effect: spec.name_ja for effect, spec in EFFECT_SPECS.items()}
DEFAULT_PARAMS: dict[Effect, dict[str, Any]] = {effect: dict(spec.default_params) for effect, spec in EFFECT_SPECS.items()}
CONTEXT_REQUIRED_EFFECTS = frozenset((effect for effect, spec in EFFECT_SPECS.items() if spec.context_required))

@dataclass(frozen=True)
class Rect:
    x1: int
    y1: int
    x2: int
    y2: int

    def __post_init__(self) -> None:
        if self.x1 >= self.x2 or self.y1 >= self.y2:
            raise EffectParameterError('Rect requires x1 < x2 and y1 < y2')

    @property
    def width(self) -> int:
        return self.x2 - self.x1

    @property
    def height(self) -> int:
        return self.y2 - self.y1

    @property
    def center(self) -> tuple[float, float]:
        return ((self.x1 + self.x2) / 2, (self.y1 + self.y2) / 2)

@dataclass(frozen=True)
class EffectContext:
    """Geometry and sampling information not present in one Dialogue line.

    ``text_box`` should cover the rendered lyric including outline and shadow.
    The Natural v7 renderer keeps the lyric as one fixed ASS line and uses
    this rectangle to place sweep bands and bound local particles.  The
    ``glyph_widths`` field remains part of the shared context contract so the
    vendored validation path can preserve a caller's measured layout.  It is
    deliberately permissive: finite non-negative widths (including zero for
    combining/mark-only clusters) are retained, while a positive total is
    still required only by character layout code that actually consumes it.
    """
    play_res_x: int = 1920
    play_res_y: int = 1080
    anchor_x: int | None = None
    anchor_y: int | None = None
    text_box: Rect | None = None
    offscreen_margin: int = 240
    motion_step_ms: int = 100
    glyph_widths: tuple[float, ...] | None = None
    strict: bool = True

    def __post_init__(self) -> None:
        if self.play_res_x <= 0 or self.play_res_y <= 0:
            raise EffectParameterError('play_res_x/play_res_y must be positive')
        if self.offscreen_margin < 0:
            raise EffectParameterError('offscreen_margin must be non-negative')
        if not 40 <= self.motion_step_ms <= 500:
            raise EffectParameterError('motion_step_ms must be between 40 and 500')
        if self.text_box is not None and (not (0 <= self.text_box.x1 < self.text_box.x2 <= self.play_res_x and 0 <= self.text_box.y1 < self.text_box.y2 <= self.play_res_y)):
            raise EffectParameterError('text_box must be inside PlayRes')
        if self.glyph_widths is not None:
            if not self.glyph_widths or any(
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(float(value))
                or float(value) < 0
                for value in self.glyph_widths
            ):
                raise EffectParameterError(
                    'glyph_widths must contain finite non-negative values'
                )

    @property
    def anchor(self) -> tuple[int, int]:
        return (self.play_res_x // 2 if self.anchor_x is None else self.anchor_x, self.play_res_y // 2 if self.anchor_y is None else self.anchor_y)

    @property
    def box(self) -> Rect:
        if self.text_box is not None:
            return self.text_box
        anchor_x, anchor_y = self.anchor
        half_width = round(self.play_res_x * 0.31)
        half_height = round(self.play_res_y * 0.1)
        return Rect(max(0, anchor_x - half_width), max(0, anchor_y - half_height), min(self.play_res_x, anchor_x + half_width), min(self.play_res_y, anchor_y + half_height))
_TIME_RE = re.compile('^\\s*(\\d+):([0-5]?\\d):([0-5]?\\d)(?:\\.(\\d{1,3}))?\\s*$')
_DIALOGUE_RE = re.compile('^\\s*Dialogue\\s*:\\s*(.*)$', re.IGNORECASE)
_LEADING_OVERRIDE_RE = re.compile('^\\{([^{}]*)\\}')
_OVERRIDE_RE = re.compile('\\{[^{}]*\\}')
_POS_RE = re.compile('\\\\pos\\(\\s*(-?\\d+(?:\\.\\d+)?)\\s*,\\s*(-?\\d+(?:\\.\\d+)?)\\s*\\)', re.IGNORECASE)
_CONFLICT_RE = re.compile('\\\\(?:fad|fade|t|move|clip|iclip|k|K|kf|ko)(?=[(\\d\\\\])')
_DRAWING_RE = re.compile('\\\\p\\s*[1-9]', re.IGNORECASE)

@dataclass(frozen=True)
class DialogueEvent:
    layer: int
    start_ms: int
    end_ms: int
    style: str
    name: str
    margin_l: str
    margin_r: str
    margin_v: str
    effect_field: str
    text: str

    def __post_init__(self) -> None:
        if self.end_ms <= self.start_ms:
            raise EffectError('Dialogue end time must be after start time')

    @property
    def duration_ms(self) -> int:
        return self.end_ms - self.start_ms

    def format(self) -> str:
        return f'Dialogue: {self.layer},{_format_time(self.start_ms)},{_format_time(self.end_ms)},{self.style},{self.name},{self.margin_l},{self.margin_r},{self.margin_v},{self.effect_field},{self.text}'

@dataclass(frozen=True)
class Glyph:
    text: str
    index: int
    count: int
    x: float
    y: float
    width: float
    order_ltr: float
    centre_distance: float
    is_space: bool = False

@dataclass(frozen=True)
class MotionState:
    x: float
    y: float
    scale_x: float = 100.0
    scale_y: float = 100.0
    rotation_z: float = 0.0
    rotation_x: float = 0.0
    rotation_y: float = 0.0
    shear_x: float = 0.0
    shear_y: float = 0.0
    alpha: int = 0
    primary_color: str | None = None
    outline_color: str | None = None
    border: float | None = None
    blur: float | None = None
    shadow: float | None = None

def _parse_time(value: str) -> int:
    match = _TIME_RE.fullmatch(value)
    if not match:
        raise EffectError(f'invalid ASS timestamp: {value!r}')
    hours, minutes, seconds = map(int, match.group(1, 2, 3))
    fraction = match.group(4) or ''
    millis = int((fraction + '000')[:3])
    return ((hours * 60 + minutes) * 60 + seconds) * 1000 + millis

def _format_time(milliseconds: int) -> str:
    if milliseconds < 0:
        raise EffectError('ASS timestamp cannot be negative')
    centiseconds = (milliseconds + 5) // 10
    hours, remainder = divmod(centiseconds, 360000)
    minutes, remainder = divmod(remainder, 6000)
    seconds, centis = divmod(remainder, 100)
    return f'{hours}:{minutes:02d}:{seconds:02d}.{centis:02d}'

def parse_dialogue(line: str) -> DialogueEvent:
    """Parse one ASS v4+ ``Dialogue:`` line."""
    if '\n' in line or '\r' in line:
        raise EffectError('exactly one Dialogue line is required')
    match = _DIALOGUE_RE.fullmatch(line)
    if not match:
        raise EffectError("input must begin with 'Dialogue:'")
    fields = match.group(1).split(',', 9)
    if len(fields) != 10:
        raise EffectError('Dialogue line must contain 10 ASS fields; text may contain commas')
    try:
        layer = int(fields[0].strip())
    except ValueError as exc:
        raise EffectError(f'invalid Dialogue layer: {fields[0]!r}') from exc
    return DialogueEvent(layer=layer, start_ms=_parse_time(fields[1]), end_ms=_parse_time(fields[2]), style=fields[3].strip(), name=fields[4], margin_l=fields[5].strip(), margin_r=fields[6].strip(), margin_v=fields[7].strip(), effect_field=fields[8], text=fields[9])

def _coerce_effect(value: Effect | str | int) -> Effect:
    if isinstance(value, Effect):
        return value
    effects = list(Effect)
    if isinstance(value, int):
        if 1 <= value <= len(effects):
            return effects[value - 1]
        raise EffectParameterError('numeric effect must be in the range 1..36')
    candidate = str(value).strip()
    if candidate.isdecimal():
        return _coerce_effect(int(candidate))
    normalized = candidate.lower().replace('-', '_').replace(' ', '_')
    aliases: dict[str, Effect] = {effect.value: effect for effect in Effect}
    for effect, spec in EFFECT_SPECS.items():
        aliases[spec.name_en.lower().replace('-', '_').replace(' ', '_')] = effect
        aliases[spec.name_ja] = effect
    try:
        if normalized in aliases:
            return aliases[normalized]
        return aliases[candidate]
    except KeyError as exc:
        choices = ', '.join((effect.value for effect in Effect))
        raise EffectParameterError(f'unknown effect {value!r}; choose 1..36 or one of: {choices}') from exc

def _coerce_params(params: Mapping[str, Any] | None) -> dict[str, Any]:
    if params is None:
        return {}
    if not isinstance(params, Mapping):
        raise EffectParameterError('params must be a mapping or None')
    result = dict(params)
    forbidden = {'start_direction', 'end_direction', 'in_direction', 'out_direction', 'enter_direction', 'exit_direction'}
    used_forbidden = forbidden.intersection(result)
    if used_forbidden:
        names = ', '.join(sorted(used_forbidden))
        raise EffectParameterError(f"separate start/end directions are not supported: {names}; use the single 'direction' parameter")
    return result

def _validate_param_names(params: Mapping[str, Any], allowed: set[str]) -> None:
    unknown = set(params) - allowed
    if unknown:
        raise EffectParameterError('unsupported parameter(s): ' + ', '.join(sorted(unknown)))

def _number(params: Mapping[str, Any], name: str, default: float, *, minimum: float, maximum: float) -> float:
    value = params.get(name, default)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise EffectParameterError(f'{name} must be a number')
    value = float(value)
    if not math.isfinite(value) or not minimum <= value <= maximum:
        raise EffectParameterError(f'{name} must be between {minimum:g} and {maximum:g}')
    return value

def _integer(params: Mapping[str, Any], name: str, default: int, *, minimum: int, maximum: int) -> int:
    value = params.get(name, default)
    if isinstance(value, bool) or not isinstance(value, int):
        raise EffectParameterError(f'{name} must be an integer')
    if not minimum <= value <= maximum:
        raise EffectParameterError(f'{name} must be between {minimum} and {maximum}')
    return value

def _string(params: Mapping[str, Any], name: str, default: str) -> str:
    value = params.get(name, default)
    if not isinstance(value, str) or not value:
        raise EffectParameterError(f'{name} must be a non-empty string')
    return value

def _direction(params: Mapping[str, Any], allowed: Sequence[Direction], default: Direction) -> Direction:
    raw = params.get('direction', default)
    try:
        direction = raw if isinstance(raw, Direction) else Direction(str(raw))
    except ValueError as exc:
        names = ', '.join((item.value for item in allowed))
        raise EffectParameterError(f'direction must be one of: {names}') from exc
    if direction not in allowed:
        names = ', '.join((item.value for item in allowed))
        raise EffectParameterError(f'direction must be one of: {names}')
    return direction

def _phase(params: Mapping[str, Any], allowed: Sequence[Phase], default: Phase) -> Phase:
    raw = params.get('phase', default)
    try:
        phase = raw if isinstance(raw, Phase) else Phase(str(raw))
    except ValueError as exc:
        names = ', '.join((item.value for item in allowed))
        raise EffectParameterError(f'phase must be one of: {names}') from exc
    if phase not in allowed:
        names = ', '.join((item.value for item in allowed))
        raise EffectParameterError(f'phase must be one of: {names}')
    return phase

def _ass_color(value: Any, name: str='color') -> str:
    text = str(value)
    if not re.fullmatch('&H[0-9A-Fa-f]{6}&', text):
        raise EffectParameterError(f"{name} must be an ASS BGR value such as '&H4FD8FF&'")
    return text.upper()

def _palette(params: Mapping[str, Any], name: str, default: Sequence[str], *, minimum: int=2, maximum: int=12) -> tuple[str, ...]:
    raw = params.get(name, default)
    if isinstance(raw, str) or not isinstance(raw, Sequence):
        raise EffectParameterError(f'{name} must be a sequence of ASS colours')
    values = tuple((_ass_color(item, name) for item in raw))
    if not minimum <= len(values) <= maximum:
        raise EffectParameterError(f'{name} must contain between {minimum} and {maximum} colours')
    return values

def _fmt(value: float) -> str:
    if abs(value) < 0.0005:
        value = 0.0
    return f'{value:.3f}'.rstrip('0').rstrip('.')

def _clamp(value: float, low: float=0.0, high: float=1.0) -> float:
    return low if value < low else high if value > high else value

def _smooth(value: float) -> float:
    value = _clamp(value)
    return value * value * (3.0 - 2.0 * value)

def _ease_out_back(value: float, overshoot: float=1.70158) -> float:
    value = _clamp(value) - 1.0
    return 1.0 + (overshoot + 1.0) * value ** 3 + overshoot * value ** 2

def _pulse(value: float, power: float=2.0) -> float:
    return max(0.0, math.sin(math.pi * _clamp(value))) ** power

def _fractional(value: float) -> float:
    return value - math.floor(value)

def _add_tags(text: str, tags: str) -> str:
    if not tags:
        return text
    match = _LEADING_OVERRIDE_RE.match(text)
    if match:
        return '{' + match.group(1) + tags + '}' + text[match.end():]
    return '{' + tags + '}' + text

def _remove_position_tags(text: str) -> str:

    def clean(match: re.Match[str]) -> str:
        body = re.sub('\\\\(?:pos|move|org)\\([^)]*\\)', '', match.group(0))
        return '' if body == '{}' else body
    return _OVERRIDE_RE.sub(clean, text)

def _event_anchor(event: DialogueEvent, context: EffectContext) -> tuple[int, int]:
    match = _POS_RE.search(event.text)
    if match:
        return (round(float(match.group(1))), round(float(match.group(2))))
    return context.anchor

def _clone(event: DialogueEvent, *, start_ms: int | None=None, end_ms: int | None=None, text: str | None=None, layer: int | None=None, effect_field: str | None=None) -> DialogueEvent:
    return replace(event, start_ms=event.start_ms if start_ms is None else start_ms, end_ms=event.end_ms if end_ms is None else end_ms, text=event.text if text is None else text, layer=event.layer if layer is None else layer, effect_field=event.effect_field if effect_field is None else effect_field)

def _runtime_split_graphemes(text: str) -> tuple[str, ...]:
    """Resolve the canonical renderer's grapheme splitter at call time.

    Natural36 is vendored as an internal engine, but the host package owns
    the Unicode shaping policy.  Importing lazily avoids a module cycle when
    the host registry imports this engine and, importantly, means tests and
    future renderer fixes are observed without copying the implementation.
    """

    from . import core as current_core

    return current_core.split_graphemes(text)


def _split_text(text: str, *, purpose: str) -> tuple[str, list[str]]:
    leading = ''
    match = _LEADING_OVERRIDE_RE.match(text)
    payload = text
    if match:
        leading = match.group(0)
        payload = text[match.end():]
    if _OVERRIDE_RE.search(payload):
        raise EffectError(f'{purpose} does not support inline override blocks; move static tags to the leading override block')
    if _DRAWING_RE.search(leading):
        raise EffectError(f'{purpose} cannot process ASS vector drawings')
    tokens: list[str] = []
    index = 0
    plain_start = 0
    while index < len(payload):
        if payload[index] != '\\' or index + 1 >= len(payload):
            index += 1
            continue

        # Flush the plain span through the host's UAX #29 splitter before
        # handling ASS's non-breaking-space escape as a dedicated token.
        if plain_start < index:
            tokens.extend(_runtime_split_graphemes(payload[plain_start:index]))
        code = payload[index + 1]
        if code in {'N', 'n'}:
            raise EffectError(f'{purpose} supports one visual line only')
        if code == 'h':
            tokens.append(payload[index:index + 2])
            index += 2
            plain_start = index
            continue

        # Unknown backslash escapes are retained as ordinary text.  Keep the
        # slash in the next plain span so no source characters are lost.
        index += 1
        plain_start = index - 1
    if plain_start < len(payload):
        tokens.extend(_runtime_split_graphemes(payload[plain_start:]))
    if not tokens:
        raise EffectError('Dialogue text must contain visible text')
    return (leading, tokens)

def _glyph_weight(token: str) -> float:
    if token == '\\h' or token.isspace():
        return 0.52
    char = token[0]
    width = unicodedata.east_asian_width(char)
    if width in {'W', 'F'}:
        return 1.0
    category = unicodedata.category(char)
    if category.startswith('P'):
        return 0.48
    if category.startswith('M'):
        return 0.2
    if char.isdigit():
        return 0.62
    return 0.66

def _layout_glyphs(event: DialogueEvent, context: EffectContext) -> tuple[str, list[Glyph]]:
    leading, tokens = _split_text(event.text, purpose='character choreography')
    leading = _remove_position_tags(leading)
    weights = list(context.glyph_widths or tuple((_glyph_weight(token) for token in tokens)))
    if len(weights) != len(tokens):
        raise EffectParameterError(f'glyph_widths length must equal the visible grapheme count ({len(tokens)})')
    total = sum(weights)
    if total <= 0:
        raise EffectParameterError('glyph widths must have a positive total')
    box = context.box
    anchor_x, anchor_y = _event_anchor(event, context)
    x1 = anchor_x - box.width / 2
    unit = box.width / total
    cursor = x1
    count = len(tokens)
    glyphs: list[Glyph] = []
    for index, (token, weight) in enumerate(zip(tokens, weights, strict=True)):
        width = unit * weight
        x = cursor + width / 2
        order = 0.5 if count == 1 else index / (count - 1)
        centre_distance = 0.0 if count == 1 else abs(index - (count - 1) / 2) / ((count - 1) / 2)
        glyphs.append(Glyph(text=token, index=index, count=count, x=x, y=anchor_y, width=width, order_ltr=order, centre_distance=centre_distance, is_space=token == '\\h' or token.isspace()))
        cursor += width
    return (leading, glyphs)

def _sample_times(duration_ms: int, step_ms: int) -> list[int]:
    if duration_ms <= 0:
        return [0]
    points = list(range(0, duration_ms, step_ms))
    if not points or points[-1] != duration_ms:
        points.append(duration_ms)
    return points

def _order(glyph: Glyph, direction: Direction) -> float:
    if direction is Direction.LEFT_TO_RIGHT:
        return glyph.order_ltr
    if direction is Direction.RIGHT_TO_LEFT:
        return 1.0 - glyph.order_ltr
    if direction is Direction.CENTER_OUT:
        return glyph.centre_distance
    if direction is Direction.EDGES_IN:
        return 1.0 - glyph.centre_distance
    return glyph.order_ltr

def _stagger_entry(t_ms: float, span_ms: int, order: float, stagger: float) -> float:
    if span_ms <= 0:
        return 1.0
    delay = span_ms * _clamp(stagger, 0.0, 0.95) * _clamp(order)
    active = max(1.0, span_ms - span_ms * _clamp(stagger, 0.0, 0.95))
    return _smooth((t_ms - delay) / active)

def _stagger_exit(t_ms: float, duration_ms: int, span_ms: int, order: float, stagger: float) -> float:
    if span_ms <= 0:
        return 0.0
    local = t_ms - (duration_ms - span_ms)
    delay = span_ms * _clamp(stagger, 0.0, 0.95) * _clamp(order)
    active = max(1.0, span_ms - span_ms * _clamp(stagger, 0.0, 0.95))
    return _smooth((local - delay) / active)

def _presence(t_ms: float, duration_ms: int, start_ms: int, end_ms: int, *, order: float=0.0, stagger: float=0.0) -> tuple[float, float, float]:
    entry = _stagger_entry(t_ms, start_ms, order, stagger)
    exit_progress = _stagger_exit(t_ms, duration_ms, end_ms, order, stagger)
    visible = _clamp(min(entry, 1.0 - exit_progress))
    return (entry, exit_progress, visible)

def _alpha_from_presence(value: float, *, floor: int=0) -> int:
    return round(_clamp(1.0 - value) * (255 - floor) + floor)

def _seed_value(seed: int, index: int, lane: int=0) -> float:
    rng = random.Random(seed * 1000003 + index * 9973 + lane * 7919)
    return rng.random()

def _direction_vector(direction: Direction) -> tuple[float, float]:
    if direction is Direction.LEFT_TO_RIGHT:
        return (1.0, 0.0)
    if direction is Direction.RIGHT_TO_LEFT:
        return (-1.0, 0.0)
    if direction is Direction.TOP_TO_BOTTOM:
        return (0.0, 1.0)
    if direction is Direction.BOTTOM_TO_TOP:
        return (0.0, -1.0)
    raise EffectParameterError(f'{direction.value} is not a cardinal direction')

def _format_alpha(alpha: int) -> str:
    return f'&H{max(0, min(255, int(alpha))):02X}&'

def _state_static_tags(state: MotionState) -> str:
    tags = f'\\fscx{_fmt(state.scale_x)}\\fscy{_fmt(state.scale_y)}\\frz{_fmt(state.rotation_z)}\\frx{_fmt(state.rotation_x)}\\fry{_fmt(state.rotation_y)}\\fax{_fmt(state.shear_x)}\\fay{_fmt(state.shear_y)}\\alpha{_format_alpha(state.alpha)}'
    if state.primary_color is not None:
        tags += f'\\1c{state.primary_color}'
    if state.outline_color is not None:
        tags += f'\\3c{state.outline_color}'
    if state.border is not None:
        tags += f'\\bord{_fmt(state.border)}'
    if state.blur is not None:
        tags += f'\\blur{_fmt(state.blur)}'
    if state.shadow is not None:
        tags += f'\\shad{_fmt(state.shadow)}'
    return tags

def _state_transition_tags(state: MotionState) -> str:
    return _state_static_tags(state)

def _animated_text(base_text: str, state0: MotionState, state1: MotionState, segment_ms: int, *, clip0: Rect | None=None, clip1: Rect | None=None, extra_tags: str='') -> str:
    tags = f'\\an5\\move({_fmt(state0.x)},{_fmt(state0.y)},{_fmt(state1.x)},{_fmt(state1.y)},0,{segment_ms})' + _state_static_tags(state0)
    if clip0 is not None:
        tags += f'\\clip({clip0.x1},{clip0.y1},{clip0.x2},{clip0.y2})'
    tags += extra_tags
    transition = _state_transition_tags(state1)
    if clip1 is not None:
        transition += f'\\clip({clip1.x1},{clip1.y1},{clip1.x2},{clip1.y2})'
    tags += f'\\t(0,{segment_ms},{transition})'
    return _add_tags(base_text, tags)
GlyphStateFunction = Callable[[Glyph, float, int], MotionState]
LineStateFunction = Callable[[float, int], MotionState]

def _emit_sampled_glyphs(event: DialogueEvent, context: EffectContext, state_fn: GlyphStateFunction, *, layer_offset: int=0, step_ms: int | None=None) -> list[DialogueEvent]:
    leading, glyphs = _layout_glyphs(event, context)
    points = _sample_times(event.duration_ms, step_ms or context.motion_step_ms)
    result: list[DialogueEvent] = []
    for first, second in zip(points, points[1:]):
        segment = second - first
        if segment <= 0:
            continue
        for glyph in glyphs:
            if glyph.is_space:
                continue
            state0 = state_fn(glyph, first / event.duration_ms, first)
            state1 = state_fn(glyph, second / event.duration_ms, second)
            if state0.alpha >= 255 and state1.alpha >= 255:
                continue
            text = _animated_text(leading + glyph.text, state0, state1, segment)
            result.append(_clone(event, start_ms=event.start_ms + first, end_ms=event.start_ms + second, text=text, layer=event.layer + layer_offset))
    return result

def _emit_sampled_line(event: DialogueEvent, context: EffectContext, state_fn: LineStateFunction, *, layer_offset: int=0, step_ms: int | None=None, clip_fn: Callable[[float, int], Rect | None] | None=None, extra_tags: str='') -> list[DialogueEvent]:
    points = _sample_times(event.duration_ms, step_ms or context.motion_step_ms)
    result: list[DialogueEvent] = []
    base_text = _remove_position_tags(event.text)
    for first, second in zip(points, points[1:]):
        segment = second - first
        if segment <= 0:
            continue
        state0 = state_fn(first / event.duration_ms, first)
        state1 = state_fn(second / event.duration_ms, second)
        if state0.alpha >= 255 and state1.alpha >= 255:
            continue
        clip0 = clip_fn(first / event.duration_ms, first) if clip_fn else None
        clip1 = clip_fn(second / event.duration_ms, second) if clip_fn else None
        text = _animated_text(base_text, state0, state1, segment, clip0=clip0, clip1=clip1, extra_tags=extra_tags)
        result.append(_clone(event, start_ms=event.start_ms + first, end_ms=event.start_ms + second, text=text, layer=event.layer + layer_offset))
    return result

def _static_line(event: DialogueEvent, context: EffectContext, *, layer_offset: int=0, alpha: int=0, color: str | None=None, border: float | None=None, blur: float | None=None, scale: float=100.0, extra_tags: str='') -> DialogueEvent:
    anchor_x, anchor_y = _event_anchor(event, context)
    state = MotionState(anchor_x, anchor_y, scale_x=scale, scale_y=scale, alpha=alpha, primary_color=color, border=border, blur=blur)
    tags = f'\\an5\\pos({_fmt(state.x)},{_fmt(state.y)})' + _state_static_tags(state) + extra_tags
    return _clone(event, layer=event.layer + layer_offset, text=_add_tags(_remove_position_tags(event.text), tags))

def _drawing_event(event: DialogueEvent, start_rel_ms: int, end_rel_ms: int, path: str, tags: str, *, layer_offset: int=0) -> DialogueEvent:
    if end_rel_ms <= start_rel_ms:
        raise EffectError('drawing event duration must be positive')
    text = '{' + tags + '\\p1}' + path + '{\\p0}'
    return _clone(event, start_ms=event.start_ms + start_rel_ms, end_ms=event.start_ms + end_rel_ms, text=text, layer=event.layer + layer_offset)

def _rect_path(rect: Rect) -> str:
    return f'm {rect.x1} {rect.y1} l {rect.x2} {rect.y1} {rect.x2} {rect.y2} {rect.x1} {rect.y2}'

def _line_rect(x1: float, y1: float, x2: float, y2: float, thickness: float) -> Rect:
    if abs(x2 - x1) >= abs(y2 - y1):
        top = round((y1 + y2) / 2 - thickness / 2)
        bottom = max(top + 1, round((y1 + y2) / 2 + thickness / 2))
        return Rect(round(min(x1, x2)), top, max(round(min(x1, x2)) + 1, round(max(x1, x2))), bottom)
    left = round((x1 + x2) / 2 - thickness / 2)
    right = max(left + 1, round((x1 + x2) / 2 + thickness / 2))
    return Rect(left, round(min(y1, y2)), right, max(round(min(y1, y2)) + 1, round(max(y1, y2))))

def _parse_color_components(color: str) -> tuple[int, int, int]:
    color = _ass_color(color)
    b = int(color[2:4], 16)
    g = int(color[4:6], 16)
    r = int(color[6:8], 16)
    return (r, g, b)

def _format_color_components(rgb: tuple[float, float, float]) -> str:
    r, g, b = (max(0, min(255, round(value))) for value in rgb)
    return f'&H{b:02X}{g:02X}{r:02X}&'

def _lerp_color(first: str, second: str, amount: float) -> str:
    amount = _clamp(amount)
    a = _parse_color_components(first)
    b = _parse_color_components(second)
    return _format_color_components(tuple((x + (y - x) * amount for x, y in zip(a, b, strict=True))))

def _palette_color(colors: Sequence[str], position: float) -> str:
    position = _fractional(position) * len(colors)
    index = int(math.floor(position)) % len(colors)
    next_index = (index + 1) % len(colors)
    return _lerp_color(colors[index], colors[next_index], position - math.floor(position))

def _presence_for_line(t_ms: int, duration: int, start: int, end: int) -> float:
    entry = 1.0 if start <= 0 else _smooth(t_ms / start)
    exit_keep = 1.0 if end <= 0 else 1.0 - _smooth((t_ms - (duration - end)) / end)
    return _clamp(min(entry, exit_keep))

def _scene_box(context: EffectContext) -> Rect:
    """Return the strictly local phenomenon region around the lyric.

    Version 3 keeps the phenomenon close enough to read as a lyric accent,
    rather than a miniature environmental scene.  Padding is intentionally
    smaller than version 2 and scales mainly from the rendered lyric height.
    """
    box = context.box
    pad_x = max(34, min(96, round(box.height * 0.58), round(box.width * 0.09)))
    pad_y_top = max(40, min(88, round(box.height * 0.58)))
    pad_y_bottom = max(44, min(96, round(box.height * 0.66)))
    return Rect(max(0, box.x1 - pad_x), max(0, box.y1 - pad_y_top), min(context.play_res_x, box.x2 + pad_x), min(context.play_res_y, box.y2 + pad_y_bottom))

def _scene_fade(event: DialogueEvent, start: int, end: int) -> str:
    return f'\\fade(255,0,255,0,{start},{event.duration_ms - end},{event.duration_ms})'

def _clip_tag(rect: Rect | None) -> str:
    if rect is None:
        return ''
    return f'\\clip({rect.x1},{rect.y1},{rect.x2},{rect.y2})'

def _themed_text(event: DialogueEvent, start: int, end: int, context: EffectContext, *, primary: str='&HFFFFFF&', outline: str='&H332640&', glow: str='&HFFD27A&', glow_alpha: int=88, border: float=4.0, float_y: float=0.0, whole_shift_x: float=0.0, extra_crisp: str='') -> list[DialogueEvent]:
    """Create a readable glow layer and a crisp lyric layer."""
    primary = _ass_color(primary, 'primary')
    outline = _ass_color(outline, 'outline')
    glow = _ass_color(glow, 'glow')
    x, y = _event_anchor(event, context)
    fade = _scene_fade(event, start, end)
    base = _remove_position_tags(event.text)
    if whole_shift_x or float_y:
        move = f'\\move({_fmt(x - whole_shift_x)},{_fmt(y - float_y)},{_fmt(x + whole_shift_x)},{_fmt(y + float_y)},0,{event.duration_ms})'
        position = f'\\an5{move}'
    else:
        position = f'\\an5\\pos({_fmt(x)},{_fmt(y)})'
    glow_tags = position + f'\\1c{glow}\\1a&HFF&\\3c{glow}\\3a{_format_alpha(glow_alpha)}' + f'\\bord{_fmt(max(7.0, border * 2.4))}\\blur{_fmt(max(7.0, border * 2.2))}\\shad0' + fade
    crisp_tags = position + f'\\1c{primary}\\3c{outline}\\bord{_fmt(border)}\\blur0.65\\shad1' + fade + extra_crisp
    return [_clone(event, layer=event.layer + 5, text=_add_tags(base, glow_tags)), _clone(event, layer=event.layer + 8, text=_add_tags(base, crisp_tags))]

def _ellipse_path(rx: int, ry: int) -> str:
    rx = max(1, int(rx))
    ry = max(1, int(ry))
    kx = round(rx * 0.5522848)
    ky = round(ry * 0.5522848)
    return f'm {-rx} 0 b {-rx} {-ky} {-kx} {-ry} 0 {-ry} b {kx} {-ry} {rx} {-ky} {rx} 0 b {rx} {ky} {kx} {ry} 0 {ry} b {-kx} {ry} {-rx} {ky} {-rx} 0'

def _arc_path(rx: float, ry: float, *, start_angle: float=math.pi, end_angle: float=2.0 * math.pi, samples: int=48) -> str:
    """Return an open local-coordinate elliptical arc suitable for a border-only drawing."""
    if samples < 4:
        raise EffectError('arc requires at least four samples')
    points = [(math.cos(start_angle + (end_angle - start_angle) * index / samples) * rx, math.sin(start_angle + (end_angle - start_angle) * index / samples) * ry) for index in range(samples + 1)]
    return _polyline_path(points)

def _breaking_curl_path(width: float, height: float, direction_sign: float) -> str:
    """Return an open cubic breaker crest, mirrored for travel direction."""
    sign = 1.0 if direction_sign >= 0 else -1.0
    points = ((-0.52, 0.38), (-0.46, -0.1), (-0.26, -0.58), (0.16, -0.54), (0.48, -0.5), (0.58, -0.13), (0.36, 0.06), (0.2, 0.2), (-0.03, 0.1), (0.06, -0.12))
    scaled = [(sign * x * width, y * height) for x, y in points]
    first = scaled[0]
    controls = scaled[1:]
    return f'm {round(first[0])} {round(first[1])} ' + ' '.join(('b ' + ' '.join((f'{round(x)} {round(y)}' for x, y in controls[index:index + 3])) for index in range(0, len(controls), 3)))

def _ellipse_path_at(cx: float, cy: float, rx: int, ry: int) -> str:
    kx = round(rx * 0.5522848)
    ky = round(ry * 0.5522848)
    x = round(cx)
    y = round(cy)
    return f'm {x - rx} {y} b {x - rx} {y - ky} {x - kx} {y - ry} {x} {y - ry} b {x + kx} {y - ry} {x + rx} {y - ky} {x + rx} {y} b {x + rx} {y + ky} {x + kx} {y + ry} {x} {y + ry} b {x - kx} {y + ry} {x - rx} {y + ky} {x - rx} {y}'

def _star_path(outer: int=10, inner: int=4, points: int=4) -> str:
    coords: list[tuple[int, int]] = []
    for index in range(points * 2):
        radius = outer if index % 2 == 0 else inner
        angle = -math.pi / 2 + index * math.pi / points
        coords.append((round(radius * math.cos(angle)), round(radius * math.sin(angle))))
    return 'm ' + f'{coords[0][0]} {coords[0][1]} l ' + ' '.join((f'{x} {y}' for x, y in coords[1:]))

def _snowflake_path(radius: int=12) -> str:
    r = max(4, radius)
    d = round(r * 0.72)
    return f'm {-r} 0 l {r} 0 m 0 {-r} l 0 {r} m {-d} {-d} l {d} {d} m {-d} {d} l {d} {-d}'

def _cloud_path(width: int=130, height: int=54) -> str:
    w = max(40, width)
    h = max(18, height)
    return f'm {-w // 2} {h // 3} b {-w // 2 - 8} {-h // 7} {-w // 3} {-h // 2} {-w // 7} {-h // 4} b {-w // 10} {-h} {w // 4} {-h} {w // 3} {-h // 4} b {w // 2} {-h // 3} {w // 2 + 12} {h // 7} {w // 2} {h // 3} l {-w // 2} {h // 3}'

def _droplet_path(width: int=8, height: int=18) -> str:
    w = max(2, width)
    h = max(5, height)
    return f'm 0 {-h} b {w} {-h // 3} {w} {h // 2} 0 {h} b {-w} {h // 2} {-w} {-h // 3} 0 {-h}'

def _petal_path(width: int=12, height: int=20) -> str:
    w = max(3, width)
    h = max(5, height)
    return f'm 0 {-h} b {w} {-h // 2} {w} {h // 2} 0 {h} b {-w} {h // 2} {-w} {-h // 2} 0 {-h}'

def _leaf_path(width: int=13, height: int=24) -> str:
    w = max(3, width)
    h = max(6, height)
    return f'm 0 {-h} b {w} {-h // 2} {w} {h // 2} 0 {h} b {-w} {h // 2} {-w} {-h // 2} 0 {-h} m 0 {-h + 2} l 0 {h - 2}'

def _seed_path(size: int=12) -> str:
    s = max(4, size)
    return f'm 0 0 l {s // 3} {s} m 0 0 l {-s} {-s // 3} m 0 0 l {-s // 2} {-s} m 0 0 l {s} {-s // 2}'

def _splash_path(size: int=15) -> str:
    s = max(5, size)
    return f'm {-s} {s // 2} l {-s // 2} 0 {-s // 3} {-s} 0 {-s // 3} {s // 3} {-s} {s // 2} 0 {s} {s // 2} {s // 2} {s // 3} 0 {s // 2} {-s // 2} {s // 3}'

def _flame_path(width: int=10, height: int=20) -> str:
    w = max(3, width)
    h = max(6, height)
    return f'm 0 {-h} b {w // 2} {-h // 2} {w} {-h // 4} {w // 2} {h // 3} b {w // 3} {h} {-w // 2} {h} {-w} {h // 3} b {-w // 2} 0 {-w // 3} {-h // 3} 0 {-h}'

def _diamond_path(width: int=8, height: int=13) -> str:
    return f'm 0 {-height} l {width} 0 0 {height} {-width} 0'

def _triangle_path(width: int=12, height: int=28) -> str:
    return f'm {-width} {-height // 2} l {width} {-height // 2} 0 {height}'

def _polyline_path(points: Sequence[tuple[float, float]]) -> str:
    if len(points) < 2:
        raise EffectError('polyline requires at least two points')
    first = points[0]
    return 'm ' + f'{round(first[0])} {round(first[1])} l ' + ' '.join((f'{round(x)} {round(y)}' for x, y in points[1:]))

def _polygon_path(points: Sequence[tuple[float, float]]) -> str:
    if len(points) < 3:
        raise EffectError('polygon requires at least three points')
    return _polyline_path(tuple(points) + (points[0],))

def _wave_polygon(x1: int, x2: int, baseline: float, bottom: float, amplitude: float, wavelength: float, phase: float, *, samples: int=36) -> str:
    points: list[tuple[float, float]] = []
    for index in range(samples + 1):
        x = x1 + (x2 - x1) * index / samples
        y = baseline + amplitude * math.sin(2 * math.pi * ((x - x1) / wavelength + phase))
        points.append((x, y))
    points.extend(((x2, bottom), (x1, bottom)))
    return _polygon_path(points)

def _wavy_line(x1: int, x2: int, baseline: float, amplitude: float, wavelength: float, phase: float, *, samples: int=34) -> str:
    return _polyline_path([(x1 + (x2 - x1) * index / samples, baseline + amplitude * math.sin(2 * math.pi * ((x2 - x1) * index / samples / wavelength + phase))) for index in range(samples + 1)])

def _vertical_ribbon_path(width: float, height: float, wobble: float, phase: float, *, samples: int=14) -> str:
    """Return a closed local-coordinate ribbon with independently wavering edges."""
    left: list[tuple[float, float]] = []
    right: list[tuple[float, float]] = []
    for index in range(samples + 1):
        t = index / samples
        y = -height / 2 + height * t
        centre = wobble * math.sin(2 * math.pi * (1.25 * t + phase))
        pinch = 0.12 * width * math.sin(2 * math.pi * (2.1 * t + phase * 0.7))
        left.append((centre - width / 2 + pinch, y))
        right.append((centre + width / 2 - pinch, y))
    return _polygon_path(tuple(left) + tuple(reversed(right)))

def _moving_shape(event: DialogueEvent, begin: int, finish: int, path: str, *, x0: float, y0: float, x1: float, y1: float, color: str, alpha: int=0, scale0: float=100.0, scale1: float | None=None, rotation0: float=0.0, rotation1: float | None=None, blur: float=0.0, border: float=0.0, outline: str | None=None, fill: bool=True, fade_in: int | None=None, fade_out: int | None=None, clip: Rect | None=None, layer_offset: int=1, extra_tags: str='') -> DialogueEvent:
    duration = finish - begin
    if duration <= 0:
        raise EffectError('moving shape duration must be positive')
    color = _ass_color(color)
    outline_color = _ass_color(outline or color)
    scale1 = scale0 if scale1 is None else scale1
    rotation1 = rotation0 if rotation1 is None else rotation1
    if fade_in is None:
        fade_in = min(100, max(0, duration // 5))
    if fade_out is None:
        fade_out = min(180, max(0, duration // 4))
    fill_tags = f'\\1c{color}\\1a{_format_alpha(alpha)}' if fill else '\\1a&HFF&'
    outline_alpha = alpha if fill or alpha != 255 else 0
    tags = f'\\an5\\move({_fmt(x0)},{_fmt(y0)},{_fmt(x1)},{_fmt(y1)},0,{duration})' + fill_tags + f'\\3c{outline_color}\\3a{_format_alpha(outline_alpha)}\\bord{_fmt(border)}' + f'\\blur{_fmt(blur)}\\fscx{_fmt(scale0)}\\fscy{_fmt(scale0)}\\frz{_fmt(rotation0)}' + _clip_tag(clip) + f'\\fad({fade_in},{fade_out})' + extra_tags
    transition = f'\\fscx{_fmt(scale1)}\\fscy{_fmt(scale1)}\\frz{_fmt(rotation1)}'
    if scale1 != scale0 or rotation1 != rotation0:
        tags += f'\\t(0,{duration},{transition})'
    return _drawing_event(event, begin, finish, path, tags, layer_offset=layer_offset)

def _static_drawing(event: DialogueEvent, path: str, *, color: str, alpha: int, blur: float=0.0, border: float=0.0, outline: str | None=None, fill: bool=True, clip: Rect | None=None, layer_offset: int=0, start: int=0, end: int | None=None, extra_tags: str='') -> DialogueEvent:
    finish = event.duration_ms if end is None else end
    color = _ass_color(color)
    outline_color = _ass_color(outline or color)
    fill_tags = f'\\1c{color}\\1a{_format_alpha(alpha)}' if fill else '\\1a&HFF&'
    outline_alpha = alpha if fill or alpha != 255 else 0
    tags = '\\an7\\pos(0,0)' + fill_tags + f'\\3c{outline_color}\\3a{_format_alpha(outline_alpha)}\\bord{_fmt(border)}\\blur{_fmt(blur)}' + _clip_tag(clip) + extra_tags
    return _drawing_event(event, start, finish, path, tags, layer_offset=layer_offset)

def _pulse_ring(event: DialogueEvent, begin: int, duration: int, *, x: float, y: float, rx: int, ry: int, color: str, border: float=2.0, scale0: float=25.0, scale1: float=170.0, alpha0: int=35, clip: Rect | None=None, layer_offset: int=3) -> DialogueEvent | None:
    finish = min(event.duration_ms, begin + duration)
    if finish - begin < 30:
        return None
    local = finish - begin
    tags = f'\\an5\\pos({_fmt(x)},{_fmt(y)})\\1a&HFF&\\3c{_ass_color(color)}' + f'\\3a{_format_alpha(alpha0)}\\bord{_fmt(border)}\\blur1.2' + f'\\fscx{_fmt(scale0)}\\fscy{_fmt(scale0)}' + _clip_tag(clip) + f'\\t(0,{local},\\fscx{_fmt(scale1)}\\fscy{_fmt(scale1)}\\3a&HFF&)'
    return _drawing_event(event, begin, finish, _ellipse_path(rx, ry), tags, layer_offset=layer_offset)

def _add_wash(result: list[DialogueEvent], event: DialogueEvent, start: int, end: int, context: EffectContext, colors: Sequence[str], alphas: Sequence[int], *, layer_offset: int=0) -> None:
    """Add soft local auras instead of rectangular scene-wide colour bands."""
    scene = _scene_box(context)
    if len(colors) != len(alphas):
        raise EffectError('wash colors and alphas must have the same length')
    cx, cy = context.box.center
    fade = _scene_fade(event, start, end)
    count = max(1, len(colors))
    for index, (color, alpha) in enumerate(zip(colors, alphas, strict=True)):
        shrink = 1.0 - index * 0.13 / count
        rx = max(24, round(scene.width * 0.47 * shrink))
        ry = max(18, round(scene.height * (0.39 - index * 0.045 / count)))
        offset_y = (index - (count - 1) / 2) * scene.height * 0.08
        path = _ellipse_path_at(cx, cy + offset_y, rx, ry)
        result.append(_static_drawing(event, path, color=color, alpha=min(235, alpha + 34), blur=16 + index * 2, clip=scene, layer_offset=layer_offset, extra_tags=fade))

def _add_clouds(result: list[DialogueEvent], event: DialogueEvent, context: EffectContext, *, count: int, seed: int, direction: Direction, color: str, alpha: int, y_min: float, y_max: float, drift: float, layer_offset: int, blur: float=6.0, scale_min: float=75.0, scale_max: float=150.0) -> None:
    scene = _scene_box(context)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    path = _cloud_path()
    for index in range(count):
        x = scene.x1 + _seed_value(seed, index) * scene.width
        y = y_min + _seed_value(seed, index, 1) * max(1.0, y_max - y_min)
        scale = scale_min + _seed_value(seed, index, 2) * (scale_max - scale_min)
        result.append(_moving_shape(event, 0, event.duration_ms, path, x0=x - sign * drift / 2, y0=y, x1=x + sign * drift / 2, y1=y + (_seed_value(seed, index, 3) - 0.5) * 16, color=color, alpha=alpha, scale0=scale, scale1=scale * (0.96 + _seed_value(seed, index, 4) * 0.08), blur=blur, clip=scene, layer_offset=layer_offset, fade_in=220, fade_out=260))

def _iter_particle_passes(duration_ms: int, *, count: int, travel_ms: float, seed: int) -> Sequence[tuple[int, int, int, float, float, float]]:
    """Yield clipped repeated passes as (index, begin, finish, f0, f1, speed_scale)."""
    passes: list[tuple[int, int, int, float, float, float]] = []
    for index in range(count):
        speed_scale = 0.72 + _seed_value(seed, index, 7) * 0.58
        travel = max(120.0, travel_ms * speed_scale)
        phase = _seed_value(seed, index, 8)
        raw = -phase * travel
        while raw < duration_ms:
            raw_end = raw + travel
            begin = max(0, round(raw))
            finish = min(duration_ms, round(raw_end))
            if finish - begin >= 35:
                f0 = _clamp((begin - raw) / travel)
                f1 = _clamp((finish - raw) / travel)
                passes.append((index, begin, finish, f0, f1, speed_scale))
            raw += travel
    return passes

def _branching_bolt_points(x: float, y: float, length: float, spread: float, *, seed: int, direction_sign: float, segments: int=8) -> list[tuple[float, float]]:
    points = [(x, y)]
    px, py = (x, y)
    for index in range(1, segments + 1):
        py = y + length * index / segments
        lateral = (_seed_value(seed, index, 1) - 0.5) * spread / segments * 2.2 + direction_sign * spread * 0.065
        px += lateral
        points.append((px, py))
    return points

def _orbit_position(cx: float, cy: float, radius_x: float, radius_y: float, angle: float) -> tuple[float, float]:
    return (cx + radius_x * math.cos(angle), cy + radius_y * math.sin(angle))

def _effect_rain_veil(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'density', 'speed', 'slant', 'ripples', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    density = _integer(params, 'density', 56, minimum=12, maximum=120)
    speed = _number(params, 'speed', 820, minimum=250, maximum=2200)
    slant = _number(params, 'slant', 70, minimum=0, maximum=260)
    ripples = _integer(params, 'ripples', 12, minimum=3, maximum=30)
    seed = _integer(params, 'seed', 101, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H3C2A22&', '&H5A4030&', '&H2A1B16&'), (160, 170, 178))
    _add_clouds(result, event, context, count=5, seed=seed + 11, direction=direction, color='&H5C4B48&', alpha=72, y_min=scene.y1 + 22, y_max=scene.y1 + 100, drift=120, layer_offset=1, blur=10, scale_min=110, scale_max=190)
    puddle = _ellipse_path_at((box.x1 + box.x2) / 2, box.y2 + 112, round(box.width * 0.48), 48)
    result.append(_static_drawing(event, puddle, color='&H8B5635&', alpha=174, blur=10, clip=scene, layer_offset=1, extra_tags=_scene_fade(event, start, end)))
    result.append(_static_drawing(event, _arc_path(box.width * 0.48, 48, start_angle=0.1 * math.pi, end_angle=0.9 * math.pi), color='&HFFD7AD&', alpha=118, blur=3.2, border=2.6, outline='&HFFD7AD&', fill=False, clip=scene, layer_offset=4, extra_tags=f'\\an5\\pos({_fmt((box.x1 + box.x2) / 2)},{_fmt(box.y2 + 112)})' + _scene_fade(event, start, end)))
    runoff = _wavy_line(scene.x1 - 180, scene.x2 + 180, box.y2 + 108, 4.5, 230, 0.13, samples=96)
    result.append(_moving_absolute_drawing(event, 0, event.duration_ms, runoff, dx0=-sign * 70, dy0=0, dx1=sign * 70, dy1=0, color='&HFFE1BD&', alpha=138, blur=2.2, border=1.8, outline='&HFFE1BD&', fill=False, clip=scene, layer_offset=5, fade_in=260, fade_out=320))
    rain_path_far = 'm -1 -22 l 1 -22 1 22 -1 22'
    rain_path_near = 'm -2 -32 l 2 -32 2 32 -2 32'
    height = scene.height + 120
    travel_ms = height / speed * 1000.0
    for depth, count, path, alpha, scale, layer in ((0, round(density * 0.66), rain_path_far, 146, 72.0, 2), (1, max(4, density - round(density * 0.66)), rain_path_near, 74, 118.0, 7)):
        for index, begin, finish, f0, f1, speed_scale in _iter_particle_passes(event.duration_ms, count=count, travel_ms=travel_ms * (1.15 if depth == 0 else 0.78), seed=seed + depth * 1000):
            base_x = scene.x1 + _seed_value(seed + depth * 1000, index) * scene.width
            y_start = scene.y1 - 60
            y_end = scene.y2 + 60
            x_start = base_x - sign * slant * 0.5
            x_end = base_x + sign * slant * 0.5
            x0 = x_start + (x_end - x_start) * f0
            x1 = x_start + (x_end - x_start) * f1
            y0 = y_start + (y_end - y_start) * f0
            y1 = y_start + (y_end - y_start) * f1
            local_scale = scale * (0.78 + 0.4 * _seed_value(seed, index, depth + 3))
            result.append(_moving_shape(event, begin, finish, path, x0=x0, y0=y0, x1=x1, y1=y1, color='&HFFD7B0&', alpha=alpha, scale0=local_scale, blur=0.7 if depth == 0 else 1.4, rotation0=-sign * 9, clip=scene, layer_offset=layer, fade_in=35, fade_out=45))
    for index in range(ripples):
        begin = round((index + 0.35) * event.duration_ms / ripples)
        x = box.x1 + 28 + _seed_value(seed, index, 20) * max(1, box.width - 56)
        y = box.y2 + 90 + (_seed_value(seed, index, 21) - 0.5) * 30
        ring = _pulse_ring(event, begin, 620, x=x, y=y, rx=24, ry=7, color='&HFFD6A0&', border=2.2, scale0=35, scale1=190, alpha0=75, clip=scene, layer_offset=6)
        if ring is not None:
            result.append(ring)
        splash_finish = min(event.duration_ms, begin + 250)
        if splash_finish - begin > 30:
            result.append(_moving_shape(event, begin, splash_finish, _splash_path(12), x0=x, y0=y - 2, x1=x, y1=y - 18, color='&HFFF0D0&', alpha=45, scale0=70, scale1=115, blur=0.8, clip=scene, layer_offset=8, fade_in=10, fade_out=150))
            for side in (-1.0, 1.0):
                result.append(_moving_shape(event, begin, splash_finish, _ellipse_path(2, 4), x0=x + side * 2, y0=y - 4, x1=x + side * (12 + 8 * _seed_value(seed, index, 30 + int(side > 0))), y1=y - 26 - 10 * _seed_value(seed, index, 32 + int(side > 0)), color='&HFFF0D0&', alpha=72, scale0=65, scale1=90, rotation0=side * 18, blur=0.6, clip=scene, layer_offset=9, fade_in=5, fade_out=160))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFDF7&', outline='&H38271F&', glow='&HFFBD76&', glow_alpha=104, border=4.4))
    return result

def _effect_drizzle_mist(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'density', 'speed', 'mist_bands', 'beads', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    density = _integer(params, 'density', 54, minimum=16, maximum=140)
    speed = _number(params, 'speed', 420, minimum=120, maximum=1200)
    mist_bands = _integer(params, 'mist_bands', 5, minimum=2, maximum=10)
    beads = _integer(params, 'beads', 18, minimum=4, maximum=50)
    seed = _integer(params, 'seed', 211, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H68564C&', '&H746259&', '&H4C3E39&'), (184, 176, 188))
    cloud = _cloud_path(220, 52)
    for index in range(mist_bands):
        y = scene.y1 + scene.height * (0.2 + 0.62 * index / max(1, mist_bands - 1))
        x = scene.x1 + _seed_value(seed, index, 31) * scene.width
        scale = 180 + _seed_value(seed, index, 32) * 120
        result.append(_moving_shape(event, 0, event.duration_ms, cloud, x0=x - sign * 110, y0=y, x1=x + sign * 110, y1=y + (_seed_value(seed, index, 33) - 0.5) * 20, color='&HCCC1B8&', alpha=176 - index * 5, scale0=scale, scale1=scale * 1.04, blur=16 + index * 2, clip=scene, layer_offset=1 + index % 2, fade_in=260, fade_out=300))
    path = 'm -1 -9 l 1 -9 1 9 -1 9'
    travel_ms = (scene.height + 80) / speed * 1000
    for index, begin, finish, f0, f1, speed_scale in _iter_particle_passes(event.duration_ms, count=density, travel_ms=travel_ms, seed=seed + 100):
        base_x = scene.x1 + _seed_value(seed, index, 40) * scene.width
        y_start, y_end = (scene.y1 - 35, scene.y2 + 35)
        drift = sign * (24 + 32 * _seed_value(seed, index, 41))
        x0 = base_x - drift / 2 + drift * f0
        x1 = base_x - drift / 2 + drift * f1
        y0 = y_start + (y_end - y_start) * f0
        y1 = y_start + (y_end - y_start) * f1
        result.append(_moving_shape(event, begin, finish, path, x0=x0, y0=y0, x1=x1, y1=y1, color='&HFFF5E8&', alpha=162, scale0=55 + 35 * _seed_value(seed, index, 42), blur=0.8, rotation0=-sign * 7, clip=scene, layer_offset=5, fade_in=25, fade_out=35))
    bead_path = _ellipse_path(5, 7)
    for index in range(beads):
        side = -1 if index % 2 == 0 else 1
        x = (box.x1 - 22 if side < 0 else box.x2 + 22) + (_seed_value(seed, index, 51) - 0.5) * 34
        y = box.y1 + _seed_value(seed, index, 52) * box.height
        fall = 12 + 36 * _seed_value(seed, index, 53)
        result.append(_moving_shape(event, 0, event.duration_ms, bead_path, x0=x, y0=y, x1=x + sign * 5, y1=y + fall, color='&HFFF9F1&', alpha=112, scale0=55 + 45 * _seed_value(seed, index, 54), scale1=70 + 50 * _seed_value(seed, index, 55), blur=1.2, border=0.8, outline='&H9A8175&', clip=scene, layer_offset=7, fade_in=180, fade_out=220))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFDFB&', outline='&H51443F&', glow='&HD9D0C7&', glow_alpha=126, border=4.0))
    return result

def _effect_cloudburst(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'density', 'speed', 'clouds', 'splashes', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    density = _integer(params, 'density', 88, minimum=24, maximum=180)
    speed = _number(params, 'speed', 1100, minimum=400, maximum=2600)
    clouds = _integer(params, 'clouds', 5, minimum=2, maximum=10)
    splashes = _integer(params, 'splashes', 16, minimum=4, maximum=36)
    seed = _integer(params, 'seed', 401, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H241B19&', '&H362722&', '&H15100F&'), (115, 130, 145))
    _add_clouds(result, event, context, count=clouds, seed=seed + 2, direction=direction, color='&H2B2525&', alpha=32, y_min=scene.y1 + 8, y_max=scene.y1 + 90, drift=150, layer_offset=2, blur=14, scale_min=150, scale_max=245)
    rain_path = 'm -2 -34 l 2 -34 2 34 -2 34'
    travel_ms = (scene.height + 120) / speed * 1000
    for index, begin, finish, f0, f1, speed_scale in _iter_particle_passes(event.duration_ms, count=density, travel_ms=travel_ms, seed=seed + 10):
        x = scene.x1 + _seed_value(seed, index, 10) * scene.width
        drift = sign * (45 + 70 * _seed_value(seed, index, 11))
        y0 = scene.y1 - 55 + (scene.height + 110) * f0
        y1 = scene.y1 - 55 + (scene.height + 110) * f1
        result.append(_moving_shape(event, begin, finish, rain_path, x0=x - drift / 2 + drift * f0, y0=y0, x1=x - drift / 2 + drift * f1, y1=y1, color='&HD9C9C1&', alpha=52 + round(80 * _seed_value(seed, index, 12)), scale0=70 + 75 * _seed_value(seed, index, 13), rotation0=-sign * 10, blur=1.1, clip=scene, layer_offset=6 if index % 4 else 9, fade_in=20, fade_out=35))
    for index in range(5):
        y = scene.y1 + (index + 1) * scene.height / 6
        begin = round(index * 110)
        finish = event.duration_ms
        sheet = Rect(scene.x1, round(y - 7), scene.x2, round(y + 8))
        result.append(_moving_absolute_drawing(event, begin, finish, _rect_path(sheet), dx0=-sign * 80, dy0=0, dx1=sign * 80, dy1=0, color='&H80706B&', alpha=205, blur=10, clip=scene, layer_offset=5, fade_in=150, fade_out=220))
    surge_path = _wave_polygon(scene.x1 - 120, scene.x2 + 120, box.y2 + 92, scene.y2 + 30, 24, 210, 0.12)
    result.append(_moving_absolute_drawing(event, 0, event.duration_ms, surge_path, dx0=-sign * 120, dy0=0, dx1=sign * 120, dy1=0, color='&H5B3F32&', alpha=118, blur=4, clip=scene, layer_offset=4, fade_in=220, fade_out=260))
    for index in range(splashes):
        begin = round((index + _seed_value(seed, index, 20)) * event.duration_ms / splashes)
        finish = min(event.duration_ms, begin + 320)
        if finish - begin < 30:
            continue
        x = scene.x1 + _seed_value(seed, index, 21) * scene.width
        y = box.y2 + 75 + (_seed_value(seed, index, 22) - 0.5) * 38
        result.append(_moving_shape(event, begin, finish, _splash_path(13 + round(8 * _seed_value(seed, index, 23))), x0=x, y0=y, x1=x + sign * 10, y1=y - 30, color='&HFFF1E5&', alpha=26, scale0=70, scale1=135, blur=1.0, clip=scene, layer_offset=10, fade_in=10, fade_out=170))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFFFF&', outline='&H1B1515&', glow='&HCBB7AA&', glow_alpha=82, border=5.0))
    return result

def _effect_rainbow_arch(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'bands', 'radius', 'thickness', 'sparkles'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    bands = _integer(params, 'bands', 7, minimum=3, maximum=9)
    radius = _number(params, 'radius', 330, minimum=120, maximum=620)
    thickness = _number(params, 'thickness', 11, minimum=3, maximum=28)
    sparkles = _integer(params, 'sparkles', 18, minimum=4, maximum=50)
    scene = _scene_box(context)
    box = context.box
    anchor_x, anchor_y = _event_anchor(event, context)
    center_y = box.y2 + 140
    palette = ('&H5252FF&', '&H4E9FFF&', '&H4DEBFF&', '&H63E887&', '&HFFD96E&', '&HFF8D68&', '&HDE72C7&')
    order = range(bands) if direction is Direction.LEFT_TO_RIGHT else reversed(range(bands))
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&HAFC5D5&', '&HC7D4D8&', '&H839AA8&'), (220, 224, 230))
    rainbow_clip = Rect(scene.x1, scene.y1, scene.x2, min(scene.y2, round(center_y)))
    for sequence, band_index in enumerate(order):
        begin = min(event.duration_ms - 50, sequence * 55)
        finish = event.duration_ms
        rx = round(radius - band_index * (thickness * 1.35))
        ry = max(50, round(rx * 0.42))
        local = finish - begin
        tags = f'\\an5\\pos({_fmt(anchor_x)},{_fmt(center_y)})\\1a&HFF&\\3c{palette[band_index % len(palette)]}' + f'\\3a&H2A&\\bord{_fmt(thickness)}\\blur2.2\\fscx70\\fscy70' + _clip_tag(rainbow_clip) + f'\\fad(180,{min(280, end)})\\t(0,{min(local, 850)},\\fscx100\\fscy100\\3a&H10&)'
        result.append(_drawing_event(event, begin, finish, _arc_path(rx, ry), tags, layer_offset=2 + band_index))
    drop_path = _droplet_path(5, 14)
    seed = 707
    for index in range(max(12, sparkles)):
        begin = round(_seed_value(seed, index, 1) * max(1, event.duration_ms - 800))
        finish = min(event.duration_ms, begin + 700)
        x = scene.x1 + _seed_value(seed, index, 2) * scene.width
        y = scene.y1 + _seed_value(seed, index, 3) * scene.height * 0.78
        result.append(_moving_shape(event, begin, finish, drop_path, x0=x, y0=y, x1=x + (18 if direction is Direction.LEFT_TO_RIGHT else -18), y1=y + 80, color='&HFFF9EF&', alpha=110, scale0=45 + 45 * _seed_value(seed, index, 4), blur=0.8, clip=scene, layer_offset=9, fade_in=70, fade_out=180))
    for index in range(sparkles):
        begin = round((index + 0.15) * event.duration_ms / sparkles)
        finish = min(event.duration_ms, begin + 420)
        angle = math.pi + index / max(1, sparkles - 1) * math.pi
        rx = radius - index % bands * thickness * 1.2
        ry = rx * 0.42
        x = anchor_x + math.cos(angle) * rx
        y = center_y + math.sin(angle) * ry
        result.append(_moving_shape(event, begin, finish, _star_path(8, 2, 4), x0=x, y0=y, x1=x, y1=y - 5, color=palette[index % len(palette)], alpha=0, scale0=35, scale1=130, rotation0=0, rotation1=70, blur=1.0, clip=scene, layer_offset=10, fade_in=40, fade_out=190))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFFFF&', outline='&H554455&', glow='&H93DFFF&', glow_alpha=94, border=4.2))
    return result

def _effect_crepuscular_rays(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'rays', 'dust', 'opening', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    rays = _integer(params, 'rays', 9, minimum=3, maximum=20)
    dust = _integer(params, 'dust', 38, minimum=8, maximum=100)
    opening = _number(params, 'opening', 220, minimum=70, maximum=500)
    seed = _integer(params, 'seed', 809, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    source_x = scene.x1 + scene.width * (0.32 if sign > 0 else 0.68)
    source_y = scene.y1 + 28
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H3F3228&', '&H816B50&', '&H5B4733&'), (118, 166, 184))
    for index in range(rays):
        target_x = scene.x1 + scene.width * index / max(1, rays - 1)
        target_y = scene.y2 + 30
        half = opening * (0.1 + 0.16 * _seed_value(seed, index, 1))
        path = _polygon_path(((source_x - half * 0.15, source_y), (source_x + half * 0.15, source_y), (target_x + half, target_y), (target_x - half, target_y)))
        result.append(_static_drawing(event, path, color='&H9ADFFF&', alpha=212 - round(28 * _seed_value(seed, index, 2)), blur=12, clip=scene, layer_offset=1, extra_tags=_scene_fade(event, start, end)))
    _add_clouds(result, event, context, count=7, seed=seed + 20, direction=direction, color='&H2F2927&', alpha=54, y_min=scene.y1 - 8, y_max=scene.y1 + 82, drift=105, layer_offset=4, blur=8, scale_min=110, scale_max=190)
    dust_path = _ellipse_path(3, 3)
    for index in range(dust):
        x = scene.x1 + _seed_value(seed, index, 30) * scene.width
        y = scene.y1 + _seed_value(seed, index, 31) * scene.height
        drift_x = sign * (18 + 55 * _seed_value(seed, index, 32))
        drift_y = -12 - 35 * _seed_value(seed, index, 33)
        alpha = 80 + round(110 * _seed_value(seed, index, 34))
        result.append(_moving_shape(event, 0, event.duration_ms, dust_path, x0=x - drift_x / 2, y0=y - drift_y / 2, x1=x + drift_x / 2, y1=y + drift_y / 2, color='&HCEF3FF&', alpha=alpha, scale0=35 + 75 * _seed_value(seed, index, 35), scale1=55 + 95 * _seed_value(seed, index, 36), blur=1.4, clip=scene, layer_offset=6, fade_in=180, fade_out=240))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFDF5&', outline='&H4B3727&', glow='&H92DFFF&', glow_alpha=72, border=4.3))
    return result

def _effect_snowfall_depth(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'far_flakes', 'near_flakes', 'drift', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    far_flakes = _integer(params, 'far_flakes', 44, minimum=10, maximum=120)
    near_flakes = _integer(params, 'near_flakes', 18, minimum=4, maximum=50)
    drift = _number(params, 'drift', 70, minimum=0, maximum=220)
    seed = _integer(params, 'seed', 907, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H513E45&', '&H765F65&', '&H443339&'), (154, 176, 186))
    snow_ground = _wave_polygon(scene.x1, scene.x2, box.y2 + 118, scene.y2 + 10, 14, 290, 0.18)
    result.append(_static_drawing(event, snow_ground, color='&HF8EDE9&', alpha=62, blur=6, clip=scene, layer_offset=2, extra_tags=_scene_fade(event, start, end)))
    dot = _ellipse_path(3, 3)
    for index, begin, finish, f0, f1, speed_scale in _iter_particle_passes(event.duration_ms, count=far_flakes, travel_ms=2600, seed=seed):
        base_x = scene.x1 + _seed_value(seed, index, 1) * scene.width
        phase = _seed_value(seed, index, 2) * math.pi * 2
        y0 = scene.y1 - 25 + (scene.height + 50) * f0
        y1 = scene.y1 - 25 + (scene.height + 50) * f1
        sway0 = math.sin(phase + f0 * math.pi * 3) * drift * 0.2
        sway1 = math.sin(phase + f1 * math.pi * 3) * drift * 0.2
        result.append(_moving_shape(event, begin, finish, dot, x0=base_x + sign * drift * (f0 - 0.5) + sway0, y0=y0, x1=base_x + sign * drift * (f1 - 0.5) + sway1, y1=y1, color='&HFFF9F7&', alpha=126 + round(70 * _seed_value(seed, index, 3)), scale0=35 + 55 * _seed_value(seed, index, 4), blur=0.8, clip=scene, layer_offset=3, fade_in=80, fade_out=120))
    snowflake = _snowflake_path(13)
    for index, begin, finish, f0, f1, speed_scale in _iter_particle_passes(event.duration_ms, count=near_flakes, travel_ms=3300, seed=seed + 1000):
        base_x = scene.x1 + _seed_value(seed, index, 11) * scene.width
        phase = _seed_value(seed, index, 12) * math.pi * 2
        y0 = scene.y1 - 30 + (scene.height + 60) * f0
        y1 = scene.y1 - 30 + (scene.height + 60) * f1
        sway0 = math.sin(phase + f0 * math.pi * 4) * drift * 0.55
        sway1 = math.sin(phase + f1 * math.pi * 4) * drift * 0.55
        scale = 60 + 95 * _seed_value(seed, index, 13)
        result.append(_moving_shape(event, begin, finish, snowflake, x0=base_x + sign * drift * (f0 - 0.5) + sway0, y0=y0, x1=base_x + sign * drift * (f1 - 0.5) + sway1, y1=y1, color='&HFFFFFF&', alpha=255, scale0=scale, scale1=scale * (0.9 + 0.2 * _seed_value(seed, index, 14)), rotation0=_seed_value(seed, index, 15) * 180, rotation1=_seed_value(seed, index, 15) * 180 + sign * 240, blur=0.6, border=1.5, outline='&HFFF4ED&', fill=False, clip=scene, layer_offset=9, fade_in=100, fade_out=160))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFFFF&', outline='&H4A343D&', glow='&HFFE6E1&', glow_alpha=86, border=4.2, float_y=2.5))
    return result

def _effect_blizzard_whiteout(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'streaks', 'gust_bands', 'whiteout', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    streaks = _integer(params, 'streaks', 70, minimum=20, maximum=180)
    gust_bands = _integer(params, 'gust_bands', 5, minimum=2, maximum=10)
    whiteout = _integer(params, 'whiteout', 55, minimum=10, maximum=90)
    seed = _integer(params, 'seed', 1009, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H69616E&', '&H8B828E&', '&H5B535F&'), (138, 160, 172))
    streak_path = 'm -34 -2 l 34 -2 34 2 -34 2'
    for index, begin, finish, f0, f1, speed_scale in _iter_particle_passes(event.duration_ms, count=streaks, travel_ms=720, seed=seed):
        y = scene.y1 + _seed_value(seed, index, 1) * scene.height
        x_start = scene.x1 - 90 if sign > 0 else scene.x2 + 90
        x_end = scene.x2 + 90 if sign > 0 else scene.x1 - 90
        jitter0 = math.sin((f0 + _seed_value(seed, index, 2)) * math.pi * 4) * 16
        jitter1 = math.sin((f1 + _seed_value(seed, index, 2)) * math.pi * 4) * 16
        result.append(_moving_shape(event, begin, finish, streak_path, x0=x_start + (x_end - x_start) * f0, y0=y + jitter0, x1=x_start + (x_end - x_start) * f1, y1=y + jitter1, color='&HFFFFFF&', alpha=70 + round(110 * _seed_value(seed, index, 3)), scale0=45 + 100 * _seed_value(seed, index, 4), rotation0=sign * (4 + 8 * _seed_value(seed, index, 5)), blur=1.2, clip=scene, layer_offset=6 if index % 3 else 10, fade_in=15, fade_out=30))
    for index in range(gust_bands):
        y = scene.y1 + (index + 0.7) * scene.height / (gust_bands + 1)
        path = _wavy_line(scene.x1 - 220, scene.x2 + 220, y, 18 + index * 3, 230, index * 0.17, samples=96)
        result.append(_moving_absolute_drawing(event, 0, event.duration_ms, path, dx0=-sign * 170, dy0=0, dx1=sign * 170, dy1=0, color='&HFFFFFF&', alpha=175 + min(36, index * 7), blur=9 + index * 0.8, border=4.0 + index * 1.0, outline='&HF7EDF4&', fill=False, clip=scene, layer_offset=4, fade_in=220, fade_out=260))
    pulse_count = 3
    for index in range(pulse_count):
        begin = round((index + 0.35) * event.duration_ms / pulse_count)
        finish = min(event.duration_ms, begin + 520)
        if finish - begin < 40:
            continue
        alpha = 255 - round(255 * whiteout / 100)
        result.append(_static_drawing(event, _rect_path(scene), color='&HFFFFFF&', alpha=max(80, alpha), blur=14, clip=scene, layer_offset=8, start=begin, end=finish, extra_tags='\\fad(120,260)'))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFFFF&', outline='&H352D38&', glow='&HFFFFFF&', glow_alpha=122, border=5.4))
    return result

def _effect_diamond_dust(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'crystals', 'pillars', 'sparkle_cycles', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    crystals = _integer(params, 'crystals', 46, minimum=10, maximum=120)
    pillars = _integer(params, 'pillars', 5, minimum=2, maximum=10)
    sparkle_cycles = _number(params, 'sparkle_cycles', 2.2, minimum=0.5, maximum=8)
    seed = _integer(params, 'seed', 1103, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H5A3C56&', '&H8B6D82&', '&H4D354A&'), (150, 176, 188))
    for index in range(pillars):
        center = scene.x1 + scene.width * (index + 0.5) / pillars
        half = scene.width / pillars * (0.16 + 0.12 * _seed_value(seed, index, 1))
        path = _polygon_path(((center - half, scene.y2), (center - half * 0.25, scene.y1), (center + half * 0.25, scene.y1), (center + half, scene.y2)))
        result.append(_static_drawing(event, path, color='&HFFD9E8&', alpha=220 - round(18 * _seed_value(seed, index, 2)), blur=16, clip=scene, layer_offset=1, extra_tags=_scene_fade(event, start, end)))
    palette = ('&HFFFFFF&', '&HFFF0C7&', '&HFFCF9A&', '&HFFC5ED&', '&HD4FFB9&')
    base_crystal = _star_path(8, 2, 4)
    pulse_period = max(340, round(event.duration_ms / max(1.0, sparkle_cycles * 2.2)))
    for index in range(crystals):
        x = scene.x1 + _seed_value(seed, index, 10) * scene.width
        y = scene.y1 + _seed_value(seed, index, 11) * scene.height
        drift_x = sign * (12 + 42 * _seed_value(seed, index, 12))
        drift_y = -8 - 25 * _seed_value(seed, index, 13)
        scale = 30 + 70 * _seed_value(seed, index, 14)
        result.append(_moving_shape(event, 0, event.duration_ms, base_crystal, x0=x - drift_x / 2, y0=y - drift_y / 2, x1=x + drift_x / 2, y1=y + drift_y / 2, color=palette[index % len(palette)], alpha=170, scale0=scale, scale1=scale * 1.08, rotation0=_seed_value(seed, index, 15) * 90, rotation1=_seed_value(seed, index, 15) * 90 + sign * 55, blur=0.8, clip=scene, layer_offset=5, fade_in=180, fade_out=220))
        phase = round(_seed_value(seed, index, 16) * pulse_period)
        begin = phase
        pulse_index = 0
        while begin < event.duration_ms:
            finish = min(event.duration_ms, begin + 280)
            if finish - begin > 35:
                result.append(_moving_shape(event, begin, finish, _star_path(10, 2, 4), x0=x + drift_x * (begin / event.duration_ms - 0.5), y0=y + drift_y * (begin / event.duration_ms - 0.5), x1=x + drift_x * (finish / event.duration_ms - 0.5), y1=y + drift_y * (finish / event.duration_ms - 0.5) - 3, color=palette[(index + pulse_index) % len(palette)], alpha=0, scale0=25, scale1=145, rotation0=0, rotation1=85, blur=1.5, clip=scene, layer_offset=9, fade_in=45, fade_out=150))
            begin += pulse_period
            pulse_index += 1
    result.extend(_themed_text(event, start, end, context, primary='&HFFFFFF&', outline='&H56384F&', glow='&HFFE0F4&', glow_alpha=70, border=4.2))
    return result

def _effect_hailstorm(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'pellets', 'bounce', 'impacts', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    pellets = _integer(params, 'pellets', 48, minimum=12, maximum=120)
    bounce = _number(params, 'bounce', 70, minimum=10, maximum=180)
    impacts = _integer(params, 'impacts', 12, minimum=3, maximum=36)
    seed = _integer(params, 'seed', 1201, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    ground = box.y2 + 102
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H39313A&', '&H514753&', '&H272229&'), (118, 140, 154))
    _add_clouds(result, event, context, count=5, seed=seed + 1, direction=direction, color='&H4C4650&', alpha=60, y_min=scene.y1, y_max=scene.y1 + 90, drift=105, layer_offset=2, blur=10, scale_min=120, scale_max=200)
    pellet = _ellipse_path(6, 6)
    travel = 1050
    for index in range(pellets):
        phase = round(_seed_value(seed, index, 1) * travel)
        begin = -phase
        cycle = 0
        while begin < event.duration_ms:
            raw_fall_end = begin + travel
            fall_begin = max(0, begin)
            fall_end = min(event.duration_ms, raw_fall_end)
            x_base = scene.x1 + _seed_value(seed, index, 2) * scene.width
            drift = sign * (18 + 42 * _seed_value(seed, index, 3))
            if fall_end - fall_begin > 35:
                f0 = _clamp((fall_begin - begin) / travel)
                f1 = _clamp((fall_end - begin) / travel)
                result.append(_moving_shape(event, fall_begin, fall_end, pellet, x0=x_base - drift / 2 + drift * f0, y0=scene.y1 - 22 + (ground - scene.y1 + 22) * f0, x1=x_base - drift / 2 + drift * f1, y1=scene.y1 - 22 + (ground - scene.y1 + 22) * f1, color='&HFFF7F2&', alpha=35 + round(90 * _seed_value(seed, index, 4)), scale0=50 + 75 * _seed_value(seed, index, 5), blur=0.5, border=0.8, outline='&HBAAEBE&', clip=scene, layer_offset=7, fade_in=25, fade_out=25))
            if 0 <= raw_fall_end < event.duration_ms:
                rebound_end = min(event.duration_ms, raw_fall_end + 260)
                if rebound_end - raw_fall_end > 30:
                    result.append(_moving_shape(event, raw_fall_end, rebound_end, pellet, x0=x_base + drift / 2, y0=ground, x1=x_base + drift / 2 + sign * 18, y1=ground - bounce * (0.55 + 0.45 * _seed_value(seed, index, 6)), color='&HFFFFFF&', alpha=60, scale0=55 + 60 * _seed_value(seed, index, 7), rotation0=0, rotation1=160, blur=0.6, clip=scene, layer_offset=9, fade_in=5, fade_out=110))
            begin += travel + 420
            cycle += 1
    for index in range(impacts):
        begin = round((index + 0.25) * event.duration_ms / impacts)
        x = box.x1 + _seed_value(seed, index, 20) * box.width
        ring = _pulse_ring(event, begin, 400, x=x, y=ground, rx=18, ry=5, color='&HFFFFFF&', border=2.1, scale0=25, scale1=135, alpha0=35, clip=scene, layer_offset=10)
        if ring is not None:
            result.append(ring)
    result.extend(_themed_text(event, start, end, context, primary='&HFFFFFF&', outline='&H3D3540&', glow='&HFFF2F8&', glow_alpha=92, border=4.6))
    return result

def _frost_segments(box: Rect, *, branches: int, depth: int, reach: float, seed: int) -> list[tuple[tuple[float, float], tuple[float, float], int, float]]:
    segments: list[tuple[tuple[float, float], tuple[float, float], int, float]] = []
    anchors: list[tuple[float, float, float]] = []
    for index in range(branches):
        side = index % 4
        t = (index // 4 + 0.5) / max(1, math.ceil(branches / 4))
        if side == 0:
            anchors.append((box.x1 + box.width * t, box.y1, -math.pi / 2))
        elif side == 1:
            anchors.append((box.x2, box.y1 + box.height * t, 0.0))
        elif side == 2:
            anchors.append((box.x1 + box.width * t, box.y2, math.pi / 2))
        else:
            anchors.append((box.x1, box.y1 + box.height * t, math.pi))
    for index, (x, y, angle) in enumerate(anchors):

        def grow(px: float, py: float, current_angle: float, level: int, local_reach: float, lane: int) -> None:
            jitter = (_seed_value(seed + index, lane, level) - 0.5) * 0.42
            angle2 = current_angle + jitter
            length = local_reach * (0.64 + 0.32 * _seed_value(seed + index, lane, level + 10))
            ex = px + math.cos(angle2) * length
            ey = py + math.sin(angle2) * length
            order = level + index / max(1, branches)
            segments.append(((px, py), (ex, ey), level, order))
            if level < depth:
                grow(ex, ey, angle2 - 0.62, level + 1, local_reach * 0.58, lane * 2 + 1)
                grow(ex, ey, angle2 + 0.62, level + 1, local_reach * 0.58, lane * 2 + 2)
        grow(x, y, angle, 0, reach, index + 1)
    return segments

def _effect_frost_bloom(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'branches', 'depth', 'reach', 'seed'})
    direction = _direction(params, (Direction.CENTER_OUT, Direction.EDGES_IN), Direction.CENTER_OUT)
    branches = _integer(params, 'branches', 18, minimum=6, maximum=32)
    depth = _integer(params, 'depth', 3, minimum=1, maximum=4)
    reach = _number(params, 'reach', 115, minimum=35, maximum=220)
    seed = _integer(params, 'seed', 1301, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H6C5261&', '&H8D7480&', '&H58434F&'), (178, 194, 204))
    pane = Rect(max(scene.x1, box.x1 - 55), max(scene.y1, box.y1 - 48), min(scene.x2, box.x2 + 55), min(scene.y2, box.y2 + 48))
    result.append(_static_drawing(event, _rect_path(pane), color='&HFFF1F5&', alpha=220, blur=5, border=2.2, outline='&HFFE8F2&', clip=scene, layer_offset=1, extra_tags=_scene_fade(event, start, end)))
    segments = _frost_segments(box, branches=branches, depth=depth, reach=reach, seed=seed)
    max_order = max((order for _, _, _, order in segments))
    ordered = sorted(segments, key=lambda item: item[3], reverse=direction is Direction.EDGES_IN)
    for index, (first, second, level, order) in enumerate(ordered):
        normalized = index / max(1, len(ordered) - 1)
        begin = round(normalized * min(start + 450, event.duration_ms * 0.42))
        finish = max(begin + 80, event.duration_ms - round((1.0 - normalized) * min(end * 0.55, 420)))
        finish = min(event.duration_ms, finish)
        if finish - begin < 35:
            continue
        result.append(_static_drawing(event, _polyline_path((first, second)), color='&HFFFFFF&', alpha=255, blur=0.7 + level * 0.25, border=max(0.8, 2.2 - level * 0.35), outline='&HFFF6F8&', fill=False, clip=scene, layer_offset=5 + level, start=begin, end=finish, extra_tags=f'\\fad({min(100, finish - begin // 3)},{min(220, end)})'))
        if level == depth and index % 3 == 0:
            ex, ey = second
            sparkle_end = min(event.duration_ms, begin + 420)
            if sparkle_end - begin > 40:
                result.append(_moving_shape(event, begin, sparkle_end, _star_path(7, 2, 4), x0=ex, y0=ey, x1=ex, y1=ey, color='&HFFFFFF&', alpha=0, scale0=25, scale1=130, rotation0=0, rotation1=60, blur=1.0, clip=scene, layer_offset=10, fade_in=45, fade_out=170))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFFFF&', outline='&H664657&', glow='&HFFE8F4&', glow_alpha=66, border=4.4))
    return result

def _ice_crack_segments(box: Rect, *, branches: int, depth: int, seed: int, from_edges: bool) -> list[tuple[tuple[float, float], tuple[float, float], int, float]]:
    cx, cy = box.center
    starts: list[tuple[float, float, float]] = []
    for index in range(branches):
        angle = 2 * math.pi * index / branches + (_seed_value(seed, index, 1) - 0.5) * 0.35
        if from_edges:
            radius_x = box.width * 0.55
            radius_y = box.height * 0.7
            sx = cx + math.cos(angle) * radius_x
            sy = cy + math.sin(angle) * radius_y
            starts.append((sx, sy, angle + math.pi))
        else:
            starts.append((cx, cy, angle))
    segments: list[tuple[tuple[float, float], tuple[float, float], int, float]] = []
    for index, (sx, sy, angle) in enumerate(starts):

        def crack(px: float, py: float, a: float, level: int, length: float, lane: int) -> None:
            a2 = a + (_seed_value(seed + index, lane, level) - 0.5) * 0.55
            ex = px + math.cos(a2) * length
            ey = py + math.sin(a2) * length
            segments.append(((px, py), (ex, ey), level, level + index / branches))
            if level < depth:
                crack(ex, ey, a2 - 0.42, level + 1, length * 0.55, lane * 2 + 1)
                if _seed_value(seed + index, lane, level + 20) > 0.35:
                    crack(ex, ey, a2 + 0.48, level + 1, length * 0.48, lane * 2 + 2)
        crack(sx, sy, angle, 0, min(box.width, box.height * 2.8) * 0.32, index + 1)
    return segments

def _effect_ice_crack(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'branches', 'depth', 'shards', 'seed'})
    direction = _direction(params, (Direction.CENTER_OUT, Direction.EDGES_IN), Direction.CENTER_OUT)
    branches = _integer(params, 'branches', 12, minimum=5, maximum=24)
    depth = _integer(params, 'depth', 3, minimum=1, maximum=4)
    shards = _integer(params, 'shards', 18, minimum=4, maximum=40)
    seed = _integer(params, 'seed', 1501, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    pane = Rect(max(scene.x1, box.x1 - 100), max(scene.y1, box.y1 - 95), min(scene.x2, box.x2 + 100), min(scene.y2, box.y2 + 95))
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H6B4F5E&', '&H927383&', '&H55404C&'), (170, 190, 202))
    result.append(_static_drawing(event, _rect_path(pane), color='&HFFE8EE&', alpha=220, blur=3, border=2.4, outline='&HFFD7E5&', clip=scene, layer_offset=1, extra_tags=_scene_fade(event, start, end)))
    segments = _ice_crack_segments(box, branches=branches, depth=depth, seed=seed, from_edges=direction is Direction.EDGES_IN)
    ordered = sorted(segments, key=lambda item: item[3])
    for index, (first, second, level, order) in enumerate(ordered):
        begin = round(index / max(1, len(ordered) - 1) * min(950, start + 300))
        finish = event.duration_ms
        result.append(_static_drawing(event, _polyline_path((first, second)), color='&HFFFFFF&', alpha=255, blur=0.6, border=max(0.7, 2.8 - level * 0.5), outline='&HFFF6F9&', fill=False, clip=pane, layer_offset=6 + level, start=begin, end=finish, extra_tags=f'\\fad({min(80, max(10, finish - begin))},{min(end, 260)})'))
    shard_path = _triangle_path(10, 22)
    cx, cy = box.center
    for index in range(shards):
        angle = 2 * math.pi * index / shards + (_seed_value(seed, index, 30) - 0.5) * 0.3
        radius = 45 + _seed_value(seed, index, 31) * min(box.width * 0.42, 240)
        x = cx + math.cos(angle) * radius
        y = cy + math.sin(angle) * radius * 0.52
        begin = round((0.36 + 0.38 * _seed_value(seed, index, 32)) * event.duration_ms)
        finish = min(event.duration_ms, begin + 760)
        if finish - begin < 40:
            continue
        result.append(_moving_shape(event, begin, finish, shard_path, x0=x, y0=y, x1=x + math.cos(angle) * (18 + 38 * _seed_value(seed, index, 33)), y1=y + math.sin(angle) * (12 + 28 * _seed_value(seed, index, 34)), color='&HFFF1F6&', alpha=150, scale0=40 + 65 * _seed_value(seed, index, 35), scale1=55 + 75 * _seed_value(seed, index, 36), rotation0=math.degrees(angle), rotation1=math.degrees(angle) + 80, blur=0.7, border=1.0, outline='&HFFD6E4&', clip=pane, layer_offset=10, fade_in=80, fade_out=220))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFFFF&', outline='&H5D4150&', glow='&HFFE1ED&', glow_alpha=64, border=4.5))
    return result

def _effect_avalanche(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'powder', 'distance', 'debris', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    powder = _integer(params, 'powder', 38, minimum=8, maximum=80)
    distance = _number(params, 'distance', 1800, minimum=300, maximum=2800)
    debris = _integer(params, 'debris', 26, minimum=5, maximum=60)
    seed = _integer(params, 'seed', 1601, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H806C72&', '&HA58F94&', '&H66545B&'), (188, 204, 214))
    if sign > 0:
        mountain_points = ((scene.x1, scene.y2), (scene.x1 + scene.width * 0.34, scene.y1 + 45), (scene.x1 + scene.width * 0.62, scene.y2), (scene.x2, scene.y2))
    else:
        mountain_points = ((scene.x1, scene.y2), (scene.x2 - scene.width * 0.62, scene.y2), (scene.x2 - scene.width * 0.34, scene.y1 + 45), (scene.x2, scene.y2))
    mountain = _polygon_path(mountain_points)
    result.append(_static_drawing(event, mountain, color='&H7B6870&', alpha=126, blur=3, clip=scene, layer_offset=1, extra_tags=_scene_fade(event, start, end)))
    ridge = ((scene.x1 + scene.width * 0.18, scene.y2 - scene.height * 0.24), (scene.x1 + scene.width * 0.34, scene.y1 + 45), (scene.x1 + scene.width * 0.48, scene.y2 - scene.height * 0.15)) if sign > 0 else ((scene.x2 - scene.width * 0.18, scene.y2 - scene.height * 0.24), (scene.x2 - scene.width * 0.34, scene.y1 + 45), (scene.x2 - scene.width * 0.48, scene.y2 - scene.height * 0.15))
    result.append(_static_drawing(event, _polyline_path(ridge), color='&HFFF4F6&', alpha=95, blur=1.4, border=5.0, outline='&HFFF4F6&', fill=False, clip=scene, layer_offset=3, extra_tags=_scene_fade(event, start, end)))
    mass_points = [(-420, 80), (-340, 20), (-220, -70), (-80, -105), (90, -80), (240, -25), (410, 45), (430, 150), (-430, 150)]
    mass_path = _polygon_path(mass_points)
    y = box.y2 + 110
    x0 = scene.x1 - 420 if sign > 0 else scene.x2 + 420
    x1 = x0 + sign * distance
    result.append(_moving_shape(event, 0, event.duration_ms, mass_path, x0=x0, y0=y, x1=x1, y1=y + 12, color='&HFFF4F5&', alpha=20, scale0=100, scale1=116, blur=3.5, border=2.0, outline='&HD9C8CF&', clip=scene, layer_offset=6, fade_in=180, fade_out=320))
    cloud = _cloud_path(90, 42)
    for index in range(powder):
        phase = _seed_value(seed, index, 1)
        begin = round(phase * event.duration_ms * 0.72)
        finish = min(event.duration_ms, begin + 900 + round(500 * _seed_value(seed, index, 2)))
        if finish - begin < 40:
            continue
        progress = begin / event.duration_ms
        front_x = x0 + (x1 - x0) * progress
        local_x = front_x - sign * (50 + 260 * _seed_value(seed, index, 3))
        local_y = y - 40 - 110 * _seed_value(seed, index, 4)
        scale = 45 + 100 * _seed_value(seed, index, 5)
        result.append(_moving_shape(event, begin, finish, cloud, x0=local_x, y0=local_y, x1=local_x + sign * (120 + 180 * _seed_value(seed, index, 6)), y1=local_y - 45 - 55 * _seed_value(seed, index, 7), color='&HFFF7F6&', alpha=95 + round(80 * _seed_value(seed, index, 8)), scale0=scale, scale1=scale * 1.8, blur=7, clip=scene, layer_offset=7, fade_in=80, fade_out=320))
    chunk = _diamond_path(9, 11)
    for index in range(debris):
        begin = round(_seed_value(seed, index, 20) * event.duration_ms * 0.76)
        finish = min(event.duration_ms, begin + 620)
        if finish - begin < 35:
            continue
        progress = begin / event.duration_ms
        front_x = x0 + (x1 - x0) * progress
        x = front_x - sign * (25 + 190 * _seed_value(seed, index, 21))
        yy = y - 45 - 130 * _seed_value(seed, index, 22)
        result.append(_moving_shape(event, begin, finish, chunk, x0=x, y0=yy, x1=x + sign * (80 + 120 * _seed_value(seed, index, 23)), y1=yy + 80 + 50 * _seed_value(seed, index, 24), color='&HFFFFFF&', alpha=30, scale0=45 + 80 * _seed_value(seed, index, 25), rotation0=_seed_value(seed, index, 26) * 180, rotation1=_seed_value(seed, index, 26) * 180 + sign * 280, blur=0.8, clip=scene, layer_offset=10, fade_in=30, fade_out=160))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFFFF&', outline='&H4A3940&', glow='&HFFF0F2&', glow_alpha=75, border=5.0))
    return result

def _effect_morning_mist(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'bands', 'drift', 'opacity', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    bands = _integer(params, 'bands', 7, minimum=3, maximum=12)
    drift = _number(params, 'drift', 130, minimum=20, maximum=360)
    opacity = _integer(params, 'opacity', 125, minimum=40, maximum=220)
    seed = _integer(params, 'seed', 1709, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H827568&', '&HA99B8D&', '&H74685E&'), (194, 208, 214))
    cloud = _cloud_path(230, 58)
    for index in range(bands):
        y = scene.y1 + scene.height * (0.16 + 0.72 * index / max(1, bands - 1))
        x = scene.x1 + _seed_value(seed, index, 1) * scene.width
        scale = 210 + 150 * _seed_value(seed, index, 2)
        local_drift = drift * (0.45 + 0.85 * index / max(1, bands - 1))
        result.append(_moving_shape(event, 0, event.duration_ms, cloud, x0=x - sign * local_drift / 2, y0=y, x1=x + sign * local_drift / 2, y1=y + (_seed_value(seed, index, 3) - 0.5) * 16, color='&HE9E3DD&', alpha=min(245, opacity + index * 8), scale0=scale, scale1=scale * (0.98 + 0.06 * _seed_value(seed, index, 4)), blur=18 + index * 2.4, clip=scene, layer_offset=2 if index < bands // 2 else 9, fade_in=300, fade_out=340))
    for index in range(3):
        y = scene.y1 + scene.height * (0.35 + index * 0.18)
        path = _wavy_line(scene.x1 - 180, scene.x2 + 180, y, 12 + index * 4, 310, index * 0.24, samples=96)
        result.append(_moving_absolute_drawing(event, 0, event.duration_ms, path, dx0=-sign * 110, dy0=0, dx1=sign * 110, dy1=0, color='&HFFFFFF&', alpha=205 + index * 8, blur=16 + index * 2.0, border=20 + index * 5, outline='&HF3ECE6&', fill=False, clip=scene, layer_offset=7, fade_in=300, fade_out=360))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFDFC&', outline='&H665D56&', glow='&HEDE7E2&', glow_alpha=118, border=4.3))
    return result

def _effect_sea_of_clouds(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'layers', 'cloudlets', 'drift', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    layers = _integer(params, 'layers', 5, minimum=3, maximum=9)
    cloudlets = _integer(params, 'cloudlets', 18, minimum=6, maximum=45)
    drift = _number(params, 'drift', 90, minimum=15, maximum=260)
    seed = _integer(params, 'seed', 1801, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H8CB6D2&', '&HBED5DF&', '&H8C9FAF&'), (182, 206, 218))
    peaks = [(scene.x1, scene.y2), (scene.x1 + scene.width * 0.12, box.y2 + 50), (scene.x1 + scene.width * 0.24, scene.y2), (scene.x1 + scene.width * 0.46, box.y2 + 8), (scene.x1 + scene.width * 0.62, scene.y2), (scene.x1 + scene.width * 0.78, box.y2 + 62), (scene.x2, scene.y2)]
    result.append(_static_drawing(event, _polygon_path(peaks), color='&H706875&', alpha=126, blur=4, clip=scene, layer_offset=1, extra_tags=_scene_fade(event, start, end)))
    cloud = _cloud_path(150, 54)
    for layer in range(layers):
        layer_y = box.y2 + 36 + layer * (scene.y2 - box.y2 - 25) / max(1, layers)
        per_layer = max(2, round(cloudlets / layers))
        for index in range(per_layer + (1 if layer < cloudlets % layers else 0)):
            key = layer * 100 + index
            x = scene.x1 + _seed_value(seed, key, 1) * scene.width
            scale = 115 + layer * 32 + 70 * _seed_value(seed, key, 2)
            local_drift = drift * (0.45 + layer / max(1, layers - 1))
            result.append(_moving_shape(event, 0, event.duration_ms, cloud, x0=x - sign * local_drift / 2, y0=layer_y + (_seed_value(seed, key, 3) - 0.5) * 45, x1=x + sign * local_drift / 2, y1=layer_y + (_seed_value(seed, key, 4) - 0.5) * 45, color='&HFFF7F3&', alpha=82 + layer * 18, scale0=scale, scale1=scale * 1.05, blur=7 + layer * 2.2, clip=scene, layer_offset=2 + layer, fade_in=260, fade_out=320))
    sun_x = scene.x1 + scene.width * (0.25 if sign > 0 else 0.75)
    sun_y = scene.y1 + 60
    result.append(_moving_shape(event, 0, event.duration_ms, _ellipse_path(48, 48), x0=sun_x - sign * 8, y0=sun_y, x1=sun_x + sign * 8, y1=sun_y - 3, color='&H9CEBFF&', alpha=95, scale0=100, scale1=106, blur=12, clip=scene, layer_offset=1, fade_in=280, fade_out=300))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFFFF&', outline='&H615667&', glow='&HFFF0E8&', glow_alpha=78, border=4.4, float_y=2.0))
    return result

def _effect_gentle_breeze(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'streamlines', 'grass_blades', 'seeds', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    streamlines = _integer(params, 'streamlines', 12, minimum=4, maximum=28)
    grass_blades = _integer(params, 'grass_blades', 20, minimum=6, maximum=48)
    seeds = _integer(params, 'seeds', 14, minimum=3, maximum=36)
    seed = _integer(params, 'seed', 1901, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&HA9CABF&', '&HBCD7C9&', '&H86A897&'), (208, 218, 224))
    for index in range(streamlines):
        y = scene.y1 + scene.height * (0.12 + 0.72 * (index + 0.5) / streamlines)
        amplitude = 7 + 11 * _seed_value(seed, index, 1)
        wavelength = 220 + 190 * _seed_value(seed, index, 2)
        path = _wavy_line(scene.x1 - 180, scene.x2 + 180, y, amplitude, wavelength, _seed_value(seed, index, 3), samples=90)
        result.append(_moving_absolute_drawing(event, 0, event.duration_ms, path, dx0=-sign * 120, dy0=0, dx1=sign * 120, dy1=0, color='&HFFF5D8&', alpha=165 + round(28 * _seed_value(seed, index, 4)), blur=1.0, border=1.0 + 1.4 * _seed_value(seed, index, 4), outline='&HFFF2D7&', fill=False, clip=scene, layer_offset=3, fade_in=240, fade_out=280))
    baseline = box.y2 + 122
    for index in range(grass_blades):
        x = scene.x1 + scene.width * (index + 0.5) / grass_blades
        height = 28 + 65 * _seed_value(seed, index, 10)
        bend = sign * (8 + 22 * _seed_value(seed, index, 11))
        path = _polyline_path(((x, baseline), (x + bend * 0.35, baseline - height * 0.55), (x + bend, baseline - height)))
        result.append(_static_drawing(event, path, color='&H6C8C66&', alpha=255, blur=0.5, border=2.0 + _seed_value(seed, index, 12) * 1.2, outline='&H6C8C66&', fill=False, clip=scene, layer_offset=5, extra_tags=_scene_fade(event, start, end)))
    seed_path = _seed_path(11)
    for index in range(seeds):
        begin = round(_seed_value(seed, index, 20) * event.duration_ms * 0.45)
        finish = min(event.duration_ms, begin + 1800 + round(900 * _seed_value(seed, index, 21)))
        if finish - begin < 40:
            continue
        x0 = scene.x1 - 40 if sign > 0 else scene.x2 + 40
        x1 = scene.x2 + 40 if sign > 0 else scene.x1 - 40
        y = scene.y1 + scene.height * (0.3 + 0.48 * _seed_value(seed, index, 22))
        result.append(_moving_shape(event, begin, finish, seed_path, x0=x0, y0=y, x1=x1, y1=y - 35 - 70 * _seed_value(seed, index, 23), color='&HFFF7E4&', alpha=60, scale0=45 + 70 * _seed_value(seed, index, 24), rotation0=_seed_value(seed, index, 25) * 120, rotation1=_seed_value(seed, index, 25) * 120 + sign * 280, blur=0.6, border=1.0, outline='&HFFF7E4&', fill=False, clip=scene, layer_offset=8, fade_in=160, fade_out=240))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFDF4&', outline='&H4F7055&', glow='&HCDF0C7&', glow_alpha=100, border=4.1, whole_shift_x=2.5 * sign, float_y=-1.5))
    return result

def _effect_gust_front(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'streaks', 'debris', 'displacement', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    streaks = _integer(params, 'streaks', 34, minimum=8, maximum=90)
    debris = _integer(params, 'debris', 20, minimum=4, maximum=50)
    displacement = _number(params, 'displacement', 26, minimum=4, maximum=80)
    seed = _integer(params, 'seed', 2003, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    anchor_x, anchor_y = _event_anchor(event, context)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H68584F&', '&H86766B&', '&H55483F&'), (176, 190, 200))
    pressure_path = _ellipse_path(round(scene.height * 0.44), round(scene.height * 0.34))
    result.append(_moving_shape(event, 0, min(event.duration_ms, max(900, start + 650)), pressure_path, x0=scene.x1 - sign * scene.height * 0.55 if sign > 0 else scene.x2 + scene.height * 0.55, y0=anchor_y, x1=anchor_x + sign * 80, y1=anchor_y, color='&HFFFFFF&', alpha=255, scale0=80, scale1=130, blur=5, border=8, outline='&HEEE1D8&', fill=False, clip=scene, layer_offset=3, fade_in=60, fade_out=320))
    for index in range(6):
        y = scene.y1 + scene.height * (0.14 + 0.7 * (index + 0.5) / 6)
        wake = _wavy_line(scene.x1 - 160, scene.x2 + 160, y, 4 + index * 1.2, 330 + index * 35, index * 0.13, samples=84)
        result.append(_moving_absolute_drawing(event, 0, event.duration_ms, wake, dx0=-sign * 90, dy0=0, dx1=sign * 130, dy1=-4, color='&HFFF1DE&', alpha=192 + index * 6, blur=2.0 + index * 0.3, border=1.5 + index * 0.25, outline='&HFFF1DE&', fill=False, clip=scene, layer_offset=4, fade_in=180, fade_out=300))
    streak_path = 'm -48 -1 l 48 -1 48 1 -48 1'
    for index in range(streaks):
        begin = round(_seed_value(seed, index, 1) * event.duration_ms * 0.62)
        finish = min(event.duration_ms, begin + 360 + round(420 * _seed_value(seed, index, 2)))
        if finish - begin < 35:
            continue
        y = scene.y1 + _seed_value(seed, index, 3) * scene.height
        x0 = scene.x1 - 100 if sign > 0 else scene.x2 + 100
        x1 = scene.x2 + 100 if sign > 0 else scene.x1 - 100
        result.append(_moving_shape(event, begin, finish, streak_path, x0=x0, y0=y, x1=x1, y1=y + (_seed_value(seed, index, 4) - 0.5) * 24, color='&HFFF1DE&', alpha=90 + round(90 * _seed_value(seed, index, 5)), scale0=45 + 80 * _seed_value(seed, index, 6), blur=1.2, clip=scene, layer_offset=6, fade_in=20, fade_out=60))
    debris_path = _diamond_path(7, 10)
    for index in range(debris):
        begin = round(_seed_value(seed, index, 10) * event.duration_ms * 0.58)
        finish = min(event.duration_ms, begin + 680 + round(520 * _seed_value(seed, index, 11)))
        if finish - begin < 40:
            continue
        y = scene.y1 + scene.height * (0.18 + 0.65 * _seed_value(seed, index, 12))
        x0 = scene.x1 - 50 if sign > 0 else scene.x2 + 50
        x1 = scene.x2 + 50 if sign > 0 else scene.x1 - 50
        result.append(_moving_shape(event, begin, finish, debris_path, x0=x0, y0=y, x1=x1, y1=y - 45 - 65 * _seed_value(seed, index, 13), color='&H9F8A66&', alpha=40, scale0=40 + 90 * _seed_value(seed, index, 14), rotation0=_seed_value(seed, index, 15) * 180, rotation1=_seed_value(seed, index, 15) * 180 + sign * 520, blur=0.5, clip=scene, layer_offset=9, fade_in=40, fade_out=120))

    def line_state(t: float, t_ms: int) -> MotionState:
        visible = _presence_for_line(t_ms, event.duration_ms, start, end)
        impact = _pulse(_clamp((t - 0.18) / 0.42), 2.2)
        recoil = sign * displacement * impact
        return MotionState(anchor_x + recoil, anchor_y - 3 * impact, rotation_z=sign * 1.8 * impact, shear_x=sign * 0.035 * impact, alpha=_alpha_from_presence(visible), primary_color='&HFFFFFF&', outline_color='&H4A3932&', border=4.6, blur=0.65, shadow=1.0)
    result.extend(_emit_sampled_line(event, context, line_state, layer_offset=10, step_ms=max(70, context.motion_step_ms)))

    def glow_state(t: float, t_ms: int) -> MotionState:
        visible = _presence_for_line(t_ms, event.duration_ms, start, end)
        impact = _pulse(_clamp((t - 0.18) / 0.42), 2.0)
        return MotionState(anchor_x + sign * displacement * impact, anchor_y - 3 * impact, rotation_z=sign * 1.8 * impact, alpha=max(70, _alpha_from_presence(visible, floor=70)), primary_color='&HFFF2DE&', outline_color='&HFFF2DE&', border=10.0, blur=10.0, shadow=0.0)
    result.extend(_emit_sampled_line(event, context, glow_state, layer_offset=7, step_ms=max(80, context.motion_step_ms)))
    return result

def _spiral_path(turns: float, radius: float, *, samples: int=80) -> str:
    points: list[tuple[float, float]] = []
    for index in range(samples + 1):
        t = index / samples
        angle = turns * 2 * math.pi * t
        r = radius * t
        points.append((math.cos(angle) * r, math.sin(angle) * r * 0.58))
    return _polyline_path(points)

def _effect_whirlwind(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'particles', 'turns', 'radius', 'seed'})
    direction = _direction(params, (Direction.CLOCKWISE, Direction.COUNTERCLOCKWISE), Direction.CLOCKWISE)
    particles = _integer(params, 'particles', 46, minimum=8, maximum=90)
    turns = _number(params, 'turns', 2.1, minimum=0.4, maximum=5)
    radius = _number(params, 'radius', 250, minimum=60, maximum=440)
    seed = _integer(params, 'seed', 2101, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    cx, cy = context.box.center
    sign = 1.0 if direction is Direction.CLOCKWISE else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H7C6655&', '&H9A8370&', '&H675446&'), (198, 210, 216))
    for radius_scale, line_alpha, line_blur, line_border, layer in ((1.28, 188, 8.0, 11.0, 2), (1.0, 46, 2.3, 4.0, 5), (0.7, 92, 1.2, 2.0, 6)):
        spiral = _spiral_path(turns + 0.25 * radius_scale, radius * radius_scale, samples=128)
        result.append(_moving_shape(event, 0, event.duration_ms, spiral, x0=cx, y0=cy + 42, x1=cx + sign * 18, y1=cy - 38, color='&HDEC5A9&', alpha=line_alpha, scale0=88, scale1=116, rotation0=0, rotation1=sign * (260 + radius_scale * 80), blur=line_blur, border=line_border, outline='&HDEC5A9&', fill=False, clip=scene, layer_offset=layer, fade_in=240, fade_out=320))
    for pulse_index in range(3):
        ring = _pulse_ring(event, round((0.18 + pulse_index * 0.23) * event.duration_ms), 850, x=cx, y=cy + radius * 0.34, rx=max(28, round(radius * 0.32)), ry=max(8, round(radius * 0.09)), color='&HD8B78F&', border=3.0, scale0=50, scale1=180, alpha0=105, clip=scene, layer_offset=4)
        if ring is not None:
            result.append(ring)
    particle_path = _diamond_path(6, 8)
    points = _sample_times(event.duration_ms, max(100, context.motion_step_ms + 20))
    for index in range(particles):
        phase = _seed_value(seed, index, 1) * 2 * math.pi
        base_radius = radius * (0.28 + 0.78 * _seed_value(seed, index, 2))
        vertical = 20 + 80 * _seed_value(seed, index, 3)
        for first, second in zip(points, points[1:]):
            t0 = first / event.duration_ms
            t1 = second / event.duration_ms
            visible0 = _presence_for_line(first, event.duration_ms, start, end)
            visible1 = _presence_for_line(second, event.duration_ms, start, end)
            if visible0 <= 0 and visible1 <= 0:
                continue
            a0 = phase + sign * 2 * math.pi * turns * t0
            a1 = phase + sign * 2 * math.pi * turns * t1
            r0 = base_radius * (0.95 - 0.3 * t0)
            r1 = base_radius * (0.95 - 0.3 * t1)
            x0, y0 = _orbit_position(cx, cy + 35 - vertical * t0, r0, r0 * 0.52, a0)
            x1, y1 = _orbit_position(cx, cy + 35 - vertical * t1, r1, r1 * 0.52, a1)
            alpha = 70 + round(115 * _seed_value(seed, index, 4))
            result.append(_moving_shape(event, first, second, particle_path, x0=x0, y0=y0, x1=x1, y1=y1, color='&H9C7D55&' if index % 3 else '&HDBB98B&', alpha=min(245, alpha + _alpha_from_presence(min(visible0, visible1)) // 3), scale0=35 + 75 * _seed_value(seed, index, 5), rotation0=math.degrees(a0), rotation1=math.degrees(a1) + sign * 70, blur=0.6, clip=scene, layer_offset=7 if index % 4 else 10, fade_in=0, fade_out=0))
    result.extend(_themed_text(event, start, end, context, primary='&HFFF8ED&', outline='&H5B4636&', glow='&HD9B987&', glow_alpha=96, border=4.5))
    return result

def _effect_tornado(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'rings', 'debris', 'width', 'seed'})
    direction = _direction(params, (Direction.CLOCKWISE, Direction.COUNTERCLOCKWISE), Direction.CLOCKWISE)
    rings = _integer(params, 'rings', 14, minimum=6, maximum=24)
    debris = _integer(params, 'debris', 34, minimum=8, maximum=70)
    width = _number(params, 'width', 330, minimum=120, maximum=560)
    seed = _integer(params, 'seed', 2203, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    cx = (box.x1 + box.x2) / 2
    top_y = scene.y1 + 95
    bottom_y = scene.y2 - 65
    sign = 1.0 if direction is Direction.CLOCKWISE else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H3F3A42&', '&H5B555D&', '&H302C33&'), (112, 132, 150))
    _add_clouds(result, event, context, count=6, seed=seed, direction=Direction.LEFT_TO_RIGHT if sign > 0 else Direction.RIGHT_TO_LEFT, color='&H423F48&', alpha=34, y_min=scene.y1, y_max=scene.y1 + 72, drift=130, layer_offset=2, blur=12, scale_min=150, scale_max=240)
    funnel = _polygon_path(((cx - width * 0.54, top_y - 24), (cx + width * 0.54, top_y - 24), (cx + width * 0.1, bottom_y + 20), (cx - width * 0.1, bottom_y + 20)))
    result.append(_static_drawing(event, funnel, color='&H77717C&', alpha=218, blur=16, clip=scene, layer_offset=2, extra_tags=_scene_fade(event, start, end)))
    for dust_index in range(5):
        ring = _pulse_ring(event, round((0.1 + dust_index * 0.16) * event.duration_ms), 980, x=cx, y=bottom_y + 18, rx=round(width * 0.22), ry=max(8, round(width * 0.045)), color='&H9A8272&', border=3.5, scale0=45, scale1=210, alpha0=120, clip=scene, layer_offset=5)
        if ring is not None:
            result.append(ring)
    for index in range(rings):
        t = index / max(1, rings - 1)
        y = top_y + (bottom_y - top_y) * t
        rx = round(width * (0.52 - 0.4 * t))
        ry = max(8, round(rx * 0.18))
        phase_x = sign * (18 * math.sin(index * 0.8))
        path = _ellipse_path(rx, ry)
        result.append(_moving_shape(event, 0, event.duration_ms, path, x0=cx - phase_x, y0=y, x1=cx + phase_x, y1=y - 6 * t, color='&HAAA2AF&', alpha=65 + round(100 * t), scale0=85, scale1=110, rotation0=0, rotation1=sign * (180 + index * 22), blur=3 + t * 4, border=max(2.0, 7.0 - t * 4.0), outline='&HAAA2AF&', fill=False, clip=scene, layer_offset=3 + index % 3, fade_in=220, fade_out=320))
    particle_path = _diamond_path(7, 9)
    points = _sample_times(event.duration_ms, max(105, context.motion_step_ms + 25))
    for index in range(debris):
        base_t = _seed_value(seed, index, 10)
        phase = _seed_value(seed, index, 11) * 2 * math.pi
        for first, second in zip(points, points[1:]):
            t0 = first / event.duration_ms
            t1 = second / event.duration_ms
            v0 = _presence_for_line(first, event.duration_ms, start, end)
            v1 = _presence_for_line(second, event.duration_ms, start, end)
            if v0 <= 0 and v1 <= 0:
                continue
            vertical0 = _fractional(base_t + t0 * (0.42 + 0.35 * _seed_value(seed, index, 12)))
            vertical1 = _fractional(base_t + t1 * (0.42 + 0.35 * _seed_value(seed, index, 12)))
            y0 = bottom_y - (bottom_y - top_y) * vertical0
            y1 = bottom_y - (bottom_y - top_y) * vertical1
            radius0 = width * (0.1 + 0.42 * (1 - vertical0))
            radius1 = width * (0.1 + 0.42 * (1 - vertical1))
            a0 = phase + sign * 2 * math.pi * (2.2 * t0 + vertical0)
            a1 = phase + sign * 2 * math.pi * (2.2 * t1 + vertical1)
            x0 = cx + math.cos(a0) * radius0
            x1 = cx + math.cos(a1) * radius1
            result.append(_moving_shape(event, first, second, particle_path, x0=x0, y0=y0 + math.sin(a0) * radius0 * 0.17, x1=x1, y1=y1 + math.sin(a1) * radius1 * 0.17, color='&H75645A&' if index % 3 else '&HB09D8E&', alpha=35 + round(100 * _seed_value(seed, index, 13)), scale0=35 + 85 * _seed_value(seed, index, 14), rotation0=math.degrees(a0), rotation1=math.degrees(a1) + sign * 100, blur=0.7, clip=scene, layer_offset=8 if index % 4 else 11, fade_in=0, fade_out=0))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFFFF&', outline='&H332E36&', glow='&HB5ADB9&', glow_alpha=96, border=5.0))
    return result

def _effect_sandstorm(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'grains', 'bands', 'speed', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    grains = _integer(params, 'grains', 92, minimum=24, maximum=200)
    bands = _integer(params, 'bands', 6, minimum=2, maximum=12)
    speed = _number(params, 'speed', 560, minimum=180, maximum=1500)
    seed = _integer(params, 'seed', 2309, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H4B7391&', '&H6289A6&', '&H3D607B&'), (136, 158, 172))
    dune = _wave_polygon(scene.x1 - 150, scene.x2 + 150, box.y2 + 115, scene.y2 + 10, 34, 420, 0.06)
    result.append(_moving_absolute_drawing(event, 0, event.duration_ms, dune, dx0=-sign * 90, dy0=0, dx1=sign * 90, dy1=0, color='&H3D678B&', alpha=70, blur=5, clip=scene, layer_offset=2, fade_in=220, fade_out=280))
    for index in range(bands):
        y = scene.y1 + scene.height * (0.14 + 0.72 * (index + 0.5) / bands)
        thickness = 14 + 22 * _seed_value(seed, index, 1)
        path = _wavy_line(scene.x1 - 220, scene.x2 + 220, y, 12 + 14 * _seed_value(seed, index, 2), 260, index * 0.19, samples=96)
        result.append(_moving_absolute_drawing(event, 0, event.duration_ms, path, dx0=-sign * 180, dy0=0, dx1=sign * 180, dy1=0, color='&H5C82A0&', alpha=190 + min(38, index * 7), blur=8.0 + index * 0.7, border=4.0 + thickness * 0.22, outline='&H5C82A0&', fill=False, clip=scene, layer_offset=4, fade_in=220, fade_out=300))
    grain_path = _ellipse_path(3, 2)
    travel_ms = (scene.width + 120) / speed * 1000
    for index, begin, finish, f0, f1, speed_scale in _iter_particle_passes(event.duration_ms, count=grains, travel_ms=travel_ms, seed=seed + 100):
        x_start = scene.x1 - 60 if sign > 0 else scene.x2 + 60
        x_end = scene.x2 + 60 if sign > 0 else scene.x1 - 60
        y = scene.y1 + _seed_value(seed, index, 10) * scene.height
        wave0 = math.sin((f0 + _seed_value(seed, index, 11)) * math.pi * 4) * 22
        wave1 = math.sin((f1 + _seed_value(seed, index, 11)) * math.pi * 4) * 22
        result.append(_moving_shape(event, begin, finish, grain_path, x0=x_start + (x_end - x_start) * f0, y0=y + wave0, x1=x_start + (x_end - x_start) * f1, y1=y + wave1, color='&H5E8FB2&' if index % 3 else '&H8BB5CA&', alpha=35 + round(150 * _seed_value(seed, index, 12)), scale0=30 + 100 * _seed_value(seed, index, 13), blur=0.5 + 1.2 * _seed_value(seed, index, 14), clip=scene, layer_offset=7 if index % 4 else 10, fade_in=20, fade_out=40))
    result.extend(_themed_text(event, start, end, context, primary='&HFFF4DC&', outline='&H4A6575&', glow='&H73A4C1&', glow_alpha=86, border=5.2))
    return result

def _effect_heat_haze(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'bands', 'distortion', 'wisps', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    bands = _integer(params, 'bands', 8, minimum=3, maximum=16)
    distortion = _number(params, 'distortion', 14, minimum=2, maximum=45)
    wisps = _integer(params, 'wisps', 16, minimum=4, maximum=40)
    seed = _integer(params, 'seed', 2401, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    anchor_x, anchor_y = _event_anchor(event, context)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H5E86B2&', '&H6FA6CE&', '&H416F9F&'), (158, 180, 194))
    horizon = Rect(scene.x1, box.y2 + 105, scene.x2, box.y2 + 114)
    result.append(_static_drawing(event, _rect_path(horizon), color='&H4CCBFF&', alpha=80, blur=8, clip=scene, layer_offset=2, extra_tags=_scene_fade(event, start, end)))
    for index in range(wisps):
        x = scene.x1 + _seed_value(seed, index, 1) * scene.width
        y0 = box.y2 + 115 + _seed_value(seed, index, 2) * 35
        height = 120 + 130 * _seed_value(seed, index, 3)
        points = []
        for step in range(9):
            t = step / 8
            points.append((math.sin((t * 2.5 + _seed_value(seed, index, 4)) * math.pi) * 12, -height * t))
        path = _polyline_path(points)
        result.append(_moving_shape(event, 0, event.duration_ms, path, x0=x - sign * 12, y0=y0, x1=x + sign * 12, y1=y0 - 18, color='&HFFF1CF&', alpha=155 + round(35 * _seed_value(seed, index, 6)), scale0=80 + 55 * _seed_value(seed, index, 5), blur=7, border=2.0 + 2.5 * _seed_value(seed, index, 6), outline='&HFFF1CF&', fill=False, clip=scene, layer_offset=3, fade_in=260, fade_out=320))
    result.extend(_themed_text(event, start, end, context, primary='&HFFEFE0&', outline='&H654D43&', glow='&H5CC6FF&', glow_alpha=122, border=4.4))
    band_height = box.height / bands
    for band in range(bands):
        y1 = round(box.y1 + band * band_height)
        y2 = box.y2 if band == bands - 1 else round(box.y1 + (band + 1) * band_height + 1)
        clip = Rect(box.x1 - 12, y1, box.x2 + 12, max(y1 + 1, y2))
        phase = _seed_value(seed, band, 10) * math.pi * 2

        def state(t: float, t_ms: int, *, phase: float=phase, band: int=band) -> MotionState:
            visible = _presence_for_line(t_ms, event.duration_ms, start, end)
            offset = sign * distortion * math.sin(2 * math.pi * (1.1 * t + band * 0.16) + phase)
            lift = 2.5 * math.sin(2 * math.pi * (0.7 * t + band * 0.11) + phase)
            return MotionState(anchor_x + offset, anchor_y + lift, shear_x=sign * 0.018 * math.sin(2 * math.pi * t + phase), alpha=max(96, _alpha_from_presence(visible, floor=96)), primary_color='&HFFF8E9&', outline_color='&H7A594A&', border=3.2, blur=0.9 + 0.6 * abs(math.sin(2 * math.pi * t + phase)), shadow=0.0)
        result.extend(_emit_sampled_line(event, context, state, layer_offset=11, step_ms=max(75, context.motion_step_ms), clip_fn=lambda t, ms, clip=clip: clip))
    return result

def _moving_absolute_drawing(event: DialogueEvent, begin: int, finish: int, path: str, *, dx0: float, dy0: float, dx1: float, dy1: float, color: str, alpha: int, blur: float=0.0, border: float=0.0, outline: str | None=None, fill: bool=True, clip: Rect | None=None, layer_offset: int=1, fade_in: int=180, fade_out: int=240, extra_tags: str='') -> DialogueEvent:
    duration = finish - begin
    if duration <= 0:
        raise EffectError('moving absolute drawing duration must be positive')
    color = _ass_color(color)
    outline_color = _ass_color(outline or color)
    fill_tags = f'\\1c{color}\\1a{_format_alpha(alpha)}' if fill else '\\1a&HFF&'
    outline_alpha = alpha if fill or alpha != 255 else 0
    tags = f'\\an7\\move({_fmt(dx0)},{_fmt(dy0)},{_fmt(dx1)},{_fmt(dy1)},0,{duration})' + fill_tags + f'\\3c{outline_color}\\3a{_format_alpha(outline_alpha)}\\bord{_fmt(border)}\\blur{_fmt(blur)}' + _clip_tag(clip) + f'\\fad({fade_in},{fade_out})' + extra_tags
    return _drawing_event(event, begin, finish, path, tags, layer_offset=layer_offset)

def _effect_ocean_swell(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'layers', 'amplitude', 'wavelength', 'foam'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    layers = _integer(params, 'layers', 4, minimum=2, maximum=8)
    amplitude = _number(params, 'amplitude', 48, minimum=10, maximum=120)
    wavelength = _number(params, 'wavelength', 360, minimum=120, maximum=900)
    foam = _integer(params, 'foam', 24, minimum=6, maximum=60)
    scene = _scene_box(context)
    box = context.box
    anchor_x, anchor_y = _event_anchor(event, context)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H533B2B&', '&H79563B&', '&H342519&'), (128, 158, 176))
    palette = ('&HA76B3E&', '&HC5824B&', '&HE0A266&', '&HF2C58A&')
    for layer in range(layers):
        baseline = box.y2 + 35 + layer * 32
        amp = amplitude * (0.52 + 0.24 * layer)
        wave = wavelength * (0.82 + 0.18 * layer)
        phase = layer * 0.17
        path = _wave_polygon(scene.x1 - 260, scene.x2 + 260, baseline, scene.y2 + 60, amp, wave, phase)
        drift = 80 + layer * 46
        result.append(_moving_absolute_drawing(event, 0, event.duration_ms, path, dx0=-sign * drift, dy0=0, dx1=sign * drift, dy1=0, color=palette[layer % len(palette)], alpha=100 + layer * 22, blur=2.5 + layer * 1.2, clip=scene, layer_offset=2 + layer, fade_in=220, fade_out=300))
        crest = _wavy_line(scene.x1 - 260, scene.x2 + 260, baseline, amp, wave, phase)
        result.append(_moving_absolute_drawing(event, 0, event.duration_ms, crest, dx0=-sign * drift, dy0=0, dx1=sign * drift, dy1=0, color='&HFFFFFF&', alpha=255, blur=1.3, border=max(1.0, 3.5 - layer * 0.45), outline='&HFFF5DF&', fill=False, clip=scene, layer_offset=5 + layer, fade_in=220, fade_out=300))
    seed = 2501
    foam_path = _ellipse_path(5, 3)
    for index in range(foam):
        begin = round(_seed_value(seed, index, 1) * event.duration_ms * 0.55)
        finish = min(event.duration_ms, begin + 1200 + round(900 * _seed_value(seed, index, 2)))
        if finish - begin < 40:
            continue
        x0 = scene.x1 - 30 if sign > 0 else scene.x2 + 30
        x1 = scene.x2 + 30 if sign > 0 else scene.x1 - 30
        lane = index % layers
        base_y = box.y2 + 30 + lane * 30
        result.append(_moving_shape(event, begin, finish, foam_path, x0=x0, y0=base_y + math.sin(index * 0.8) * amplitude * 0.45, x1=x1, y1=base_y - 10 + math.sin(index * 0.8 + 2.4) * amplitude * 0.45, color='&HFFF7E8&', alpha=45 + round(90 * _seed_value(seed, index, 3)), scale0=35 + 85 * _seed_value(seed, index, 4), blur=0.7, clip=scene, layer_offset=9, fade_in=80, fade_out=170))

    def text_state(t: float, t_ms: int) -> MotionState:
        visible = _presence_for_line(t_ms, event.duration_ms, start, end)
        bob = math.sin(2 * math.pi * (0.75 * t + 0.1)) * 5.5
        tilt = math.sin(2 * math.pi * (0.75 * t + 0.1)) * 0.8
        return MotionState(anchor_x, anchor_y + bob, rotation_z=tilt, alpha=_alpha_from_presence(visible), primary_color='&HFFFDF5&', outline_color='&H3C2B20&', border=4.5, blur=0.65, shadow=1.0)
    result.extend(_emit_sampled_line(event, context, text_state, layer_offset=11, step_ms=max(85, context.motion_step_ms)))

    def glow_state(t: float, t_ms: int) -> MotionState:
        visible = _presence_for_line(t_ms, event.duration_ms, start, end)
        bob = math.sin(2 * math.pi * (0.75 * t + 0.1)) * 5.5
        return MotionState(anchor_x, anchor_y + bob, alpha=max(90, _alpha_from_presence(visible, floor=90)), primary_color='&HE9B87D&', outline_color='&HE9B87D&', border=11, blur=10, shadow=0)
    result.extend(_emit_sampled_line(event, context, glow_state, layer_offset=8, step_ms=max(95, context.motion_step_ms)))
    return result

def _effect_breaking_wave(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'crest', 'spray', 'foam', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    crest = _number(params, 'crest', 260, minimum=120, maximum=520)
    spray = _integer(params, 'spray', 42, minimum=10, maximum=100)
    foam = _integer(params, 'foam', 30, minimum=8, maximum=80)
    seed = _integer(params, 'seed', 2609, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H4C3121&', '&H6E4931&', '&H2C1D14&'), (120, 148, 168))
    wave_path = _wave_polygon(scene.x1 - 420, scene.x2 + 420, box.y2 + 65, scene.y2 + 80, 66, 300, 0.15, samples=96)
    result.append(_moving_absolute_drawing(event, 0, event.duration_ms, wave_path, dx0=-sign * 330, dy0=0, dx1=sign * 330, dy1=18, color='&HAD6F40&', alpha=46, blur=3.5, clip=scene, layer_offset=4, fade_in=200, fade_out=330))
    curl_x0 = scene.x1 - crest * 0.45 if sign > 0 else scene.x2 + crest * 0.45
    curl_x1 = box.x2 - crest * 0.1 if sign > 0 else box.x1 + crest * 0.1
    curl_y = box.y1 + box.height * 0.46
    curl_clip = Rect(scene.x1, scene.y1, scene.x2, box.y2 + 115)
    for width, alpha, blur, layer in ((24, 170, 9, 5), (8, 38, 2.0, 8)):
        result.append(_moving_shape(event, 0, min(event.duration_ms, round(event.duration_ms * 0.78)), _breaking_curl_path(crest * 0.92, crest * 0.64, sign), x0=curl_x0, y0=curl_y + 30, x1=curl_x1, y1=curl_y - 12, color='&HFFF7E8&', alpha=alpha, scale0=68, scale1=118, rotation0=-sign * 10, rotation1=sign * 18, blur=blur, border=width, outline='&HFFF7E8&', fill=False, clip=curl_clip, layer_offset=layer, fade_in=130, fade_out=320))
    droplet = _ellipse_path(4, 6)
    for index in range(spray):
        begin = round((0.18 + 0.38 * _seed_value(seed, index, 1)) * event.duration_ms)
        apex = 220 + round(360 * _seed_value(seed, index, 2))
        finish = min(event.duration_ms, begin + 620 + round(480 * _seed_value(seed, index, 3)))
        if finish - begin < 60:
            continue
        origin_x = curl_x1 - sign * (40 + 120 * _seed_value(seed, index, 4))
        origin_y = curl_y + 25 * (_seed_value(seed, index, 5) - 0.5)
        mid = begin + (finish - begin) // 2
        scale = 40 + 90 * _seed_value(seed, index, 6)
        if mid - begin > 30:
            result.append(_moving_shape(event, begin, mid, droplet, x0=origin_x, y0=origin_y, x1=origin_x + sign * (40 + 150 * _seed_value(seed, index, 7)), y1=origin_y - apex, color='&HFFF9EF&', alpha=25 + round(70 * _seed_value(seed, index, 8)), scale0=scale, rotation0=sign * 15, blur=0.8, clip=scene, layer_offset=10, fade_in=25, fade_out=0))
        if finish - mid > 30:
            result.append(_moving_shape(event, mid, finish, droplet, x0=origin_x + sign * (40 + 150 * _seed_value(seed, index, 7)), y0=origin_y - apex, x1=origin_x + sign * (110 + 240 * _seed_value(seed, index, 9)), y1=box.y2 + 110, color='&HFFF9EF&', alpha=35 + round(70 * _seed_value(seed, index, 8)), scale0=scale, rotation0=sign * 15, blur=0.8, clip=scene, layer_offset=10, fade_in=0, fade_out=100))
    foam_path = _ellipse_path(8, 5)
    for index in range(foam):
        begin = round((0.3 + 0.5 * _seed_value(seed, index, 20)) * event.duration_ms)
        finish = min(event.duration_ms, begin + 600 + round(500 * _seed_value(seed, index, 21)))
        if finish - begin < 40:
            continue
        x = box.x1 + _seed_value(seed, index, 22) * box.width
        y = box.y2 + 65 + (_seed_value(seed, index, 23) - 0.5) * 55
        result.append(_moving_shape(event, begin, finish, foam_path, x0=x, y0=y, x1=x - sign * (50 + 90 * _seed_value(seed, index, 24)), y1=y + 12, color='&HFFF8ED&', alpha=55, scale0=45 + 100 * _seed_value(seed, index, 25), scale1=70 + 130 * _seed_value(seed, index, 26), blur=1.1, clip=scene, layer_offset=9, fade_in=50, fade_out=220))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFFFF&', outline='&H322117&', glow='&HDB9E69&', glow_alpha=72, border=5.0))
    return result

def _effect_rising_tide(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'level', 'surge', 'glints', 'seed'})
    level = _number(params, 'level', 110, minimum=20, maximum=260)
    surge = _number(params, 'surge', 95, minimum=10, maximum=220)
    glints = _integer(params, 'glints', 20, minimum=4, maximum=60)
    seed = _integer(params, 'seed', 2707, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    anchor_x, anchor_y = _event_anchor(event, context)
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H493126&', '&H694636&', '&H2D1D16&'), (138, 164, 180))
    points = _sample_times(event.duration_ms, max(75, context.motion_step_ms))
    target = max(scene.y1 + 20, box.y2 - min(level, box.height * 0.82))
    bottom = scene.y2 + 10
    base_text = _remove_position_tags(event.text)
    for first, second in zip(points, points[1:]):
        t0 = first / event.duration_ms
        t1 = second / event.duration_ms
        presence0 = _presence_for_line(first, event.duration_ms, start, end)
        presence1 = _presence_for_line(second, event.duration_ms, start, end)
        line0 = bottom - (bottom - target) * presence0 + math.sin(2 * math.pi * (1.15 * t0)) * surge * 0.08
        line1 = bottom - (bottom - target) * presence1 + math.sin(2 * math.pi * (1.15 * t1)) * surge * 0.08
        line_mid = (line0 + line1) / 2
        if line_mid < scene.y2:
            water_top = max(scene.y1, min(scene.y2 - 1, round(line_mid)))
            water_rect = Rect(scene.x1, water_top, scene.x2, scene.y2)
            result.append(_static_drawing(event, _rect_path(water_rect), color='&HAD7048&', alpha=86, blur=2.5, clip=scene, layer_offset=4, start=first, end=second))
        surface = _wavy_line(scene.x1 - 30, scene.x2 + 30, line_mid, 7, 220, t0 * 1.4)
        result.append(_static_drawing(event, surface, color='&HFFFFFF&', alpha=255, blur=1.2, border=2.0, outline='&HFFF3D5&', fill=False, clip=scene, layer_offset=7, start=first, end=second))
        above_y2 = max(scene.y1 + 1, min(scene.y2, round(line_mid)))
        below_y1 = max(scene.y1, min(scene.y2 - 1, round(line_mid)))
        if above_y2 > scene.y1:
            tags = f'\\an5\\pos({_fmt(anchor_x)},{_fmt(anchor_y)})\\1c&HFFFDF8&\\3c&H3C291F&\\bord4.4\\blur0.65' + f'\\clip({scene.x1},{scene.y1},{scene.x2},{above_y2})'
            result.append(_clone(event, start_ms=event.start_ms + first, end_ms=event.start_ms + second, layer=event.layer + 10, text=_add_tags(base_text, tags)))
        if below_y1 < scene.y2:
            tags = f'\\an5\\pos({_fmt(anchor_x)},{_fmt(anchor_y)})\\1c&HFFCAA0&\\3c&H5F3F2C&\\bord4.8\\blur1.0' + f'\\clip({scene.x1},{below_y1},{scene.x2},{scene.y2})'
            result.append(_clone(event, start_ms=event.start_ms + first, end_ms=event.start_ms + second, layer=event.layer + 10, text=_add_tags(base_text, tags)))
    for index in range(glints):
        begin = round(_seed_value(seed, index, 1) * event.duration_ms * 0.75)
        finish = min(event.duration_ms, begin + 520)
        if finish - begin < 35:
            continue
        t = begin / event.duration_ms
        presence = _presence_for_line(begin, event.duration_ms, start, end)
        line = bottom - (bottom - target) * presence + math.sin(2 * math.pi * 1.15 * t) * surge * 0.08
        x = scene.x1 + _seed_value(seed, index, 2) * scene.width
        result.append(_moving_shape(event, begin, finish, _star_path(7, 2, 4), x0=x - 14, y0=line, x1=x + 14, y1=line - 2, color='&HFFF1C7&', alpha=0, scale0=30, scale1=120, rotation0=0, rotation1=70, blur=1.1, clip=scene, layer_offset=11, fade_in=45, fade_out=180))
    return result

def _effect_waterfall(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'streams', 'mist', 'splashes', 'seed'})
    streams = _integer(params, 'streams', 16, minimum=5, maximum=36)
    mist = _integer(params, 'mist', 36, minimum=8, maximum=80)
    splashes = _integer(params, 'splashes', 24, minimum=6, maximum=60)
    seed = _integer(params, 'seed', 2801, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    ground = box.y2 + 112
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H463126&', '&H644737&', '&H2B1E17&'), (128, 154, 172))
    lip = _wave_polygon(scene.x1 - 80, scene.x2 + 80, scene.y1 + 56, scene.y1 + 112, 14, 230, 0.08, samples=72)
    result.append(_static_drawing(event, lip, color='&H30231D&', alpha=42, blur=2.4, clip=scene, layer_offset=2, extra_tags=_scene_fade(event, start, end)))
    for index in range(streams):
        x = scene.x1 + scene.width * (index + 0.5) / streams
        width = 10 + 26 * _seed_value(seed, index, 1)
        path = _vertical_ribbon_path(width, 220, 5 + 11 * _seed_value(seed, index, 12), _seed_value(seed, index, 13), samples=16)
        for pass_index in range(3):
            begin = max(0, round((pass_index - _seed_value(seed, index, 2)) * event.duration_ms / 2.2))
            finish = min(event.duration_ms, begin + round(event.duration_ms / 1.6))
            if finish - begin < 40:
                continue
            result.append(_moving_shape(event, begin, finish, path, x0=x + (_seed_value(seed, index, pass_index + 3) - 0.5) * 20, y0=scene.y1 - 100, x1=x + (_seed_value(seed, index, pass_index + 6) - 0.5) * 20, y1=ground + 80, color='&HFFD8B4&' if index % 3 else '&HFFF3E2&', alpha=70 + round(95 * _seed_value(seed, index, 9)), scale0=75 + 70 * _seed_value(seed, index, 10), blur=2.0 + 2.5 * _seed_value(seed, index, 11), clip=scene, layer_offset=3 + index % 3, fade_in=35, fade_out=70))
    cloud = _cloud_path(75, 35)
    for index in range(mist):
        x = scene.x1 + _seed_value(seed, index, 20) * scene.width
        y = ground + (_seed_value(seed, index, 21) - 0.5) * 45
        scale = 45 + 90 * _seed_value(seed, index, 22)
        result.append(_moving_shape(event, 0, event.duration_ms, cloud, x0=x - 20, y0=y, x1=x + 20, y1=y - 45 - 45 * _seed_value(seed, index, 23), color='&HFFF5ED&', alpha=130 + round(70 * _seed_value(seed, index, 24)), scale0=scale, scale1=scale * 1.6, blur=6, clip=scene, layer_offset=7, fade_in=180, fade_out=300))
    droplet = _ellipse_path(4, 6)
    for index in range(splashes):
        begin = round(_seed_value(seed, index, 30) * event.duration_ms * 0.72)
        finish = min(event.duration_ms, begin + 520 + round(300 * _seed_value(seed, index, 31)))
        if finish - begin < 40:
            continue
        x = scene.x1 + _seed_value(seed, index, 32) * scene.width
        y = ground
        side = -1 if index % 2 else 1
        result.append(_moving_shape(event, begin, finish, droplet, x0=x, y0=y, x1=x + side * (30 + 85 * _seed_value(seed, index, 33)), y1=y - 70 - 95 * _seed_value(seed, index, 34), color='&HFFFFFF&', alpha=25, scale0=40 + 75 * _seed_value(seed, index, 35), rotation0=side * 16, blur=0.7, clip=scene, layer_offset=10, fade_in=20, fade_out=190))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFFFF&', outline='&H302019&', glow='&HFFD6B0&', glow_alpha=76, border=4.8))
    return result

def _effect_river_current(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'ribbons', 'foam', 'speed', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    ribbons = _integer(params, 'ribbons', 7, minimum=3, maximum=14)
    foam = _integer(params, 'foam', 26, minimum=6, maximum=70)
    speed = _number(params, 'speed', 300, minimum=80, maximum=800)
    seed = _integer(params, 'seed', 2903, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H5E3B2A&', '&H80543A&', '&H3F281D&'), (148, 172, 188))
    for index in range(ribbons):
        y = box.y1 - 30 + (box.height + 150) * (index + 0.5) / ribbons
        amplitude = 12 + 18 * _seed_value(seed, index, 1)
        wavelength = 250 + 170 * _seed_value(seed, index, 2)
        path = _wavy_line(scene.x1 - 240, scene.x2 + 240, y, amplitude, wavelength, _seed_value(seed, index, 3))
        drift = speed * event.duration_ms / 1000 * (0.32 + 0.18 * index / max(1, ribbons - 1))
        result.append(_moving_absolute_drawing(event, 0, event.duration_ms, path, dx0=-sign * drift / 2, dy0=0, dx1=sign * drift / 2, dy1=0, color='&HDEA67D&' if index % 2 else '&HFFCF9E&', alpha=255, blur=1.2 + index * 0.2, border=2.5 + 2.2 * _seed_value(seed, index, 4), outline='&HDEA67D&' if index % 2 else '&HFFCF9E&', fill=False, clip=scene, layer_offset=3 + index % 3, fade_in=220, fade_out=280))
    for index in range(5):
        x = scene.x1 + scene.width * (0.12 + 0.18 * index)
        y = box.y2 + 112 + (_seed_value(seed, index, 10) - 0.5) * 28
        result.append(_static_drawing(event, _ellipse_path_at(x, y, 36 + round(22 * _seed_value(seed, index, 11)), 12 + round(7 * _seed_value(seed, index, 12))), color='&H2D2422&', alpha=80, blur=2.2, clip=scene, layer_offset=2, extra_tags=_scene_fade(event, start, end)))
    foam_path = _ellipse_path(6, 4)
    travel_ms = (scene.width + 80) / speed * 1000
    for index, begin, finish, f0, f1, speed_scale in _iter_particle_passes(event.duration_ms, count=foam, travel_ms=travel_ms, seed=seed + 100):
        x_start = scene.x1 - 40 if sign > 0 else scene.x2 + 40
        x_end = scene.x2 + 40 if sign > 0 else scene.x1 - 40
        lane = index % ribbons
        y_base = box.y1 - 25 + (box.height + 150) * (lane + 0.5) / ribbons
        phase = _seed_value(seed, index, 20)
        y0 = y_base + math.sin((f0 + phase) * math.pi * 4) * 18
        y1 = y_base + math.sin((f1 + phase) * math.pi * 4) * 18
        result.append(_moving_shape(event, begin, finish, foam_path, x0=x_start + (x_end - x_start) * f0, y0=y0, x1=x_start + (x_end - x_start) * f1, y1=y1, color='&HFFF5E7&', alpha=45 + round(100 * _seed_value(seed, index, 21)), scale0=35 + 90 * _seed_value(seed, index, 22), blur=0.6, clip=scene, layer_offset=9, fade_in=30, fade_out=45))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFDF4&', outline='&H3D2B22&', glow='&HE7B685&', glow_alpha=90, border=4.4))
    return result

def _effect_whirlpool(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'rings', 'foam', 'turns', 'seed'})
    direction = _direction(params, (Direction.CLOCKWISE, Direction.COUNTERCLOCKWISE), Direction.CLOCKWISE)
    rings = _integer(params, 'rings', 11, minimum=5, maximum=20)
    foam = _integer(params, 'foam', 34, minimum=8, maximum=70)
    turns = _number(params, 'turns', 2.0, minimum=0.5, maximum=5)
    seed = _integer(params, 'seed', 3001, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    cx, cy = box.center
    cy += 38
    sign = 1.0 if direction is Direction.CLOCKWISE else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H3E2A20&', '&H5B3D2D&', '&H251912&'), (118, 146, 166))
    result.append(_static_drawing(event, _ellipse_path_at(cx, cy, round(box.width * 0.34), round(box.height * 0.78)), color='&H24140E&', alpha=88, blur=10, clip=scene, layer_offset=2, extra_tags=_scene_fade(event, start, end)))
    for index in range(rings):
        scale = 0.28 + 0.72 * (index + 1) / rings
        rx = round(box.width * 0.42 * scale)
        ry = max(8, round(box.height * 0.75 * scale))
        result.append(_moving_shape(event, 0, event.duration_ms, _ellipse_path(rx, ry), x0=cx, y0=cy, x1=cx, y1=cy, color='&HF0B87B&', alpha=255, scale0=96, scale1=88 if index % 2 else 103, rotation0=0, rotation1=sign * (180 + index * 26), blur=1.8 + index * 0.22, border=max(1.0, 4.2 - index * 0.18), outline='&HF0B87B&', fill=False, clip=scene, layer_offset=3 + index % 3, fade_in=220, fade_out=300))
    path = _ellipse_path(5, 3)
    points = _sample_times(event.duration_ms, max(95, context.motion_step_ms))
    for index in range(foam):
        phase = _seed_value(seed, index, 1) * 2 * math.pi
        radius0 = box.width * (0.22 + 0.32 * _seed_value(seed, index, 2))
        for first, second in zip(points, points[1:]):
            t0, t1 = (first / event.duration_ms, second / event.duration_ms)
            v0 = _presence_for_line(first, event.duration_ms, start, end)
            v1 = _presence_for_line(second, event.duration_ms, start, end)
            if v0 <= 0 and v1 <= 0:
                continue
            r0 = radius0 * (1.0 - 0.58 * t0)
            r1 = radius0 * (1.0 - 0.58 * t1)
            a0 = phase + sign * 2 * math.pi * turns * t0
            a1 = phase + sign * 2 * math.pi * turns * t1
            x0, y0 = _orbit_position(cx, cy, r0, r0 * 0.34, a0)
            x1, y1 = _orbit_position(cx, cy, r1, r1 * 0.34, a1)
            result.append(_moving_shape(event, first, second, path, x0=x0, y0=y0, x1=x1, y1=y1, color='&HFFF2D7&', alpha=45 + round(100 * _seed_value(seed, index, 3)), scale0=35 + 90 * _seed_value(seed, index, 4), rotation0=math.degrees(a0), rotation1=math.degrees(a1), blur=0.6, clip=scene, layer_offset=8 if index % 4 else 11, fade_in=0, fade_out=0))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFFFF&', outline='&H2A1A14&', glow='&HDB9C66&', glow_alpha=88, border=4.9))
    return result

def _effect_lava_flow(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'channels', 'cracks', 'embers', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    channels = _integer(params, 'channels', 5, minimum=2, maximum=10)
    cracks = _integer(params, 'cracks', 22, minimum=6, maximum=50)
    embers = _integer(params, 'embers', 26, minimum=6, maximum=60)
    seed = _integer(params, 'seed', 3109, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    preferred_ground_y = box.y2 + 74
    # A bottom-aligned lyric can leave less than 74 px below its text box.
    # Reserve a non-empty in-frame crust instead of constructing an inverted
    # Rect.  Normal placements retain the original preferred ground line.
    minimum_crust_height = min(scene.height, max(24, min(72, scene.height // 3)))
    ground_y = max(scene.y1, min(preferred_ground_y, scene.y2 - minimum_crust_height))
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H151018&', '&H21131A&', '&H09080D&'), (54, 72, 88))
    crust = Rect(scene.x1, ground_y, scene.x2, scene.y2)
    result.append(_static_drawing(event, _rect_path(crust), color='&H141317&', alpha=18, blur=2, clip=scene, layer_offset=2, extra_tags=_scene_fade(event, start, end)))
    for index in range(channels):
        y = ground_y + 20 + (scene.y2 - ground_y - 25) * (index + 0.5) / channels
        amplitude = 10 + 18 * _seed_value(seed, index, 1)
        path = _wavy_line(scene.x1 - 220, scene.x2 + 220, y, amplitude, 210 + 100 * _seed_value(seed, index, 2), _seed_value(seed, index, 3))
        drift = 90 + 70 * index
        for border, blur, color, alpha, layer in ((14, 9, '&H0050FF&', 105, 3), (6, 3, '&H008CFF&', 22, 5), (2, 0.8, '&H4AD8FF&', 0, 7)):
            result.append(_moving_absolute_drawing(event, 0, event.duration_ms, path, dx0=-sign * drift, dy0=0, dx1=sign * drift, dy1=0, color=color, alpha=255, blur=blur, border=border, outline=color, fill=False, clip=scene, layer_offset=layer, fade_in=220, fade_out=300))
    for index in range(cracks):
        x = scene.x1 + _seed_value(seed, index, 10) * scene.width
        y = ground_y + _seed_value(seed, index, 11) * max(1, scene.y2 - ground_y)
        length = 25 + 75 * _seed_value(seed, index, 12)
        angle = -0.8 + 1.6 * _seed_value(seed, index, 13)
        points = [(x, y)]
        px, py = (x, y)
        for step in range(3):
            px += math.cos(angle + (_seed_value(seed, index, 14 + step) - 0.5) * 0.8) * length / 3
            py += math.sin(angle + (_seed_value(seed, index, 17 + step) - 0.5) * 0.8) * length / 3
            points.append((px, py))
        result.append(_static_drawing(event, _polyline_path(points), color='&H003FFF&', alpha=255, blur=2.2, border=2.4, outline='&H006CFF&', fill=False, clip=scene, layer_offset=6, extra_tags=_scene_fade(event, start, end)))
    ember_path = _flame_path(6, 11)
    for index in range(embers):
        begin = round(_seed_value(seed, index, 30) * event.duration_ms * 0.68)
        finish = min(event.duration_ms, begin + 820 + round(650 * _seed_value(seed, index, 31)))
        if finish - begin < 40:
            continue
        x = scene.x1 + _seed_value(seed, index, 32) * scene.width
        y = ground_y + 20 + _seed_value(seed, index, 33) * max(1, scene.y2 - ground_y - 20)
        result.append(_moving_shape(event, begin, finish, ember_path, x0=x, y0=y, x1=x + sign * (18 + 55 * _seed_value(seed, index, 34)), y1=y - 100 - 150 * _seed_value(seed, index, 35), color='&H1A96FF&' if index % 3 else '&H55D8FF&', alpha=10 + round(70 * _seed_value(seed, index, 36)), scale0=35 + 80 * _seed_value(seed, index, 37), rotation0=_seed_value(seed, index, 38) * 60, rotation1=_seed_value(seed, index, 38) * 60 + sign * 150, blur=1.2, clip=scene, layer_offset=10, fade_in=40, fade_out=220))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFFFF&', outline='&H1A1016&', glow='&H0086FF&', glow_alpha=40, border=4.8))
    return result

def _effect_ember_drift(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'embers', 'smoke_bands', 'flares', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    embers = _integer(params, 'embers', 52, minimum=12, maximum=120)
    smoke_bands = _integer(params, 'smoke_bands', 5, minimum=2, maximum=10)
    flares = _integer(params, 'flares', 8, minimum=2, maximum=24)
    seed = _integer(params, 'seed', 3203, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H171019&', '&H21141D&', '&H0B090D&'), (58, 76, 92))
    cloud = _cloud_path(210, 58)
    for index in range(smoke_bands):
        y = scene.y1 + scene.height * (0.22 + 0.64 * index / max(1, smoke_bands - 1))
        x = scene.x1 + _seed_value(seed, index, 1) * scene.width
        scale = 170 + 140 * _seed_value(seed, index, 2)
        result.append(_moving_shape(event, 0, event.duration_ms, cloud, x0=x - sign * 120, y0=y, x1=x + sign * 120, y1=y - 25 - 30 * _seed_value(seed, index, 3), color='&H3E3640&', alpha=112 + index * 12, scale0=scale, scale1=scale * 1.22, blur=18, clip=scene, layer_offset=2, fade_in=280, fade_out=340))
    ember_path = _flame_path(5, 10)
    travel_ms = 2200
    for index, begin, finish, f0, f1, speed_scale in _iter_particle_passes(event.duration_ms, count=embers, travel_ms=travel_ms, seed=seed + 100):
        x = scene.x1 + _seed_value(seed, index, 10) * scene.width
        y_start = scene.y2 + 25
        y_end = scene.y1 - 25
        phase = _seed_value(seed, index, 11) * math.pi * 2
        sway0 = math.sin(phase + f0 * math.pi * 4) * (18 + 45 * _seed_value(seed, index, 12))
        sway1 = math.sin(phase + f1 * math.pi * 4) * (18 + 45 * _seed_value(seed, index, 12))
        result.append(_moving_shape(event, begin, finish, ember_path, x0=x + sign * 45 * (f0 - 0.5) + sway0, y0=y_start + (y_end - y_start) * f0, x1=x + sign * 45 * (f1 - 0.5) + sway1, y1=y_start + (y_end - y_start) * f1, color='&H247EFF&' if index % 4 else '&H5ED8FF&', alpha=10 + round(100 * _seed_value(seed, index, 13)), scale0=30 + 90 * _seed_value(seed, index, 14), scale1=35 + 105 * _seed_value(seed, index, 15), rotation0=_seed_value(seed, index, 16) * 90, rotation1=_seed_value(seed, index, 16) * 90 + sign * 180, blur=1.0 + _seed_value(seed, index, 17), clip=scene, layer_offset=7 if index % 4 else 10, fade_in=40, fade_out=120))
    for index in range(flares):
        begin = round((index + 0.4) * event.duration_ms / flares)
        finish = min(event.duration_ms, begin + 520)
        x = box.x1 + _seed_value(seed, index, 20) * box.width
        y = box.y2 + 50 + _seed_value(seed, index, 21) * 100
        result.append(_moving_shape(event, begin, finish, _star_path(11, 3, 5), x0=x, y0=y, x1=x + sign * 16, y1=y - 42, color='&H3EADFF&', alpha=0, scale0=25, scale1=155, rotation0=0, rotation1=110, blur=2.4, clip=scene, layer_offset=11, fade_in=40, fade_out=220))
    result.extend(_themed_text(event, start, end, context, primary='&HFFF8F1&', outline='&H1A1016&', glow='&H247EFF&', glow_alpha=42, border=4.6))
    return result

def _effect_cherry_blossom_storm(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'petals', 'gusts', 'seed'})
    direction = _direction(params, (Direction.CLOCKWISE, Direction.COUNTERCLOCKWISE), Direction.CLOCKWISE)
    petals = _integer(params, 'petals', 54, minimum=16, maximum=120)
    gusts = _integer(params, 'gusts', 4, minimum=1, maximum=8)
    seed = _integer(params, 'seed', 3301, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    cx, cy = box.center
    sign = 1.0 if direction is Direction.CLOCKWISE else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H8E6C85&', '&HB98FA8&', '&H74566D&'), (184, 202, 214))
    branch_origin_x = scene.x1 + 30 if sign > 0 else scene.x2 - 30
    branch_origin_y = scene.y1 + 30
    branch_points = [(branch_origin_x, branch_origin_y), (branch_origin_x + sign * 150, branch_origin_y + 45), (branch_origin_x + sign * 290, branch_origin_y + 85), (branch_origin_x + sign * 430, branch_origin_y + 155)]
    result.append(_static_drawing(event, _polyline_path(branch_points), color='&H59404F&', alpha=255, blur=1.0, border=13, outline='&H59404F&', fill=False, clip=scene, layer_offset=2, extra_tags=_scene_fade(event, start, end)))
    for index in range(7):
        parent = branch_points[1 + index % 3]
        angle = -1.2 + 0.35 * index if sign > 0 else -1.9 - 0.35 * index
        end_point = (parent[0] + math.cos(angle) * (75 + index * 7), parent[1] + math.sin(angle) * (75 + index * 7))
        result.append(_static_drawing(event, _polyline_path((parent, end_point)), color='&H59404F&', alpha=255, blur=0.6, border=5.5, outline='&H59404F&', fill=False, clip=scene, layer_offset=2, extra_tags=_scene_fade(event, start, end)))
    for index in range(gusts):
        y = box.y1 - 50 + index * (box.height + 170) / max(1, gusts - 1)
        path = _wavy_line(scene.x1 - 240, scene.x2 + 240, y, 18 + index * 5, 300, index * 0.21, samples=96)
        result.append(_moving_absolute_drawing(event, 0, event.duration_ms, path, dx0=-sign * 150, dy0=0, dx1=sign * 150, dy1=-12, color='&HFFD5EC&', alpha=198 + index * 7, blur=5.5, border=2.5 + index * 0.7, outline='&HFFD5EC&', fill=False, clip=scene, layer_offset=3, fade_in=240, fade_out=300))
    petal_path = _petal_path(8, 14)
    points = _sample_times(event.duration_ms, max(105, context.motion_step_ms + 20))
    for index in range(petals):
        phase = _seed_value(seed, index, 1) * 2 * math.pi
        radius_x = 90 + _seed_value(seed, index, 2) * scene.width * 0.54
        radius_y = 45 + _seed_value(seed, index, 3) * scene.height * 0.36
        center_x = cx + (_seed_value(seed, index, 4) - 0.5) * scene.width * 0.32
        center_y = cy + (_seed_value(seed, index, 5) - 0.5) * scene.height * 0.3
        fall = 60 + 180 * _seed_value(seed, index, 6)
        for first, second in zip(points, points[1:]):
            t0, t1 = (first / event.duration_ms, second / event.duration_ms)
            v0 = _presence_for_line(first, event.duration_ms, start, end)
            v1 = _presence_for_line(second, event.duration_ms, start, end)
            if v0 <= 0 and v1 <= 0:
                continue
            a0 = phase + sign * 2 * math.pi * (0.62 + 0.55 * _seed_value(seed, index, 7)) * t0
            a1 = phase + sign * 2 * math.pi * (0.62 + 0.55 * _seed_value(seed, index, 7)) * t1
            x0 = center_x + math.cos(a0) * radius_x * (0.55 + 0.45 * t0)
            x1 = center_x + math.cos(a1) * radius_x * (0.55 + 0.45 * t1)
            y0 = center_y + math.sin(a0) * radius_y + fall * t0
            y1 = center_y + math.sin(a1) * radius_y + fall * t1
            color = ('&HFFCBEB&', '&HFFD9F2&', '&HFFFFFF&', '&HEDA4D7&')[index % 4]
            result.append(_moving_shape(event, first, second, petal_path, x0=x0, y0=y0, x1=x1, y1=y1, color=color, alpha=25 + round(105 * _seed_value(seed, index, 8)), scale0=35 + 90 * _seed_value(seed, index, 9), rotation0=math.degrees(a0) + index * 17, rotation1=math.degrees(a1) + index * 17 + sign * 80, blur=0.5 + 1.0 * _seed_value(seed, index, 10), clip=scene, layer_offset=7 if index % 4 else 10, fade_in=0, fade_out=0))
    result.extend(_themed_text(event, start, end, context, primary='&HFFF9FD&', outline='&H704D64&', glow='&HFFB8E4&', glow_alpha=72, border=4.4))
    return result

def _effect_falling_leaves(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'leaves', 'tumble', 'ground_swirl', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    leaves = _integer(params, 'leaves', 40, minimum=10, maximum=90)
    tumble = _number(params, 'tumble', 3.0, minimum=0.5, maximum=8)
    ground_swirl = _integer(params, 'ground_swirl', 18, minimum=4, maximum=40)
    seed = _integer(params, 'seed', 3407, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    ground = box.y2 + 120
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H476B8E&', '&H5F86A7&', '&H385876&'), (172, 190, 204))
    leaf_colors = ('&H2C6FD9&', '&H347FC0&', '&H3D9EEB&', '&H4885A8&', '&H2458B8&')
    leaf_path = _leaf_path(8, 15)
    for index, begin, finish, f0, f1, speed_scale in _iter_particle_passes(event.duration_ms, count=leaves, travel_ms=2600, seed=seed):
        base_x = scene.x1 + _seed_value(seed, index, 1) * scene.width
        phase = _seed_value(seed, index, 2) * math.pi * 2
        drift = sign * (55 + 130 * _seed_value(seed, index, 3))
        y0 = scene.y1 - 30 + (ground - scene.y1 + 30) * f0
        y1 = scene.y1 - 30 + (ground - scene.y1 + 30) * f1
        sway0 = math.sin(phase + tumble * 2 * math.pi * f0) * (18 + 40 * _seed_value(seed, index, 4))
        sway1 = math.sin(phase + tumble * 2 * math.pi * f1) * (18 + 40 * _seed_value(seed, index, 4))
        result.append(_moving_shape(event, begin, finish, leaf_path, x0=base_x + drift * (f0 - 0.5) + sway0, y0=y0, x1=base_x + drift * (f1 - 0.5) + sway1, y1=y1, color=leaf_colors[index % len(leaf_colors)], alpha=20 + round(90 * _seed_value(seed, index, 5)), scale0=45 + 95 * _seed_value(seed, index, 6), rotation0=math.degrees(phase + tumble * 2 * math.pi * f0), rotation1=math.degrees(phase + tumble * 2 * math.pi * f1), blur=0.5 + 0.8 * _seed_value(seed, index, 7), border=0.7, outline='&H274D62&', clip=scene, layer_offset=6 if index % 4 else 10, fade_in=60, fade_out=100))
    swirl_begin = round(event.duration_ms * 0.56)
    swirl_points = _sample_times(event.duration_ms - swirl_begin, max(90, context.motion_step_ms))
    cx = (box.x1 + box.x2) / 2
    for index in range(ground_swirl):
        phase = 2 * math.pi * index / ground_swirl
        radius = 70 + 190 * _seed_value(seed, index, 20)
        for local_first, local_second in zip(swirl_points, swirl_points[1:]):
            first = swirl_begin + local_first
            second = swirl_begin + local_second
            t0 = local_first / max(1, event.duration_ms - swirl_begin)
            t1 = local_second / max(1, event.duration_ms - swirl_begin)
            a0 = phase + sign * 2 * math.pi * 1.2 * t0
            a1 = phase + sign * 2 * math.pi * 1.2 * t1
            x0, y0 = _orbit_position(cx, ground - 8 - 70 * t0, radius * (1 - 0.25 * t0), 22 + 30 * t0, a0)
            x1, y1 = _orbit_position(cx, ground - 8 - 70 * t1, radius * (1 - 0.25 * t1), 22 + 30 * t1, a1)
            result.append(_moving_shape(event, first, second, leaf_path, x0=x0, y0=y0, x1=x1, y1=y1, color=leaf_colors[(index + 2) % len(leaf_colors)], alpha=45, scale0=35 + 70 * _seed_value(seed, index, 21), rotation0=math.degrees(a0), rotation1=math.degrees(a1) + sign * 60, blur=0.5, clip=scene, layer_offset=9, fade_in=0, fade_out=0))
    result.extend(_themed_text(event, start, end, context, primary='&HFFF6E8&', outline='&H36576B&', glow='&H3E88C4&', glow_alpha=82, border=4.5))
    return result

def _effect_firefly_night(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'fireflies', 'glow_radius', 'trails', 'seed'})
    direction = _direction(params, (Direction.CLOCKWISE, Direction.COUNTERCLOCKWISE), Direction.CLOCKWISE)
    fireflies = _integer(params, 'fireflies', 30, minimum=8, maximum=70)
    glow_radius = _number(params, 'glow_radius', 10, minimum=4, maximum=28)
    trails = _integer(params, 'trails', 12, minimum=2, maximum=30)
    seed = _integer(params, 'seed', 3503, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    sign = 1.0 if direction is Direction.CLOCKWISE else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H241D13&', '&H30291A&', '&H110E09&'), (42, 58, 76))
    baseline = box.y2 + 125
    for index in range(24):
        x = scene.x1 + scene.width * (index + 0.5) / 24
        height = 35 + 80 * _seed_value(seed, index, 1)
        bend = (-1 if index % 2 else 1) * (5 + 15 * _seed_value(seed, index, 2))
        result.append(_static_drawing(event, _polyline_path(((x, baseline), (x + bend * 0.4, baseline - height * 0.6), (x + bend, baseline - height))), color='&H26392A&', alpha=255, blur=0.7, border=2.2 + _seed_value(seed, index, 3), outline='&H26392A&', fill=False, clip=scene, layer_offset=2, extra_tags=_scene_fade(event, start, end)))
    body = _ellipse_path(3, 3)
    glow = _ellipse_path(round(glow_radius), round(glow_radius))
    for index in range(fireflies):
        x0 = scene.x1 + _seed_value(seed, index, 10) * scene.width
        y0 = scene.y1 + scene.height * (0.18 + 0.68 * _seed_value(seed, index, 11))
        dx = (35 + 120 * _seed_value(seed, index, 12)) * (1 if _seed_value(seed, index, 13) > 0.5 else -1)
        dy = -35 + 70 * _seed_value(seed, index, 14)
        period = 520 + round(900 * _seed_value(seed, index, 15))
        phase = round(_seed_value(seed, index, 16) * period)
        result.append(_moving_shape(event, 0, event.duration_ms, body, x0=x0 - dx / 2, y0=y0 - dy / 2, x1=x0 + dx / 2, y1=y0 + dy / 2, color='&H78FFB8&', alpha=80, scale0=65, blur=0.8, clip=scene, layer_offset=8, fade_in=200, fade_out=240))
        begin = phase
        pulse_index = 0
        while begin < event.duration_ms:
            finish = min(event.duration_ms, begin + 320)
            if finish - begin > 35:
                t = begin / event.duration_ms
                px = x0 - dx / 2 + dx * t + math.sin((t * 2.7 + index) * math.pi) * 18
                py = y0 - dy / 2 + dy * t + math.cos((t * 2.2 + index) * math.pi) * 12
                result.append(_moving_shape(event, begin, finish, glow, x0=px, y0=py, x1=px + sign * 4, y1=py - 3, color='&H7CFFB0&', alpha=130, scale0=40, scale1=150, blur=4.5, clip=scene, layer_offset=7, fade_in=65, fade_out=170))
                result.append(_moving_shape(event, begin, finish, _star_path(7, 2, 4), x0=px, y0=py, x1=px + sign * 3, y1=py - 2, color='&H8EFFE0&', alpha=0, scale0=25, scale1=100, rotation0=0, rotation1=70, blur=1.0, clip=scene, layer_offset=10, fade_in=50, fade_out=150))
            begin += period
            pulse_index += 1
    for index in range(min(trails, fireflies)):
        x = scene.x1 + _seed_value(seed, index, 30) * scene.width
        y = scene.y1 + scene.height * (0.25 + 0.55 * _seed_value(seed, index, 31))
        points = []
        for step in range(18):
            t = step / 17
            angle = sign * (t * 1.8 * math.pi + _seed_value(seed, index, 32) * math.pi * 2)
            points.append((x + math.cos(angle) * (20 + 45 * t), y + math.sin(angle) * (12 + 28 * t) - 35 * t))
        result.append(_static_drawing(event, _polyline_path(points), color='&H7CFFB0&', alpha=185, blur=3.8, border=1.1, outline='&H7CFFB0&', fill=False, clip=scene, layer_offset=6, extra_tags=_scene_fade(event, start, end)))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFDF1&', outline='&H26352A&', glow='&H72FF9E&', glow_alpha=58, border=4.2))
    return result

def _effect_bioluminescent_tide(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'wave_layers', 'sparks', 'foam', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    wave_layers = _integer(params, 'wave_layers', 3, minimum=2, maximum=6)
    sparks = _integer(params, 'sparks', 46, minimum=12, maximum=100)
    foam = _integer(params, 'foam', 28, minimum=6, maximum=70)
    seed = _integer(params, 'seed', 3607, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H2A1D16&', '&H37271D&', '&H120E0A&'), (52, 68, 82))
    for layer in range(wave_layers):
        baseline = box.y2 + 58 + layer * 34
        amp = 26 + layer * 18
        path = _wave_polygon(scene.x1 - 260, scene.x2 + 260, baseline, scene.y2 + 60, amp, 270 + layer * 70, layer * 0.17)
        drift = 90 + layer * 65
        result.append(_moving_absolute_drawing(event, 0, event.duration_ms, path, dx0=-sign * drift, dy0=0, dx1=sign * drift, dy1=0, color='&H844B2C&' if layer else '&H5D371F&', alpha=58 + layer * 18, blur=2.5 + layer, clip=scene, layer_offset=2 + layer, fade_in=220, fade_out=300))
        crest = _wavy_line(scene.x1 - 260, scene.x2 + 260, baseline, amp, 270 + layer * 70, layer * 0.17)
        result.append(_moving_absolute_drawing(event, 0, event.duration_ms, crest, dx0=-sign * drift, dy0=0, dx1=sign * drift, dy1=0, color='&HFFCC60&', alpha=255, blur=3.0, border=4.0 - layer * 0.4, outline='&HFFCC60&', fill=False, clip=scene, layer_offset=6 + layer, fade_in=220, fade_out=300))
    glow_dot = _ellipse_path(4, 4)
    for index in range(sparks):
        begin = round(_seed_value(seed, index, 1) * event.duration_ms * 0.76)
        finish = min(event.duration_ms, begin + 420 + round(420 * _seed_value(seed, index, 2)))
        if finish - begin < 40:
            continue
        x = scene.x1 + _seed_value(seed, index, 3) * scene.width
        y = box.y2 + 30 + _seed_value(seed, index, 4) * (scene.y2 - box.y2 - 35)
        result.append(_moving_shape(event, begin, finish, glow_dot, x0=x - sign * 15, y0=y + 8, x1=x + sign * 15, y1=y - 8 - 24 * _seed_value(seed, index, 5), color='&HFFDF70&' if index % 3 else '&HFFF1B4&', alpha=55, scale0=30, scale1=130 + 80 * _seed_value(seed, index, 6), blur=3.5, clip=scene, layer_offset=8 if index % 4 else 11, fade_in=70, fade_out=220))
    foam_path = _ellipse_path(7, 4)
    for index in range(foam):
        begin = round(_seed_value(seed, index, 20) * event.duration_ms * 0.7)
        finish = min(event.duration_ms, begin + 850)
        x = scene.x1 + _seed_value(seed, index, 21) * scene.width
        y = box.y2 + 62 + _seed_value(seed, index, 22) * 110
        result.append(_moving_shape(event, begin, finish, foam_path, x0=x, y0=y, x1=x - sign * (35 + 70 * _seed_value(seed, index, 23)), y1=y + 8, color='&HFFF0A4&', alpha=65, scale0=40 + 90 * _seed_value(seed, index, 24), scale1=70 + 120 * _seed_value(seed, index, 25), blur=1.8, clip=scene, layer_offset=9, fade_in=60, fade_out=230))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFDF2&', outline='&H231A13&', glow='&HFFCC55&', glow_alpha=42, border=4.4))
    return result

def _effect_meteor_shower(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'meteors', 'stars', 'radiant_spread', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    meteors = _integer(params, 'meteors', 30, minimum=8, maximum=70)
    stars = _integer(params, 'stars', 55, minimum=16, maximum=130)
    radiant_spread = _number(params, 'radiant_spread', 240, minimum=80, maximum=520)
    seed = _integer(params, 'seed', 3701, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    radiant_x = scene.x1 + scene.width * (0.22 if sign > 0 else 0.78)
    radiant_y = scene.y1 + 42
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H24142E&', '&H301A3D&', '&H110918&'), (46, 60, 78))
    star_path = _star_path(5, 1, 4)
    for index in range(stars):
        x = scene.x1 + _seed_value(seed, index, 1) * scene.width
        y = scene.y1 + _seed_value(seed, index, 2) * scene.height
        scale = 20 + 65 * _seed_value(seed, index, 3)
        alpha = 60 + round(135 * _seed_value(seed, index, 4))
        result.append(_moving_shape(event, 0, event.duration_ms, star_path, x0=x, y0=y, x1=x + sign * (2 + 6 * _seed_value(seed, index, 5)), y1=y - 2, color='&HFFFFFF&' if index % 5 else '&HFFCFB4&', alpha=alpha, scale0=scale, scale1=scale * (0.85 + 0.35 * _seed_value(seed, index, 6)), rotation0=0, rotation1=25, blur=0.4, clip=scene, layer_offset=2, fade_in=220, fade_out=260))
    for index in range(meteors):
        begin = round(_seed_value(seed, index, 10) * event.duration_ms * 0.8)
        duration = 300 + round(720 * _seed_value(seed, index, 11))
        finish = min(event.duration_ms, begin + duration)
        if finish - begin < 45:
            continue
        start_x = radiant_x + (_seed_value(seed, index, 12) - 0.5) * radiant_spread
        start_y = radiant_y + (_seed_value(seed, index, 13) - 0.5) * radiant_spread * 0.35
        distance = 250 + 760 * _seed_value(seed, index, 14)
        angle = (0.46 + 0.3 * _seed_value(seed, index, 15)) * math.pi
        dx = sign * abs(math.cos(angle)) * distance
        dy = abs(math.sin(angle)) * distance * 0.78
        end_x = start_x + dx
        end_y = start_y + dy
        tail_length = 90 + 220 * _seed_value(seed, index, 16)
        tail_path = f'm {-round(tail_length)} -2 l 0 -1 0 1 {-round(tail_length)} 2'
        rotation = math.degrees(math.atan2(dy, dx))
        for scale, alpha, blur, color, layer in ((120, 125, 4.5, '&HFF8EC8&', 6), (80, 20, 1.2, '&HFFF2E8&', 8)):
            result.append(_moving_shape(event, begin, finish, tail_path, x0=start_x, y0=start_y, x1=end_x, y1=end_y, color=color, alpha=alpha, scale0=scale, rotation0=rotation, blur=blur, clip=scene, layer_offset=layer, fade_in=15, fade_out=90))
        result.append(_moving_shape(event, begin, finish, _star_path(8, 2, 4), x0=start_x, y0=start_y, x1=end_x, y1=end_y, color='&HFFFFFF&', alpha=0, scale0=45 + 70 * _seed_value(seed, index, 17), rotation0=0, rotation1=100, blur=1.0, clip=scene, layer_offset=10, fade_in=10, fade_out=100))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFFFF&', outline='&H2A1535&', glow='&HFF9ACF&', glow_alpha=50, border=4.5))
    return result

def _effect_solar_eclipse(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'corona_rays', 'stars', 'ring_scale'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    corona_rays = _integer(params, 'corona_rays', 28, minimum=12, maximum=60)
    stars = _integer(params, 'stars', 24, minimum=6, maximum=60)
    ring_scale = _number(params, 'ring_scale', 150, minimum=80, maximum=260)
    scene = _scene_box(context)
    box = context.box
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    sun_x = (box.x1 + box.x2) / 2
    sun_y = box.y1 - 58
    radius = min(92, round(scene.height * 0.16))
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H170F23&', '&H21132E&', '&H090611&'), (38, 52, 70))
    for glow_radius, alpha, blur, layer in ((radius * 2, 190, 26, 1), (round(radius * 1.4), 110, 13, 2), (radius, 0, 1.5, 3)):
        result.append(_moving_shape(event, 0, event.duration_ms, _ellipse_path(glow_radius, glow_radius), x0=sun_x, y0=sun_y, x1=sun_x, y1=sun_y, color='&H75D8FF&', alpha=alpha, scale0=100, scale1=104, blur=blur, clip=scene, layer_offset=layer, fade_in=240, fade_out=300))
    for index in range(corona_rays):
        angle = 2 * math.pi * index / corona_rays
        inner = radius * (0.94 + 0.05 * math.sin(index * 1.7))
        outer = radius * (1.3 + 0.38 * _seed_value(3801, index, 1))
        p1 = (sun_x + math.cos(angle) * inner, sun_y + math.sin(angle) * inner)
        p2 = (sun_x + math.cos(angle) * outer, sun_y + math.sin(angle) * outer)
        result.append(_static_drawing(event, _polyline_path((p1, p2)), color='&H9EE8FF&', alpha=255, blur=2.5, border=1.6 + 2.2 * _seed_value(3801, index, 2), outline='&H9EE8FF&', fill=False, clip=scene, layer_offset=2, extra_tags=_scene_fade(event, start, end)))
    moon_start = sun_x - sign * radius * 2.4
    moon_end = sun_x + sign * radius * 2.4
    result.append(_moving_shape(event, 0, event.duration_ms, _ellipse_path(round(radius * 0.97), round(radius * 0.97)), x0=moon_start, y0=sun_y + 2, x1=moon_end, y1=sun_y - 2, color='&H0A0710&', alpha=0, scale0=100, blur=0.8, clip=scene, layer_offset=7, fade_in=0, fade_out=0))
    star_path = _star_path(5, 1, 4)
    total_begin = round(event.duration_ms * 0.34)
    total_end = round(event.duration_ms * 0.7)
    for index in range(stars):
        x = scene.x1 + _seed_value(3803, index, 1) * scene.width
        y = scene.y1 + _seed_value(3803, index, 2) * scene.height * 0.74
        result.append(_moving_shape(event, total_begin, total_end, star_path, x0=x, y0=y, x1=x, y1=y, color='&HFFFFFF&', alpha=60 + round(100 * _seed_value(3803, index, 3)), scale0=30 + 65 * _seed_value(3803, index, 4), scale1=40 + 85 * _seed_value(3803, index, 5), rotation0=0, rotation1=45, blur=0.5, clip=scene, layer_offset=5, fade_in=160, fade_out=180))
    diamond_begin = round(event.duration_ms * (0.71 if sign > 0 else 0.29))
    diamond_begin = max(0, min(event.duration_ms - 220, diamond_begin))
    result.append(_moving_shape(event, diamond_begin, min(event.duration_ms, diamond_begin + 420), _star_path(13, 3, 4), x0=sun_x + sign * radius * 0.88, y0=sun_y - radius * 0.34, x1=sun_x + sign * radius * 0.92, y1=sun_y - radius * 0.36, color='&HFFFFFF&', alpha=0, scale0=35, scale1=ring_scale, rotation0=0, rotation1=90, blur=3.0, clip=scene, layer_offset=10, fade_in=35, fade_out=210))
    result.extend(_themed_text(event, start, end, context, primary='&HFFF9F5&', outline='&H25132F&', glow='&H8EDFFF&', glow_alpha=46, border=4.7))
    return result

def _effect_moonlight_clouds(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'cloud_layers', 'beams', 'stars', 'seed'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    cloud_layers = _integer(params, 'cloud_layers', 6, minimum=3, maximum=12)
    beams = _integer(params, 'beams', 7, minimum=3, maximum=14)
    stars = _integer(params, 'stars', 28, minimum=8, maximum=70)
    seed = _integer(params, 'seed', 3907, minimum=0, maximum=2 ** 31 - 1)
    scene = _scene_box(context)
    box = context.box
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    moon_x = scene.x1 + scene.width * (0.27 if sign > 0 else 0.73)
    moon_y = scene.y1 + 75
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H3B263D&', '&H4E3552&', '&H211722&'), (72, 94, 112))
    for radius, alpha, blur, layer in ((78, 175, 18, 1), (52, 58, 6, 2), (39, 8, 1.2, 3)):
        result.append(_moving_shape(event, 0, event.duration_ms, _ellipse_path(radius, radius), x0=moon_x - sign * 7, y0=moon_y, x1=moon_x + sign * 7, y1=moon_y - 2, color='&HFFF1D7&', alpha=alpha, scale0=100, scale1=104, blur=blur, clip=scene, layer_offset=layer, fade_in=240, fade_out=300))
    star_path = _star_path(4, 1, 4)
    for index in range(stars):
        x = scene.x1 + _seed_value(seed, index, 1) * scene.width
        y = scene.y1 + _seed_value(seed, index, 2) * scene.height * 0.62
        result.append(_moving_shape(event, 0, event.duration_ms, star_path, x0=x, y0=y, x1=x + sign * 3, y1=y - 2, color='&HFFFFFF&', alpha=90 + round(120 * _seed_value(seed, index, 3)), scale0=25 + 55 * _seed_value(seed, index, 4), scale1=30 + 70 * _seed_value(seed, index, 5), rotation0=0, rotation1=30, blur=0.4, clip=scene, layer_offset=1, fade_in=220, fade_out=260))
    for index in range(beams):
        target_x = box.x1 - 100 + (box.width + 200) * index / max(1, beams - 1)
        half = 28 + 36 * _seed_value(seed, index, 10)
        path = _polygon_path(((moon_x - 10, moon_y + 25), (moon_x + 10, moon_y + 25), (target_x + half, scene.y2), (target_x - half, scene.y2)))
        result.append(_static_drawing(event, path, color='&HFFE8D0&', alpha=224 - round(20 * _seed_value(seed, index, 11)), blur=13, clip=scene, layer_offset=2, extra_tags=_scene_fade(event, start, end)))
    _add_clouds(result, event, context, count=cloud_layers, seed=seed + 50, direction=direction, color='&H32283A&', alpha=42, y_min=scene.y1 + 18, y_max=box.y1 + 70, drift=180, layer_offset=6, blur=10, scale_min=125, scale_max=220)
    result.extend(_themed_text(event, start, end, context, primary='&HFFFDF8&', outline='&H3C2B43&', glow='&HFFE0C7&', glow_alpha=74, border=4.4))
    return result

def _effect_sunrise_horizon(event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    _validate_param_names(params, {'direction', 'rays', 'mist_bands', 'glow_layers'})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    rays = _integer(params, 'rays', 12, minimum=4, maximum=24)
    mist_bands = _integer(params, 'mist_bands', 5, minimum=2, maximum=10)
    glow_layers = _integer(params, 'glow_layers', 6, minimum=3, maximum=10)
    scene = _scene_box(context)
    box = context.box
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    sun_x = scene.x1 + scene.width * (0.3 if sign > 0 else 0.7)
    horizon_y = box.y2 + 108
    result: list[DialogueEvent] = []
    _add_wash(result, event, start, end, context, ('&H5D3A4D&', '&H82586D&', '&H9B786F&', '&H6A4D4D&'), (110, 146, 176, 194))
    for layer in range(glow_layers):
        radius = 36 + layer * 18
        alpha = min(230, 22 + layer * 31)
        blur = 2 + layer * 5
        result.append(_moving_shape(event, 0, event.duration_ms, _ellipse_path(radius, radius), x0=sun_x, y0=horizon_y + 65, x1=sun_x + sign * 12, y1=horizon_y - 95, color='&H55C8FF&' if layer < 3 else '&H7ADFFF&', alpha=alpha, scale0=100, scale1=106, blur=blur, clip=scene, layer_offset=1 + layer, fade_in=220, fade_out=300))
    for index in range(rays):
        angle = -math.pi + (index + 0.5) * math.pi / rays
        target_x = sun_x + math.cos(angle) * scene.width * 0.75
        target_y = horizon_y + abs(math.sin(angle)) * scene.height * 0.58
        half = 14 + 28 * (index % 3) / 2
        path = _polygon_path(((sun_x - half * 0.2, horizon_y), (sun_x + half * 0.2, horizon_y), (target_x + half, target_y), (target_x - half, target_y)))
        result.append(_static_drawing(event, path, color='&H76DCFF&', alpha=218, blur=11, clip=scene, layer_offset=2, extra_tags=_scene_fade(event, start, end)))
    horizon = Rect(scene.x1, horizon_y, scene.x2, horizon_y + 7)
    result.append(_static_drawing(event, _rect_path(horizon), color='&H4DCBFF&', alpha=60, blur=7, clip=scene, layer_offset=5, extra_tags=_scene_fade(event, start, end)))
    cloud = _cloud_path(220, 52)
    for index in range(mist_bands):
        y = horizon_y - 35 + index * 32
        x = scene.x1 + scene.width * (0.15 + 0.7 * index / max(1, mist_bands - 1))
        scale = 155 + index * 42
        result.append(_moving_shape(event, 0, event.duration_ms, cloud, x0=x - sign * 90, y0=y, x1=x + sign * 90, y1=y - 12, color='&HFFE8DF&', alpha=160 + index * 12, scale0=scale, scale1=scale * 1.08, blur=13 + index * 2, clip=scene, layer_offset=6 if index < mist_bands // 2 else 9, fade_in=260, fade_out=320))
    result.extend(_themed_text(event, start, end, context, primary='&HFFFDF8&', outline='&H5A3949&', glow='&H5BCFFF&', glow_alpha=58, border=4.5))
    return result

@dataclass(frozen=True)
class LocalizedLyricSpec:
    """Text-centred three-phase choreography for one natural phenomenon.

    ``entry_motion`` brings the lyric from a nearby phenomenon source to its
    final typeset position. ``hold_mode`` either leaves only local ambience or
    stops the phenomenon. ``exit_motion`` removes the glyphs through the same
    physical metaphor. Carrier drawings are optional and travel immediately
    behind selected glyphs.
    """
    entry_motion: str
    exit_motion: str
    primary: str
    outline: str
    glow: str
    accent: str
    carrier: str | None = None
    carrier_palette: tuple[str, ...] = ()
    carrier_every: int = 0
    hold_carrier_every: int = 0
    carrier_scale: float = 100.0
    carrier_offset_y: float = 0.0
    stagger: float = 0.56
    entry_scale: float = 62.0
    exit_scale: float = 68.0
    rotation: float = 20.0
    arrival: str = 'spark'
    hold_mode: str = 'ambient'
    description_en: str = ''
    description_ja: str = ''

def _localized_spec(entry_motion: str, exit_motion: str, *, primary: str, outline: str, glow: str, accent: str, carrier: str | None=None, carrier_palette: Sequence[str]=(), carrier_every: int=0, hold_carrier_every: int=0, carrier_scale: float=100.0, carrier_offset_y: float=0.0, stagger: float=0.56, entry_scale: float=62.0, exit_scale: float=68.0, rotation: float=20.0, arrival: str='spark', hold_mode: str='ambient', description_en: str, description_ja: str) -> LocalizedLyricSpec:
    return LocalizedLyricSpec(entry_motion=entry_motion, exit_motion=exit_motion, primary=_ass_color(primary), outline=_ass_color(outline), glow=_ass_color(glow), accent=_ass_color(accent), carrier=carrier, carrier_palette=tuple((_ass_color(value) for value in carrier_palette)), carrier_every=carrier_every, hold_carrier_every=hold_carrier_every, carrier_scale=carrier_scale, carrier_offset_y=carrier_offset_y, stagger=stagger, entry_scale=entry_scale, exit_scale=exit_scale, rotation=rotation, arrival=arrival, hold_mode=hold_mode, description_en=description_en, description_ja=description_ja)
LOCALIZED_CHOREOGRAPHY: dict[Effect, LocalizedLyricSpec] = {Effect.RAIN_VEIL: _localized_spec('fall', 'fall', primary='&HFFFDF8&', outline='&H38271F&', glow='&HFFD0A0&', accent='&HFFD9B5&', carrier='drop', carrier_every=2, carrier_scale=78, carrier_offset_y=-17, arrival='splash', description_en='Raindrops lower the glyphs into place; local rain and ripples remain, then runoff carries them below.', description_ja='雨粒が文字を下ろして配置し、文字周囲の雨脚と波紋だけが続いた後、流れ落ちる水が文字を下へ運びます。'), Effect.DRIZZLE_MIST: _localized_spec('condense', 'disperse', primary='&HFFFDF9&', outline='&H4B3D39&', glow='&HFFE4D3&', accent='&HFFEFE5&', carrier='bead', carrier_every=3, carrier_scale=70, carrier_offset_y=-10, entry_scale=48, exit_scale=52, rotation=8, arrival='glow', description_en='Mist beads gather around each target position until the lyric condenses, then the letters diffuse back into droplets.', description_ja='霧と結露粒が文字位置へ集まって歌詞を凝結させ、消失時には文字が再び微細な水滴へ拡散します。'), Effect.CLOUDBURST: _localized_spec('fall', 'sweep_down', primary='&HFFFDFC&', outline='&H34272B&', glow='&HFFCFA7&', accent='&HFFD9C0&', carrier='cloud_drop', carrier_every=2, carrier_scale=82, carrier_offset_y=-19, stagger=0.46, entry_scale=56, arrival='splash', description_en='Compact cloudlets release glyph-bearing sheets of rain; a local downpour persists and a final surge sweeps the text away.', description_ja='小さな雨雲から文字を抱えた雨膜が落ち、文字周囲だけ豪雨が続いた後、最後の水流が歌詞を押し流します。'), Effect.RAINBOW_ARCH: _localized_spec('arc', 'arc', primary='&HFFFFFF&', outline='&H53324C&', glow='&HFFB9F0&', accent='&HFF94D8&', carrier='prism', carrier_every=3, carrier_scale=82, stagger=0.62, entry_scale=68, exit_scale=64, rotation=15, arrival='prism', description_en='The growing local rainbow acts as a rail that delivers the glyphs, holds beneath them, and returns them along the arc.', description_ja='文字周囲に伸びる虹をレールとして文字が運ばれ、虹が下支えした後、同じ弧を戻って消えます。'), Effect.CREPUSCULAR_RAYS: _localized_spec('ray', 'ray', primary='&HFFF9E9&', outline='&H4B3A31&', glow='&H7DE5FF&', accent='&H8AE8FF&', entry_scale=132, exit_scale=48, rotation=3, arrival='glow', description_en='Narrow shafts of light resolve the blurred glyphs locally; the beams hold around the line and close to erase it.', description_ja='細い光芒がぼやけた文字を局所的に結像させ、文字周囲の光だけが残り、光の閉鎖とともに消えます。'), Effect.SNOWFALL_DEPTH: _localized_spec('fall', 'lift', primary='&HFFFFFF&', outline='&H4B3A56&', glow='&HFFEBD2&', accent='&HFFF6E8&', carrier='snow', carrier_every=2, carrier_scale=92, entry_scale=58, exit_scale=58, rotation=24, arrival='snow', description_en='Near snowflakes carry selected glyphs down through depth; a small snowfall remains and the departing wind lifts the letters away.', description_ja='前景の雪片が文字を抱えて奥行きから降ろし、文字周囲の降雪だけが続き、最後は風が文字を雪とともに持ち上げます。'), Effect.BLIZZARD_WHITEOUT: _localized_spec('sweep', 'sweep', primary='&HFFFFFF&', outline='&H493F50&', glow='&HFFF4E5&', accent='&HFFFFFF&', carrier='snow', carrier_every=3, carrier_scale=78, stagger=0.44, entry_scale=74, exit_scale=72, rotation=20, arrival='snow', description_en='A narrow blizzard front blows the glyphs into order, circles only the lyric, and a second white gust strips them away.', description_ja='細い吹雪の前線が文字を順番に吹き寄せ、歌詞の周囲だけを巡った後、次の白い突風が文字を奪います。'), Effect.DIAMOND_DUST: _localized_spec('condense', 'shatter', primary='&HFFFFFF&', outline='&H45324E&', glow='&HFFDFFF&', accent='&HFFF7FF&', carrier='crystal', carrier_every=2, carrier_scale=92, entry_scale=34, exit_scale=42, rotation=38, arrival='prism', description_en='Ice crystals converge and flash into glyphs, twinkle close to the line, then detach as diamond fragments.', description_ja='氷晶が収束して閃きながら文字になり、文字近傍できらめいた後、ダイヤ状の破片として離れます。'), Effect.HAILSTORM: _localized_spec('impact', 'fall', primary='&HFFFFFF&', outline='&H433849&', glow='&HFFE8DC&', accent='&HFFF5EA&', carrier='hail', carrier_every=2, carrier_scale=86, carrier_offset_y=8, stagger=0.54, entry_scale=40, exit_scale=50, rotation=16, arrival='impact', hold_mode='stopped', description_en='Hail impacts bounce the glyphs up into place; the impact ceases during the hold and renewed pellets knock the text downward.', description_ja='雹の衝突で文字が跳ね上がって整列し、表示中は衝突を止め、再び降る氷粒が文字を下へ叩き落とします。'), Effect.FROST_BLOOM: _localized_spec('grow', 'retract', primary='&HFFFFFF&', outline='&H4B3451&', glow='&HFFE5F4&', accent='&HFFF4FB&', carrier='crystal', carrier_every=3, carrier_scale=72, entry_scale=5, exit_scale=8, rotation=6, arrival='frost', description_en='Frost branches grow outward from the lyric centre and crystallize the letters; the structure remains locally and retracts along its veins.', description_ja='歌詞中央から霜の枝が伸びて文字を結晶化し、局所的な霜華を保った後、葉脈を逆行するように縮退します。'), Effect.ICE_CRACK: _localized_spec('shatter', 'shatter', primary='&HFFFFFF&', outline='&H402E4D&', glow='&HFFE6FF&', accent='&HFFF4FF&', carrier='shard', carrier_every=2, carrier_scale=94, entry_scale=76, exit_scale=48, rotation=42, arrival='crack', description_en='Local cracks open an icy mask and assemble the lyric from shards; the frozen frame holds, then the glyphs leave on breaking pieces.', description_ja='文字近傍の亀裂が氷膜を開き、破片から歌詞を組み上げ、凍結した枠を保った後、文字が砕けた片に乗って離れます。'), Effect.AVALANCHE: _localized_spec('sweep', 'sweep', primary='&HFFFFFF&', outline='&H51414F&', glow='&HFFF0E0&', accent='&HFFF8EC&', carrier='snowbank', carrier_every=4, carrier_scale=88, carrier_offset_y=17, stagger=0.34, entry_scale=70, exit_scale=64, rotation=10, arrival='snow', description_en='A compact snow mass pushes the glyphs into line and banks beneath them; a second local slide carries the text out.', description_ja='小規模な雪塊が文字を押し並べて下支えし、文字周囲に雪煙を残した後、二度目の局所雪崩が歌詞を運び去ります。'), Effect.MORNING_MIST: _localized_spec('condense', 'disperse', primary='&HFFFDFC&', outline='&H4D4551&', glow='&HFFF2E5&', accent='&HFFF8EF&', carrier='cloud', carrier_every=4, carrier_scale=54, carrier_offset_y=8, entry_scale=46, exit_scale=44, rotation=4, arrival='glow', description_en='Small fog banks condense the line from nearby vapour, continue drifting only around the letters, and dissolve them back into mist.', description_ja='小さな霧の層が近傍の水蒸気から文字を凝結させ、歌詞周囲だけ漂った後、文字を霧へ溶かし戻します。'), Effect.SEA_OF_CLOUDS: _localized_spec('rise', 'sink', primary='&HFFFFFF&', outline='&H4A3B50&', glow='&HFFE8D5&', accent='&HFFF4E7&', carrier='cloud', carrier_every=3, hold_carrier_every=4, carrier_scale=62, carrier_offset_y=20, entry_scale=66, exit_scale=58, rotation=5, arrival='glow', description_en='Cloudlets lift groups of glyphs above a miniature cloud sea, support them during the hold, and receive them again as they sink.', description_ja='雲片が文字群を小さな雲海から持ち上げ、表示中も一部を支え、消失時には沈む文字を再び雲が受け取ります。'), Effect.GENTLE_BREEZE: _localized_spec('float', 'float', primary='&HFFFFFF&', outline='&H3C4A43&', glow='&HCFFFD8&', accent='&HD9FFE2&', carrier='seed', carrier_every=2, carrier_scale=82, carrier_offset_y=8, stagger=0.62, entry_scale=72, exit_scale=68, rotation=18, arrival='breeze', description_en='Airborne seeds gently tow the glyphs into place; soft streamlines remain nearby and later lift the letters away.', description_ja='風に乗る種子が文字を穏やかに牽引して並べ、近傍の気流だけが続き、最後は文字を再び風へ持ち上げます。'), Effect.GUST_FRONT: _localized_spec('impact', 'sweep', primary='&HFFFFFF&', outline='&H3E414B&', glow='&HD9F9FF&', accent='&HE8FCFF&', carrier='debris', carrier_every=3, carrier_scale=74, stagger=0.38, entry_scale=48, exit_scale=62, rotation=35, arrival='impact', hold_mode='stopped', description_en='A pressure arc slams the glyphs into alignment, stops after the hit, and a return gust tears the line away with debris.', description_ja='気圧弧が文字を衝突させて整列し、衝撃後はいったん静止し、戻りの突風が微片とともに歌詞を引き剥がします。'), Effect.WHIRLWIND: _localized_spec('orbit', 'orbit_out', primary='&HFFFFFF&', outline='&H4A3B42&', glow='&HDFF9E4&', accent='&HE9FFE8&', carrier='debris', carrier_every=3, carrier_scale=76, entry_scale=52, exit_scale=54, rotation=50, arrival='breeze', description_en='Fragments orbit inward while carrying glyphs to the line; a small vortex remains and later unwinds the letters outward.', description_ja='微片が文字を抱えて内向きに周回しながら配置し、小さな渦だけが残り、最後は逆にほどけて文字を外へ運びます。'), Effect.TORNADO: _localized_spec('orbit', 'orbit_sink', primary='&HFFFFFF&', outline='&H443945&', glow='&HE3F3E7&', accent='&HF2FFF3&', carrier='debris', carrier_every=3, carrier_scale=80, entry_scale=48, exit_scale=34, rotation=58, arrival='breeze', description_en='The miniature funnel spirals glyphs upward into their positions, remains beside the line, and finally sucks them down its core.', description_ja='小さな漏斗雲が文字を螺旋状に持ち上げて配置し、歌詞の傍らに留まり、最後は中心へ文字を吸い下ろします。'), Effect.SANDSTORM: _localized_spec('sweep', 'disperse', primary='&HFFF7E8&', outline='&H4A3729&', glow='&H80CBFF&', accent='&H91D7FF&', carrier='sand', carrier_every=2, carrier_scale=70, stagger=0.4, entry_scale=54, exit_scale=42, rotation=22, arrival='sand', description_en='A narrow sand band deposits grains until the glyphs become solid; local dust continues and then abrades the letters into particles.', description_ja='細い砂塵帯が粒を堆積して文字を実体化し、文字周囲の砂だけが続いた後、歌詞を削って粒子へ戻します。'), Effect.HEAT_HAZE: _localized_spec('ray', 'disperse', primary='&HFFF9EF&', outline='&H56382F&', glow='&H72BFFF&', accent='&H7CCBFF&', entry_scale=128, exit_scale=72, rotation=4, arrival='heat', description_en='A compact mirage sharpens from stretched, blurred glyphs; only nearby shimmer remains before the line melts into refracted air.', description_ja='引き伸ばされぼけた文字が小さな陽炎の中で結像し、周囲の揺らぎだけが続いた後、屈折した空気へ溶けます。'), Effect.OCEAN_SWELL: _localized_spec('wave', 'wave', primary='&HFFFFFF&', outline='&H4D3448&', glow='&HFFB66C&', accent='&HFFC27B&', carrier='foam', carrier_every=4, carrier_scale=78, carrier_offset_y=16, stagger=0.5, entry_scale=72, exit_scale=66, rotation=12, arrival='foam', description_en='A low swell lifts glyphs sequentially onto the baseline, rolls beneath them, and carries them off on the next local wave.', description_ja='低いうねりが文字を順に持ち上げて基線へ置き、その下だけ波が続き、次の局所波が歌詞を運び去ります。'), Effect.BREAKING_WAVE: _localized_spec('impact', 'wave', primary='&HFFFFFF&', outline='&H463149&', glow='&HFFCC8E&', accent='&HFFD9A6&', carrier='foam', carrier_every=3, carrier_scale=88, carrier_offset_y=14, stagger=0.42, entry_scale=46, exit_scale=60, rotation=20, arrival='foam', description_en='A compact breaker throws foam and glyphs onto the line; foam lingers locally and the backwash pulls the letters away.', description_ja='小さな砕波が泡と文字を基線へ投げ上げ、周囲に泡だけが残り、引き波が文字を沖側へ連れ去ります。'), Effect.RISING_TIDE: _localized_spec('rise', 'sink', primary='&HFFFFFF&', outline='&H49364C&', glow='&HFFBE75&', accent='&HFFCB89&', carrier='foam', carrier_every=4, carrier_scale=76, carrier_offset_y=18, entry_scale=62, exit_scale=52, rotation=8, arrival='foam', description_en='The local waterline raises floating glyphs into view, holds beneath them, then recedes while taking the letters down.', description_ja='局所的な水位が浮かぶ文字を持ち上げて見せ、表示中は下支えし、引き潮では文字を伴って沈みます。'), Effect.WATERFALL: _localized_spec('fall', 'fall', primary='&HFFFFFF&', outline='&H4A374B&', glow='&HFFD29D&', accent='&HFFDEB5&', carrier='drop', carrier_every=2, carrier_scale=74, carrier_offset_y=-17, stagger=0.48, entry_scale=58, exit_scale=42, rotation=6, arrival='splash', description_en='Narrow falling streams carry glyphs from above, continue only beside the text, and pull the letters below with the final cascade.', description_ja='細い滝筋が文字を上から運び、表示中は文字の両側だけ流れ、最後の落水が歌詞を下へ引き込みます。'), Effect.RIVER_CURRENT: _localized_spec('float', 'float', primary='&HFFFFFF&', outline='&H49344A&', glow='&HFFC887&', accent='&HFFD59E&', carrier='foam', carrier_every=4, carrier_scale=70, carrier_offset_y=15, stagger=0.56, entry_scale=76, exit_scale=72, rotation=9, arrival='foam', description_en='Foam patches tow glyphs along short current ribbons until they align; the local stream remains and later floats them away.', description_ja='泡片が短い流線に沿って文字を牽引して整列させ、文字周囲の流れだけが続き、最後はそのまま下流へ運びます。'), Effect.WHIRLPOOL: _localized_spec('orbit', 'orbit_sink', primary='&HFFFFFF&', outline='&H443049&', glow='&HFFC37B&', accent='&HFFD294&', carrier='foam', carrier_every=3, carrier_scale=74, carrier_offset_y=9, entry_scale=50, exit_scale=26, rotation=56, arrival='foam', description_en='Foam spirals carry the glyphs inward and release them in line; the nearby whirlpool then reclaims the letters through its centre.', description_ja='泡の螺旋が文字を内側へ運んで整列位置で放し、表示後は近傍の渦が中心から文字を回収します。'), Effect.LAVA_FLOW: _localized_spec('grow', 'melt', primary='&H8FD7FF&', outline='&H221B32&', glow='&H3098FF&', accent='&H29A9FF&', carrier='ember', carrier_every=3, carrier_scale=80, carrier_offset_y=12, entry_scale=8, exit_scale=20, rotation=8, arrival='ember', description_en='Glowing channels extrude the glyphs and cool them into a readable line; local cracks remain before the letters melt back into lava.', description_ja='発光する溶岩流が文字を押し出して冷却・定着させ、周囲の亀裂だけが残り、最後は歌詞が再溶融して流れへ戻ります。'), Effect.EMBER_DRIFT: _localized_spec('rise', 'ignite', primary='&H9EE4FF&', outline='&H2B2030&', glow='&H3BA6FF&', accent='&H2EB7FF&', carrier='ember', carrier_every=2, carrier_scale=74, carrier_offset_y=10, stagger=0.6, entry_scale=52, exit_scale=24, rotation=24, arrival='ember', description_en='Rising embers carry warm glyphs into place, drift locally around the line, and finally detach as the text burns into sparks.', description_ja='上昇する火の粉が暖色の文字を運び、表示中は周囲だけ漂い、最後は文字そのものが火花へ燃えほどけます。'), Effect.CHERRY_BLOSSOM_STORM: _localized_spec('orbit', 'float', primary='&HFFF9FF&', outline='&H5B3655&', glow='&HFFC4F4&', accent='&HFFD2F8&', carrier='petal', carrier_palette=('&HFFD2F8&', '&HFFE3FA&', '&HFFB8E9&'), carrier_every=2, carrier_scale=84, carrier_offset_y=10, entry_scale=58, exit_scale=62, rotation=54, arrival='petal', description_en='Petals spiral in while bearing glyphs, continue dancing close to the lyric, and later lift the letters away on the spring wind.', description_ja='花びらが文字を載せて螺旋状に舞い込み、歌詞近傍だけで踊り続け、最後は春風に乗せて文字を持ち去ります。'), Effect.FALLING_LEAVES: _localized_spec('drift', 'drift', primary='&HFFF9EC&', outline='&H4A3427&', glow='&H65B8FF&', accent='&H4CA8FF&', carrier='leaf', carrier_palette=('&H4CA8FF&', '&H55C47A&', '&H4476D7&', '&H5A91E8&'), carrier_every=1, hold_carrier_every=2, carrier_scale=94, carrier_offset_y=10, stagger=0.48, entry_scale=82, exit_scale=78, rotation=28, arrival='leaf', description_en='A few leaves brush selected glyphs into place, one may linger beside the readable line, and a few returning leaves lift the words away.', description_ja='数枚の落葉が歌詞の一部へ触れながら文字を連れてきて、表示中は一枚だけがそばに残り、消失時には数枚の葉が言葉を持ち去ります。'), Effect.FIREFLY_NIGHT: _localized_spec('condense', 'disperse', primary='&HD8FFE7&', outline='&H263A31&', glow='&H80FFB4&', accent='&H8DFFC0&', carrier='firefly', carrier_every=2, carrier_scale=82, carrier_offset_y=-7, entry_scale=34, exit_scale=30, rotation=12, arrival='firefly', description_en='Fireflies gather at glyph positions and ignite the line one light at a time; nearby lights linger and detach to darken the text.', description_ja='蛍が文字位置へ集まり、一灯ずつ歌詞を点灯し、周囲に光を残した後、光が文字から離れて暗くします。'), Effect.BIOLUMINESCENT_TIDE: _localized_spec('wave', 'wave', primary='&HFFE9FF&', outline='&H3E314A&', glow='&HFF7BE8&', accent='&HFF8EF0&', carrier='glow_foam', carrier_every=3, carrier_scale=82, carrier_offset_y=16, stagger=0.52, entry_scale=66, exit_scale=58, rotation=12, arrival='glow_foam', description_en='A luminous local wave writes the glyphs in blue light, glows beneath them, and erases them as the radiance recedes.', description_ja='発光する局所波が青い光で文字を書き、下部だけ輝き続け、光の引きとともに歌詞を消していきます。'), Effect.METEOR_SHOWER: _localized_spec('flash', 'ignite', primary='&HFFFFFF&', outline='&H43283F&', glow='&HFFB9FF&', accent='&HFFD8FF&', carrier='meteor', carrier_every=2, carrier_scale=92, carrier_offset_y=-7, stagger=0.68, entry_scale=30, exit_scale=26, rotation=28, arrival='meteor', hold_mode='stopped', description_en='Short meteors terminate at glyph positions to reveal the line, stop during the hold, and launch the letters away as new streaks.', description_ja='短い流星が文字位置で終端して歌詞を出現させ、表示中は停止し、消失時には文字が新たな流星となって飛び去ります。'), Effect.SOLAR_ECLIPSE: _localized_spec('ray', 'ray', primary='&HFFFFFF&', outline='&H3A2742&', glow='&H6CCFFF&', accent='&H7BD8FF&', entry_scale=142, exit_scale=42, rotation=2, arrival='corona', description_en='A miniature eclipse uncovers corona-lit glyphs, remains as a local halo, and closes its shadow over the line to remove it.', description_ja='小さな日食がコロナに照らされた文字を露出し、局所的な光環を保ち、最後は影を閉じて歌詞を覆い消します。'), Effect.MOONLIGHT_CLOUDS: _localized_spec('ray', 'condense', primary='&HFFFFFF&', outline='&H49334E&', glow='&HFFD8F5&', accent='&HFFE7FA&', carrier='cloud', carrier_every=4, carrier_scale=52, carrier_offset_y=9, entry_scale=124, exit_scale=46, rotation=4, arrival='moon', description_en='Small clouds part so a moonbeam resolves the lyric; the beam stays near the line and closing clouds absorb the letters.', description_ja='小さな雲が開いて月光が文字を結像し、文字近傍だけを照らし続け、閉じる雲が歌詞を吸収します。'), Effect.SUNRISE_HORIZON: _localized_spec('horizon', 'horizon', primary='&HFFFDF8&', outline='&H5A3949&', glow='&H5BCFFF&', accent='&H66D8FF&', entry_scale=54, exit_scale=48, rotation=3, arrival='sun', description_en='A tiny sun rises beneath the lyric and lifts the glyphs over a local horizon; at the end it sets and takes the line below.', description_ja='小さな太陽が歌詞下で昇り、局所的な地平線の上へ文字を持ち上げ、最後は沈みながら歌詞も下へ連れていきます。')}

@dataclass(frozen=True)
class RestrainedObjectBudget:
    """Maximum simultaneously legible natural objects for one effect.

    Counts are visual-object budgets, not raw ASS event counts. A moving object
    may be represented by two consecutive Dialogue events so that its curved
    trajectory remains smooth. Version 3 deliberately keeps the numbers near
    the original ASS_Effects23 visual density.
    """
    entry_carriers: int = 3
    hold_carriers: int = 0
    exit_carriers: int = 3
    arrival_cues: int = 1
    ambient_entry: int = 1
    ambient_hold: int = 1
    ambient_exit: int = 1

@dataclass(frozen=True)
class RestrainedAmbientRecipe:
    """One compact signature motif used around the lyric only."""
    motif: str
    secondary: str | None = None

def _budget_for(effect: Effect, *, entry_carriers: int | None=None, hold_carriers: int | None=None, exit_carriers: int | None=None, arrival_cues: int | None=None, ambient_entry: int | None=None, ambient_hold: int | None=None, ambient_exit: int | None=None) -> RestrainedObjectBudget:
    spec = LOCALIZED_CHOREOGRAPHY[effect]
    base = RestrainedObjectBudget(entry_carriers=3 if spec.carrier else 0, hold_carriers=0, exit_carriers=3 if spec.carrier else 0, arrival_cues=1, ambient_entry=1, ambient_hold=0 if spec.hold_mode == 'stopped' else 1, ambient_exit=1)
    return replace(base, entry_carriers=base.entry_carriers if entry_carriers is None else entry_carriers, hold_carriers=base.hold_carriers if hold_carriers is None else hold_carriers, exit_carriers=base.exit_carriers if exit_carriers is None else exit_carriers, arrival_cues=base.arrival_cues if arrival_cues is None else arrival_cues, ambient_entry=base.ambient_entry if ambient_entry is None else ambient_entry, ambient_hold=base.ambient_hold if ambient_hold is None else ambient_hold, ambient_exit=base.ambient_exit if ambient_exit is None else ambient_exit)
RESTRAINED_OBJECT_BUDGETS: dict[Effect, RestrainedObjectBudget] = {effect: _budget_for(effect) for effect in Effect}
RESTRAINED_OBJECT_BUDGETS.update({Effect.RAIN_VEIL: _budget_for(Effect.RAIN_VEIL, entry_carriers=3, exit_carriers=3, ambient_entry=2, ambient_hold=1, ambient_exit=2), Effect.DRIZZLE_MIST: _budget_for(Effect.DRIZZLE_MIST, entry_carriers=2, exit_carriers=2, ambient_entry=1, ambient_hold=1, ambient_exit=1), Effect.CLOUDBURST: _budget_for(Effect.CLOUDBURST, entry_carriers=3, exit_carriers=3, ambient_entry=2, ambient_hold=1, ambient_exit=2), Effect.SNOWFALL_DEPTH: _budget_for(Effect.SNOWFALL_DEPTH, entry_carriers=4, hold_carriers=1, exit_carriers=3, ambient_entry=0, ambient_hold=0, ambient_exit=0), Effect.BLIZZARD_WHITEOUT: _budget_for(Effect.BLIZZARD_WHITEOUT, entry_carriers=3, exit_carriers=3, ambient_entry=1, ambient_hold=1, ambient_exit=1), Effect.DIAMOND_DUST: _budget_for(Effect.DIAMOND_DUST, entry_carriers=3, hold_carriers=1, exit_carriers=3, ambient_entry=0, ambient_hold=0, ambient_exit=0), Effect.HAILSTORM: _budget_for(Effect.HAILSTORM, entry_carriers=3, exit_carriers=3, ambient_entry=0, ambient_hold=0, ambient_exit=0), Effect.CHERRY_BLOSSOM_STORM: _budget_for(Effect.CHERRY_BLOSSOM_STORM, entry_carriers=4, hold_carriers=1, exit_carriers=3, ambient_entry=0, ambient_hold=0, ambient_exit=0), Effect.FALLING_LEAVES: _budget_for(Effect.FALLING_LEAVES, entry_carriers=4, hold_carriers=1, exit_carriers=3, arrival_cues=0, ambient_entry=0, ambient_hold=0, ambient_exit=0), Effect.FIREFLY_NIGHT: _budget_for(Effect.FIREFLY_NIGHT, entry_carriers=3, hold_carriers=1, exit_carriers=3, ambient_entry=0, ambient_hold=0, ambient_exit=0), Effect.METEOR_SHOWER: _budget_for(Effect.METEOR_SHOWER, entry_carriers=2, exit_carriers=2, arrival_cues=0, ambient_entry=0, ambient_hold=0, ambient_exit=0)})
RESTRAINED_AMBIENT_RECIPES: dict[Effect, RestrainedAmbientRecipe] = {Effect.RAIN_VEIL: RestrainedAmbientRecipe('rain'), Effect.DRIZZLE_MIST: RestrainedAmbientRecipe('mist'), Effect.CLOUDBURST: RestrainedAmbientRecipe('rain_heavy'), Effect.RAINBOW_ARCH: RestrainedAmbientRecipe('rainbow'), Effect.CREPUSCULAR_RAYS: RestrainedAmbientRecipe('rays'), Effect.SNOWFALL_DEPTH: RestrainedAmbientRecipe('none'), Effect.BLIZZARD_WHITEOUT: RestrainedAmbientRecipe('wind_snow'), Effect.DIAMOND_DUST: RestrainedAmbientRecipe('none'), Effect.HAILSTORM: RestrainedAmbientRecipe('none'), Effect.FROST_BLOOM: RestrainedAmbientRecipe('frost'), Effect.ICE_CRACK: RestrainedAmbientRecipe('crack'), Effect.AVALANCHE: RestrainedAmbientRecipe('snowbank'), Effect.MORNING_MIST: RestrainedAmbientRecipe('mist'), Effect.SEA_OF_CLOUDS: RestrainedAmbientRecipe('cloud'), Effect.GENTLE_BREEZE: RestrainedAmbientRecipe('wind'), Effect.GUST_FRONT: RestrainedAmbientRecipe('wind'), Effect.WHIRLWIND: RestrainedAmbientRecipe('spiral'), Effect.TORNADO: RestrainedAmbientRecipe('funnel'), Effect.SANDSTORM: RestrainedAmbientRecipe('sand'), Effect.HEAT_HAZE: RestrainedAmbientRecipe('haze'), Effect.OCEAN_SWELL: RestrainedAmbientRecipe('wave'), Effect.BREAKING_WAVE: RestrainedAmbientRecipe('breaker'), Effect.RISING_TIDE: RestrainedAmbientRecipe('tide'), Effect.WATERFALL: RestrainedAmbientRecipe('waterfall'), Effect.RIVER_CURRENT: RestrainedAmbientRecipe('current'), Effect.WHIRLPOOL: RestrainedAmbientRecipe('whirlpool'), Effect.LAVA_FLOW: RestrainedAmbientRecipe('lava'), Effect.EMBER_DRIFT: RestrainedAmbientRecipe('ember'), Effect.CHERRY_BLOSSOM_STORM: RestrainedAmbientRecipe('none'), Effect.FALLING_LEAVES: RestrainedAmbientRecipe('none'), Effect.FIREFLY_NIGHT: RestrainedAmbientRecipe('none'), Effect.BIOLUMINESCENT_TIDE: RestrainedAmbientRecipe('glow_wave'), Effect.METEOR_SHOWER: RestrainedAmbientRecipe('none'), Effect.SOLAR_ECLIPSE: RestrainedAmbientRecipe('eclipse'), Effect.MOONLIGHT_CLOUDS: RestrainedAmbientRecipe('moonbeam'), Effect.SUNRISE_HORIZON: RestrainedAmbientRecipe('sunrise')}
for _effect, _choreography in LOCALIZED_CHOREOGRAPHY.items():
    EFFECT_SPECS[_effect] = replace(EFFECT_SPECS[_effect], description_en=_choreography.description_en, description_ja=_choreography.description_ja)

@dataclass(frozen=True)
class _CarrierStyle:
    path: str
    fill: bool
    border: float
    blur: float
    alpha: int
    scale: float
    y_offset: float

def _carrier_style(kind: str) -> _CarrierStyle:
    styles: dict[str, _CarrierStyle] = {'drop': _CarrierStyle(_droplet_path(8, 18), True, 0.8, 0.8, 36, 100, 0), 'bead': _CarrierStyle(_ellipse_path(5, 7), True, 0.4, 1.8, 58, 100, 0), 'cloud_drop': _CarrierStyle(_droplet_path(10, 22), True, 1.0, 1.2, 34, 100, 0), 'spark': _CarrierStyle(_star_path(12, 3, 4), True, 0.6, 2.5, 24, 100, 0), 'prism': _CarrierStyle(_diamond_path(9, 14), True, 0.6, 2.0, 32, 100, 0), 'snow': _CarrierStyle(_snowflake_path(13), False, 2.1, 1.0, 28, 100, 0), 'crystal': _CarrierStyle(_diamond_path(9, 15), False, 1.8, 1.2, 24, 100, 0), 'hail': _CarrierStyle(_ellipse_path(7, 7), True, 1.0, 0.8, 30, 100, 0), 'shard': _CarrierStyle(_diamond_path(10, 17), True, 0.8, 1.0, 48, 100, 0), 'snowbank': _CarrierStyle(_cloud_path(62, 24), True, 0.6, 2.2, 70, 100, 0), 'cloud': _CarrierStyle(_cloud_path(64, 26), True, 0.5, 3.0, 76, 100, 0), 'seed': _CarrierStyle(_seed_path(13), False, 1.8, 0.8, 28, 100, 0), 'debris': _CarrierStyle(_triangle_path(8, 16), True, 0.7, 0.8, 50, 100, 0), 'sand': _CarrierStyle(_ellipse_path(4, 2), True, 0.3, 0.9, 42, 100, 0), 'foam': _CarrierStyle(_splash_path(10), False, 1.6, 1.2, 34, 100, 0), 'glow_foam': _CarrierStyle(_splash_path(10), False, 2.0, 3.2, 18, 100, 0), 'ember': _CarrierStyle(_flame_path(8, 17), True, 0.5, 2.0, 28, 100, 0), 'petal': _CarrierStyle(_petal_path(11, 18), True, 0.6, 0.8, 34, 100, 0), 'leaf': _CarrierStyle(_leaf_path(15, 25), True, 0.8, 0.7, 20, 100, 0), 'firefly': _CarrierStyle(_ellipse_path(4, 4), True, 0.4, 4.0, 8, 100, 0), 'meteor': _CarrierStyle(_triangle_path(7, 21), True, 0.6, 2.2, 18, 100, 0)}
    try:
        return styles[kind]
    except KeyError as exc:
        raise EffectError(f'unknown localized carrier style: {kind}') from exc

def _localized_direction(params: Mapping[str, Any], effect: Effect) -> Direction:
    default = DEFAULT_PARAMS[effect].get('direction', Direction.LEFT_TO_RIGHT)
    raw = params.get('direction', default)
    if isinstance(raw, Direction):
        return raw
    try:
        return Direction(str(raw))
    except ValueError as exc:
        raise EffectParameterError(f'invalid direction for localized choreography: {raw!r}') from exc

def _localized_sign(direction: Direction) -> float:
    if direction in {Direction.RIGHT_TO_LEFT, Direction.COUNTERCLOCKWISE, Direction.EDGES_IN}:
        return -1.0
    return 1.0

def _localized_order(glyph: Glyph, direction: Direction) -> float:
    if direction in {Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT, Direction.CENTER_OUT, Direction.EDGES_IN}:
        return _order(glyph, direction)
    if direction is Direction.COUNTERCLOCKWISE:
        return 1.0 - glyph.order_ltr
    return glyph.order_ltr

def _motion_geometry(mode: str, glyph: Glyph, context: EffectContext, direction: Direction, seed: int, *, entering: bool) -> tuple[tuple[float, float], tuple[float, float], tuple[float, float]]:
    """Return a two-segment local trajectory.

    Entry returns ``external -> bend -> glyph``; exit returns
    ``glyph -> bend -> external``. All external points are intentionally near
    the lyric box rather than screen edges.
    """
    scene = _scene_box(context)
    box = context.box
    cx, cy = box.center
    sign = _localized_sign(direction)
    spin = sign
    u0 = _seed_value(seed, glyph.index, 101)
    u1 = _seed_value(seed, glyph.index, 102)
    u2 = _seed_value(seed, glyph.index, 103)
    x, y = (glyph.x, glyph.y)
    target = (x, y)
    if mode == 'fall':
        external = (x - sign * (20 + 38 * u0), scene.y1 - 22 - 34 * u1) if entering else (x + sign * (24 + 42 * u0), scene.y2 + 28 + 30 * u1)
        bend = (x + sign * (18 * (u2 - 0.35)), y + (-48 if entering else 46) + 18 * (u1 - 0.5))
    elif mode == 'lift':
        external = (x - sign * (24 + 32 * u0), scene.y2 + 30) if entering else (x + sign * (28 + 40 * u0), scene.y1 - 35)
        bend = (x - sign * 16 * (u1 - 0.4), y + (44 if entering else -46))
    elif mode == 'sweep_down':
        external = (scene.x1 - 36 if sign > 0 else scene.x2 + 36, y - 28 + 54 * (u0 - 0.5)) if entering else (x + sign * (80 + 60 * u0), scene.y2 + 34)
        bend = (x - sign * (46 if entering else -42), y + (24 if entering else 42))
    elif mode == 'drift':
        if entering:
            external = (x - sign * (52 + 30 * u0), y - 30 + 60 * u1)
            bend = (x - sign * (24 + 14 * u2), y - 16 + 28 * u0)
        else:
            external = (x + sign * (58 + 34 * u0), y - 34 + 68 * u1)
            bend = (x + sign * (26 + 16 * u2), y - 18 + 30 * u0)
    elif mode == 'float':
        external = (scene.x1 - 42 if sign > 0 else scene.x2 + 42, y - 74 + 148 * u0) if entering else (scene.x2 + 42 if sign > 0 else scene.x1 - 42, y - 82 + 130 * u0)
        bend = (x - sign * (58 if entering else -58), y - 42 + 74 * u1)
    elif mode == 'arc':
        external = (scene.x1 - 36 if sign > 0 else scene.x2 + 36, y + 42 + 46 * u0) if entering else (scene.x2 + 36 if sign > 0 else scene.x1 - 36, y + 40 + 50 * u0)
        bend = (x - sign * (58 if entering else -58), scene.y1 + 20 + 30 * u1)
    elif mode == 'condense':
        radial = math.tau * _seed_value(seed, glyph.index, 104)
        radius_x = 70 + 75 * u0
        radius_y = 38 + 48 * u1
        external = (x + math.cos(radial) * radius_x, y + math.sin(radial) * radius_y)
        bend = (x + math.cos(radial) * radius_x * 0.36, y + math.sin(radial) * radius_y * 0.36)
    elif mode == 'disperse':
        radial = math.tau * _seed_value(seed, glyph.index, 105)
        radius_x = 92 + 78 * u0
        radius_y = 45 + 56 * u1
        external = (x + math.cos(radial) * radius_x, y + math.sin(radial) * radius_y)
        bend = (x + math.cos(radial) * radius_x * 0.34, y + math.sin(radial) * radius_y * 0.34)
    elif mode == 'impact':
        external = (scene.x1 - 44 if sign > 0 else scene.x2 + 44, y - 28 + 56 * u0) if entering else (scene.x2 + 48 if sign > 0 else scene.x1 - 48, y - 34 + 68 * u0)
        bend = (x + sign * (13 if entering else 18), y - 4 + 8 * (u1 - 0.5))
    elif mode == 'flash':
        external = (x - sign * (110 + 70 * u0), scene.y1 - 36 - 38 * u1) if entering else (x + sign * (120 + 78 * u0), scene.y1 - 45 - 40 * u1)
        bend = (x - sign * (18 if entering else -20), y - 18 - 20 * u2)
    elif mode == 'ray':
        external = (x - sign * (18 + 24 * u0), y + 26 + 24 * u1) if entering else (x + sign * (18 + 28 * u0), y - 24 - 26 * u1)
        bend = (x - sign * (6 if entering else -6), y + (8 if entering else -8))
    elif mode == 'grow':
        external = (cx, cy + 32 * (u0 - 0.5)) if entering else (cx, cy + 24 * (u0 - 0.5))
        bend = ((x + cx) / 2, (y + cy) / 2)
    elif mode == 'retract':
        external = (cx, cy)
        bend = ((x + cx) / 2, (y + cy) / 2)
    elif mode == 'shatter':
        angle = math.atan2(y - cy, x - cx) + (u0 - 0.5) * 0.8
        radius = 92 + 65 * u1
        external = (x + math.cos(angle) * radius, y + math.sin(angle) * radius)
        bend = (x + math.cos(angle) * 28, y + math.sin(angle) * 28)
    elif mode == 'sweep':
        external = (scene.x1 - 52 if sign > 0 else scene.x2 + 52, y + 38 + 42 * (u0 - 0.5)) if entering else (scene.x2 + 52 if sign > 0 else scene.x1 - 52, y + 42 + 44 * (u0 - 0.5))
        bend = (x - sign * (55 if entering else -55), y + 22 + 16 * (u1 - 0.5))
    elif mode in {'orbit', 'orbit_out', 'orbit_sink'}:
        angle = (glyph.order_ltr * math.tau * 1.35 + u0 * 1.1) * spin
        if mode == 'orbit_sink' and (not entering):
            external = (cx + math.cos(angle) * 22, scene.y2 + 35)
            bend = (cx + math.cos(angle) * 72, cy + math.sin(angle) * 48)
        else:
            radius_x = scene.width * (0.4 if entering or mode == 'orbit_out' else 0.3)
            radius_y = min(scene.height * 0.42, 105)
            external = (cx + math.cos(angle) * radius_x, cy + math.sin(angle) * radius_y)
            bend = ((x + external[0]) / 2 + spin * 26 * math.sin(angle), (y + external[1]) / 2 - spin * 18 * math.cos(angle))
    elif mode == 'rise':
        external = (x - sign * (18 + 30 * u0), scene.y2 + 28 + 24 * u1) if entering else (x + sign * (18 + 34 * u0), scene.y1 - 30 - 24 * u1)
        bend = (x + sign * 14 * (u2 - 0.4), y + (42 if entering else -42))
    elif mode == 'sink':
        external = (x + sign * (18 + 30 * u0), scene.y2 + 32 + 26 * u1)
        bend = (x - sign * 12 * (u2 - 0.4), y + 44)
    elif mode == 'wave':
        external = (scene.x1 - 44 if sign > 0 else scene.x2 + 44, y + 70 + 26 * u0) if entering else (scene.x2 + 44 if sign > 0 else scene.x1 - 44, y + 72 + 30 * u0)
        bend = (x - sign * (62 if entering else -62), y + 38 - 26 * math.sin(math.pi * u1))
    elif mode == 'ignite':
        external = (x - sign * (24 + 30 * u0), scene.y2 + 26) if entering else (x + sign * (32 + 34 * u0), scene.y1 - 42 - 34 * u1)
        bend = (x + sign * 14 * (u2 - 0.5), y + (38 if entering else -45))
    elif mode == 'melt':
        external = (x + sign * (22 + 34 * u0), scene.y2 + 32)
        bend = (x - sign * 10 * (u1 - 0.5), y + 38)
    elif mode == 'horizon':
        external = (x - sign * (10 + 20 * u0), box.y2 + 74 + 24 * u1)
        bend = (x + sign * 8 * (u2 - 0.5), y + 34)
    else:
        raise EffectError(f'unknown localized lyric motion: {mode}')
    if entering:
        return (external, bend, target)
    return (target, bend, external)

def _motion_scales(mode: str, spec: LocalizedLyricSpec, *, entering: bool) -> tuple[float, float, float]:
    if entering:
        first = spec.entry_scale
        last = 100.0
    else:
        first = 100.0
        last = spec.exit_scale
    middle = (first + last) / 2
    if mode == 'impact':
        middle = 118.0 if entering else 92.0
    elif mode == 'flash':
        middle = 122.0 if entering else 72.0
    elif mode in {'grow', 'retract'}:
        middle = 52.0
    elif mode in {'orbit', 'orbit_out', 'orbit_sink'}:
        middle = 78.0
    elif mode in {'ray'}:
        middle = 106.0 if entering else 76.0
    return (first, middle, last)

def _phase_state(x: float, y: float, *, scale: float, rotation: float, alpha: int, primary: str, outline: str, border: float, blur: float, shadow: float=0.0) -> MotionState:
    return MotionState(x=x, y=y, scale_x=scale, scale_y=scale, rotation_z=rotation, alpha=alpha, primary_color=primary, outline_color=outline, border=border, blur=blur, shadow=shadow)

def _motion_rotations(mode: str, spec: LocalizedLyricSpec, direction: Direction, glyph: Glyph, *, entering: bool) -> tuple[float, float, float]:
    sign = _localized_sign(direction)
    jitter = (_seed_value(97 + glyph.index, glyph.index, 1) - 0.5) * 0.35
    magnitude = spec.rotation * (0.72 + glyph.centre_distance * 0.35 + jitter)
    if mode in {'orbit', 'orbit_out', 'orbit_sink'}:
        magnitude *= 1.8
    if entering:
        return (-sign * magnitude, sign * magnitude * 0.28, 0.0)
    return (0.0, -sign * magnitude * 0.32, sign * magnitude)

def _selected_glyph_indices(glyphs: Sequence[Glyph], count: int, *, seed: int, lane: int) -> frozenset[int]:
    """Choose a small, evenly distributed set of visible glyphs.

    The selection is deterministic and deliberately avoids attaching one
    natural object to every character. This is the main visual-density guard
    for version 3.
    """
    visible = [glyph for glyph in glyphs if not glyph.is_space]
    if count <= 0 or not visible:
        return frozenset()
    if count >= len(visible):
        return frozenset((glyph.index for glyph in visible))
    chosen: list[int] = []
    for slot in range(count):
        centre = (slot + 0.5) * len(visible) / count - 0.5
        jitter = (_seed_value(seed, slot, lane) - 0.5) * min(1.2, len(visible) / count * 0.45)
        index = max(0, min(len(visible) - 1, round(centre + jitter)))
        while visible[index].index in chosen:
            index = (index + 1) % len(visible)
        chosen.append(visible[index].index)
    return frozenset(chosen)

def _append_text_segment(result: list[DialogueEvent], event: DialogueEvent, text: str, begin: int, finish: int, state0: MotionState, state1: MotionState, *, layer_offset: int) -> None:
    if finish - begin < 20:
        return
    result.append(_clone(event, start_ms=event.start_ms + begin, end_ms=event.start_ms + finish, layer=event.layer + layer_offset, text=_animated_text(text, state0, state1, finish - begin)))

def _append_carrier_segment(result: list[DialogueEvent], event: DialogueEvent, begin: int, finish: int, p0: tuple[float, float], p1: tuple[float, float], *, carrier_kind: str, color: str, scale0: float, scale1: float, rotation0: float, rotation1: float, y_offset: float, scene: Rect, layer_offset: int, fade_in: int, fade_out: int, marker: str='') -> None:
    if finish - begin < 20:
        return
    style = _carrier_style(carrier_kind)
    item = _moving_shape(event, begin, finish, style.path, x0=p0[0], y0=p0[1] + y_offset + style.y_offset, x1=p1[0], y1=p1[1] + y_offset + style.y_offset, color=color, alpha=min(150, style.alpha + 26), scale0=scale0 * style.scale / 100, scale1=scale1 * style.scale / 100, rotation0=rotation0, rotation1=rotation1, blur=max(0.4, style.blur * 0.78), border=max(0.35, style.border * 0.88), outline=color, fill=style.fill, fade_in=fade_in, fade_out=fade_out, clip=scene, layer_offset=layer_offset)
    result.append(_clone(item, effect_field=marker) if marker else item)

def _carrier_color(spec: LocalizedLyricSpec, glyph: Glyph) -> str:
    if spec.carrier_palette:
        return spec.carrier_palette[glyph.index % len(spec.carrier_palette)]
    return spec.accent

def _append_arrival_cue(result: list[DialogueEvent], event: DialogueEvent, spec: LocalizedLyricSpec, glyph: Glyph, begin: int, scene: Rect, *, marker: str='') -> None:
    if begin >= event.duration_ms - 60:
        return
    cue = spec.arrival
    duration = 220 if cue not in {'flash', 'meteor'} else 150
    finish = min(event.duration_ms, begin + duration)
    if finish - begin < 30:
        return
    x, y = (glyph.x, glyph.y + 18)
    item: DialogueEvent | None
    if cue in {'splash', 'foam', 'glow_foam'}:
        item = _pulse_ring(event, begin, duration, x=x, y=y + 13, rx=12, ry=4, color=spec.accent, border=1.25, scale0=34, scale1=125, alpha0=92, clip=scene, layer_offset=9)
    elif cue in {'impact', 'crack'}:
        item = _pulse_ring(event, begin, duration, x=x, y=y, rx=11, ry=7, color=spec.accent, border=1.5, scale0=28, scale1=132, alpha0=78, clip=scene, layer_offset=9)
    else:
        path = _star_path(8 if cue not in {'corona', 'sun'} else 11, 3, 4)
        item = _moving_shape(event, begin, finish, path, x0=x, y0=y - 10, x1=x, y1=y - 10, color=spec.accent, alpha=62, scale0=24, scale1=105 if cue not in {'heat', 'moon'} else 82, rotation0=-16, rotation1=24, blur=1.7, border=0.45, clip=scene, layer_offset=9, fade_in=20, fade_out=max(45, finish - begin - 30))
    if item is not None:
        result.append(_clone(item, effect_field=marker) if marker else item)

def _append_hold_text(result: list[DialogueEvent], event: DialogueEvent, start: int, end: int, context: EffectContext, spec: LocalizedLyricSpec) -> None:
    begin = start
    finish = event.duration_ms - end
    if finish - begin < 20:
        return
    x, y = _event_anchor(event, context)
    base = _remove_position_tags(event.text)
    glow_tags = f'\\an5\\pos({_fmt(x)},{_fmt(y)})' + f'\\1c{spec.glow}\\1a&HFF&\\3c{spec.glow}\\3a&HA8&' + '\\bord5.4\\blur4.2\\shad0'
    crisp_tags = f'\\an5\\pos({_fmt(x)},{_fmt(y)})' + f'\\1c{spec.primary}\\3c{spec.outline}\\bord3.4\\blur0.35\\shad0.8'
    result.append(_clone(event, start_ms=event.start_ms + begin, end_ms=event.start_ms + finish, layer=event.layer + 8, text=_add_tags(base, glow_tags)))
    result.append(_clone(event, start_ms=event.start_ms + begin, end_ms=event.start_ms + finish, layer=event.layer + 12, text=_add_tags(base, crisp_tags)))

def _append_hold_carriers(result: list[DialogueEvent], event: DialogueEvent, start: int, end: int, context: EffectContext, spec: LocalizedLyricSpec, glyphs: Sequence[Glyph], selected_indices: frozenset[int], *, effect: Effect) -> None:
    if not spec.carrier or not selected_indices:
        return
    begin = start
    finish = event.duration_ms - end
    if finish - begin < 80:
        return
    scene = _scene_box(context)
    style = _carrier_style(spec.carrier)
    for glyph in glyphs:
        if glyph.index not in selected_indices:
            continue
        color = _carrier_color(spec, glyph)
        sway = 2.0 + 1.8 * _seed_value(41, glyph.index, 3)
        item = _moving_shape(event, begin, finish, style.path, x0=glyph.x - sway, y0=glyph.y + spec.carrier_offset_y + style.y_offset, x1=glyph.x + sway, y1=glyph.y + spec.carrier_offset_y + style.y_offset - 1, color=color, alpha=min(176, style.alpha + 92), scale0=spec.carrier_scale * 0.62 * style.scale / 100, scale1=spec.carrier_scale * 0.66 * style.scale / 100, rotation0=-6, rotation1=6, blur=max(0.4, style.blur * 0.7), border=max(0.35, style.border * 0.82), outline=color, fill=style.fill, fade_in=min(150, max(20, (finish - begin) // 6)), fade_out=min(170, max(20, (finish - begin) // 5)), clip=scene, layer_offset=7)
        result.append(_clone(item, effect_field=f'NAT40:{effect.value}:carrier:hold:{glyph.index}'))

def _localized_lyric_events(event: DialogueEvent, start: int, end: int, effect: Effect, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    spec = LOCALIZED_CHOREOGRAPHY[effect]
    direction = _localized_direction(params, effect)
    seed = int(params.get('seed', DEFAULT_PARAMS[effect].get('seed', _legacy_effect_number(effect) * 1009)))
    leading, glyphs = _layout_glyphs(event, context)
    scene = _scene_box(context)
    result: list[DialogueEvent] = []
    budget = RESTRAINED_OBJECT_BUDGETS[effect]
    entry_carrier_indices = _selected_glyph_indices(glyphs, budget.entry_carriers, seed=seed, lane=201)
    hold_carrier_indices = _selected_glyph_indices(glyphs, budget.hold_carriers, seed=seed, lane=202)
    exit_carrier_indices = _selected_glyph_indices(glyphs, budget.exit_carriers, seed=seed, lane=203)
    arrival_cue_indices = _selected_glyph_indices(glyphs, budget.arrival_cues, seed=seed, lane=204)
    if start > 0:
        for glyph in glyphs:
            if glyph.is_space:
                continue
            order = _localized_order(glyph, direction)
            delay = round(start * spec.stagger * order * 0.72)
            begin = min(max(0, delay), max(0, start - 90))
            finish = start
            if finish - begin < 40:
                begin = max(0, finish - 40)
            mid = begin + max(20, round((finish - begin) * 0.54))
            if mid >= finish:
                mid = begin + max(1, (finish - begin) // 2)
            p0, p1, p2 = _motion_geometry(spec.entry_motion, glyph, context, direction, seed, entering=True)
            s0, s1, s2 = _motion_scales(spec.entry_motion, spec, entering=True)
            r0, r1, r2 = _motion_rotations(spec.entry_motion, spec, direction, glyph, entering=True)
            text = leading + glyph.text
            blur0 = 7.0 if spec.entry_motion in {'condense', 'ray', 'flash'} else 3.2
            glow0 = _phase_state(*p0, scale=s0, rotation=r0, alpha=248, primary=spec.glow, outline=spec.glow, border=5.4, blur=4.8)
            glow1 = _phase_state(*p1, scale=s1, rotation=r1, alpha=150, primary=spec.glow, outline=spec.glow, border=5.4, blur=4.2)
            glow2 = _phase_state(*p2, scale=s2, rotation=r2, alpha=178, primary=spec.glow, outline=spec.glow, border=4.8, blur=3.8)
            crisp0 = _phase_state(*p0, scale=s0, rotation=r0, alpha=255, primary=spec.accent, outline=spec.outline, border=3.4, blur=blur0, shadow=0.8)
            crisp1 = _phase_state(*p1, scale=s1, rotation=r1, alpha=72, primary=spec.accent, outline=spec.outline, border=3.4, blur=1.4, shadow=0.8)
            crisp2 = _phase_state(*p2, scale=s2, rotation=r2, alpha=0, primary=spec.primary, outline=spec.outline, border=3.4, blur=0.35, shadow=0.8)
            _append_text_segment(result, event, text, begin, mid, glow0, glow1, layer_offset=8)
            _append_text_segment(result, event, text, mid, finish, glow1, glow2, layer_offset=8)
            _append_text_segment(result, event, text, begin, mid, crisp0, crisp1, layer_offset=12)
            _append_text_segment(result, event, text, mid, finish, crisp1, crisp2, layer_offset=12)
            if spec.carrier and glyph.index in entry_carrier_indices:
                color = _carrier_color(spec, glyph)
                marker = f'NAT40:{effect.value}:carrier:entry:{glyph.index}'
                _append_carrier_segment(result, event, begin, mid, p0, p1, carrier_kind=spec.carrier, color=color, scale0=spec.carrier_scale * 0.58, scale1=spec.carrier_scale * 0.82, rotation0=r0, rotation1=r1, y_offset=spec.carrier_offset_y, scene=scene, layer_offset=7, fade_in=35, fade_out=0, marker=marker)
                _append_carrier_segment(result, event, mid, finish, p1, p2, carrier_kind=spec.carrier, color=color, scale0=spec.carrier_scale * 0.82, scale1=spec.carrier_scale * 0.7, rotation0=r1, rotation1=r2, y_offset=spec.carrier_offset_y, scene=scene, layer_offset=7, fade_in=0, fade_out=min(110, max(20, finish - mid - 10)), marker=marker)
            if glyph.index in arrival_cue_indices:
                cue_time = min(finish - 20, begin + round((finish - begin) * 0.8))
                _append_arrival_cue(result, event, spec, glyph, cue_time, scene, marker=f'NAT40:{effect.value}:cue:entry:{glyph.index}')
    _append_hold_carriers(result, event, start, end, context, spec, glyphs, hold_carrier_indices, effect=effect)
    _append_hold_text(result, event, start, end, context, spec)
    if end > 0:
        phase_start = event.duration_ms - end
        for glyph in glyphs:
            if glyph.is_space:
                continue
            order = _localized_order(glyph, direction)
            delay = round(end * spec.stagger * order * 0.66)
            begin = min(event.duration_ms - 40, phase_start + delay)
            finish = event.duration_ms
            if finish - begin < 40:
                begin = max(phase_start, finish - 40)
            mid = begin + max(20, round((finish - begin) * 0.48))
            if mid >= finish:
                mid = begin + max(1, (finish - begin) // 2)
            p0, p1, p2 = _motion_geometry(spec.exit_motion, glyph, context, direction, seed + 1103, entering=False)
            s0, s1, s2 = _motion_scales(spec.exit_motion, spec, entering=False)
            r0, r1, r2 = _motion_rotations(spec.exit_motion, spec, direction, glyph, entering=False)
            text = leading + glyph.text
            glow0 = _phase_state(*p0, scale=s0, rotation=r0, alpha=178, primary=spec.glow, outline=spec.glow, border=4.8, blur=3.8)
            glow1 = _phase_state(*p1, scale=s1, rotation=r1, alpha=145, primary=spec.glow, outline=spec.glow, border=5.4, blur=4.2)
            glow2 = _phase_state(*p2, scale=s2, rotation=r2, alpha=255, primary=spec.glow, outline=spec.glow, border=5.6, blur=5.4)
            crisp0 = _phase_state(*p0, scale=s0, rotation=r0, alpha=0, primary=spec.primary, outline=spec.outline, border=3.4, blur=0.35, shadow=0.8)
            crisp1 = _phase_state(*p1, scale=s1, rotation=r1, alpha=70, primary=spec.accent, outline=spec.outline, border=3.4, blur=1.5, shadow=0.8)
            crisp2 = _phase_state(*p2, scale=s2, rotation=r2, alpha=255, primary=spec.accent, outline=spec.outline, border=3.0, blur=5.2, shadow=0)
            _append_text_segment(result, event, text, begin, mid, glow0, glow1, layer_offset=8)
            _append_text_segment(result, event, text, mid, finish, glow1, glow2, layer_offset=8)
            _append_text_segment(result, event, text, begin, mid, crisp0, crisp1, layer_offset=12)
            _append_text_segment(result, event, text, mid, finish, crisp1, crisp2, layer_offset=12)
            if spec.carrier and glyph.index in exit_carrier_indices:
                color = _carrier_color(spec, glyph)
                marker = f'NAT40:{effect.value}:carrier:exit:{glyph.index}'
                _append_carrier_segment(result, event, begin, mid, p0, p1, carrier_kind=spec.carrier, color=color, scale0=spec.carrier_scale * 0.68, scale1=spec.carrier_scale * 0.82, rotation0=r0, rotation1=r1, y_offset=spec.carrier_offset_y, scene=scene, layer_offset=7, fade_in=min(90, max(20, (mid - begin) // 3)), fade_out=0, marker=marker)
                _append_carrier_segment(result, event, mid, finish, p1, p2, carrier_kind=spec.carrier, color=color, scale0=spec.carrier_scale * 0.82, scale1=spec.carrier_scale * 0.56, rotation0=r1, rotation1=r2, y_offset=spec.carrier_offset_y, scene=scene, layer_offset=7, fade_in=0, fade_out=min(145, max(30, finish - mid - 15)), marker=marker)
    return result
_SIMPLE_CLIP_RE = re.compile('\\\\clip\\(\\s*(-?\\d+)\\s*,\\s*(-?\\d+)\\s*,\\s*(-?\\d+)\\s*,\\s*(-?\\d+)\\s*\\)', re.IGNORECASE)

def _force_local_drawing_clip(item: DialogueEvent, context: EffectContext) -> DialogueEvent:
    if not _DRAWING_RE.search(item.text):
        return item
    scene = _scene_box(context)
    match = _LEADING_OVERRIDE_RE.match(item.text)
    if not match:
        return _clone(item, text=_add_tags(item.text, _clip_tag(scene)))
    body = match.group(1)
    found = False

    def replace_clip(clip_match: re.Match[str]) -> str:
        nonlocal found
        found = True
        x1, y1, x2, y2 = map(int, clip_match.groups())
        nx1 = max(scene.x1, min(x1, x2))
        ny1 = max(scene.y1, min(y1, y2))
        nx2 = min(scene.x2, max(x1, x2))
        ny2 = min(scene.y2, max(y1, y2))
        if nx2 <= nx1 or ny2 <= ny1:
            nx1, ny1 = (scene.x1, scene.y1)
            nx2, ny2 = (scene.x1 + 1, scene.y1 + 1)
        return f'\\clip({nx1},{ny1},{nx2},{ny2})'
    new_body = _SIMPLE_CLIP_RE.sub(replace_clip, body)
    if not found and '\\iclip' not in new_body.lower():
        new_body += _clip_tag(scene)
    return _clone(item, text='{' + new_body + '}' + item.text[match.end():])

def _ambient_marker(effect: Effect, phase: str, index: int) -> str:
    return f'NAT40:{effect.value}:ambient:{phase}:{index}'

def _mark_ambient(item: DialogueEvent, effect: Effect, phase: str, index: int) -> DialogueEvent:
    return _clone(item, effect_field=_ambient_marker(effect, phase, index))

def _restrained_particle(event: DialogueEvent, begin: int, finish: int, *, kind: str, color: str, scene: Rect, seed: int, index: int, phase: str, direction: Direction, scale: float=58.0, y_bias: float=0.0) -> DialogueEvent:
    style = _carrier_style(kind)
    sign = _localized_sign(direction)
    ux = _seed_value(seed, index, 501)
    uy = _seed_value(seed, index, 502)
    x = scene.x1 + scene.width * (0.16 + 0.68 * ux)
    y = scene.y1 + scene.height * (0.2 + 0.6 * uy) + y_bias
    if phase == 'entry':
        x0, y0 = (x - sign * (24 + 18 * ux), scene.y1 - 16)
        x1, y1 = (x, y)
    elif phase == 'exit':
        x0, y0 = (x, y)
        x1, y1 = (x + sign * (26 + 20 * ux), scene.y2 + 16)
    else:
        x0, y0 = (x - sign * 5, y + 2)
        x1, y1 = (x + sign * 5, y - 2)
    return _moving_shape(event, begin, finish, style.path, x0=x0, y0=y0, x1=x1, y1=y1, color=color, alpha=min(190, style.alpha + (82 if phase == 'hold' else 54)), scale0=scale * style.scale / 100, scale1=scale * (0.94 if phase == 'exit' else 1.03) * style.scale / 100, rotation0=-12 * sign, rotation1=14 * sign, blur=max(0.4, style.blur * 0.72), border=max(0.35, style.border * 0.82), outline=color, fill=style.fill, fade_in=min(90, max(20, (finish - begin) // 5)), fade_out=min(120, max(25, (finish - begin) // 4)), clip=scene, layer_offset=5)

def _render_restrained_ambient_phase(event: DialogueEvent, begin: int, finish: int, *, phase: str, count: int, effect: Effect, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    if count <= 0 or finish - begin < 40:
        return []
    recipe = RESTRAINED_AMBIENT_RECIPES[effect]
    if recipe.motif == 'none':
        return []
    spec = LOCALIZED_CHOREOGRAPHY[effect]
    scene = _scene_box(context)
    box = context.box
    cx, cy = box.center
    direction = _localized_direction(params, effect)
    sign = _localized_sign(direction)
    seed = int(params.get('seed', DEFAULT_PARAMS[effect].get('seed', 1009)))
    alpha = 158 if phase == 'hold' else 92
    fade_in = min(100, max(20, (finish - begin) // 6))
    fade_out = min(130, max(25, (finish - begin) // 5))
    fade = f'\\fad({fade_in},{fade_out})'
    motif = recipe.motif
    result: list[DialogueEvent] = []

    def add(item: DialogueEvent, index: int=0) -> None:
        result.append(_mark_ambient(_force_local_drawing_clip(item, context), effect, phase, index))
    if motif in {'rain', 'rain_heavy'}:
        length = 30 if motif == 'rain' else 42
        width = 2 if motif == 'rain' else 3
        path = f'm {-width} {-length // 2} l {width} {-length // 2} {width + 8 * sign} {length // 2} {-width + 8 * sign} {length // 2}'
        for index in range(count):
            ux = _seed_value(seed, index, 511)
            x = scene.x1 + scene.width * (0.22 + 0.56 * ux)
            y0 = scene.y1 - length * 0.55
            y1 = scene.y2 + length * 0.45
            if phase == 'hold':
                span = max(160, min(420, finish - begin))
                local_begin = begin + round((finish - begin - span) * _seed_value(seed, index, 512))
                local_finish = min(finish, local_begin + span)
            else:
                local_begin, local_finish = (begin, finish)
            add(_moving_shape(event, local_begin, local_finish, path, x0=x - sign * 8, y0=y0, x1=x + sign * 8, y1=y1, color=spec.accent, alpha=alpha + (18 if motif == 'rain' else 0), scale0=78 if motif == 'rain' else 94, scale1=78 if motif == 'rain' else 94, rotation0=0, rotation1=0, blur=0.65, border=0, clip=scene, layer_offset=4, fade_in=35, fade_out=55), index)
        if phase == 'hold' and count > 0:
            ring_begin = begin + round((finish - begin) * 0.55)
            ring = _pulse_ring(event, ring_begin, min(260, finish - ring_begin), x=cx + sign * box.width * 0.2, y=box.y2 + 14, rx=13, ry=4, color=spec.accent, border=1.1, scale0=35, scale1=116, alpha0=125, clip=scene, layer_offset=4)
            if ring is not None:
                add(ring, 0)
    elif motif == 'mist':
        for index in range(count):
            y = cy + (index - (count - 1) / 2) * 18
            add(_moving_shape(event, begin, finish, _cloud_path(118, 34), x0=cx - sign * 24, y0=y, x1=cx + sign * 24, y1=y - 2, color=spec.glow, alpha=200 if phase == 'hold' else 172, scale0=92, scale1=98, rotation0=-2, rotation1=2, blur=5.5, border=0.4, outline=spec.accent, clip=scene, layer_offset=3, fade_in=fade_in, fade_out=fade_out), index)
    elif motif == 'rainbow':
        colors = ('&H5A8CFF&', '&H6BE8FF&', '&HFFB8A0&')
        for band, color in enumerate(colors):
            add(_moving_shape(event, begin, finish, _arc_path(125 + band * 10, 45 + band * 4, samples=28), x0=cx, y0=box.y2 + 22, x1=cx, y1=box.y2 + 22, color=color, alpha=170 if phase == 'hold' else 116, scale0=92, scale1=100, rotation0=0, rotation1=0, blur=1.4, border=1.8, outline=color, fill=False, clip=scene, layer_offset=3, fade_in=fade_in, fade_out=fade_out), 0)
    elif motif == 'rays':
        for index in range(count):
            offset = (index - (count - 1) / 2) * 56
            ray = _polygon_path(((cx + offset - 16, scene.y1), (cx + offset + 16, scene.y1), (cx + offset + sign * 42, scene.y2)))
            add(_static_drawing(event, ray, color=spec.glow, alpha=210 if phase == 'hold' else 184, blur=7.0, clip=scene, layer_offset=3, start=begin, end=finish, extra_tags=fade), index)
    elif motif in {'wind', 'wind_snow'}:
        baseline = cy + (8 if phase == 'hold' else 18 * sign)
        path = _wavy_line(scene.x1 + 20, scene.x2 - 20, baseline, 8, 120, 0.15 if phase == 'entry' else 0.55, samples=24)
        add(_static_drawing(event, path, color=spec.accent, alpha=176 if phase == 'hold' else 128, blur=1.0, border=1.4, outline=spec.accent, fill=False, clip=scene, layer_offset=3, start=begin, end=finish, extra_tags=fade), 0)
        if motif == 'wind_snow' and count > 1:
            add(_restrained_particle(event, begin, finish, kind='snow', color=spec.glow, scene=scene, seed=seed, index=1, phase=phase, direction=direction, scale=52), 1)
    elif motif == 'frost':
        branches = [((box.x1 + 70, cy), (box.x1 + 42, cy - 26), (box.x1 + 22, cy - 18)), ((box.x2 - 70, cy), (box.x2 - 42, cy + 24), (box.x2 - 20, cy + 14)), ((cx, box.y1 + 8), (cx + 12, scene.y1 + 8), (cx + 28, scene.y1 + 18))]
        path = ' '.join((_polyline_path(points) for points in branches))
        add(_static_drawing(event, path, color=spec.accent, alpha=176 if phase == 'hold' else 106, blur=1.0, border=1.4, outline=spec.accent, fill=False, clip=scene, layer_offset=3, start=begin, end=finish, extra_tags=fade), 0)
    elif motif == 'crack':
        points = ((cx - 80, cy - 8), (cx - 36, cy + 5), (cx - 8, cy - 13), (cx + 20, cy + 12), (cx + 70, cy - 4))
        add(_static_drawing(event, _polyline_path(points), color=spec.accent, alpha=168 if phase == 'hold' else 88, blur=0.8, border=1.5, outline=spec.accent, fill=False, clip=scene, layer_offset=4, start=begin, end=finish, extra_tags=fade), 0)
    elif motif in {'snowbank', 'cloud'}:
        width = 135 if motif == 'snowbank' else 115
        y = box.y2 + 24 if motif == 'snowbank' else cy - 26
        add(_moving_shape(event, begin, finish, _cloud_path(width, 34), x0=cx - sign * 30, y0=y, x1=cx + sign * 28, y1=y, color=spec.glow, alpha=192 if phase == 'hold' else 152, scale0=88, scale1=96, rotation0=0, rotation1=0, blur=4.0, border=0.5, outline=spec.accent, clip=scene, layer_offset=3, fade_in=fade_in, fade_out=fade_out), 0)
    elif motif in {'spiral', 'whirlpool'}:
        path = _spiral_path(1.25 if motif == 'spiral' else 1.55, 54, samples=42)
        add(_moving_shape(event, begin, finish, path, x0=cx, y0=cy + (10 if motif == 'whirlpool' else 0), x1=cx + sign * 4, y1=cy + (10 if motif == 'whirlpool' else 0), color=spec.accent, alpha=172 if phase == 'hold' else 112, scale0=82, scale1=96, rotation0=-12 * sign, rotation1=22 * sign, blur=1.2, border=1.5, outline=spec.accent, fill=False, clip=scene, layer_offset=3, fade_in=fade_in, fade_out=fade_out), 0)
    elif motif == 'funnel':
        add(_moving_shape(event, begin, finish, _vertical_ribbon_path(52, scene.height * 0.56, 8, 0.2), x0=cx - sign * 8, y0=cy, x1=cx + sign * 8, y1=cy, color=spec.accent, alpha=216 if phase == 'hold' else 178, scale0=66, scale1=74, rotation0=-3, rotation1=3, blur=1.7, border=0.7, outline=spec.accent, clip=scene, layer_offset=3, fade_in=fade_in, fade_out=fade_out), 0)
    elif motif in {'sand', 'ember'}:
        kind = 'sand' if motif == 'sand' else 'ember'
        for index in range(count):
            add(_restrained_particle(event, begin, finish, kind=kind, color=spec.accent, scene=scene, seed=seed, index=index, phase=phase, direction=direction, scale=46 if motif == 'sand' else 58, y_bias=12 if motif == 'ember' else 0), index)
    elif motif == 'haze':
        paths = []
        for offset in (-42, 42):
            paths.append(_polyline_path([(cx + offset + 7 * math.sin(i * 0.9), scene.y1 + i * scene.height / 10) for i in range(11)]))
        add(_static_drawing(event, ' '.join(paths), color=spec.glow, alpha=205 if phase == 'hold' else 170, blur=3.0, border=1.2, outline=spec.glow, fill=False, clip=scene, layer_offset=3, start=begin, end=finish, extra_tags=fade), 0)
    elif motif in {'wave', 'tide', 'current', 'glow_wave'}:
        baseline = box.y2 + (16 if motif != 'tide' else 8)
        amplitude = 7 if motif in {'wave', 'current'} else 10
        path = _wavy_line(scene.x1 + 18, scene.x2 - 18, baseline, amplitude, 150, 0.2 if phase == 'entry' else 0.55, samples=28)
        add(_static_drawing(event, path, color=spec.accent, alpha=150 if motif == 'glow_wave' else 180 if phase == 'hold' else 126, blur=3.0 if motif == 'glow_wave' else 1.1, border=2.0 if motif == 'glow_wave' else 1.4, outline=spec.accent, fill=False, clip=scene, layer_offset=3, start=begin, end=finish, extra_tags=fade), 0)
    elif motif == 'breaker':
        add(_moving_shape(event, begin, finish, _breaking_curl_path(150, 66, sign), x0=cx - sign * 32, y0=box.y2 + 8, x1=cx + sign * 20, y1=box.y2 + 8, color=spec.accent, alpha=174 if phase == 'hold' else 112, scale0=78, scale1=96, rotation0=0, rotation1=0, blur=1.4, border=1.7, outline=spec.accent, fill=False, clip=scene, layer_offset=3, fade_in=fade_in, fade_out=fade_out), 0)
    elif motif == 'waterfall':
        for index in range(count):
            x = cx + (index - (count - 1) / 2) * 92
            add(_moving_shape(event, begin, finish, _vertical_ribbon_path(12, scene.height * 0.66, 3, index * 0.2), x0=x, y0=cy - 14, x1=x + sign * 3, y1=cy + 14, color=spec.glow, alpha=190 if phase == 'hold' else 145, scale0=86, scale1=92, rotation0=0, rotation1=0, blur=2.8, border=0.4, outline=spec.accent, clip=scene, layer_offset=3, fade_in=fade_in, fade_out=fade_out), index)
    elif motif == 'lava':
        path = _wavy_line(scene.x1 + 18, scene.x2 - 18, box.y2 + 16, 6, 95, 0.15 if phase == 'entry' else 0.6, samples=30)
        add(_static_drawing(event, path, color=spec.accent, alpha=120 if phase == 'hold' else 72, blur=3.8, border=3.2, outline=spec.accent, fill=False, clip=scene, layer_offset=3, start=begin, end=finish, extra_tags=fade), 0)
    elif motif == 'eclipse':
        add(_moving_shape(event, begin, finish, _ellipse_path(28, 28), x0=cx, y0=cy - 34, x1=cx + sign * 4, y1=cy - 34, color='&H181018&', alpha=36, scale0=88, scale1=96, rotation0=0, rotation1=0, blur=0.5, border=2.0, outline=spec.accent, clip=scene, layer_offset=4, fade_in=fade_in, fade_out=fade_out), 0)
    elif motif == 'moonbeam':
        beam = _polygon_path(((cx - 28, scene.y1), (cx + 16, scene.y1), (cx + sign * 72, scene.y2)))
        add(_static_drawing(event, beam, color=spec.glow, alpha=218 if phase == 'hold' else 190, blur=7.0, clip=scene, layer_offset=2, start=begin, end=finish, extra_tags=fade), 0)
    elif motif == 'sunrise':
        add(_moving_shape(event, begin, finish, _ellipse_path(24, 24), x0=cx, y0=box.y2 + 38, x1=cx, y1=box.y2 + 12, color=spec.accent, alpha=118 if phase == 'hold' else 70, scale0=72, scale1=96, rotation0=0, rotation1=0, blur=3.6, border=0.6, outline=spec.glow, clip=scene, layer_offset=3, fade_in=fade_in, fade_out=fade_out), 0)
    return result

def _localized_ambient_events(generated: Sequence[DialogueEvent], event: DialogueEvent, start: int, end: int, effect: Effect, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    """Discard the scene renderer and emit only a sparse lyric-adjacent motif.

    ``generated`` has already served its compatibility purpose: the legacy
    handler validated every effect-specific parameter. Its dense environmental
    events are intentionally not returned in version 3.
    """
    del generated
    budget = RESTRAINED_OBJECT_BUDGETS[effect]
    duration = event.duration_ms
    phases = (('entry', 0, start, budget.ambient_entry), ('hold', start, duration - end, budget.ambient_hold), ('exit', duration - end, duration, budget.ambient_exit))
    result: list[DialogueEvent] = []
    for phase, begin, finish, count in phases:
        if phase == 'hold' and LOCALIZED_CHOREOGRAPHY[effect].hold_mode == 'stopped':
            continue
        result.extend(_render_restrained_ambient_phase(event, begin, finish, phase=phase, count=count, effect=effect, params=params, context=context))
    return result

@dataclass(frozen=True)
class SweepTransitionSpec:
    """Whole-line text reveal and sparse physical-particle choreography.

    The lyric itself never moves and is never split into estimated glyph
    positions. ``reveal_mode`` is either ``sweep`` (overlapping rectangular
    bands reveal the already-typeset complete line) or ``flash`` (the complete
    line blinks in and out). ``sweep_policy`` resolves to one of the four
    cardinal directions. Particles are independent drawings whose piecewise
    paths approximate phenomenon-appropriate physical motion.
    """
    reveal_mode: str
    sweep_policy: str
    particle_model: str
    particle_kind: str
    entry_particles: int
    hold_particles: int
    exit_particles: int
    description_en: str
    description_ja: str

def _sweep_transition(reveal_mode: str, sweep_policy: str, particle_model: str, particle_kind: str, entry_particles: int, hold_particles: int, exit_particles: int, description_en: str, description_ja: str) -> SweepTransitionSpec:
    if reveal_mode not in {'sweep', 'flash'}:
        raise RuntimeError(f'invalid reveal mode: {reveal_mode}')
    if not 0 <= hold_particles <= 8:
        raise RuntimeError('readable hold may contain at most eight particles')
    return SweepTransitionSpec(reveal_mode=reveal_mode, sweep_policy=sweep_policy, particle_model=particle_model, particle_kind=particle_kind, entry_particles=entry_particles, hold_particles=hold_particles, exit_particles=exit_particles, description_en=description_en, description_ja=description_ja)
SWEEP_TRANSITIONS: dict[Effect, SweepTransitionSpec] = {Effect.RAIN_VEIL: _sweep_transition('sweep', 'top_down', 'rain', 'drop', 4, 1, 4, 'A few accelerating drops cross a top-to-bottom soft reveal; one local drop remains, and new rain closes the lyric in the same direction.', '加速する少数の雨粒とともに柔らかな帯が上から下へ文字を現し、表示中は一滴だけ残り、再び降る雨が同じ方向へ文字を消します。'), Effect.DRIZZLE_MIST: _sweep_transition('sweep', 'top_down', 'drizzle', 'drop', 3, 1, 3, 'Fine slow droplets accompany a soft downward condensation sweep and return to dissolve the line.', '細く遅い霧雨が柔らかな下向きの凝結スイープに沿い、再び降って文字を溶かします。'), Effect.CLOUDBURST: _sweep_transition('sweep', 'top_down', 'downpour', 'cloud_drop', 4, 0, 4, 'Four fast heavy drops define a compact downpour front that reveals and then clears the line.', '四本の速い大粒の雨が局所的な豪雨前線を作り、文字を現した後、再び通過して消します。'), Effect.RAINBOW_ARCH: _sweep_transition('sweep', 'horizontal_param', 'prism_arc', 'prism', 3, 1, 3, 'Prism particles travel along a shallow arc while a horizontal colour-light sweep reveals and removes the line.', 'プリズム粒子が浅い弧を進み、横方向の色光スイープが文字を現して消します。'), Effect.CREPUSCULAR_RAYS: _sweep_transition('sweep', 'top_down', 'light_dust', 'spark', 3, 1, 3, 'Illuminated dust sinks slowly through a downward shaft-like reveal and returns as the light closes.', '照らされた微粒子が下向きの光芒状スイープをゆっくり沈み、光が閉じるときに再び通過します。'), Effect.SNOWFALL_DEPTH: _sweep_transition('sweep', 'top_down', 'snow', 'snow', 4, 1, 4, 'Slow flakes with depth-scaled drift descend through a top-to-bottom reveal and later cover the lyric again.', '奥行きで大きさと漂い方の異なる雪片が上から下へ降り、同じ降雪で文字を再び覆います。'), Effect.BLIZZARD_WHITEOUT: _sweep_transition('sweep', 'horizontal_param', 'blizzard', 'snow', 4, 1, 4, 'Fast wind-driven snow and a matching horizontal sweep expose the lyric, then a second gust strips it away.', '風に押された高速の雪と同方向の横スイープが文字を現し、二度目の吹雪が文字を奪います。'), Effect.DIAMOND_DUST: _sweep_transition('flash', 'top_down', 'crystal_twinkle', 'crystal', 4, 1, 4, 'Drifting ice crystals twinkle while the complete lyric resolves through several light pulses and departs the same way.', '漂う氷晶がきらめき、完成した歌詞全体が数回の光パルスで結像し、同じ点滅で消えます。'), Effect.HAILSTORM: _sweep_transition('sweep', 'top_down', 'hail_bounce', 'hail', 4, 0, 4, 'Falling pellets accelerate, rebound at the lyric baseline, and synchronize with a downward reveal and conceal.', '落下する雹が加速し、歌詞下端付近で反発しながら、下向きの出現・消失スイープに同期します。'), Effect.FROST_BLOOM: _sweep_transition('sweep', 'frost_cardinal', 'frost_crystal', 'crystal', 3, 1, 3, 'Small frost crystals rise from the lower edge as the line crystallizes upward, then the process reverses visually without moving the text.', '小さな霜結晶が下端から立ち上がり、文字が上向きに結晶化して現れます。文字自体は動かさず、再度の結晶通過で消します。'), Effect.ICE_CRACK: _sweep_transition('flash', 'top_down', 'shard_burst', 'shard', 4, 0, 4, 'The lyric flashes into view with converging ice fragments and flashes out as the fragments burst away; no guessed glyph fracture is used.', '氷片が収束すると文字が点滅して現れ、氷片が外へ弾けると点滅して消えます。推定文字位置ごとの破砕は行いません。'), Effect.AVALANCHE: _sweep_transition('sweep', 'horizontal_param', 'avalanche', 'snow', 4, 0, 4, 'Snow clumps accelerate sideways and slightly downward with a compact horizontal front that reveals and buries the lyric.', '雪塊が横方向へ加速しながら少し沈み、局所的な前線が文字を現して再び埋めます。'), Effect.MORNING_MIST: _sweep_transition('sweep', 'bottom_up', 'mist_rise', 'cloud', 3, 1, 3, 'Thin mist parcels rise slowly with a bottom-to-top reveal and later veil the lyric on another pass.', '薄い霧の塊がゆっくり上昇し、下から上へ文字を現した後、再度の通過で包み隠します。'), Effect.SEA_OF_CLOUDS: _sweep_transition('sweep', 'bottom_up', 'cloud_rise', 'cloud', 3, 1, 3, 'Soft cloud puffs lift beneath a bottom-up reveal and return as a quiet cloud layer to close the line.', '柔らかな雲片が下から持ち上がるスイープに沿い、再び静かな雲層となって文字を閉じます。'), Effect.GENTLE_BREEZE: _sweep_transition('sweep', 'horizontal_param', 'breeze', 'seed', 3, 1, 3, 'Light seeds follow a low-amplitude sinusoidal breeze while a matching horizontal sweep reveals and removes the lyric.', '軽い種子が小さな正弦波状のそよ風に乗り、同方向の横スイープが文字を現して消します。'), Effect.GUST_FRONT: _sweep_transition('sweep', 'horizontal_param', 'gust', 'debris', 4, 0, 4, 'Small debris accelerates sharply across the line with a fast horizontal reveal and a second clearing gust.', '小さな飛来物が横方向へ急加速し、高速の横スイープで文字を現し、次の突風で消します。'), Effect.WHIRLWIND: _sweep_transition('sweep', 'bottom_up', 'vortex_rise', 'seed', 4, 1, 4, 'Light particles spiral upward around a narrow local axis while the lyric reveals from bottom to top.', '軽い粒子が局所的な細い軸の周囲を旋回しながら上昇し、文字は下から上へ現れます。'), Effect.TORNADO: _sweep_transition('sweep', 'bottom_up', 'tornado', 'debris', 4, 0, 4, 'Heavier debris spirals upward with a shrinking radius; a bottom-up sweep follows the rising funnel without drawing a large tornado body.', 'やや重い破片が半径を縮めながら旋回上昇し、大きな竜巻本体を描かずに下から上のスイープを同期させます。'), Effect.SANDSTORM: _sweep_transition('sweep', 'horizontal_param', 'sand', 'sand', 5, 1, 5, 'Fine grains advect rapidly with turbulent vertical jitter and a horizontal reveal front.', '細かな砂粒が上下に乱れながら高速移流し、横方向のスイープ前線とともに文字を出し入れします。'), Effect.HEAT_HAZE: _sweep_transition('sweep', 'bottom_up', 'heat', 'bead', 3, 1, 3, 'Tiny heat motes rise and meander while a soft bottom-up sweep makes the lyric appear and evaporate.', '微小な熱粒子が揺らぎながら上昇し、柔らかな下から上のスイープで文字が現れて蒸発するように消えます。'), Effect.OCEAN_SWELL: _sweep_transition('sweep', 'horizontal_param', 'wave_advect', 'foam', 3, 1, 3, 'Foam particles ride a shallow sinusoidal current as a horizontal wave-front reveal passes through the line.', '泡粒子が浅い正弦波状の流れに乗り、横方向の波面スイープが歌詞を通過します。'), Effect.BREAKING_WAVE: _sweep_transition('sweep', 'horizontal_param', 'breaker_foam', 'foam', 4, 0, 4, 'Foam follows short ballistic arcs over a compact horizontal breaker that reveals and washes away the lyric.', '泡が短い放物線を描き、局所的な横向きの砕波スイープが文字を現して洗い流します。'), Effect.RISING_TIDE: _sweep_transition('sweep', 'bottom_up', 'tide_bubble', 'bead', 3, 1, 3, 'Buoyant bubbles rise with a bottom-up waterline reveal and return with the next tide to conceal the text.', '浮力で上がる気泡と下から上の水位スイープが文字を現し、次の満ち潮で再び隠します。'), Effect.WATERFALL: _sweep_transition('sweep', 'top_down', 'waterfall', 'drop', 4, 1, 4, 'Nearly vertical accelerating drops pass through a top-down reveal and repeat for the disappearance.', 'ほぼ垂直に加速する水滴が上から下のスイープを通り、消失時にも同じ落下を繰り返します。'), Effect.RIVER_CURRENT: _sweep_transition('sweep', 'horizontal_param', 'river', 'bead', 3, 1, 3, 'Small water beads advect steadily with gentle cross-current oscillation and a horizontal reveal.', '小さな水粒が緩い横揺れを伴って一定速度で流れ、横方向のスイープで文字を出し入れします。'), Effect.WHIRLPOOL: _sweep_transition('sweep', 'top_down', 'whirlpool_sink', 'bead', 4, 1, 4, 'Water particles spiral inward and sink while a top-down sweep exposes and then submerges the line.', '水粒が内側へ旋回しながら沈み、上から下のスイープが文字を現して再び沈めます。'), Effect.LAVA_FLOW: _sweep_transition('sweep', 'horizontal_param', 'lava_flow', 'ember', 3, 1, 3, 'Viscous glowing droplets creep horizontally while a slow warm sweep reveals and remelts the lyric.', '粘性のある発光粒がゆっくり横へ進み、暖色の遅いスイープが文字を現して再び溶かします。'), Effect.EMBER_DRIFT: _sweep_transition('sweep', 'bottom_up', 'ember_rise', 'ember', 4, 1, 4, 'Buoyant embers rise with lateral wobble and a bottom-up reveal, then another ember draft lifts the line away.', '浮力を受けた火の粉が横に揺れながら上昇し、下から上へ文字を現し、次の上昇流で消します。'), Effect.CHERRY_BLOSSOM_STORM: _sweep_transition('sweep', 'top_down', 'petal_fall', 'petal', 4, 1, 4, 'Four fluttering petals descend with a top-down reveal; one remains during reading and a later fall conceals the lyric.', '四枚の花びらがひらひら降りながら上から下へ文字を現し、表示中は一枚だけ残り、再度の落下で消します。'), Effect.FALLING_LEAVES: _sweep_transition('sweep', 'top_down', 'leaf_fall', 'leaf', 4, 1, 4, 'A handful of tumbling leaves fall with the same top-to-bottom reveal boundary, then a second fall sweeps the lyric away.', '少数の葉が回転しながら降り、同じ上から下のスイープ境界で文字を現します。再度の落葉が歌詞を消します。'), Effect.FIREFLY_NIGHT: _sweep_transition('flash', 'top_down', 'firefly_wander', 'firefly', 4, 1, 4, 'Fireflies wander with smooth low-speed turns while the complete lyric appears and disappears through soft flicker pulses.', '蛍が低速で滑らかに方向を変え、完成した歌詞全体が柔らかな点滅で現れて消えます。'), Effect.BIOLUMINESCENT_TIDE: _sweep_transition('sweep', 'horizontal_param', 'biolume_wave', 'glow_foam', 3, 1, 3, 'Glowing foam particles ride a horizontal wave and illuminate the matching reveal front.', '発光する泡粒子が横波に乗り、同方向のスイープ前線を照らします。'), Effect.METEOR_SHOWER: _sweep_transition('sweep', 'top_down', 'meteor', 'meteor', 4, 0, 4, 'Short fast meteor particles cut diagonally downward while the lyric reveals from top to bottom without moving individual glyphs.', '短く高速の流星粒子が斜め下へ走り、個々の文字を動かさずに歌詞全体を上から下へ現します。'), Effect.SOLAR_ECLIPSE: _sweep_transition('sweep', 'horizontal_param', 'corona', 'spark', 3, 1, 3, 'Sparse corona sparks arc around the line while a horizontal shadow-light boundary reveals and hides the lyric.', '少数のコロナ粒子が歌詞周囲を弧状に動き、横方向の影と光の境界が文字を出し入れします。'), Effect.MOONLIGHT_CLOUDS: _sweep_transition('sweep', 'horizontal_param', 'moon_cloud', 'cloud', 3, 1, 3, 'Small cloud puffs drift horizontally across a cool moonlit reveal and return to cover the lyric.', '小さな雲片が月光色の横スイープを漂い、再び通過して文字を覆います。'), Effect.SUNRISE_HORIZON: _sweep_transition('sweep', 'bottom_up', 'sunrise_dust', 'spark', 3, 1, 3, 'Warm dust rises from the baseline as a bottom-up dawn reveal brightens the lyric, then dims it on the next pass.', '暖かな微粒子が基線から上昇し、下から上の日の出スイープが歌詞を明るく現し、次の通過で暗く消します。')}
FLASH_EFFECTS = frozenset((effect for effect, spec in SWEEP_TRANSITIONS.items() if spec.reveal_mode == 'flash'))

def _resolve_sweep_direction(effect: Effect, params: Mapping[str, Any]) -> Direction:
    policy = SWEEP_TRANSITIONS[effect].sweep_policy
    if policy == 'top_down':
        return Direction.TOP_TO_BOTTOM
    if policy == 'bottom_up':
        return Direction.BOTTOM_TO_TOP
    if policy == 'left_right':
        return Direction.LEFT_TO_RIGHT
    if policy == 'right_left':
        return Direction.RIGHT_TO_LEFT
    raw = params.get('direction', DEFAULT_PARAMS[effect].get('direction', Direction.LEFT_TO_RIGHT))
    if not isinstance(raw, Direction):
        try:
            raw = Direction(str(raw))
        except ValueError as exc:
            raise EffectParameterError(f'invalid direction for sweep choreography: {raw!r}') from exc
    if policy == 'horizontal_param':
        if raw in {Direction.RIGHT_TO_LEFT, Direction.COUNTERCLOCKWISE, Direction.EDGES_IN}:
            return Direction.RIGHT_TO_LEFT
        return Direction.LEFT_TO_RIGHT
    if policy == 'frost_cardinal':
        return Direction.TOP_TO_BOTTOM if raw is Direction.EDGES_IN else Direction.BOTTOM_TO_TOP
    raise EffectError(f'unknown sweep policy: {policy}')

def _text_style_tags(spec: LocalizedLyricSpec, *, glow: bool=False) -> str:
    if glow:
        return f'\\1c{spec.glow}\\3c{spec.glow}\\bord5.2\\blur4.2\\shad0'
    return '\\bord3.4\\blur0.35\\shad0.8'

def _expanded_text_box(context: EffectContext, amount: int=6) -> Rect:
    box = context.box
    pad_x = max(96, min(180, round(box.height * 1.1)))
    pad_y = max(amount, min(18, round(box.height * 0.1)))
    return Rect(max(0, box.x1 - pad_x), max(0, box.y1 - pad_y), min(context.play_res_x, box.x2 + pad_x), min(context.play_res_y, box.y2 + pad_y))

def _sweep_bands(rect: Rect, direction: Direction) -> list[Rect]:
    horizontal = direction in {Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT}
    count = 20 if horizontal else 12
    extent = rect.width if horizontal else rect.height
    overlap = max(3, round(extent / count * 0.22))
    bands: list[Rect] = []
    for index in range(count):
        low = round(extent * index / count)
        high = round(extent * (index + 1) / count)
        low = max(0, low - overlap)
        high = min(extent, high + overlap)
        if horizontal:
            band = Rect(rect.x1 + low, rect.y1, rect.x1 + high, rect.y2)
        else:
            band = Rect(rect.x1, rect.y1 + low, rect.x2, rect.y1 + high)
        bands.append(band)
    if direction in {Direction.RIGHT_TO_LEFT, Direction.BOTTOM_TO_TOP}:
        bands.reverse()
    return bands

def _sweep_text_phase(event: DialogueEvent, begin: int, finish: int, *, entering: bool, effect: Effect, direction: Direction, context: EffectContext) -> list[DialogueEvent]:
    if finish <= begin:
        return []
    spec = LOCALIZED_CHOREOGRAPHY[effect]
    rect = _expanded_text_box(context)
    bands = _sweep_bands(rect, direction)
    duration = finish - begin
    ramp = max(70, min(180, round(duration * 0.18)))
    travel = max(1, duration - ramp)
    result: list[DialogueEvent] = []
    for index, band in enumerate(bands):
        progress = index / max(1, len(bands) - 1)
        delay = round(travel * progress)
        transition_end = min(duration, delay + ramp)
        if entering:
            alpha_tags = f'\\alpha&HFF&\\t({delay},{transition_end},\\alpha&H00&)'
        else:
            alpha_tags = f'\\alpha&H00&\\t({delay},{transition_end},\\alpha&HFF&)'
        crisp = _clone(event, start_ms=event.start_ms + begin, end_ms=event.start_ms + finish, layer=event.layer + 12, effect_field=f"NAT40:{effect.value}:text:{('entry' if entering else 'exit')}:band:{index}", text=_add_tags(event.text, _text_style_tags(spec) + _clip_tag(band) + alpha_tags))
        result.append(crisp)
        glow_start = max(0, delay - round(ramp * 0.45))
        glow_peak = min(duration, delay + round(ramp * 0.45))
        glow_end = min(duration, delay + round(ramp * 1.25))
        if entering:
            glow_alpha = f'\\alpha&HFF&\\t({glow_start},{glow_peak},\\alpha&H78&)\\t({glow_peak},{glow_end},\\alpha&HFF&)'
        else:
            glow_alpha = f'\\alpha&HFF&\\t({glow_start},{glow_peak},\\alpha&H70&)\\t({glow_peak},{glow_end},\\alpha&HFF&)'
        result.append(_clone(event, start_ms=event.start_ms + begin, end_ms=event.start_ms + finish, layer=event.layer + 9, effect_field=f"NAT40:{effect.value}:text:{('entry' if entering else 'exit')}:glow:{index}", text=_add_tags(event.text, _text_style_tags(spec, glow=True) + _clip_tag(band) + glow_alpha)))
    return result

def _flash_text_phase(event: DialogueEvent, begin: int, finish: int, *, entering: bool, effect: Effect) -> list[DialogueEvent]:
    if finish <= begin:
        return []
    spec = LOCALIZED_CHOREOGRAPHY[effect]
    duration = finish - begin
    result: list[DialogueEvent] = []
    pulse_centres = (0.12, 0.34, 0.57)
    pulse_width = max(55, min(115, round(duration * 0.1)))
    for index, fraction in enumerate(pulse_centres):
        centre = begin + round(duration * fraction)
        start_rel = max(begin, centre - pulse_width // 2)
        end_rel = min(finish, centre + pulse_width // 2)
        if end_rel <= start_rel:
            continue
        alpha = 88 - index * 18 if entering else 48 + index * 22
        result.append(_clone(event, start_ms=event.start_ms + start_rel, end_ms=event.start_ms + end_rel, layer=event.layer + 12, effect_field=f"NAT40:{effect.value}:text:{('entry' if entering else 'exit')}:flash:{index}", text=_add_tags(event.text, _text_style_tags(spec) + f'\\alpha{_format_alpha(max(0, min(255, alpha)))}' + f'\\fad({min(28, max(8, (end_rel - start_rel) // 4))},{min(36, max(10, (end_rel - start_rel) // 3))})')))
        result.append(_clone(event, start_ms=event.start_ms + start_rel, end_ms=event.start_ms + end_rel, layer=event.layer + 9, effect_field=f"NAT40:{effect.value}:text:{('entry' if entering else 'exit')}:flash_glow:{index}", text=_add_tags(event.text, _text_style_tags(spec, glow=True) + f'\\alpha{_format_alpha(min(210, alpha + 70))}' + '\\fad(20,28)')))
    settle_start = begin + round(duration * 0.67)
    if entering:
        tags = _text_style_tags(spec) + f'\\alpha&HFF&\\t(0,{max(1, finish - settle_start)},\\alpha&H00&)'
    else:
        tags = _text_style_tags(spec) + f'\\alpha&H00&\\t(0,{max(1, finish - settle_start)},\\alpha&HFF&)'
    result.append(_clone(event, start_ms=event.start_ms + settle_start, end_ms=event.start_ms + finish, layer=event.layer + 12, effect_field=f"NAT40:{effect.value}:text:{('entry' if entering else 'exit')}:settle", text=_add_tags(event.text, tags)))
    return result

def _hold_text_event(event: DialogueEvent, start: int, end: int, effect: Effect) -> DialogueEvent | None:
    hold_end = event.duration_ms - end
    if hold_end <= start:
        return None
    spec = LOCALIZED_CHOREOGRAPHY[effect]
    return _clone(event, start_ms=event.start_ms + start, end_ms=event.start_ms + hold_end, layer=event.layer + 12, effect_field=f'NAT40:{effect.value}:text:hold', text=_add_tags(event.text, _text_style_tags(spec) + '\\alpha&H00&'))

def _localized_lyric_events(event: DialogueEvent, start: int, end: int, effect: Effect, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    """Reveal the fully typeset line without estimating any glyph positions."""
    direction = _resolve_sweep_direction(effect, params)
    transition = SWEEP_TRANSITIONS[effect]
    result: list[DialogueEvent] = []
    if start > 0:
        if transition.reveal_mode == 'flash':
            result.extend(_flash_text_phase(event, 0, start, entering=True, effect=effect))
        else:
            result.extend(_sweep_text_phase(event, 0, start, entering=True, effect=effect, direction=direction, context=context))
    hold = _hold_text_event(event, start, end, effect)
    if hold is not None:
        result.append(hold)
    if end > 0:
        phase_start = event.duration_ms - end
        if transition.reveal_mode == 'flash':
            result.extend(_flash_text_phase(event, phase_start, event.duration_ms, entering=False, effect=effect))
        else:
            result.extend(_sweep_text_phase(event, phase_start, event.duration_ms, entering=False, effect=effect, direction=direction, context=context))
    return result

def _mist_wisp_path(width: int, height: int, variant: int, *, core: bool=False) -> str:
    """Soft, horizontally elongated mist ribbon with an irregular contour."""
    w = max(28, width) / 2
    h = max(7, height) / 2
    if core:
        w *= 0.76
        h *= 0.52
    phase = (-1, 1, 0.55, -0.55)[variant % 4]
    return f'm {round(-w)} {round(h * 0.12)} b {round(-w * 0.7)} {round(-h * (0.72 + 0.12 * phase))} {round(-w * 0.24)} {round(-h * 0.38)} 0 {round(-h * 0.56)} b {round(w * 0.3)} {round(-h * (0.8 - 0.1 * phase))} {round(w * 0.72)} {round(-h * 0.28)} {round(w)} {round(-h * 0.05)} b {round(w * 0.66)} {round(h * 0.62)} {round(w * 0.18)} {round(h * 0.42)} 0 {round(h * 0.66)} b {round(-w * 0.34)} {round(h * (0.86 + 0.08 * phase))} {round(-w * 0.76)} {round(h * 0.42)} {round(-w)} {round(h * 0.12)}'

def _cloud_bank_path(width: int, height: int, variant: int, *, core: bool=False) -> str:
    """Layered cloud bank made from overlapping soft puffs, not a tiny icon."""
    w = max(44, width)
    h = max(18, height)
    if core:
        w = round(w * 0.78)
        h = round(h * 0.72)
    shift = (-0.08, 0.04, 0.1, -0.03)[variant % 4]
    puffs = ((-0.34 + shift, 0.06, 0.3, 0.46), (-0.08 + shift, -0.14, 0.34, 0.62), (0.23 + shift, -0.02, 0.38, 0.5), (0.02 + shift, 0.17, 0.58, 0.34))
    return ' '.join((_ellipse_path_at(round(px * w), round(py * h), max(3, round(rx * w)), max(3, round(ry * h))) for px, py, rx, ry in puffs))

def _heat_wisp_path(height: int, amplitude: int, variant: int, *, core: bool=False) -> str:
    height = max(26, height)
    amplitude = max(3, amplitude)
    if core:
        height = round(height * 0.82)
        amplitude = max(2, round(amplitude * 0.62))
    turns = (1.25, 1.55, 1.85, 1.4)[variant % 4]
    phase = (0.0, 0.8, 1.7, 2.5)[variant % 4]
    points = []
    for step in range(10):
        t = step / 9
        x = amplitude * math.sin(math.tau * turns * t + phase)
        y = height * (0.5 - t)
        points.append((x, y))
    return _polyline_path(points)

def _bubble_outline_path(radius: int, variant: int) -> str:
    r = max(3, radius)
    rx = r + (1 if variant % 3 == 1 else 0)
    ry = r + (1 if variant % 3 == 2 else 0)
    return _ellipse_path(rx, ry)

def _bubble_highlight_path(radius: int, variant: int) -> str:
    r = max(3, radius)
    x = -max(1, round(r * 0.34))
    y = -max(1, round(r * 0.32))
    dot = max(1, round(r * (0.2 + 0.04 * (variant % 2))))
    return _ellipse_path_at(x, y, dot, dot)

def _foam_fleck_path(size: int, variant: int, *, core: bool=False) -> str:
    """A small collection of filled foam bubbles with a ragged silhouette."""
    s = max(4, size)
    if core:
        s = max(3, round(s * 0.7))
    offsets = ((0.0, 0.0, 1.0), (0.92, -0.42, 0.62), (-0.78, -0.54, 0.52), (0.28 if variant % 2 else -0.24, 0.68, 0.46))
    return ' '.join((_ellipse_path_at(round(dx * s), round(dy * s), max(1, round(scale * s)), max(1, round(scale * s * 0.78))) for dx, dy, scale in offsets))

def _snow_puff_path(size: int, variant: int, *, core: bool=False) -> str:
    s = max(5, size)
    if core:
        s = max(3, round(s * 0.68))
    offsets = ((0, 0, 1.0), (-0.9, 0.08, 0.62), (0.82, -0.12, 0.68), (0.12, -0.72, 0.56))
    return ' '.join((_ellipse_path_at(round(dx * s), round(dy * s), max(1, round(scale * s)), max(1, round(scale * s * 0.74))) for dx, dy, scale in offsets))

@dataclass(frozen=True)
class _PhysicalParticleStyle:
    path: str
    fill: bool
    border: float
    blur: float
    alpha: int
    scale: float

def _physical_particle_style(kind: str) -> _PhysicalParticleStyle:
    base = _carrier_style(kind)
    return _PhysicalParticleStyle(base.path, base.fill, base.border, base.blur, base.alpha, base.scale)

def _particle_colour(effect: Effect, index: int) -> str:
    spec = LOCALIZED_CHOREOGRAPHY[effect]
    if spec.carrier_palette:
        return spec.carrier_palette[index % len(spec.carrier_palette)]
    if effect in {Effect.SUNRISE_HORIZON, Effect.EMBER_DRIFT, Effect.LAVA_FLOW}:
        return spec.accent
    return spec.glow

def _rotation_sign(params: Mapping[str, Any], effect: Effect) -> float:
    raw = params.get('direction', DEFAULT_PARAMS[effect].get('direction', Direction.CLOCKWISE))
    if not isinstance(raw, Direction):
        try:
            raw = Direction(str(raw))
        except ValueError:
            return 1.0
    return -1.0 if raw in {Direction.COUNTERCLOCKWISE, Direction.RIGHT_TO_LEFT, Direction.EDGES_IN} else 1.0

def _motion_points(model: str, *, phase: str, index: int, count: int, effect: Effect, params: Mapping[str, Any], context: EffectContext, seed: int) -> list[tuple[float, float, float, float, float]]:
    """Return ``(t, x, y, scale, rotation)`` samples for one particle.

    The equations intentionally differ by material: gravity-driven drops use
    quadratic descent; snow, petals and leaves flutter; buoyant particles rise;
    wind-borne material accelerates horizontally; hail rebounds; vortex matter
    follows a shrinking or expanding spiral; foam follows a short ballistic arc.
    """
    scene = _scene_box(context)
    box = context.box
    cx, cy = box.center
    direction = _resolve_sweep_direction(effect, params)
    sign = -1.0 if direction is Direction.RIGHT_TO_LEFT else 1.0
    spin = _rotation_sign(params, effect)
    u0 = _seed_value(seed, index, 301)
    u1 = _seed_value(seed, index, 302)
    u2 = _seed_value(seed, index, 303)
    u3 = _seed_value(seed, index, 304)
    lane = (index + 0.5) / max(1, count)
    points: list[tuple[float, float, float, float, float]] = []

    def add(t: float, x: float, y: float, scale: float, rotation: float) -> None:
        points.append((t, x, y, scale, rotation))
    if model in {'rain', 'drizzle', 'downpour', 'waterfall'}:
        x0 = scene.x1 + scene.width * (0.12 + 0.76 * ((lane + u0 * 0.21) % 1.0))
        drift = (10 if model in {'waterfall'} else 24) * (u1 - 0.45)
        if model == 'downpour':
            drift *= 0.45
        gravity = 0.86 if model in {'downpour', 'waterfall'} else 0.68 if model == 'rain' else 0.52
        for t in (0.0, 0.3, 0.62, 1.0):
            y = scene.y1 - 18 + (scene.height + 38) * ((1 - gravity) * t + gravity * t * t)
            x = x0 + drift * t
            scale = 62 + (34 if model == 'downpour' else 22) * t
            add(t, x, y, scale, -8 + drift * 0.25)
    elif model in {'snow', 'petal_fall', 'leaf_fall'}:
        x0 = scene.x1 + scene.width * (0.1 + 0.8 * ((lane + u0 * 0.24) % 1.0))
        amplitude = 11 if model == 'snow' else 20 if model == 'petal_fall' else 29
        turns = 0.85 if model == 'snow' else 1.2 if model == 'petal_fall' else 1.45
        fall_power = 1.08 if model == 'snow' else 1.18
        for t in (0.0, 0.25, 0.5, 0.75, 1.0):
            x = x0 + amplitude * math.sin(math.tau * turns * t + u1 * math.tau) + sign * 9 * t
            y = scene.y1 - 18 + (scene.height + 38) * t ** fall_power
            base_scale = 70 + 28 * u2
            add(t, x, y, base_scale * (0.92 + 0.1 * t), spin * (80 + 250 * t + 60 * math.sin(math.pi * t)))
    elif model in {'blizzard', 'breeze', 'gust', 'sand', 'river', 'wave_advect', 'lava_flow', 'biolume_wave', 'moon_cloud'}:
        x0 = scene.x1 - 30 if sign > 0 else scene.x2 + 30
        x1 = scene.x2 + 30 if sign > 0 else scene.x1 - 30
        y_base = scene.y1 + scene.height * (0.18 + 0.64 * ((lane + u0 * 0.15) % 1.0))
        amplitude = {'blizzard': 14, 'breeze': 25, 'gust': 10, 'sand': 8, 'river': 7, 'wave_advect': 18, 'lava_flow': 6, 'biolume_wave': 16, 'moon_cloud': 5}[model]
        power = 1.35 if model == 'gust' else 1.18 if model in {'blizzard', 'sand'} else 1.0
        for t in (0.0, 0.28, 0.58, 1.0):
            p = t ** power
            x = x0 + (x1 - x0) * p
            y = y_base + amplitude * math.sin(math.tau * (1.1 if model in {'wave_advect', 'biolume_wave'} else 0.75) * t + u1 * math.tau)
            if model == 'sand':
                y += 5 * math.sin(math.tau * 3.4 * t + u2 * math.tau)
            if model == 'lava_flow':
                y += 8 * t * t
            scale = 64 + 34 * u2
            if model == 'moon_cloud':
                scale = 42 + 24 * u2
            add(t, x, y, scale, spin * (20 + (160 if model in {'blizzard', 'breeze'} else 55) * t))
    elif model in {'mist_rise', 'cloud_rise', 'heat', 'ember_rise', 'tide_bubble', 'sunrise_dust', 'light_dust'}:
        x0 = scene.x1 + scene.width * (0.15 + 0.7 * ((lane + u0 * 0.18) % 1.0))
        rise = scene.height * (0.65 if model in {'mist_rise', 'cloud_rise'} else 0.95)
        for t in (0.0, 0.3, 0.64, 1.0):
            p = 1 - (1 - t) ** 1.25
            y = scene.y2 + 16 - rise * p
            wobble = 18 if model in {'heat', 'ember_rise'} else 9
            x = x0 + wobble * math.sin(math.tau * (1.1 if model == 'heat' else 0.65) * t + u1 * math.tau)
            if model == 'light_dust':
                y = scene.y1 - 8 + (scene.height + 16) * t
            scale = 48 + 36 * u2
            if model in {'mist_rise', 'cloud_rise'}:
                scale = 42 + 28 * u2 + 8 * t
            add(t, x, y, scale, spin * (15 + 80 * t))
    elif model == 'hail_bounce':
        x = scene.x1 + scene.width * (0.12 + 0.76 * ((lane + u0 * 0.17) % 1.0))
        impact = min(scene.y2 - 3, box.y2 + 46)
        add(0.0, x - 10 * (u1 - 0.5), scene.y1 - 14, 68, 0)
        add(0.52, x, impact, 82, spin * 90)
        add(0.73, x + 9 * (u2 - 0.5), impact - (26 + 20 * u3), 76, spin * 160)
        add(1.0, x + 15 * (u1 - 0.5), impact - 2, 72, spin * 230)
    elif model == 'crystal_twinkle':
        x0 = scene.x1 + scene.width * (0.12 + 0.76 * ((lane + u0 * 0.19) % 1.0))
        y0 = scene.y1 + scene.height * (0.18 + 0.64 * u1)
        for t in (0.0, 0.3, 0.6, 1.0):
            x = x0 + 8 * math.sin(math.tau * t + u2 * math.tau)
            y = y0 + 12 * t + 5 * math.sin(math.tau * 1.5 * t + u3 * math.tau)
            add(t, x, y, 54 + 38 * (0.5 + 0.5 * math.sin(math.tau * 2 * t)), spin * 180 * t)
    elif model in {'frost_crystal', 'shard_burst'}:
        angle = math.tau * ((lane + u0 * 0.13) % 1.0)
        radius = min(scene.width * 0.42, 120)
        inner = 8 + 10 * u1
        if model == 'frost_crystal':
            start = (cx + math.cos(angle) * inner, box.y2 + 14)
            endp = (cx + math.cos(angle) * radius * 0.48, scene.y1 + 8)
            for t in (0.0, 0.34, 0.68, 1.0):
                x = start[0] + (endp[0] - start[0]) * t
                y = start[1] + (endp[1] - start[1]) * t
                add(t, x, y, 48 + 28 * t, spin * 150 * t)
        else:
            outer = (cx + math.cos(angle) * radius, cy + math.sin(angle) * min(scene.height * 0.42, 76))
            innerp = (cx + math.cos(angle) * inner, cy + math.sin(angle) * inner)
            p0, p1 = (outer, innerp) if phase == 'entry' else (innerp, outer)
            for t in (0.0, 0.26, 0.58, 1.0):
                p = t * t if phase == 'exit' else 1 - (1 - t) * (1 - t)
                x = p0[0] + (p1[0] - p0[0]) * p
                y = p0[1] + (p1[1] - p0[1]) * p
                add(t, x, y, 48 + 42 * t, spin * 260 * t)
    elif model == 'avalanche':
        x0 = scene.x1 - 36 if sign > 0 else scene.x2 + 36
        x1 = scene.x2 + 36 if sign > 0 else scene.x1 - 36
        y0 = scene.y1 + scene.height * (0.2 + 0.5 * lane)
        for t in (0.0, 0.28, 0.6, 1.0):
            p = t ** 1.28
            x = x0 + (x1 - x0) * p
            y = y0 + 34 * t * t + 8 * math.sin(math.tau * t + u1 * math.tau)
            add(t, x, y, 62 + 32 * t, spin * 170 * t)
    elif model in {'vortex_rise', 'tornado', 'whirlpool_sink'}:
        turns = 1.2 if model == 'vortex_rise' else 1.75 if model == 'tornado' else 1.55
        base_angle = math.tau * (lane + u0 * 0.12)
        max_rx = min(scene.width * 0.38, 130)
        max_ry = min(scene.height * 0.36, 58)
        for t in (0.0, 0.22, 0.45, 0.68, 1.0):
            angle = base_angle + spin * math.tau * turns * t
            if model == 'whirlpool_sink':
                radius = 1.0 - 0.78 * t
                y_center = cy + 18 * t
            elif model == 'tornado':
                radius = 1.0 - 0.68 * t
                y_center = scene.y2 - max_ry - (scene.height - 2 * max_ry) * 0.92 * t
            else:
                radius = 0.95 - 0.42 * t
                y_center = scene.y2 - max_ry - (scene.height - 2 * max_ry) * 0.78 * t
            x = cx + math.cos(angle) * max_rx * radius
            y = y_center + math.sin(angle) * max_ry * radius
            add(t, x, y, 58 + 30 * (1 - radius), spin * 360 * turns * t)
    elif model == 'breaker_foam':
        x0 = scene.x1 - 24 if sign > 0 else scene.x2 + 24
        x1 = scene.x2 + 24 if sign > 0 else scene.x1 - 24
        y0 = box.y2 + 28 + 8 * (u0 - 0.5)
        for t in (0.0, 0.28, 0.58, 1.0):
            x = x0 + (x1 - x0) * t
            y = y0 - (42 + 18 * u1) * 4 * t * (1 - t) + 14 * t
            add(t, x, y, 54 + 34 * t, spin * 190 * t)
    elif model == 'prism_arc':
        x0 = scene.x1 - 18 if sign > 0 else scene.x2 + 18
        x1 = scene.x2 + 18 if sign > 0 else scene.x1 - 18
        for t in (0.0, 0.3, 0.62, 1.0):
            x = x0 + (x1 - x0) * t
            y = cy + 24 - (48 + 18 * u1) * math.sin(math.pi * t)
            add(t, x, y, 52 + 32 * math.sin(math.pi * t), spin * 180 * t)
    elif model == 'firefly_wander':
        x0 = scene.x1 + scene.width * (0.12 + 0.76 * ((lane + u0 * 0.21) % 1.0))
        y0 = scene.y1 + scene.height * (0.18 + 0.64 * u1)
        for t in (0.0, 0.25, 0.5, 0.75, 1.0):
            x = x0 + 18 * math.sin(math.tau * 0.9 * t + u2 * math.tau) + 7 * math.sin(math.tau * 2.1 * t)
            y = y0 + 12 * math.sin(math.tau * 0.7 * t + u3 * math.tau) - 8 * t
            add(t, x, y, 58 + 30 * (0.5 + 0.5 * math.sin(math.tau * 2.0 * t)), 0)
    elif model == 'meteor':
        start_x = scene.x1 + scene.width * (0.18 + 0.64 * ((lane + u0 * 0.2) % 1.0))
        if sign > 0:
            start_x -= 38
        else:
            start_x += 38
        end_x = start_x + sign * (90 + 50 * u1)
        for t in (0.0, 0.36, 0.72, 1.0):
            x = start_x + (end_x - start_x) * t
            y = scene.y1 - 26 + (scene.height + 56) * t
            add(t, x, y, 62 + 18 * t, -sign * 28)
    elif model == 'corona':
        base_angle = math.pi * (1.05 if sign > 0 else -0.05) + u0 * 0.25
        for t in (0.0, 0.3, 0.62, 1.0):
            angle = base_angle + sign * math.pi * 0.9 * t
            x = cx + math.cos(angle) * min(scene.width * 0.42, 145)
            y = cy + math.sin(angle) * min(scene.height * 0.35, 58)
            add(t, x, y, 54 + 30 * math.sin(math.pi * t), spin * 120 * t)
    else:
        raise EffectError(f'unknown physical particle model: {model}')
    return points

def _emit_piecewise_particle(event: DialogueEvent, begin: int, finish: int, *, points: Sequence[tuple[float, float, float, float, float]], effect: Effect, phase: str, particle_index: int, kind: str, colour: str, context: EffectContext) -> list[DialogueEvent]:
    if finish <= begin or len(points) < 2:
        return []
    style = _physical_particle_style(kind)
    scene = _scene_box(context)
    duration = finish - begin
    result: list[DialogueEvent] = []
    marker = f'NAT40:{effect.value}:particle:{phase}:{particle_index}'
    for segment_index, (first, second) in enumerate(zip(points, points[1:])):
        t0, x0, y0, scale0, rotation0 = first
        t1, x1, y1, scale1, rotation1 = second
        seg_begin = begin + round(duration * t0)
        seg_finish = begin + round(duration * t1)
        if seg_finish <= seg_begin:
            continue
        alpha = style.alpha
        if kind in {'firefly', 'glow_foam'}:
            alpha = max(0, style.alpha - (18 if segment_index % 2 == 0 else 0))
        item = _moving_shape(event, seg_begin, seg_finish, style.path, x0=x0, y0=y0, x1=x1, y1=y1, color=colour, alpha=alpha, scale0=scale0, scale1=scale1, rotation0=rotation0, rotation1=rotation1, blur=style.blur, border=style.border, outline=colour, fill=style.fill, fade_in=min(45, max(0, (seg_finish - seg_begin) // 4)) if segment_index == 0 else 0, fade_out=min(80, max(0, (seg_finish - seg_begin) // 3)) if segment_index == len(points) - 2 else 0, clip=scene, layer_offset=7)
        result.append(_clone(item, effect_field=marker + f':segment:{segment_index}'))
    return result

def _particle_kind_for(effect: Effect, model: str, base_kind: str, index: int) -> str:
    if False and index % 3 == 2:
        return 'prism'
    if False and index % 2 == 0:
        return 'drop'
    if model == 'light_dust' and index % 2:
        return 'bead'
    return base_kind

def _render_physical_particle_phase(event: DialogueEvent, begin: int, finish: int, *, phase: str, count: int, effect: Effect, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    if count <= 0 or finish <= begin:
        return []
    transition = SWEEP_TRANSITIONS[effect]
    seed = int(params.get('seed', DEFAULT_PARAMS[effect].get('seed', _legacy_effect_number(effect) * 1009)))
    phase_duration = finish - begin
    result: list[DialogueEvent] = []
    for index in range(count):
        if phase == 'hold':
            particle_begin = begin
            particle_finish = finish
        else:
            offset = round(phase_duration * 0.16 * index / max(1, count - 1))
            particle_begin = begin + offset
            particle_finish = finish
        points = _motion_points(transition.particle_model, phase=phase, index=index, count=count, effect=effect, params=params, context=context, seed=seed + {'entry': 0, 'hold': 4001, 'exit': 8009}[phase])
        kind = _particle_kind_for(effect, transition.particle_model, transition.particle_kind, index)
        result.extend(_emit_piecewise_particle(event, particle_begin, particle_finish, points=points, effect=effect, phase=phase, particle_index=index, kind=kind, colour=_particle_colour(effect, index), context=context))
    return result
_V5_PARTICLE_BUDGETS: dict[Effect, tuple[int, int, int]] = {Effect.RAIN_VEIL: (28, 8, 28), Effect.DRIZZLE_MIST: (30, 9, 30), Effect.CLOUDBURST: (32, 9, 32), Effect.RAINBOW_ARCH: (10, 3, 10), Effect.CREPUSCULAR_RAYS: (14, 4, 14), Effect.SNOWFALL_DEPTH: (28, 8, 28), Effect.BLIZZARD_WHITEOUT: (18, 5, 18), Effect.DIAMOND_DUST: (20, 6, 20), Effect.HAILSTORM: (20, 4, 20), Effect.FROST_BLOOM: (12, 3, 12), Effect.ICE_CRACK: (12, 3, 12), Effect.AVALANCHE: (18, 4, 18), Effect.MORNING_MIST: (14, 5, 14), Effect.SEA_OF_CLOUDS: (12, 4, 12), Effect.GENTLE_BREEZE: (12, 4, 12), Effect.GUST_FRONT: (16, 4, 16), Effect.WHIRLWIND: (18, 5, 18), Effect.TORNADO: (18, 4, 18), Effect.SANDSTORM: (18, 5, 18), Effect.HEAT_HAZE: (16, 5, 16), Effect.OCEAN_SWELL: (14, 4, 14), Effect.BREAKING_WAVE: (18, 5, 18), Effect.RISING_TIDE: (16, 5, 16), Effect.WATERFALL: (30, 8, 30), Effect.RIVER_CURRENT: (14, 5, 14), Effect.WHIRLPOOL: (16, 5, 16), Effect.LAVA_FLOW: (14, 4, 14), Effect.EMBER_DRIFT: (14, 4, 14), Effect.CHERRY_BLOSSOM_STORM: (20, 5, 20), Effect.FALLING_LEAVES: (18, 5, 18), Effect.FIREFLY_NIGHT: (12, 5, 12), Effect.BIOLUMINESCENT_TIDE: (16, 5, 16), Effect.METEOR_SHOWER: (14, 3, 14), Effect.SOLAR_ECLIPSE: (10, 3, 10), Effect.MOONLIGHT_CLOUDS: (12, 4, 12), Effect.SUNRISE_HORIZON: (14, 4, 14)}
_V5_PARTICLE_KINDS: dict[Effect, str] = {Effect.RAIN_VEIL: 'rain_streak', Effect.DRIZZLE_MIST: 'drizzle_streak', Effect.CLOUDBURST: 'heavy_rain_streak', Effect.AVALANCHE: 'snow_puff', Effect.MORNING_MIST: 'mist_wisp', Effect.SEA_OF_CLOUDS: 'cloud_bank', Effect.HEAT_HAZE: 'heat_wisp', Effect.OCEAN_SWELL: 'foam', Effect.BREAKING_WAVE: 'foam', Effect.RISING_TIDE: 'bubble', Effect.WATERFALL: 'water_streak', Effect.RIVER_CURRENT: 'bubble', Effect.WHIRLPOOL: 'bubble', Effect.MOONLIGHT_CLOUDS: 'cloud_bank'}
for _v5_effect, _v5_budget in _V5_PARTICLE_BUDGETS.items():
    _v5_previous = SWEEP_TRANSITIONS[_v5_effect]
    SWEEP_TRANSITIONS[_v5_effect] = replace(_v5_previous, particle_kind=_V5_PARTICLE_KINDS.get(_v5_effect, _v5_previous.particle_kind), entry_particles=_v5_budget[0], hold_particles=_v5_budget[1], exit_particles=_v5_budget[2], description_en=_v5_previous.description_en.replace('A few ', 'A varied field of ').replace('a few ', 'a varied field of '), description_ja=_v5_previous.description_ja.replace('少数の', '密度と速度の異なる').replace('四本の', '時間差で降る多数の'))
_V5_DESCRIPTION_OVERRIDES: dict[Effect, tuple[str, str]] = {Effect.RAIN_VEIL: ('Many independently timed, tapered rain streaks accelerate through a soft top-to-bottom reveal; a smaller local shower continues during reading and a fresh field closes the lyric.', '発生時刻・長さ・速度・傾きの異なる多数の細い雨筋が、上から下の柔らかなスイープとともに文字を現します。表示中は局所的な小雨だけを残し、新しい雨の群れで文字を消します。'), Effect.DRIZZLE_MIST: ('A fine, irregular field of short drizzle streaks descends slowly with the reveal and returns as a soft wet veil for the exit.', '短く細い霧雨が不規則な時間差でゆっくり降り、下向きスイープで文字を現した後、柔らかな濡れ幕となって再び文字を消します。'), Effect.CLOUDBURST: ('A dense, staggered field of long heavy-rain streaks forms a compact downpour front for both reveal and conceal.', '長く太い豪雨の雨筋が密度・速度・開始時刻を変えて降り、局所的な豪雨前線として文字を現し、同じ構造で消します。'), Effect.SNOWFALL_DEPTH: ('Many individually sized and rotated snow crystals descend at different depths while the soft vertical front reveals and later covers the lyric.', '大きさ・回転・横漂流・落下速度の異なる多数の雪結晶が奥行きを持って降り、柔らかな縦スイープで文字を現して再び覆います。'), Effect.HAILSTORM: ('Irregularly sized hail pellets accelerate, strike near the lyric baseline, rebound with different losses, and synchronize with the vertical reveal and conceal.', '大きさと速度の異なる雹が加速落下し、歌詞下端付近へ衝突して個別の減衰率で跳ね返りながら、縦方向の出現・消失に同期します。'), Effect.AVALANCHE: ('Powdery snow clumps of varied size accelerate sideways and downward in a compact local front that reveals and buries the lyric.', '大きさの異なる粉雪の塊が横方向へ加速しながら沈み、局所的な雪崩前線として文字を現して再び埋めます。'), Effect.MORNING_MIST: ('Soft horizontal mist wisps rise at different speeds and widths with the bottom-up reveal, then gather again to veil the lyric.', '幅・濃さ・上昇速度の異なる柔らかな霧の帯が下から上へ漂い、文字を現した後、再び集まって歌詞を包みます。'), Effect.SEA_OF_CLOUDS: ('Layered cloud banks with varied scale and drift rise beneath the bottom-up reveal and return as a quiet cloud field for the exit.', '大きさと漂流速度の異なる層状の雲塊が下から上へ持ち上がり、文字を現した後、静かな雲海となって再び覆います。'), Effect.HEAT_HAZE: ('Multiple translucent heat wisps rise with independent waviness and speed while a soft bottom-up front makes the lyric appear and evaporate.', '揺らぎ周期・幅・上昇速度の異なる半透明の熱気の筋が立ち上がり、柔らかな下から上の前線で文字を現し、蒸発するように消します。'), Effect.OCEAN_SWELL: ('Irregular foam flecks ride a shallow sinusoidal current while a horizontal wave-front reveal passes through the lyric.', '大きさの異なる泡沫が浅い正弦波状の流れに乗り、横方向の波面スイープが歌詞を通過します。'), Effect.BREAKING_WAVE: ('Dense foam flecks follow short ballistic spray arcs over a compact breaker front that reveals and washes away the lyric.', '密度と大きさの異なる泡沫が短い放物線状の飛沫軌道を描き、局所的な砕波前線が文字を現して洗い流します。'), Effect.RISING_TIDE: ('Buoyant bubbles of varied size rise on independent paths with a bottom-up waterline reveal and return with the next tide.', '大きさと浮上速度の異なる気泡が独立した軌道で上昇し、下から上の水位スイープで文字を現して次の満ち潮で覆います。'), Effect.WATERFALL: ('A layered field of long, slightly curved water ribbons accelerates nearly vertically through the reveal and repeats for the disappearance.', '長さ・太さ・湾曲・速度の異なる多数の水筋がほぼ垂直に加速し、上から下へ文字を現して消します。'), Effect.CHERRY_BLOSSOM_STORM: ('Staggered petals of varied size, rotation and lateral flutter descend with a top-to-bottom reveal; a lighter fall remains during reading and a new fall conceals the lyric.', '大きさ・回転・横揺れ・開始時刻の異なる花びらが上から下へ舞い、文字を現します。表示中は軽い落花だけを残し、新しい花びらの群れで文字を消します。'), Effect.FALLING_LEAVES: ('Staggered leaves with varied silhouettes, tumble rates and asymmetric drift descend with the same top-to-bottom reveal and return as a second fall for the exit.', '輪郭・回転速度・非対称な横流れ・開始時刻の異なる葉が上から下へ落ち、同方向のスイープで文字を現し、二度目の落葉で消します。'), Effect.MOONLIGHT_CLOUDS: ('Soft cloud banks of varied scale drift horizontally across a cool moonlit reveal and return to cover the lyric.', '大きさと速度の異なる柔らかな雲塊が月光色の横スイープを漂い、再び通過して文字を覆います。')}
for _v5_effect, (_v5_en, _v5_ja) in _V5_DESCRIPTION_OVERRIDES.items():
    SWEEP_TRANSITIONS[_v5_effect] = replace(SWEEP_TRANSITIONS[_v5_effect], description_en=_v5_en, description_ja=_v5_ja)
_V5_COUNT_PARAMS: dict[Effect, tuple[str, ...]] = {Effect.RAIN_VEIL: ('density',), Effect.DRIZZLE_MIST: ('density',), Effect.CLOUDBURST: ('density',), Effect.RAINBOW_ARCH: ('sparkles',), Effect.CREPUSCULAR_RAYS: ('dust',), Effect.SNOWFALL_DEPTH: ('far_flakes', 'near_flakes'), Effect.BLIZZARD_WHITEOUT: ('streaks',), Effect.DIAMOND_DUST: ('crystals',), Effect.HAILSTORM: ('pellets',), Effect.FROST_BLOOM: ('branches',), Effect.ICE_CRACK: ('shards',), Effect.AVALANCHE: ('powder', 'debris'), Effect.MORNING_MIST: ('bands',), Effect.SEA_OF_CLOUDS: ('cloudlets',), Effect.GENTLE_BREEZE: ('seeds',), Effect.GUST_FRONT: ('streaks', 'debris'), Effect.WHIRLWIND: ('particles',), Effect.TORNADO: ('debris',), Effect.SANDSTORM: ('grains',), Effect.HEAT_HAZE: ('wisps',), Effect.OCEAN_SWELL: ('foam',), Effect.BREAKING_WAVE: ('spray', 'foam'), Effect.RISING_TIDE: ('glints',), Effect.WATERFALL: ('streams',), Effect.RIVER_CURRENT: ('foam',), Effect.WHIRLPOOL: ('foam',), Effect.LAVA_FLOW: ('embers',), Effect.EMBER_DRIFT: ('embers',), Effect.CHERRY_BLOSSOM_STORM: ('petals',), Effect.FALLING_LEAVES: ('leaves',), Effect.FIREFLY_NIGHT: ('fireflies',), Effect.BIOLUMINESCENT_TIDE: ('sparks', 'foam'), Effect.METEOR_SHOWER: ('meteors',), Effect.SOLAR_ECLIPSE: ('corona_rays',), Effect.MOONLIGHT_CLOUDS: ('cloud_layers',), Effect.SUNRISE_HORIZON: ('rays',)}

def _scaled_particle_count(effect: Effect, phase: str, base_count: int, params: Mapping[str, Any]) -> int:
    keys = _V5_COUNT_PARAMS[effect]
    default_total = sum((float(DEFAULT_PARAMS[effect][key]) for key in keys))
    actual_total = sum((float(params.get(key, DEFAULT_PARAMS[effect][key])) for key in keys))
    ratio = 1.0 if default_total <= 0 else _clamp(actual_total / default_total, 0.25, 2.25)
    cap = 72 if phase in {'entry', 'exit'} else 18
    return max(1, min(cap, round(base_count * ratio))) if base_count else 0
_V5_FALLING_MODELS = frozenset({'rain', 'drizzle', 'downpour', 'snow', 'petal_fall', 'leaf_fall', 'hail_bounce', 'waterfall', 'light_dust', 'crystal_twinkle', 'meteor'})
_V5_RISING_MODELS = frozenset({'mist_rise', 'cloud_rise', 'heat', 'ember_rise', 'tide_bubble', 'sunrise_dust', 'vortex_rise', 'tornado'})
_V5_HORIZONTAL_MODELS = frozenset({'blizzard', 'breeze', 'gust', 'sand', 'river', 'wave_advect', 'lava_flow', 'biolume_wave', 'moon_cloud', 'avalanche', 'breaker_foam', 'prism_arc', 'corona'})

def _particle_scene_box(context: EffectContext, model: str) -> Rect:
    """Return a lyric-local field with enough run-up for believable motion."""
    base = _scene_box(context)
    box = context.box
    if model in _V5_FALLING_MODELS:
        top = max(0, box.y1 - max(118, min(176, round(box.height * 1.4))))
        bottom = min(context.play_res_y, box.y2 + max(104, min(144, round(box.height * 1.08))))
        return Rect(base.x1, top, base.x2, bottom)
    if model in _V5_RISING_MODELS:
        top = max(0, box.y1 - max(98, min(144, round(box.height * 1.05))))
        bottom = min(context.play_res_y, box.y2 + max(122, min(174, round(box.height * 1.42))))
        return Rect(base.x1, top, base.x2, bottom)
    if model in {'whirlpool_sink', 'shard_burst', 'frost_crystal'}:
        pad = max(98, min(148, round(box.height * 1.18)))
        return Rect(base.x1, max(0, box.y1 - pad), base.x2, min(context.play_res_y, box.y2 + pad))
    return base

def _sweep_bands(rect: Rect, direction: Direction) -> list[Rect]:
    """Build overlapping bands; vertical fronts use finer, softer slices."""
    horizontal = direction in {Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT}
    count = 20 if horizontal else 18
    extent = rect.width if horizontal else rect.height
    overlap_ratio = 0.22 if horizontal else 0.42
    overlap = max(3, round(extent / count * overlap_ratio))
    bands: list[Rect] = []
    for index in range(count):
        low = round(extent * index / count)
        high = round(extent * (index + 1) / count)
        low = max(0, low - overlap)
        high = min(extent, high + overlap)
        if horizontal:
            band = Rect(rect.x1 + low, rect.y1, rect.x1 + high, rect.y2)
        else:
            band = Rect(rect.x1, rect.y1 + low, rect.x2, rect.y1 + high)
        bands.append(band)
    if direction in {Direction.RIGHT_TO_LEFT, Direction.BOTTOM_TO_TOP}:
        bands.reverse()
    return bands

def _sweep_text_phase(event: DialogueEvent, begin: int, finish: int, *, entering: bool, effect: Effect, direction: Direction, context: EffectContext) -> list[DialogueEvent]:
    """Reveal the fixed line with an organic but monotonic gradient front."""
    if finish <= begin:
        return []
    spec = LOCALIZED_CHOREOGRAPHY[effect]
    rect = _expanded_text_box(context)
    bands = _sweep_bands(rect, direction)
    duration = finish - begin
    vertical = direction in {Direction.TOP_TO_BOTTOM, Direction.BOTTOM_TO_TOP}
    ramp = max(115, min(260, round(duration * 0.25))) if vertical else max(70, min(180, round(duration * 0.18)))
    travel = max(1, duration - ramp)
    transition = SWEEP_TRANSITIONS[effect]
    seed = int(DEFAULT_PARAMS[effect].get('seed', _legacy_effect_number(effect) * 1009))
    gravity_models = {'rain', 'downpour', 'waterfall', 'hail_bounce', 'meteor'}
    result: list[DialogueEvent] = []
    previous_delay = -1
    for index, band in enumerate(bands):
        progress = index / max(1, len(bands) - 1)
        if vertical and transition.particle_model in gravity_models:
            timing = progress ** 0.78
        elif vertical:
            timing = progress ** 0.96
        else:
            timing = progress
        spacing = travel / max(1, len(bands) - 1)
        jitter = 0.0
        if vertical and 0 < index < len(bands) - 1:
            jitter = (_seed_value(seed, index, 961) - 0.5) * spacing * 0.58
        delay = max(previous_delay + 1, min(travel, round(travel * timing + jitter)))
        previous_delay = delay
        transition_end = min(duration, delay + ramp)
        if entering:
            alpha_tags = f'\\alpha&HFF&\\t({delay},{transition_end},1.15,\\alpha&H00&)'
        else:
            alpha_tags = f'\\alpha&H00&\\t({delay},{transition_end},1.15,\\alpha&HFF&)'
        result.append(_clone(event, start_ms=event.start_ms + begin, end_ms=event.start_ms + finish, layer=event.layer + 12, effect_field=f"NAT40:{effect.value}:text:{('entry' if entering else 'exit')}:band:{index}", text=_add_tags(event.text, _text_style_tags(spec) + _clip_tag(band) + alpha_tags)))
        glow_start = max(0, delay - round(ramp * 0.52))
        glow_peak = min(duration, delay + round(ramp * 0.38))
        glow_end = min(duration, delay + round(ramp * 1.35))
        glow_alpha = f'\\alpha&HFF&\\t({glow_start},{glow_peak},\\alpha&H7C&)\\t({glow_peak},{glow_end},\\alpha&HFF&)'
        result.append(_clone(event, start_ms=event.start_ms + begin, end_ms=event.start_ms + finish, layer=event.layer + 9, effect_field=f"NAT40:{effect.value}:text:{('entry' if entering else 'exit')}:glow:{index}", text=_add_tags(event.text, _text_style_tags(spec, glow=True) + _clip_tag(band) + glow_alpha)))
    return result

def _rain_streak_path(length: int, bend: int=0, width: float=1.7, *, core: bool=False) -> str:
    """Return a tapered, headed rain streak rather than a generic line glyph.

    The narrow tail and slightly wider leading end remain readable after libass
    scaling and blur.  ``core`` shortens the luminous centre so the two layers
    imply longitudinal translucency instead of a flat white dash.
    """
    length = max(14, int(length))
    if core:
        length = max(10, round(length * 0.72))
        width *= 0.52
    half = length / 2
    head_y = half
    bend_mid = bend * 0.42
    tail_w = max(0.35, width * 0.24)
    shoulder_w = max(0.7, width * 0.72)
    head_w = max(1.0, width)
    body = _polygon_path(((-tail_w, -half), (tail_w, -half), (bend_mid + shoulder_w, -half * 0.02), (bend + head_w, head_y - max(2.0, head_w * 1.25)), (bend + head_w * 0.62, head_y), (bend - head_w * 0.62, head_y), (bend - head_w, head_y - max(2.0, head_w * 1.25)), (bend_mid - shoulder_w, -half * 0.02)))
    bead = _ellipse_path_at(bend, round(head_y - head_w * 0.3), max(1, round(head_w * 0.78)), max(1, round(head_w * 0.92)))
    return body + ' ' + bead

def _water_streak_path(length: int, bend: int=2, width: float=2.8, *, core: bool=False) -> str:
    length = max(24, int(length))
    if core:
        length = max(18, round(length * 0.78))
        width *= 0.56
    half = length / 2
    points = ((-width * 0.35, -half), (width * 0.35, -half), (bend + width * 0.7, -half * 0.3), (-bend * 0.55 + width, half * 0.28), (bend * 0.35 + width * 0.72, half), (bend * 0.35 - width * 0.72, half), (-bend * 0.55 - width, half * 0.28), (bend - width * 0.7, -half * 0.3))
    return _polygon_path(points)

def _dendritic_snowflake_path(radius: int, variant: int=0) -> str:
    radius = max(6, int(radius))
    pieces: list[str] = []
    branch_angle = math.pi / (6 if variant % 2 == 0 else 7)
    for arm in range(6):
        angle = -math.pi / 2 + arm * math.pi / 3
        x2, y2 = (radius * math.cos(angle), radius * math.sin(angle))
        pieces.append(f'm 0 0 l {round(x2)} {round(y2)}')
        for fraction in (0.55, 0.78) if variant % 3 else (0.48, 0.7, 0.84):
            bx, by = (radius * fraction * math.cos(angle), radius * fraction * math.sin(angle))
            twig = radius * (0.2 if fraction < 0.7 else 0.16)
            for side in (-1, 1):
                tx = bx - twig * math.cos(angle + side * branch_angle)
                ty = by - twig * math.sin(angle + side * branch_angle)
                pieces.append(f'm {round(bx)} {round(by)} l {round(tx)} {round(ty)}')
    return ' '.join(pieces)

def _leaf_sprite_path(width: int, height: int, variant: int) -> str:
    w, h = (max(5, width), max(9, height))
    if variant % 3 == 1:
        points = ((0, -h), (w * 0.34, -h * 0.42), (w, -h * 0.32), (w * 0.52, h * 0.08), (w * 0.78, h * 0.62), (0, h), (-w * 0.54, h * 0.48), (-w, h * 0.06), (-w * 0.48, -h * 0.28))
        body = _polygon_path(points)
    elif variant % 3 == 2:
        body = f'm 0 {-h} b {round(w * 1.05)} {round(-h * 0.58)} {round(w * 0.82)} {round(h * 0.48)} 0 {h} b {round(-w * 0.62)} {round(h * 0.42)} {round(-w * 1.08)} {round(-h * 0.2)} 0 {-h}'
    else:
        body = f'm 0 {-h} b {w} {round(-h * 0.55)} {round(w * 0.72)} {round(h * 0.55)} 0 {h} b {round(-w * 0.78)} {round(h * 0.4)} {round(-w * 0.92)} {round(-h * 0.46)} 0 {-h}'
    stem = _polygon_path(((-1, h - 1), (1, h - 1), (2, h + max(4, h // 4)), (0, h + max(6, h // 3))))
    return body + ' ' + stem

def _leaf_vein_path(height: int, variant: int) -> str:
    h = max(9, height)
    slant = -2 if variant % 2 else 2
    return _polyline_path(((0, -h * 0.72), (slant, 0), (0, h * 0.78)))

def _petal_sprite_path(width: int, height: int, variant: int) -> str:
    w, h = (max(4, width), max(7, height))
    notch = 2 + variant % 3
    return f'm 0 {-h + notch} b {round(w * 0.3)} {-h} {w} {round(-h * 0.38)} {round(w * 0.72)} {round(h * 0.18)} b {round(w * 0.48)} {round(h * 0.72)} {round(w * 0.12)} {h} 0 {h} b {round(-w * 0.18)} {h} {round(-w * 0.58)} {round(h * 0.66)} {round(-w * 0.72)} {round(h * 0.12)} b {-w} {round(-h * 0.42)} {round(-w * 0.3)} {-h} 0 {-h + notch}'

def _dandelion_seed_path(size: int, variant: int) -> str:
    s = max(6, size)
    angle = -0.18 if variant % 2 else 0.18
    tip_x = round(s * angle)
    pieces = [f'm 0 {round(s * 0.95)} l {tip_x} {round(-s * 0.18)}']
    for offset in (-0.82, -0.48, -0.18, 0.18, 0.48, 0.82):
        pieces.append(f'm {tip_x} {round(-s * 0.18)} l {round(tip_x + offset * s * 0.72)} {round(-s * (0.72 + 0.14 * abs(offset)))}')
    return ' '.join(pieces)

def _bubble_cluster_path(size: int, variant: int=0) -> str:
    s = max(4, size)
    return ' '.join((_ellipse_path_at(0, 0, s, s), _ellipse_path_at(round(s * 1.12), round(-s * 0.48), max(2, round(s * 0.58)), max(2, round(s * 0.58))), _ellipse_path_at(round(-s * 0.92), round(-s * 0.7), max(2, round(s * (0.42 + 0.08 * (variant % 2)))), max(2, round(s * 0.48)))))

def _meteor_sprite_path(length: int, width: int) -> str:
    length, width = (max(18, length), max(3, width))
    tail = _polygon_path(((-width, -length), (width, -length), (round(width * 0.52), 0), (-round(width * 0.52), 0)))
    head = _ellipse_path_at(0, round(width * 0.3), width, width)
    return tail + ' ' + head

def _irregular_shard_path(size: int, variant: int) -> str:
    s = max(5, size)
    skew = -1 if variant % 2 else 1
    return _polygon_path(((0, -s), (round(skew * s * 0.68), round(-s * 0.2)), (round(skew * s * 0.32), s), (round(-skew * s * 0.55), round(s * 0.46)), (round(-skew * s * 0.72), round(-s * 0.42))))

@dataclass(frozen=True)
class _PhysicalParticleStyle:
    path: str
    fill: bool
    border: float
    blur: float
    alpha: int
    scale: float
    colour_override: str | None = None
    layer_delta: int = 0

def _physical_particle_styles(kind: str, index: int, effect: Effect) -> tuple[_PhysicalParticleStyle, ...]:
    """Return one or more vector layers for a recognisable particle sprite."""
    variant = index % 4
    theme = LOCALIZED_CHOREOGRAPHY[effect]
    white = '&HFFFFFF&'
    if kind == 'mist_wisp':
        width, height = ((76, 18), (96, 22), (118, 26), (86, 20))[variant]
        return (_PhysicalParticleStyle(_mist_wisp_path(width, height, variant), True, 0.0, 8.5, 214, 112, theme.glow, -1), _PhysicalParticleStyle(_mist_wisp_path(width, height, variant, core=True), True, 0.0, 3.4, 224, 100, white, 0))
    if kind == 'cloud_bank':
        width, height = ((76, 30), (100, 38), (126, 46), (88, 34))[variant]
        return (_PhysicalParticleStyle(_cloud_path(width, height), True, 0.0, 9.0, 202, 112, theme.glow, -1), _PhysicalParticleStyle(_cloud_path(round(width * 0.78), round(height * 0.72)), True, 0.0, 3.8, 224, 100, white, 0))
    if kind == 'heat_wisp':
        height, amplitude = ((42, 5), (56, 7), (68, 8), (48, 6))[variant]
        return (_PhysicalParticleStyle(_heat_wisp_path(height, amplitude, variant), False, 4.0, 5.5, 196, 112, theme.glow, -1), _PhysicalParticleStyle(_heat_wisp_path(height, amplitude, variant, core=True), False, 1.0, 1.1, 92, 100, white, 0))
    if kind == 'bubble':
        radius = (4, 6, 8, 5)[variant]
        return (_PhysicalParticleStyle(_bubble_outline_path(radius, variant), False, 2.4, 2.4, 176, 112, theme.glow, -1), _PhysicalParticleStyle(_bubble_outline_path(radius, variant), False, 0.85, 0.45, 44, 100, white, 0), _PhysicalParticleStyle(_bubble_highlight_path(radius, variant), True, 0.0, 0.35, 38, 100, white, 1))
    if kind == 'snow_puff':
        size = (6, 8, 11, 7)[variant]
        return (_PhysicalParticleStyle(_snow_puff_path(size, variant), True, 0.0, 3.0, 184, 114, theme.glow, -1), _PhysicalParticleStyle(_snow_puff_path(size, variant, core=True), True, 0.0, 0.7, 58, 100, white, 0))
    if kind == 'rain_streak':
        length = (38, 48, 62, 44)[variant]
        bend = (-2, 1, 3, -1)[variant]
        width = (1.6, 1.9, 2.2, 1.7)[variant]
        return (_PhysicalParticleStyle(_rain_streak_path(length, bend, width), True, 0.0, 2.4, 174, 112, theme.glow, -1), _PhysicalParticleStyle(_rain_streak_path(length, bend, width, core=True), True, 0.0, 0.55, 52, 100, white, 0))
    if kind == 'drizzle_streak':
        length = (20, 26, 32, 23)[variant]
        bend = (-1, 0, 1, 0)[variant]
        width = (0.9, 1.1, 1.25, 1.0)[variant]
        return (_PhysicalParticleStyle(_rain_streak_path(length, bend, width), True, 0.0, 1.8, 198, 105, theme.glow, -1), _PhysicalParticleStyle(_rain_streak_path(length, bend, width, core=True), True, 0.0, 0.35, 96, 94, white, 0))
    if kind in {'heavy_rain_streak', 'cloud_drop'}:
        length = (56, 70, 86, 62)[variant]
        bend = (-2, 1, 2, -1)[variant]
        width = (2.4, 2.9, 3.5, 2.7)[variant]
        return (_PhysicalParticleStyle(_rain_streak_path(length, bend, width), True, 0.0, 3.0, 158, 118, theme.glow, -1), _PhysicalParticleStyle(_rain_streak_path(length, bend, width, core=True), True, 0.0, 0.7, 36, 105, white, 0))
    if kind == 'water_streak':
        length = (62, 78, 96, 70)[variant]
        bend = (-3, 2, 4, -2)[variant]
        width = (3.0, 3.8, 4.6, 3.4)[variant]
        return (_PhysicalParticleStyle(_water_streak_path(length, bend, width), True, 0.0, 3.5, 166, 118, theme.glow, -1), _PhysicalParticleStyle(_water_streak_path(length, bend, width, core=True), True, 0.0, 0.9, 46, 104, white, 0))
    if kind == 'snow':
        radius = (7, 10, 13, 9)[variant]
        path = _dendritic_snowflake_path(radius, variant)
        return (_PhysicalParticleStyle(path, False, (1.15, 1.35, 1.55, 1.2)[variant], 0.65, 36, 100, white, 0),)
    if kind == 'crystal':
        radius = (7, 9, 12, 8)[variant]
        path = _dendritic_snowflake_path(radius, variant + 1)
        return (_PhysicalParticleStyle(path, False, 3.2, 3.4, 176, 112, theme.glow, -1), _PhysicalParticleStyle(path, False, 1.1, 0.4, 18, 100, white, 0))
    if kind == 'hail':
        radius = (4, 5, 7, 5)[variant]
        return (_PhysicalParticleStyle(_ellipse_path(radius + 2, radius + 2), True, 1.0, 1.6, 160, 104, theme.glow, -1), _PhysicalParticleStyle(_ellipse_path(radius, radius), True, 0.45, 0.35, 24, 100, white, 0))
    if kind == 'leaf':
        w, h = ((7, 13), (9, 16), (8, 18), (10, 15))[variant]
        body = _leaf_sprite_path(w, h, variant)
        vein = _leaf_vein_path(h, variant)
        return (_PhysicalParticleStyle(body, True, 0.65, 0.55, 22, 100, None, 0), _PhysicalParticleStyle(vein, False, 0.62, 0.2, 82, 100, theme.outline, 1))
    if kind == 'petal':
        w, h = ((6, 10), (7, 12), (5, 11), (8, 13))[variant]
        return (_PhysicalParticleStyle(_petal_sprite_path(w, h, variant), True, 0.45, 0.45, 30, 100, None, 0),)
    if kind == 'seed':
        return (_PhysicalParticleStyle(_dandelion_seed_path((8, 10, 12, 9)[variant], variant), False, 1.05, 0.55, 36, 100, None, 0),)
    if kind in {'foam', 'glow_foam'}:
        size = (5, 7, 9, 6)[variant]
        glow = kind == 'glow_foam'
        return (_PhysicalParticleStyle(_foam_fleck_path(size, variant), True, 0.0, 4.8 if glow else 2.8, 166 if glow else 192, 118, theme.glow, -1), _PhysicalParticleStyle(_foam_fleck_path(size, variant, core=True), True, 0.0, 0.65, 34 if glow else 68, 100, white, 0))
    if kind == 'bead':
        radius = (3, 4, 5, 4)[variant]
        return (_PhysicalParticleStyle(_ellipse_path(radius, radius), False, 1.15, 0.7, 48, 100, white, 0),)
    if kind == 'cloud':
        width, height = ((28, 13), (38, 16), (32, 15), (44, 18))[variant]
        return (_PhysicalParticleStyle(_cloud_path(width, height), True, 0.35, 3.2, 96, 100, None, 0),)
    if kind == 'sand':
        path = ' '.join((_ellipse_path_at(0, 0, 2 + variant % 2, 1), _ellipse_path_at(4 + variant, -2, 1, 1), _ellipse_path_at(-3, 2 + variant % 2, 1, 1)))
        return (_PhysicalParticleStyle(path, True, 0.2, 0.45, 52, 100, None, 0),)
    if kind == 'debris':
        return (_PhysicalParticleStyle(_irregular_shard_path((6, 8, 10, 7)[variant], variant), True, 0.5, 0.45, 52, 100, None, 0),)
    if kind == 'shard':
        return (_PhysicalParticleStyle(_irregular_shard_path((7, 9, 12, 8)[variant], variant), True, 2.2, 2.2, 172, 110, theme.glow, -1), _PhysicalParticleStyle(_irregular_shard_path((6, 8, 10, 7)[variant], variant), True, 0.55, 0.35, 42, 100, white, 0))
    if kind == 'ember':
        path = _flame_path((5, 6, 7, 5)[variant], (10, 13, 16, 12)[variant])
        return (_PhysicalParticleStyle(path, True, 0.2, 4.2, 166, 145, theme.glow, -1), _PhysicalParticleStyle(path, True, 0.35, 0.45, 16, 100, None, 0))
    if kind == 'firefly':
        radius = (2, 3, 3, 2)[variant]
        path = _ellipse_path(radius, radius)
        return (_PhysicalParticleStyle(path, True, 0.0, 7.0, 150, 230, theme.glow, -1), _PhysicalParticleStyle(path, True, 0.0, 0.45, 0, 100, white, 0))
    if kind == 'meteor':
        path = _meteor_sprite_path((22, 30, 38, 26)[variant], (3, 4, 5, 3)[variant])
        return (_PhysicalParticleStyle(path, True, 0.0, 5.0, 164, 135, theme.glow, -1), _PhysicalParticleStyle(path, True, 0.25, 0.5, 12, 100, white, 0))
    if kind == 'prism':
        path = _diamond_path((5, 7, 8, 6)[variant], (8, 11, 13, 9)[variant])
        return (_PhysicalParticleStyle(path, True, 0.0, 4.0, 166, 150, theme.glow, -1), _PhysicalParticleStyle(path, True, 0.5, 0.35, 20, 100, None, 0))
    if kind == 'spark':
        path = _star_path((7, 9, 11, 8)[variant], (2, 3, 3, 2)[variant], 4)
        return (_PhysicalParticleStyle(path, True, 0.0, 4.0, 174, 145, theme.glow, -1), _PhysicalParticleStyle(path, True, 0.25, 0.45, 20, 100, white, 0))
    base = _carrier_style(kind)
    return (_PhysicalParticleStyle(base.path, base.fill, base.border, base.blur, base.alpha, base.scale),)

def _physical_particle_style(kind: str) -> _PhysicalParticleStyle:
    """Compatibility helper returning the first v5 sprite layer."""
    return _physical_particle_styles(kind, 0, Effect.RAIN_VEIL)[0]

def _particle_colour(effect: Effect, index: int) -> str:
    spec = LOCALIZED_CHOREOGRAPHY[effect]
    if spec.carrier_palette:
        base = spec.carrier_palette[index % len(spec.carrier_palette)]
    elif effect in {Effect.SUNRISE_HORIZON, Effect.EMBER_DRIFT, Effect.LAVA_FLOW}:
        base = spec.accent
    else:
        base = spec.glow
    mix = (0.02, 0.1, 0.18, 0.06)[index % 4]
    return _lerp_color(base, '&HFFFFFF&', mix)

def _random_lane(seed: int, index: int) -> float:
    golden = 0.6180339887498949
    return _fractional(index * golden + _seed_value(seed, index, 371) * 0.57 + _seed_value(seed, index, 372) * 0.19)

def _motion_points(model: str, *, phase: str, index: int, count: int, effect: Effect, params: Mapping[str, Any], context: EffectContext, seed: int) -> list[tuple[float, float, float, float, float]]:
    """Return material-specific piecewise paths with strong per-particle variance."""
    scene = _particle_scene_box(context, model)
    box = context.box
    cx, cy = box.center
    direction = _resolve_sweep_direction(effect, params)
    sign = -1.0 if direction is Direction.RIGHT_TO_LEFT else 1.0
    spin = _rotation_sign(params, effect)
    u0 = _seed_value(seed, index, 301)
    u1 = _seed_value(seed, index, 302)
    u2 = _seed_value(seed, index, 303)
    u3 = _seed_value(seed, index, 304)
    u4 = _seed_value(seed, index, 305)
    lane = _random_lane(seed, index)
    points: list[tuple[float, float, float, float, float]] = []

    def add(t: float, x: float, y: float, scale: float, rotation: float) -> None:
        points.append((t, x, y, scale, rotation))
    if model in {'rain', 'drizzle', 'downpour', 'waterfall'}:
        x0 = scene.x1 + scene.width * (0.025 + 0.95 * lane)
        start_y = scene.y1 - (10 + 42 * u3)
        end_y = scene.y2 + (10 + 28 * u4)
        slant_param = float(params.get('slant', 0)) if model in {'rain', 'downpour'} else 0.0
        wind = sign * slant_param * (0.16 if model == 'rain' else 0.09)
        random_drift = (u1 - 0.5) * {'drizzle': 38, 'waterfall': 16}.get(model, 26)
        drift = wind + random_drift
        power = {'downpour': 1.28, 'waterfall': 1.22, 'rain': 1.55, 'drizzle': 1.12}[model] + (u2 - 0.5) * 0.22
        base_scale = {'downpour': 92, 'waterfall': 100, 'rain': 86, 'drizzle': 74}[model] * (0.76 + 0.46 * u0)
        angle = -math.degrees(math.atan2(drift, max(1.0, end_y - start_y)))
        fall_samples = (0.0, 0.44, 1.0)
        for t in fall_samples:
            p = t ** power
            y = start_y + (end_y - start_y) * p
            sway = (1.5 if model in {'downpour', 'waterfall'} else 3.5) * math.sin(math.tau * t + u4 * math.tau)
            x = x0 + drift * t + sway
            add(t, x, y, base_scale * (0.9 + 0.18 * t), angle)
    elif model in {'snow', 'petal_fall', 'leaf_fall'}:
        x0 = scene.x1 + scene.width * (0.02 + 0.96 * lane)
        start_y = scene.y1 - 18 + 48 * u3
        travel = scene.height * ({'snow': 0.72, 'petal_fall': 0.88, 'leaf_fall': 0.94}[model] + 0.34 * u4)
        end_y = start_y + travel
        amplitude = {'snow': 13, 'petal_fall': 26, 'leaf_fall': 39}[model] * (0.62 + 0.72 * u1)
        turns = {'snow': 0.72, 'petal_fall': 1.18, 'leaf_fall': 1.42}[model] * (0.78 + 0.48 * u2)
        drift = sign * {'snow': 10, 'petal_fall': 18, 'leaf_fall': 28}[model] * (u0 - 0.25)
        power = {'snow': 1.04, 'petal_fall': 1.12, 'leaf_fall': 1.18}[model]
        base_scale = {'snow': 48, 'petal_fall': 54, 'leaf_fall': 58}[model] * (0.72 + 0.7 * u4)
        for t in (0.0, 0.16, 0.33, 0.5, 0.67, 0.84, 1.0):
            phase_a = u1 * math.tau
            x = x0 + drift * t + amplitude * math.sin(math.tau * turns * t + phase_a) + amplitude * 0.23 * math.sin(math.tau * (turns * 2.3) * t + u3 * math.tau)
            y = start_y + travel * t ** power
            rotation = spin * ((70 + 300 * u2) * t + 55 * math.sin(math.tau * t + u0 * math.tau))
            squash = 0.86 + 0.22 * abs(math.sin(math.tau * (0.6 + u1) * t + u2 * math.tau))
            add(t, x, y, base_scale * squash, rotation)
    elif model in {'blizzard', 'breeze', 'gust', 'sand', 'river', 'wave_advect', 'lava_flow', 'biolume_wave', 'moon_cloud'}:
        x0 = scene.x1 - (22 + 28 * u3) if sign > 0 else scene.x2 + (22 + 28 * u3)
        x1 = scene.x2 + (22 + 34 * u4) if sign > 0 else scene.x1 - (22 + 34 * u4)
        y_base = scene.y1 + scene.height * (0.06 + 0.88 * lane)
        amplitude = {'blizzard': 17, 'breeze': 28, 'gust': 11, 'sand': 10, 'river': 8, 'wave_advect': 20, 'lava_flow': 7, 'biolume_wave': 18, 'moon_cloud': 6}[model] * (0.64 + 0.62 * u1)
        power = 1.48 if model == 'gust' else 1.22 if model in {'blizzard', 'sand'} else 1.0
        base_scale = 46 + 55 * u2 if model != 'moon_cloud' else 32 + 30 * u2
        for t in (0.0, 0.18, 0.38, 0.62, 0.82, 1.0):
            p = t ** power
            x = x0 + (x1 - x0) * p
            y = y_base + amplitude * math.sin(math.tau * (1.15 if model in {'wave_advect', 'biolume_wave'} else 0.78) * t + u1 * math.tau)
            if model == 'sand':
                y += 7 * math.sin(math.tau * (3.2 + u4) * t + u2 * math.tau)
            if model == 'lava_flow':
                y += 10 * t * t
            add(t, x, y, base_scale * (0.92 + 0.16 * t), spin * ((18 + 170 * u3) * t))
    elif model in {'mist_rise', 'cloud_rise', 'heat', 'ember_rise', 'tide_bubble', 'sunrise_dust', 'light_dust'}:
        x0 = scene.x1 + scene.width * (0.03 + 0.94 * lane)
        start_y = scene.y2 + 12 + 34 * u3
        rise = scene.height * ({'mist_rise': 0.72, 'cloud_rise': 0.68, 'light_dust': -0.86}.get(model, 0.98) + 0.18 * u4)
        for t in (0.0, 0.18, 0.38, 0.62, 0.82, 1.0):
            if model == 'light_dust':
                y = scene.y1 - 12 + (scene.height + 24) * t
            else:
                p = 1 - (1 - t) ** (1.12 + 0.28 * u2)
                y = start_y - rise * p
            wobble = {'mist_rise': 11, 'cloud_rise': 9, 'heat': 25, 'ember_rise': 20, 'tide_bubble': 12, 'sunrise_dust': 16, 'light_dust': 8}[model] * (0.58 + 0.7 * u1)
            x = x0 + wobble * math.sin(math.tau * (0.6 + 0.75 * u4) * t + u1 * math.tau)
            if model == 'heat':
                x += 6 * math.sin(math.tau * 3.0 * t + u3 * math.tau)
            if model == 'mist_rise':
                base_scale = 74 + 54 * u2
                rotation = (u3 - 0.5) * 7 + 2.5 * math.sin(math.tau * t + u4 * math.tau)
            elif model == 'cloud_rise':
                base_scale = 66 + 52 * u2
                rotation = (u3 - 0.5) * 5 + 1.8 * math.sin(math.tau * 0.7 * t + u4 * math.tau)
            elif model == 'heat':
                base_scale = 82 + 48 * u2
                rotation = (u3 - 0.5) * 4
            elif model == 'tide_bubble':
                base_scale = 42 + 46 * u2
                rotation = 0.0
            else:
                base_scale = 42 + 46 * u2
                rotation = spin * ((12 + 120 * u3) * t)
            add(t, x, y, base_scale * (0.92 + 0.16 * t), rotation)
    elif model == 'hail_bounce':
        x = scene.x1 + scene.width * (0.03 + 0.94 * lane)
        impact = min(scene.y2 - 5, box.y2 + 38 + 32 * u4)
        start_y = scene.y1 - 15 - 30 * u3
        rebound = 24 + 42 * u2
        add(0.0, x - 10 * (u1 - 0.5), start_y, 48 + 32 * u0, 0)
        add(0.48 + 0.08 * u4, x, impact, 62 + 34 * u1, spin * 90)
        add(0.7 + 0.06 * u3, x + 14 * (u2 - 0.5), impact - rebound, 56 + 28 * u0, spin * 170)
        add(1.0, x + 20 * (u1 - 0.5), impact - 1, 50 + 25 * u2, spin * 260)
    elif model == 'crystal_twinkle':
        x0 = scene.x1 + scene.width * (0.03 + 0.94 * lane)
        y0 = scene.y1 + scene.height * (0.06 + 0.82 * u1)
        for t in (0.0, 0.2, 0.42, 0.64, 0.82, 1.0):
            x = x0 + (7 + 8 * u2) * math.sin(math.tau * (0.8 + u4) * t + u2 * math.tau)
            y = y0 + (12 + 18 * u3) * t + 6 * math.sin(math.tau * 1.4 * t + u3 * math.tau)
            pulse = 0.5 + 0.5 * math.sin(math.tau * (1.6 + u4) * t + u0 * math.tau)
            add(t, x, y, 36 + 62 * pulse, spin * (120 + 220 * u2) * t)
    elif model in {'frost_crystal', 'shard_burst'}:
        angle = math.tau * _random_lane(seed + 17, index)
        radius = min(scene.width * 0.42, 150) * (0.55 + 0.55 * u3)
        inner = 8 + 13 * u1
        if model == 'frost_crystal':
            start = (cx + math.cos(angle) * inner, box.y2 + 14 + 16 * u4)
            endp = (cx + math.cos(angle) * radius * 0.48, scene.y1 + 8 + 18 * u2)
            for t in (0.0, 0.22, 0.46, 0.72, 1.0):
                p = 1 - (1 - t) ** 1.35
                add(t, start[0] + (endp[0] - start[0]) * p, start[1] + (endp[1] - start[1]) * p, 36 + 48 * t, spin * (120 + 180 * u3) * t)
        else:
            outer = (cx + math.cos(angle) * radius, cy + math.sin(angle) * min(scene.height * 0.42, 92))
            innerp = (cx + math.cos(angle) * inner, cy + math.sin(angle) * inner)
            p0, p1 = (outer, innerp) if phase == 'entry' else (innerp, outer)
            for t in (0.0, 0.2, 0.44, 0.7, 1.0):
                p = t * t if phase == 'exit' else 1 - (1 - t) * (1 - t)
                add(t, p0[0] + (p1[0] - p0[0]) * p, p0[1] + (p1[1] - p0[1]) * p, 38 + 54 * t, spin * (190 + 220 * u2) * t)
    elif model == 'avalanche':
        x0 = scene.x1 - (28 + 28 * u3) if sign > 0 else scene.x2 + (28 + 28 * u3)
        x1 = scene.x2 + (28 + 32 * u4) if sign > 0 else scene.x1 - (28 + 32 * u4)
        y0 = scene.y1 + scene.height * (0.08 + 0.78 * lane)
        for t in (0.0, 0.18, 0.4, 0.64, 0.82, 1.0):
            p = t ** (1.18 + 0.28 * u2)
            x = x0 + (x1 - x0) * p
            y = y0 + (24 + 26 * u1) * t * t + 10 * math.sin(math.tau * (0.8 + u3) * t + u1 * math.tau)
            add(t, x, y, (42 + 58 * u4) * (0.88 + 0.22 * t), spin * (120 + 180 * u2) * t)
    elif model in {'vortex_rise', 'tornado', 'whirlpool_sink'}:
        turns = 1.15 + 0.55 * u2 if model == 'vortex_rise' else 1.75 + 0.7 * u2 if model == 'tornado' else 1.45 + 0.65 * u2
        base_angle = math.tau * _random_lane(seed + 31, index)
        max_rx = min(scene.width * 0.4, 150) * (0.58 + 0.52 * u3)
        max_ry = min(scene.height * 0.38, 72) * (0.62 + 0.48 * u4)
        for t in (0.0, 0.17, 0.36, 0.56, 0.76, 1.0):
            angle = base_angle + spin * math.tau * turns * t
            if model == 'whirlpool_sink':
                radius = 1.0 - (0.68 + 0.22 * u1) * t
                y_center = cy + (12 + 20 * u4) * t
            elif model == 'tornado':
                radius = 1.0 - (0.54 + 0.25 * u1) * t
                y_center = scene.y2 - max_ry - (scene.height - 2 * max_ry) * (0.82 + 0.12 * u2) * t
            else:
                radius = 0.95 - (0.28 + 0.28 * u1) * t
                y_center = scene.y2 - max_ry - (scene.height - 2 * max_ry) * (0.68 + 0.18 * u2) * t
            add(t, cx + math.cos(angle) * max_rx * radius, y_center + math.sin(angle) * max_ry * radius, 38 + 52 * (1 - radius), spin * 360 * turns * t)
    elif model == 'breaker_foam':
        x0 = scene.x1 - (18 + 22 * u3) if sign > 0 else scene.x2 + (18 + 22 * u3)
        x1 = scene.x2 + (18 + 24 * u4) if sign > 0 else scene.x1 - (18 + 24 * u4)
        y0 = box.y2 + 20 + 18 * u0
        height = 34 + 34 * u1
        for t in (0.0, 0.18, 0.4, 0.64, 0.82, 1.0):
            x = x0 + (x1 - x0) * t
            y = y0 - height * 4 * t * (1 - t) + (8 + 14 * u2) * t
            add(t, x, y, 36 + 55 * t, spin * (120 + 180 * u3) * t)
    elif model == 'prism_arc':
        x0 = scene.x1 - (12 + 20 * u3) if sign > 0 else scene.x2 + (12 + 20 * u3)
        x1 = scene.x2 + (12 + 22 * u4) if sign > 0 else scene.x1 - (12 + 22 * u4)
        height = 38 + 36 * u1
        for t in (0.0, 0.18, 0.4, 0.64, 0.82, 1.0):
            add(t, x0 + (x1 - x0) * t, cy + 22 - height * math.sin(math.pi * t), 34 + 58 * math.sin(math.pi * t), spin * (120 + 180 * u2) * t)
    elif model == 'firefly_wander':
        x0 = scene.x1 + scene.width * (0.04 + 0.92 * lane)
        y0 = scene.y1 + scene.height * (0.08 + 0.84 * u1)
        for t in (0.0, 0.16, 0.34, 0.52, 0.7, 0.86, 1.0):
            x = x0 + (14 + 16 * u2) * math.sin(math.tau * (0.72 + 0.42 * u4) * t + u2 * math.tau) + 6 * math.sin(math.tau * 2.2 * t)
            y = y0 + (9 + 12 * u3) * math.sin(math.tau * (0.55 + 0.35 * u1) * t + u3 * math.tau) - (5 + 10 * u4) * t
            pulse = 0.45 + 0.55 * (0.5 + 0.5 * math.sin(math.tau * (1.5 + u2) * t + u0 * math.tau))
            add(t, x, y, 36 + 54 * pulse, 0)
    elif model == 'meteor':
        start_x = scene.x1 + scene.width * (0.04 + 0.92 * lane)
        start_y = scene.y1 - (18 + 38 * u3)
        dx = sign * (72 + 88 * u1)
        dy = scene.height * (0.76 + 0.42 * u4)
        for t in (0.0, 0.16, 0.34, 0.56, 0.78, 1.0):
            p = t ** (0.88 + 0.18 * u2)
            add(t, start_x + dx * p, start_y + dy * p, 40 + 45 * t, -sign * (18 + 18 * u2))
    elif model == 'corona':
        base_angle = math.pi * (1.05 if sign > 0 else -0.05) + (u0 - 0.5) * 0.42
        rx = min(scene.width * 0.42, 158) * (0.72 + 0.36 * u3)
        ry = min(scene.height * 0.35, 68) * (0.72 + 0.34 * u4)
        for t in (0.0, 0.18, 0.4, 0.64, 0.82, 1.0):
            angle = base_angle + sign * math.pi * (0.72 + 0.42 * u2) * t
            add(t, cx + math.cos(angle) * rx, cy + math.sin(angle) * ry, 36 + 52 * math.sin(math.pi * t), spin * (80 + 100 * u1) * t)
    else:
        raise EffectError(f'unknown physical particle model: {model}')
    return points

def _emit_piecewise_particle(event: DialogueEvent, begin: int, finish: int, *, points: Sequence[tuple[float, float, float, float, float]], effect: Effect, phase: str, particle_index: int, kind: str, colour: str, context: EffectContext) -> list[DialogueEvent]:
    if finish <= begin or len(points) < 2:
        return []
    styles = _physical_particle_styles(kind, particle_index, effect)
    scene = _particle_scene_box(context, SWEEP_TRANSITIONS[effect].particle_model)
    duration = finish - begin
    result: list[DialogueEvent] = []
    marker = f'NAT40:{effect.value}:particle:{phase}:{particle_index}'
    for segment_index, (first, second) in enumerate(zip(points, points[1:])):
        t0, x0, y0, scale0, rotation0 = first
        t1, x1, y1, scale1, rotation1 = second
        seg_begin = begin + round(duration * t0)
        seg_finish = begin + round(duration * t1)
        if seg_finish <= seg_begin:
            continue
        for layer_index, style in enumerate(styles):
            layer_colour = style.colour_override or colour
            alpha = style.alpha
            if kind in {'firefly', 'glow_foam', 'spark', 'crystal'}:
                alpha = max(0, style.alpha - (14 if (segment_index + particle_index) % 2 == 0 else 0))
            item = _moving_shape(event, seg_begin, seg_finish, style.path, x0=x0, y0=y0, x1=x1, y1=y1, color=layer_colour, alpha=alpha, scale0=scale0 * style.scale / 100.0, scale1=scale1 * style.scale / 100.0, rotation0=rotation0, rotation1=rotation1, blur=style.blur, border=style.border, outline=layer_colour, fill=style.fill, fade_in=min(40, max(0, (seg_finish - seg_begin) // 4)) if segment_index == 0 else 0, fade_out=min(72, max(0, (seg_finish - seg_begin) // 3)) if segment_index == len(points) - 2 else 0, clip=scene, layer_offset=7 + style.layer_delta)
            result.append(_clone(item, effect_field=marker + f':layer:{layer_index}:segment:{segment_index}'))
    return result

def _particle_kind_for(effect: Effect, model: str, base_kind: str, index: int) -> str:
    if False and index % 4 == 3:
        return 'prism'
    if False and index % 3 != 2:
        return 'rain_streak'
    if model == 'light_dust' and index % 3:
        return 'bead'
    return base_kind

_PARTICLE_SPEED_REFERENCE_PHASE_MS = 750


def _phase_particle_timing(*, begin: int, finish: int, phase: str, model: str, index: int, count: int, seed: int) -> tuple[int, int]:
    duration = finish - begin
    if duration <= 1:
        return (begin, finish)
    u0 = _seed_value(seed, index, 711)
    u1 = _seed_value(seed, index, 712)
    sequence = _fractional(index * 0.6180339887498949 + u0 * 0.47)
    slow_models = {'drizzle', 'snow', 'petal_fall', 'leaf_fall', 'mist_rise', 'cloud_rise', 'firefly_wander'}
    fast_models = {'rain', 'downpour', 'waterfall', 'meteor', 'gust', 'blizzard'}
    if phase == 'hold':
        offset_span = 0.64
        travel_fraction = 0.48 + 0.34 * u1 if model not in slow_models else 0.58 + 0.38 * u1
    else:
        offset_span = 0.44 if model in fast_models else 0.38 if model in slow_models else 0.48
        travel_fraction = 0.58 + 0.3 * u1 if model in fast_models else 0.68 + 0.28 * u1 if model in slow_models else 0.56 + 0.34 * u1
    particle_begin = begin + round(duration * offset_span * sequence)
    minimum = 150 if model in fast_models else 220
    travel_ms = max(minimum, round(duration * travel_fraction))
    particle_finish = min(finish, particle_begin + travel_ms)
    if particle_finish - particle_begin < 90:
        particle_begin = max(begin, finish - 90)
        particle_finish = finish
    return (particle_begin, particle_finish)

def _impact_events(event: DialogueEvent, *, effect: Effect, model: str, phase: str, index: int, begin: int, finish: int, point: tuple[float, float, float, float, float], colour: str, context: EffectContext) -> list[DialogueEvent]:
    if model not in {'rain', 'downpour', 'waterfall'} or index % (3 if model == 'downpour' else 4):
        return []
    scene = _particle_scene_box(context, model)
    _, x, y, _, _ = point
    y = min(scene.y2 - 3, max(scene.y1 + 3, y))
    duration = 130 if model in {'rain'} else 170
    end = finish
    start = max(begin, end - duration)
    if end <= start:
        return []
    if model in {'downpour', 'waterfall'}:
        path = _splash_path(9 + index % 4)
        border = 1.2
    else:
        path = _ellipse_path(9 + index % 3, 3 + index % 2)
        border = 0.9
    item = _moving_shape(event, start, end, path, x0=x, y0=y, x1=x + (index % 3 - 1) * 2, y1=y, color=colour, alpha=58, scale0=28, scale1=112, blur=0.7, border=border, outline=colour, fill=False, fade_in=10, fade_out=max(25, duration // 2), clip=scene, layer_offset=6)
    return [_clone(item, effect_field=f'NAT40:{effect.value}:impact:{phase}:{index}')]

def _render_physical_particle_phase(event: DialogueEvent, begin: int, finish: int, *, phase: str, count: int, effect: Effect, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    if count <= 0 or finish <= begin:
        return []
    transition = SWEEP_TRANSITIONS[effect]
    seed = int(params.get('seed', DEFAULT_PARAMS[effect].get('seed', _legacy_effect_number(effect) * 1009)))
    phase_seed = seed + {'entry': 0, 'hold': 4001, 'exit': 8009}[phase]
    result: list[DialogueEvent] = []
    for index in range(count):
        particle_begin, particle_finish = _phase_particle_timing(begin=begin, finish=finish, phase=phase, model=transition.particle_model, index=index, count=count, seed=phase_seed)
        points = _motion_points(transition.particle_model, phase=phase, index=index, count=count, effect=effect, params=params, context=context, seed=phase_seed)
        kind = _particle_kind_for(effect, transition.particle_model, transition.particle_kind, index)
        colour = _particle_colour(effect, index)
        result.extend(_emit_piecewise_particle(event, particle_begin, particle_finish, points=points, effect=effect, phase=phase, particle_index=index, kind=kind, colour=colour, context=context))
        result.extend(_impact_events(event, effect=effect, model=transition.particle_model, phase=phase, index=index, begin=particle_begin, finish=particle_finish, point=points[-1], colour=colour, context=context))
    return result

def _localized_ambient_events(generated: Sequence[DialogueEvent], event: DialogueEvent, start: int, end: int, effect: Effect, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    """Discard legacy scene output and emit lyric-local stochastic particle fields."""
    del generated
    transition = SWEEP_TRANSITIONS[effect]
    duration = event.duration_ms
    phases = (('entry', 0, start, transition.entry_particles), ('hold', start, duration - end, transition.hold_particles), ('exit', duration - end, duration, transition.exit_particles))
    result: list[DialogueEvent] = []
    for phase, begin, finish, count in phases:
        scaled_count = _scaled_particle_count(effect, phase, count, params)
        result.extend(_render_physical_particle_phase(event, begin, finish, phase=phase, count=scaled_count, effect=effect, params=params, context=context))
    return result
if set(SWEEP_TRANSITIONS) != set(Effect):
    raise RuntimeError('SWEEP_TRANSITIONS must cover every Effect')
_HANDLERS: dict[Effect, Callable[[DialogueEvent, int, int, Mapping[str, Any], EffectContext], list[DialogueEvent]]] = {Effect.RAIN_VEIL: _effect_rain_veil, Effect.DRIZZLE_MIST: _effect_drizzle_mist, Effect.CLOUDBURST: _effect_cloudburst, Effect.RAINBOW_ARCH: _effect_rainbow_arch, Effect.CREPUSCULAR_RAYS: _effect_crepuscular_rays, Effect.SNOWFALL_DEPTH: _effect_snowfall_depth, Effect.BLIZZARD_WHITEOUT: _effect_blizzard_whiteout, Effect.DIAMOND_DUST: _effect_diamond_dust, Effect.HAILSTORM: _effect_hailstorm, Effect.FROST_BLOOM: _effect_frost_bloom, Effect.ICE_CRACK: _effect_ice_crack, Effect.AVALANCHE: _effect_avalanche, Effect.MORNING_MIST: _effect_morning_mist, Effect.SEA_OF_CLOUDS: _effect_sea_of_clouds, Effect.GENTLE_BREEZE: _effect_gentle_breeze, Effect.GUST_FRONT: _effect_gust_front, Effect.WHIRLWIND: _effect_whirlwind, Effect.TORNADO: _effect_tornado, Effect.SANDSTORM: _effect_sandstorm, Effect.HEAT_HAZE: _effect_heat_haze, Effect.OCEAN_SWELL: _effect_ocean_swell, Effect.BREAKING_WAVE: _effect_breaking_wave, Effect.RISING_TIDE: _effect_rising_tide, Effect.WATERFALL: _effect_waterfall, Effect.RIVER_CURRENT: _effect_river_current, Effect.WHIRLPOOL: _effect_whirlpool, Effect.LAVA_FLOW: _effect_lava_flow, Effect.EMBER_DRIFT: _effect_ember_drift, Effect.CHERRY_BLOSSOM_STORM: _effect_cherry_blossom_storm, Effect.FALLING_LEAVES: _effect_falling_leaves, Effect.FIREFLY_NIGHT: _effect_firefly_night, Effect.BIOLUMINESCENT_TIDE: _effect_bioluminescent_tide, Effect.METEOR_SHOWER: _effect_meteor_shower, Effect.SOLAR_ECLIPSE: _effect_solar_eclipse, Effect.MOONLIGHT_CLOUDS: _effect_moonlight_clouds, Effect.SUNRISE_HORIZON: _effect_sunrise_horizon}

def _legacy_validation_context(context: EffectContext) -> EffectContext:
    """Return geometry large enough for discarded legacy scene validators.

    Version 4 keeps the legacy effect handlers only to validate their existing
    parameter schemas. Some old scene builders assume a tall environmental
    canvas and can fail on an accurately measured one-line subtitle box. Their
    drawings are discarded, so validation uses a neutral padded box while the
    real sweep and particles continue to use the caller's exact context.
    """
    box = context.box
    if box.width >= 560 and box.height >= 180:
        return context
    cx, cy = box.center
    width = min(context.play_res_x, max(560, box.width))
    height = min(context.play_res_y, max(220, box.height))
    x1 = round(cx - width / 2)
    y1 = round(cy - height / 2)
    x1 = max(0, min(x1, context.play_res_x - width))
    y1 = max(0, min(y1, context.play_res_y - height))
    validation_box = Rect(x1, y1, x1 + width, y1 + height)
    # Keep the caller's measured grapheme widths when the validation context
    # is padded.  Natural v7's environment handlers do not lay out glyphs,
    # but dropping this field here made the vendored engine violate the host
    # Context contract and broke callers that inspect/forward it.
    return EffectContext(play_res_x=context.play_res_x, play_res_y=context.play_res_y, anchor_x=context.anchor_x, anchor_y=context.anchor_y, text_box=validation_box, offscreen_margin=context.offscreen_margin, motion_step_ms=context.motion_step_ms, glyph_widths=context.glyph_widths, strict=context.strict)

def decorate_dialogue(dialogue_line: str, start_duration_ms: int, end_duration_ms: int, effect: Effect | str | int, *, params: Mapping[str, Any] | None=None, context: EffectContext | None=None) -> list[str]:
    """Apply one of thirty-six directional natural-phenomenon lyric effects.

    The lyric line is never divided into estimated glyph coordinates. During
    entry and exit the complete original line remains fixed at its ASS-rendered
    position and is exposed or concealed by overlapping rectangular bands, or
    by whole-line flicker for flash-like phenomena. Sparse local particles are
    animated independently with gravity, buoyancy, wind advection, flutter,
    bounce, wave, spiral, or ballistic motion appropriate to the phenomenon.

    No syllable timing, beat timing, audio analysis, or karaoke timing is
    consumed. ``start_duration_ms`` and ``end_duration_ms`` control the lyric
    entrance and exit phases respectively.
    """
    event = parse_dialogue(dialogue_line)
    if isinstance(start_duration_ms, bool) or not isinstance(start_duration_ms, int):
        raise EffectParameterError('start_duration_ms must be an integer')
    if isinstance(end_duration_ms, bool) or not isinstance(end_duration_ms, int):
        raise EffectParameterError('end_duration_ms must be an integer')
    if start_duration_ms < 0 or end_duration_ms < 0:
        raise EffectParameterError('effect durations must be non-negative')
    if start_duration_ms + end_duration_ms > event.duration_ms:
        raise EffectParameterError(f'start_duration_ms + end_duration_ms must not exceed the Dialogue duration ({event.duration_ms} ms)')
    selected = _coerce_effect(effect)
    effect_params = _coerce_params(params)
    if context is None:
        raise EffectParameterError(f"effect '{selected.value}' requires an explicit EffectContext because a Dialogue line does not contain PlayRes, anchor, or rendered lyric bounds")
    if _CONFLICT_RE.search(event.text):
        message = 'input Dialogue already contains a dynamic tag (fad/fade/t/move/clip/karaoke); pass a cut-in/cut-out line containing only static tags'
        if context.strict:
            raise EffectError(message)
    raw_environment = _HANDLERS[selected](event, start_duration_ms, end_duration_ms, effect_params, _legacy_validation_context(context))
    ambient = _localized_ambient_events(raw_environment, event, start_duration_ms, end_duration_ms, selected, effect_params, context)
    lyric_event = event
    if not context.strict and _CONFLICT_RE.search(event.text):
        leading_match = _LEADING_OVERRIDE_RE.match(event.text)
        leading = leading_match.group(0) if leading_match else ''
        payload = event.text[leading_match.end():] if leading_match else event.text
        lyric_event = _clone(event, text=leading + _OVERRIDE_RE.sub('', payload))
    lyric = _localized_lyric_events(lyric_event, start_duration_ms, end_duration_ms, selected, effect_params, context)
    generated = ambient + lyric
    if not generated:
        raise EffectError('effect produced no Dialogue events')
    return [item.format() for item in generated]
_v5_particle_scene_box = _particle_scene_box
_v5_physical_particle_styles = _physical_particle_styles
_v5_particle_colour = _particle_colour
_v5_motion_points = _motion_points
_v5_particle_kind_for = _particle_kind_for
_v5_phase_particle_timing = _phase_particle_timing
_v5_impact_events = _impact_events
_v5_resolve_sweep_direction = _resolve_sweep_direction
_spring_spec = EFFECT_SPECS[Effect.RAINBOW_ARCH]
EFFECT_SPECS = dict(EFFECT_SPECS)
EFFECT_SPECS[Effect.RAINBOW_ARCH] = replace(_spring_spec, name_en='Spring Breeze', name_ja='春風', description_en='Pastel spring motes and tiny petals drift on a mild horizontal breeze while the lyric is revealed and concealed in the same direction.', description_ja='淡い春色の微粒子と小さな花びらが穏やかな横風に流れ、同方向のスイープで歌詞を現して消します。')
EFFECT_SPECS[Effect.FROST_BLOOM] = replace(EFFECT_SPECS[Effect.FROST_BLOOM], categorical_params={})
EFFECT_SPECS[Effect.HEAT_HAZE] = replace(EFFECT_SPECS[Effect.HEAT_HAZE], categorical_params={})
EFFECT_NAMES_EN = {effect: spec.name_en for effect, spec in EFFECT_SPECS.items()}
EFFECT_NAMES_JA = {effect: spec.name_ja for effect, spec in EFFECT_SPECS.items()}
DEFAULT_PARAMS = {effect: dict(spec.default_params) for effect, spec in EFFECT_SPECS.items()}
LOCALIZED_CHOREOGRAPHY = dict(LOCALIZED_CHOREOGRAPHY)
LOCALIZED_CHOREOGRAPHY[Effect.RAINBOW_ARCH] = replace(LOCALIZED_CHOREOGRAPHY[Effect.RAINBOW_ARCH], glow='&HD8FFD0&', accent='&HB8F6FF&', carrier_palette=('&HC8FFC8&', '&HFFD3F2&', '&HDCF7FF&', '&HBFE8FF&'), description_en='A mild spring breeze carries pastel motes across the fixed lyric, leaves a few drifting accents, and returns to clear the line.', description_ja='穏やかな春風が淡い微粒子を固定位置の歌詞へ運び、少数の漂いを残した後、再び通過して文字を消します。')

def _replace_transition(effect: Effect, **changes: Any) -> None:
    SWEEP_TRANSITIONS[effect] = replace(SWEEP_TRANSITIONS[effect], **changes)
_replace_transition(Effect.RAIN_VEIL, particle_model='aligned_rain', particle_kind='aligned_rain_streak', description_en='Aligned rain streaks share one wind angle while independently timed drops pass through the soft vertical reveal.', description_ja='雨筋の向きを一つの風向へそろえ、発生時刻だけをずらした雨が柔らかな縦スイープを通過します。')
_replace_transition(Effect.CLOUDBURST, sweep_policy='horizontal_param', particle_model='wind_downpour', particle_kind='wind_heavy_rain', description_en='A strong side wind drives aligned heavy rain diagonally across the lyric; the horizontal reveal follows the wind direction.', description_ja='強い横風が向きをそろえた豪雨を斜めに吹き付け、文字の横スイープも風向へ合わせます。')
_replace_transition(Effect.RAINBOW_ARCH, sweep_policy='horizontal_param', particle_model='spring_breeze', particle_kind='spring_mote', entry_particles=16, hold_particles=5, exit_particles=16)
_replace_transition(Effect.CREPUSCULAR_RAYS, particle_model='near_light_dust', description_en='Illuminated dust begins near the lyric and drifts at roughly one third of the former speed.', description_ja='照らされた微粒子を文字近くから発生させ、従来のおよそ3分の1の速度で漂わせます。')
_replace_transition(Effect.SNOWFALL_DEPTH, particle_model='near_snow', description_en='Slow snow begins near the lyric, with a same-colour blurred shadow softening every crystal at each depth.', description_ja='文字近くから低速で降る雪に同色のぼかし影を重ね、各奥行きの結晶を柔らかく見せます。')
_replace_transition(Effect.DIAMOND_DUST, particle_model='stationary_twinkle', description_en='Ice crystals stay fixed in place and appear only as independent twinkles.', description_ja='氷晶は移動せず、その場で個別に点滅するだけの演出にします。')
_replace_transition(Effect.FROST_BLOOM, reveal_mode='radial', sweep_policy='radial_center', description_en='A circular stepped gradient grows from the lyric centre for both reveal and centre-out conceal.', description_ja='円形の段階グラデーションを文字中央から広げ、出現も消失も中央から外側へ進めます。')
_replace_transition(Effect.ICE_CRACK, particle_kind='sharp_shard_large', description_en='Large, acute ice shards—about three times the former sprite scale—flash around the fixed lyric.', description_ja='従来のおよそ3倍に拡大した鋭角の氷片を、固定位置の歌詞周囲で点滅させます。')
_replace_transition(Effect.SEA_OF_CLOUDS, particle_model='near_cloud_rise', description_en='Cloud particles begin close to the lyric and rise at roughly one third of the former speed.', description_ja='雲粒子を文字近くから発生させ、従来のおよそ3分の1の速度で上昇させます。')
_replace_transition(Effect.WHIRLWIND, reveal_mode='radial', sweep_policy='radial_center')
_replace_transition(Effect.TORNADO, reveal_mode='radial', sweep_policy='radial_center')
_replace_transition(Effect.SANDSTORM, entry_particles=36, hold_particles=10, exit_particles=36, description_en='The sand field uses twice the former particle budget while preserving the directional turbulent advection.', description_ja='方向性のある乱流移流を維持したまま、砂粒子数を従来の2倍にします。')
_replace_transition(Effect.HEAT_HAZE, particle_model='heat_orb_approach', particle_kind='heat_orb', description_en='Large translucent yellow-to-red heat orbs approach the viewer with a wide range of sizes.', description_ja='黄色から赤までの大きな半透明円が、広いサイズ差を持って手前へ近づきます。')
_replace_transition(Effect.OCEAN_SWELL, particle_model='water_orb_wave', particle_kind='water_orb', description_en='Large translucent blue-to-near-white water orbs ride a broad horizontal swell with strongly varied scale.', description_ja='青から白に近い水色までの大きな半透明円が、広いサイズ差を持って横うねりに乗ります。')
_replace_transition(Effect.WATERFALL, particle_model='water_orb_fall', particle_kind='water_orb', entry_particles=54, hold_particles=14, exit_particles=54, description_en='A dense fall of translucent water orbs begins with white leading particles and shifts toward blue behind them.', description_ja='大量の半透明水粒を落とし、先頭を白、後続を青系へ段階的に移します。')
_replace_transition(Effect.RIVER_CURRENT, particle_model='water_orb_flow', particle_kind='water_orb', entry_particles=42, hold_particles=12, exit_particles=42, description_en='The same translucent water-orb family as Waterfall flows horizontally in a dense field without a white leading group.', description_ja='滝と同じ半透明水粒を高密度で横へ流し、先頭だけを白くする処理は行いません。')
_replace_transition(Effect.LAVA_FLOW, particle_model='heat_orb_flow', particle_kind='heat_orb', description_en='Heat-haze orbs flow horizontally in the selected direction as a viscous lava field.', description_ja='陽炎の半透明熱円を選択方向へ横流しし、粘性のある溶岩流として見せます。')
_replace_transition(Effect.EMBER_DRIFT, particle_model='ember_orb_rise', particle_kind='small_heat_orb', description_en='Small heat-haze orbs rise from below as glowing embers.', description_ja='陽炎の熱円を小型化し、下から上へ昇る火の粉として表示します。')
_replace_transition(Effect.BIOLUMINESCENT_TIDE, particle_kind='radial_glow', description_en='Bioluminescent particles use layered circular radial-gradient sprites.', description_ja='夜光虫の粒子を、同心円レイヤーによる円形グラデーションスプライトへ変更します。')
_replace_transition(Effect.METEOR_SHOWER, particle_model='meteor_aligned', particle_kind='meteor_comic', description_en='Every meteor aligns its motion and tail; the cartoon star blooms brightly over the lyric, then dissolves with its tail.', description_ja='流星の移動方向と尾を一致させ、漫画的な星頭を文字付近で強く発光させた後、尾とともに消します。')
FLASH_EFFECTS = frozenset((effect for effect, spec in SWEEP_TRANSITIONS.items() if spec.reveal_mode == 'flash'))
_v5_coerce_effect = _coerce_effect

def _coerce_effect(value: Effect | str | int) -> Effect:
    if isinstance(value, str):
        normalized = value.strip().lower().replace('-', '_').replace(' ', '_')
        if normalized in {'rainbow_arch', 'rainbow', 'spring_breeze'} or value.strip() in {'虹', '春風'}:
            return Effect.RAINBOW_ARCH
    return _v5_coerce_effect(value)

def _resolve_sweep_direction(effect: Effect, params: Mapping[str, Any]) -> Direction:
    policy = SWEEP_TRANSITIONS[effect].sweep_policy
    if policy == 'radial_center':
        return Direction.CENTER_OUT
    return _v5_resolve_sweep_direction(effect, params)

def _star_polygon_path(outer: float, inner: float, points: int=5, *, cx: float=0, cy: float=0) -> str:
    vertices: list[tuple[float, float]] = []
    for i in range(points * 2):
        radius = outer if i % 2 == 0 else inner
        angle = -math.pi / 2 + i * math.pi / points
        vertices.append((cx + math.cos(angle) * radius, cy + math.sin(angle) * radius))
    return _polygon_path(vertices)

def _sharp_ice_shard_path(size: int, variant: int) -> str:
    s = max(18, size)
    skew = -1 if variant % 2 else 1
    return _polygon_path(((0, round(-1.65 * s)), (round(skew * 0.22 * s), round(-0.18 * s)), (round(skew * 0.82 * s), round(0.16 * s)), (round(skew * 0.13 * s), round(0.34 * s)), (round(-skew * 0.24 * s), round(1.25 * s)), (round(-skew * 0.34 * s), round(0.16 * s)), (round(-skew * 0.76 * s), round(-0.08 * s))))

def _meteor_tail_path(length: int, width: int, *, core: bool=False) -> str:
    length = max(24, length)
    width = max(3, width)
    if core:
        length = round(length * 0.72)
        width = max(2, round(width * 0.46))
    return _polygon_path(((-length, 0), (round(-length * 0.16), -width), (0, -round(width * 0.55)), (0, round(width * 0.55)), (round(-length * 0.16), width)))

def _absolute_circle_path(cx: float, cy: float, radius: float, *, clockwise: bool=True, samples: int=48) -> str:
    points = [(cx + radius * math.cos(math.tau * i / samples), cy + radius * math.sin(math.tau * i / samples)) for i in range(samples)]
    if not clockwise:
        points.reverse()
    return _polygon_path(points)

def _absolute_ring_path(cx: float, cy: float, inner: float, outer: float) -> str:
    outer_path = _absolute_circle_path(cx, cy, outer, clockwise=True)
    if inner <= 0.5:
        return outer_path
    return outer_path + ' ' + _absolute_circle_path(cx, cy, inner, clockwise=False)

def _vector_clip_tag(path: str, *, inverse: bool=False) -> str:
    return f"\\{('iclip' if inverse else 'clip')}(1,{path})"

def _radial_text_phase(event: DialogueEvent, begin: int, finish: int, *, entering: bool, effect: Effect, context: EffectContext) -> list[DialogueEvent]:
    if finish <= begin:
        return []
    spec = LOCALIZED_CHOREOGRAPHY[effect]
    rect = _expanded_text_box(context)
    cx, cy = rect.center
    radius = math.hypot(rect.width / 2, rect.height / 2) + 12
    ring_count = 14
    duration = finish - begin
    ramp = max(90, min(190, round(duration * 0.18)))
    travel = max(1, duration - ramp)
    result: list[DialogueEvent] = []
    for index in range(ring_count):
        inner = radius * index / ring_count
        outer = radius * (index + 1) / ring_count + 1.5
        path = _absolute_ring_path(cx, cy, inner, outer)
        delay = round(travel * index / max(1, ring_count - 1))
        transition_end = min(duration, delay + ramp)
        alpha_tags = f'\\alpha&HFF&\\t({delay},{transition_end},1.12,\\alpha&H00&)' if entering else f'\\alpha&H00&\\t({delay},{transition_end},1.12,\\alpha&HFF&)'
        result.append(_clone(event, start_ms=event.start_ms + begin, end_ms=event.start_ms + finish, layer=event.layer + 12, effect_field=f"NAT40:{effect.value}:text:{('entry' if entering else 'exit')}:radial:{index}", text=_add_tags(event.text, _text_style_tags(spec) + _vector_clip_tag(path) + alpha_tags)))
        glow_start = max(0, delay - round(ramp * 0.42))
        glow_end = min(duration, delay + round(ramp * 1.18))
        result.append(_clone(event, start_ms=event.start_ms + begin, end_ms=event.start_ms + finish, layer=event.layer + 9, effect_field=f"NAT40:{effect.value}:text:{('entry' if entering else 'exit')}:radial_glow:{index}", text=_add_tags(event.text, _text_style_tags(spec, glow=True) + _vector_clip_tag(path) + f'\\alpha&HFF&\\t({glow_start},{delay + max(1, ramp // 2)},\\alpha&H78&)' + f'\\t({delay + max(1, ramp // 2)},{glow_end},\\alpha&HFF&)')))
    return result

def _localized_lyric_events(event: DialogueEvent, start: int, end: int, effect: Effect, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    direction = _resolve_sweep_direction(effect, params)
    transition = SWEEP_TRANSITIONS[effect]
    result: list[DialogueEvent] = []
    if start > 0:
        if transition.reveal_mode == 'flash':
            result.extend(_flash_text_phase(event, 0, start, entering=True, effect=effect))
        elif transition.reveal_mode == 'radial':
            result.extend(_radial_text_phase(event, 0, start, entering=True, effect=effect, context=context))
        else:
            result.extend(_sweep_text_phase(event, 0, start, entering=True, effect=effect, direction=direction, context=context))
    hold = _hold_text_event(event, start, end, effect)
    if hold is not None:
        result.append(hold)
    if end > 0:
        phase_start = event.duration_ms - end
        if transition.reveal_mode == 'flash':
            result.extend(_flash_text_phase(event, phase_start, event.duration_ms, entering=False, effect=effect))
        elif transition.reveal_mode == 'radial':
            result.extend(_radial_text_phase(event, phase_start, event.duration_ms, entering=False, effect=effect, context=context))
        else:
            result.extend(_sweep_text_phase(event, phase_start, event.duration_ms, entering=False, effect=effect, direction=direction, context=context))
    return result

def _physical_particle_styles(kind: str, index: int, effect: Effect) -> tuple[_PhysicalParticleStyle, ...]:
    variant = index % 4
    theme = LOCALIZED_CHOREOGRAPHY[effect]
    white = '&HFFFFFF&'
    if kind == 'aligned_rain_streak':
        length = (28, 34, 42, 31)[variant]
        width = (1.5, 1.8, 1.35, 1.65)[variant]
        return (_PhysicalParticleStyle(_rain_streak_path(length, 0, width), True, 0.0, 2.3, 174, 112, theme.glow, -1), _PhysicalParticleStyle(_rain_streak_path(length, 0, width, core=True), True, 0.0, 0.5, 52, 100, white, 0))
    if kind == 'wind_heavy_rain':
        length = (58, 68, 80, 62)[variant]
        width = (3.2, 4.0, 4.8, 3.6)[variant]
        return (_PhysicalParticleStyle(_rain_streak_path(length, 0, width), True, 0.0, 3.6, 164, 116, theme.glow, -1), _PhysicalParticleStyle(_rain_streak_path(length, 0, width, core=True), True, 0.0, 0.7, 42, 103, white, 0))
    if kind == 'spring_mote':
        if variant % 2:
            path = _petal_sprite_path(5 + variant, 8 + variant, variant)
            return (_PhysicalParticleStyle(path, True, 0.25, 0.6, 78, 100, None, 0),)
        path = _ellipse_path(3 + variant, 2 + variant // 2)
        return (_PhysicalParticleStyle(path, True, 0.0, 3.8, 176, 135, theme.glow, -1), _PhysicalParticleStyle(path, True, 0.0, 0.5, 54, 100, white, 0))
    if kind == 'sharp_shard_large':
        size = (21, 26, 31, 23)[variant]
        path = _sharp_ice_shard_path(size, variant)
        return (_PhysicalParticleStyle(path, True, 1.6, 4.8, 172, 120, theme.glow, -1), _PhysicalParticleStyle(path, True, 0.55, 0.45, 40, 100, white, 0))
    if kind == 'heat_orb':
        radius = (18, 27, 36, 22)[variant]
        path = _ellipse_path(radius, radius)
        return (_PhysicalParticleStyle(path, True, 0.0, 13.0, 232, 132, None, -3), _PhysicalParticleStyle(path, True, 0.0, 5.0, 202, 92, None, -1), _PhysicalParticleStyle(path, True, 0.0, 0.8, 154, 52, '&H8AFFFF&', 0))
    if kind == 'small_heat_orb':
        radius = (4, 6, 8, 5)[variant]
        path = _ellipse_path(radius, radius)
        return (_PhysicalParticleStyle(path, True, 0.0, 6.0, 202, 132, None, -2), _PhysicalParticleStyle(path, True, 0.0, 1.2, 76, 82, '&H8AFFFF&', 0))
    if kind == 'water_orb':
        radius = (9, 14, 21, 11)[variant]
        path = _ellipse_path(radius, radius)
        return (_PhysicalParticleStyle(path, True, 0.0, 9.0, 234, 132, None, -3), _PhysicalParticleStyle(path, True, 0.0, 3.2, 196, 88, None, -1), _PhysicalParticleStyle(path, True, 0.0, 0.45, 116, 42, white, 0))
    if kind == 'radial_glow':
        radius = (7, 10, 14, 8)[variant]
        path = _ellipse_path(radius, radius)
        return (_PhysicalParticleStyle(path, True, 0.0, 10.0, 230, 150, None, -3), _PhysicalParticleStyle(path, True, 0.0, 5.0, 190, 110, None, -2), _PhysicalParticleStyle(path, True, 0.0, 1.0, 76, 56, white, 0))
    if kind == 'meteor_comic':
        length = (44, 58, 72, 52)[variant]
        width = (5, 6, 8, 6)[variant]
        tail = _meteor_tail_path(length, width)
        core = _meteor_tail_path(length, width, core=True)
        star_outer = _star_polygon_path(width * 2.4, width * 1.02, cx=1, cy=0)
        star_inner = _star_polygon_path(width * 1.45, width * 0.62, cx=1, cy=0)
        return (_PhysicalParticleStyle(tail, True, 0.0, 7.5, 220, 122, theme.glow, -3), _PhysicalParticleStyle(core, True, 0.0, 1.2, 86, 100, white, -2), _PhysicalParticleStyle(star_outer, True, 0.0, 6.5, 170, 128, theme.glow, -1), _PhysicalParticleStyle(star_inner, True, 0.4, 0.55, 10, 100, white, 0))
    return _v5_physical_particle_styles(kind, index, effect)

def _physical_particle_style(kind: str) -> _PhysicalParticleStyle:
    return _physical_particle_styles(kind, 0, Effect.RAIN_VEIL)[0]
_HEAT_PALETTE = ('&H48F5FF&', '&H2CC8FF&', '&H2498FF&', '&H2868FF&', '&H3848FF&', '&H5038FF&')
_WATER_PALETTE = ('&HFFFDF8&', '&HFFEBD2&', '&HFFD8A6&', '&HFFC47A&', '&HFFAA52&', '&HFF8E3C&')
_SPRING_PALETTE = ('&HC8FFC8&', '&HFFD3F2&', '&HDCF7FF&', '&HBFE8FF&', '&HCCE8B4&')
_BIOLUME_PALETTE = ('&HFFE978&', '&HFFD95A&', '&HFFF6A2&', '&HCEF77A&')

def _particle_colour(effect: Effect, index: int) -> str:
    if effect in {Effect.HEAT_HAZE, Effect.LAVA_FLOW, Effect.EMBER_DRIFT}:
        return _HEAT_PALETTE[index % len(_HEAT_PALETTE)]
    if effect == Effect.WATERFALL:
        if index < 7:
            return _WATER_PALETTE[0]
        return _WATER_PALETTE[min(len(_WATER_PALETTE) - 1, 1 + (index - 7) // 9)]
    if effect in {Effect.OCEAN_SWELL, Effect.RIVER_CURRENT}:
        return _WATER_PALETTE[1 + index * 3 % (len(_WATER_PALETTE) - 1)]
    if effect == Effect.RAINBOW_ARCH:
        return _SPRING_PALETTE[index % len(_SPRING_PALETTE)]
    if effect == Effect.BIOLUMINESCENT_TIDE:
        return _BIOLUME_PALETTE[index % len(_BIOLUME_PALETTE)]
    return _v5_particle_colour(effect, index)

def _particle_scene_box(context: EffectContext, model: str) -> Rect:
    if model in {'near_light_dust', 'near_snow', 'near_cloud_rise', 'stationary_twinkle', 'heat_orb_approach'}:
        box = context.box
        pad_x = max(68, min(112, round(box.height * 0.92)))
        pad_y = max(54, min(88, round(box.height * 0.68)))
        return Rect(max(0, box.x1 - pad_x), max(0, box.y1 - pad_y), min(context.play_res_x, box.x2 + pad_x), min(context.play_res_y, box.y2 + pad_y))
    mapped = {'aligned_rain': 'rain', 'wind_downpour': 'downpour', 'spring_breeze': 'breeze', 'water_orb_wave': 'wave_advect', 'water_orb_fall': 'waterfall', 'water_orb_flow': 'river', 'heat_orb_flow': 'lava_flow', 'ember_orb_rise': 'ember_rise', 'meteor_aligned': 'meteor'}.get(model, model)
    return _v5_particle_scene_box(context, mapped)

def _horizontal_direction_sign(effect: Effect, params: Mapping[str, Any]) -> float:
    raw = params.get('direction', DEFAULT_PARAMS[effect].get('direction', Direction.LEFT_TO_RIGHT))
    if not isinstance(raw, Direction):
        try:
            raw = Direction(str(raw))
        except ValueError:
            raw = Direction.LEFT_TO_RIGHT
    return -1.0 if raw in {Direction.RIGHT_TO_LEFT, Direction.COUNTERCLOCKWISE, Direction.EDGES_IN} else 1.0

def _motion_points(model: str, *, phase: str, index: int, count: int, effect: Effect, params: Mapping[str, Any], context: EffectContext, seed: int) -> list[tuple[float, float, float, float, float]]:
    scene = _particle_scene_box(context, model)
    box = context.box
    cx, cy = box.center
    direction = _resolve_sweep_direction(effect, params)
    sign = _horizontal_direction_sign(effect, params)
    spin = _rotation_sign(params, effect)
    u0 = _seed_value(seed, index, 1301)
    u1 = _seed_value(seed, index, 1302)
    u2 = _seed_value(seed, index, 1303)
    u3 = _seed_value(seed, index, 1304)
    u4 = _seed_value(seed, index, 1305)
    lane = _random_lane(seed, index)

    def p(t: float, x: float, y: float, scale: float, rotation: float) -> tuple[float, float, float, float, float]:
        return (t, x, y, scale, rotation)
    if model == 'aligned_rain':
        x0 = scene.x1 + scene.width * (0.025 + 0.95 * lane)
        y0 = scene.y1 - 28 - 34 * u3
        y1 = scene.y2 + 18 + 24 * u4
        drift = sign * (14 + 6 * u1)
        rotation = -sign * 8.5
        scale = 72 + 42 * u0
        return [p(0.0, x0, y0, scale * 0.92, rotation), p(0.42, x0 + drift * 0.24, y0 + (y1 - y0) * 0.31, scale, rotation), p(1.0, x0 + drift, y1, scale * 1.08, rotation)]
    if model in {'wind_downpour'}:
        x0 = scene.x1 - 54 - 26 * u3 if sign > 0 else scene.x2 + 54 + 26 * u3
        y0 = scene.y1 - 42 + scene.height * (0.04 + 0.48 * lane)
        dx = sign * scene.width * (1.02 + 0.18 * u1)
        dy = scene.height * (0.72 + 0.18 * u2)
        rotation = -sign * (31 + 3 * u3)
        scale = 78 + 50 * u0
        return [p(0.0, x0, y0, scale * 0.92, rotation), p(0.38, x0 + dx * 0.27, y0 + dy * 0.25, scale, rotation), p(1.0, x0 + dx, y0 + dy, scale * 1.08, rotation)]
    if model == 'spring_breeze':
        x0 = scene.x1 - 24 if sign > 0 else scene.x2 + 24
        x1 = scene.x2 + 24 if sign > 0 else scene.x1 - 24
        y0 = scene.y1 + scene.height * (0.12 + 0.76 * lane)
        amp = 10 + 24 * u2
        scale = 38 + 54 * u0
        return [p(t, x0 + (x1 - x0) * t, y0 + amp * math.sin(math.tau * (0.72 + 0.45 * u3) * t + u1 * math.tau), scale * (0.92 + 0.14 * t), spin * (30 + 110 * u4) * t) for t in (0.0, 0.18, 0.38, 0.62, 0.82, 1.0)]
    if model == 'near_light_dust':
        x0 = box.x1 + box.width * (0.02 + 0.96 * lane)
        y0 = box.y1 - 24 + 30 * u2
        travel = 34 + 38 * u3
        return [p(t, x0 + (5 + 9 * u1) * math.sin(math.tau * (0.46 + 0.2 * u4) * t + u0 * math.tau), y0 + travel * t, 30 + 46 * u2, spin * (18 + 55 * u3) * t) for t in (0.0, 0.25, 0.5, 0.75, 1.0)]
    if model == 'near_snow':
        x0 = box.x1 + box.width * (0.02 + 0.96 * lane)
        y0 = box.y1 - 38 + 42 * u3
        travel = 52 + 48 * u4
        amp = 8 + 15 * u1
        scale = 38 + 55 * u2
        return [p(t, x0 + amp * math.sin(math.tau * (0.48 + 0.28 * u4) * t + u0 * math.tau), y0 + travel * t, scale * (0.94 + 0.1 * t), spin * (40 + 120 * u3) * t) for t in (0.0, 0.2, 0.4, 0.6, 0.8, 1.0)]
    if model == 'stationary_twinkle':
        x = scene.x1 + scene.width * (0.06 + 0.88 * lane)
        y = scene.y1 + scene.height * (0.08 + 0.84 * u1)
        scale = 36 + 70 * u2
        rotation = spin * (u3 * 180)
        return [p(0.0, x, y, scale, rotation), p(1.0, x, y, scale, rotation)]
    if model == 'near_cloud_rise':
        x0 = box.x1 + box.width * (0.02 + 0.96 * lane)
        y0 = box.y2 + 16 + 24 * u2
        rise = 28 + 34 * u3
        drift = (u1 - 0.5) * 14
        scale = 62 + 64 * u0
        return [p(t, x0 + drift * t + 5 * math.sin(math.tau * 0.42 * t + u4 * math.tau), y0 - rise * t, scale * (0.96 + 0.08 * t), (u4 - 0.5) * 3) for t in (0.0, 0.25, 0.5, 0.75, 1.0)]
    if model == 'heat_orb_approach':
        angle = math.tau * lane
        radius = min(scene.width, scene.height) * (0.12 + 0.28 * u2)
        x0 = cx + math.cos(angle) * radius
        y0 = cy + math.sin(angle) * radius * 0.55 + (u3 - 0.5) * 22
        scale0 = 28 + 62 * u0
        scale1 = 190 + 190 * u1
        return [p(0.0, x0, y0, scale0, 0), p(0.48, x0 + (u3 - 0.5) * 18, y0 - (8 + 16 * u4), (scale0 + scale1) * 0.46, 0), p(1.0, x0 + (u3 - 0.5) * 32, y0 - (18 + 28 * u4), scale1, 0)]
    if model == 'water_orb_wave':
        x0 = scene.x1 - 36 if sign > 0 else scene.x2 + 36
        x1 = scene.x2 + 36 if sign > 0 else scene.x1 - 36
        y0 = cy + (lane - 0.5) * scene.height * 0.66
        amp = 18 + 40 * u2
        scale0 = 44 + 80 * u0
        scale1 = 120 + 170 * u1
        return [p(t, x0 + (x1 - x0) * t, y0 + amp * math.sin(math.tau * (0.7 + 0.32 * u3) * t + u4 * math.tau), scale0 + (scale1 - scale0) * t, 0) for t in (0.0, 0.34, 0.68, 1.0)]
    if model == 'water_orb_fall':
        x0 = scene.x1 + scene.width * (0.02 + 0.96 * lane)
        y0 = scene.y1 - 24 - 28 * u3
        y1 = scene.y2 + 18 + 24 * u4
        drift = (u1 - 0.5) * 22
        scale = 28 + 86 * u0
        return [p(0.0, x0, y0, scale * 0.88, 0), p(0.4, x0 + drift * 0.22, y0 + (y1 - y0) * 0.28, scale, 0), p(1.0, x0 + drift, y1, scale * 1.1, 0)]
    if model == 'water_orb_flow':
        x0 = scene.x1 - 24 if sign > 0 else scene.x2 + 24
        x1 = scene.x2 + 24 if sign > 0 else scene.x1 - 24
        y0 = scene.y1 + scene.height * (0.08 + 0.84 * lane)
        amp = 5 + 13 * u2
        scale = 28 + 88 * u0
        return [p(t, x0 + (x1 - x0) * t, y0 + amp * math.sin(math.tau * (0.8 + 0.5 * u3) * t + u4 * math.tau), scale * (0.92 + 0.14 * t), 0) for t in (0.0, 0.5, 1.0)]
    if model == 'heat_orb_flow':
        x0 = scene.x1 - 40 if sign > 0 else scene.x2 + 40
        x1 = scene.x2 + 40 if sign > 0 else scene.x1 - 40
        y0 = scene.y1 + scene.height * (0.08 + 0.84 * lane)
        amp = 7 + 18 * u2
        scale0 = 42 + 82 * u0
        scale1 = 110 + 140 * u1
        return [p(t, x0 + (x1 - x0) * t, y0 + amp * math.sin(math.tau * (0.62 + 0.38 * u3) * t + u4 * math.tau) + 8 * t * t, scale0 + (scale1 - scale0) * t, 0) for t in (0.0, 0.5, 1.0)]
    if model == 'ember_orb_rise':
        x0 = scene.x1 + scene.width * (0.04 + 0.92 * lane)
        y0 = scene.y2 + 18 + 24 * u3
        y1 = scene.y1 - 12 - 16 * u4
        amp = 8 + 18 * u2
        scale = 22 + 60 * u0
        return [p(t, x0 + amp * math.sin(math.tau * (0.7 + 0.45 * u3) * t + u1 * math.tau), y0 + (y1 - y0) * (1 - (1 - t) ** 1.18), scale * (0.88 + 0.2 * t), 0) for t in (0.0, 0.34, 0.68, 1.0)]
    if model == 'meteor_aligned':
        x0 = scene.x1 - 42 + scene.width * 0.44 * lane if sign > 0 else scene.x2 + 42 - scene.width * 0.44 * lane
        y0 = scene.y1 - 34 - 30 * u3
        dx = sign * scene.width * (0.68 + 0.18 * u1)
        dy = scene.height * (0.66 + 0.28 * u4)
        angle = -math.degrees(math.atan2(dy, dx))
        scale = 48 + 58 * u0
        return [p(t, x0 + dx * t ** 0.92, y0 + dy * t ** 0.92, scale * (0.92 + 0.16 * t), angle) for t in (0.0, 0.16, 0.34, 0.56, 0.78, 1.0)]
    return _v5_motion_points(model, phase=phase, index=index, count=count, effect=effect, params=params, context=context, seed=seed)

def _unscaled_phase_particle_timing(*, begin: int, finish: int, phase: str, model: str, index: int, count: int, seed: int) -> tuple[int, int]:
    duration = finish - begin
    if duration <= 1:
        return (begin, finish)
    if model in {'near_light_dust', 'near_snow', 'near_cloud_rise'}:
        u = _seed_value(seed, index, 1701)
        lifetime = min(duration, round(610 + 220 * u))
        span = max(0, duration - lifetime)
        sequence = _fractional(index * 0.6180339887 + _seed_value(seed, index, 1702) * 0.31)
        offset = round(span * sequence)
        return (begin + offset, begin + offset + lifetime)
    if model == 'water_orb_fall':
        u = _seed_value(seed, index, 1703)
        sequence = (index + 0.24 * u) / max(1, count)
        offset = round(duration * 0.42 * min(0.98, sequence))
        lifetime = max(180, round(duration * (0.58 + 0.26 * _seed_value(seed, index, 1704))))
        start = begin + offset
        return (start, min(finish, start + lifetime))
    return _v5_phase_particle_timing(begin=begin, finish=finish, phase=phase, model=model, index=index, count=count, seed=seed)


def _particle_lifetime_ms(*, phase: str, model: str, index: int, count: int, seed: int, speed_scale: float=1.0) -> int:
    reference_begin, reference_finish = _unscaled_phase_particle_timing(
        begin=0,
        finish=_PARTICLE_SPEED_REFERENCE_PHASE_MS,
        phase=phase,
        model=model,
        index=index,
        count=count,
        seed=seed,
    )
    return max(1, round((reference_finish - reference_begin) / speed_scale))


def _phase_particle_timing(*, begin: int, finish: int, phase: str, model: str, index: int, count: int, seed: int, speed_scale: float=1.0) -> tuple[int, int]:
    """Schedule one particle without stretching its path to the phase length.

    A 750 ms phase preserves the renderer's previous timing exactly.  Longer
    phases spread particle start times over the available interval, but each
    normalized path keeps the lifetime it had at that reference duration.
    ``speed_scale`` changes that lifetime inversely, so a value of 2 moves the
    same path at twice the speed.  The phase limits particle creation only;
    particles already created keep running to the end of their path.
    """
    duration = finish - begin
    if duration <= 1:
        return (begin, finish)
    particle_begin, _ = _unscaled_phase_particle_timing(
        begin=begin,
        finish=finish,
        phase=phase,
        model=model,
        index=index,
        count=count,
        seed=seed,
    )
    lifetime = _particle_lifetime_ms(
        phase=phase,
        model=model,
        index=index,
        count=count,
        seed=seed,
        speed_scale=speed_scale,
    )
    return (particle_begin, particle_begin + lifetime)


def _particle_speed_scale(effect: Effect, params: Mapping[str, Any]) -> float:
    """Return the path-speed multiplier for effects exposing ``speed``."""
    default_speed = DEFAULT_PARAMS[effect].get('speed')
    if default_speed is None:
        return 1.0
    return float(params.get('speed', default_speed)) / float(default_speed)


def _render_static_flash_phase(event: DialogueEvent, begin: int, finish: int, *, phase: str, count: int, effect: Effect, kind: str, model: str, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    if count <= 0 or finish <= begin:
        return []
    seed = int(params.get('seed', DEFAULT_PARAMS[effect].get('seed', 1009))) + {'entry': 0, 'hold': 4001, 'exit': 8009}[phase]
    duration = finish - begin
    result: list[DialogueEvent] = []
    scene = _particle_scene_box(context, model)
    for index in range(count):
        points = _motion_points(model, phase=phase, index=index, count=count, effect=effect, params=params, context=context, seed=seed)
        _, x, y, scale, rotation = points[0]
        styles = _physical_particle_styles(kind, index, effect)
        pulse_count = 1 if phase == 'hold' else 2
        base_sequence = _fractional(index * 0.6180339887 + _seed_value(seed, index, 1801) * 0.37)
        for pulse in range(pulse_count):
            centre_fraction = min(0.94, 0.12 + 0.68 * base_sequence + pulse * 0.18)
            pulse_duration = round(120 * (0.84 + 0.42 * _seed_value(seed, index + pulse, 1802)))
            pulse_start = begin + round(duration * centre_fraction) - pulse_duration // 2
            pulse_start = max(begin, min(finish - 40, pulse_start))
            pulse_end = min(finish, pulse_start + max(40, pulse_duration))
            if pulse_end <= pulse_start:
                continue
            for layer_index, style in enumerate(styles):
                item = _moving_shape(event, pulse_start, pulse_end, style.path, x0=x, y0=y, x1=x, y1=y, color=style.colour_override or _particle_colour(effect, index), alpha=style.alpha, scale0=scale * style.scale / 100.0, scale1=scale * style.scale / 100.0, rotation0=rotation, rotation1=rotation, blur=style.blur, border=style.border, outline=style.colour_override or _particle_colour(effect, index), fill=style.fill, fade_in=min(18, max(5, (pulse_end - pulse_start) // 5)), fade_out=min(30, max(8, (pulse_end - pulse_start) // 3)), clip=scene, layer_offset=8 + style.layer_delta)
                result.append(_clone(item, effect_field=f'NAT40:{effect.value}:particle:{phase}:{model}:{index}:layer:{layer_index}:pulse:{pulse}'))
    return result

def _edge_gradient_slices(scene: Rect, first: tuple[float, float, float, float, float], second: tuple[float, float, float, float, float]) -> tuple[str | None, list[tuple[Rect, int]]]:
    _, x0, y0, _, _ = first
    _, x1, y1, _, _ = second
    dx, dy = (x1 - x0, y1 - y0)
    margin = 52
    candidates: list[tuple[float, str]] = []
    if x0 <= scene.x1 + margin and dx > 0:
        candidates.append((abs(x0 - scene.x1) / max(1.0, abs(dx)), 'left'))
    if x0 >= scene.x2 - margin and dx < 0:
        candidates.append((abs(x0 - scene.x2) / max(1.0, abs(dx)), 'right'))
    if y0 <= scene.y1 + margin and dy > 0:
        candidates.append((abs(y0 - scene.y1) / max(1.0, abs(dy)), 'top'))
    if y0 >= scene.y2 - margin and dy < 0:
        candidates.append((abs(y0 - scene.y2) / max(1.0, abs(dy)), 'bottom'))
    if not candidates:
        return (None, [(scene, 0)])
    if abs(dx) > abs(dy) * 0.78:
        side = next((name for _, name in candidates if name in {'left', 'right'}), min(candidates)[1])
    else:
        side = next((name for _, name in candidates if name in {'top', 'bottom'}), min(candidates)[1])
    extent = scene.width if side in {'left', 'right'} else scene.height
    depth = max(42, min(84, round(extent * 0.16)))
    cuts = (0, round(depth * 0.42), depth)
    alpha_offsets = (184, 72)
    slices: list[tuple[Rect, int]] = []
    for i, alpha_offset in enumerate(alpha_offsets):
        a, b = (cuts[i], cuts[i + 1])
        if b <= a:
            continue
        if side == 'top':
            clip = Rect(scene.x1, scene.y1 + a, scene.x2, min(scene.y2, scene.y1 + b))
        elif side == 'bottom':
            clip = Rect(scene.x1, max(scene.y1, scene.y2 - b), scene.x2, scene.y2 - a)
        elif side == 'left':
            clip = Rect(scene.x1 + a, scene.y1, min(scene.x2, scene.x1 + b), scene.y2)
        else:
            clip = Rect(max(scene.x1, scene.x2 - b), scene.y1, scene.x2 - a, scene.y2)
        slices.append((clip, alpha_offset))
    if side == 'top' and scene.y1 + depth < scene.y2:
        slices.append((Rect(scene.x1, scene.y1 + depth, scene.x2, scene.y2), 0))
    elif side == 'bottom' and scene.y1 < scene.y2 - depth:
        slices.append((Rect(scene.x1, scene.y1, scene.x2, scene.y2 - depth), 0))
    elif side == 'left' and scene.x1 + depth < scene.x2:
        slices.append((Rect(scene.x1 + depth, scene.y1, scene.x2, scene.y2), 0))
    elif side == 'right' and scene.x1 < scene.x2 - depth:
        slices.append((Rect(scene.x1, scene.y1, scene.x2 - depth, scene.y2), 0))
    return (side, slices)

def _emit_piecewise_particle(event: DialogueEvent, begin: int, finish: int, *, points: Sequence[tuple[float, float, float, float, float]], effect: Effect, phase: str, particle_index: int, kind: str, colour: str, context: EffectContext) -> list[DialogueEvent]:
    if finish <= begin or len(points) < 2:
        return []
    styles = _physical_particle_styles(kind, particle_index, effect)
    scene = _particle_scene_box(context, SWEEP_TRANSITIONS[effect].particle_model)
    duration = finish - begin
    result: list[DialogueEvent] = []
    marker = f'NAT40:{effect.value}:particle:{phase}:{particle_index}'
    edge_name, gradient_slices = _edge_gradient_slices(scene, points[0], points[1])
    for segment_index, (first, second) in enumerate(zip(points, points[1:])):
        t0, x0, y0, scale0, rotation0 = first
        t1, x1, y1, scale1, rotation1 = second
        seg_begin = begin + round(duration * t0)
        seg_finish = begin + round(duration * t1)
        if seg_finish <= seg_begin:
            continue
        for layer_index, style in enumerate(styles):
            masks = gradient_slices if segment_index == 0 and edge_name is not None and (layer_index == 0) else [(scene, 0)]
            for mask_index, (mask_clip, alpha_offset) in enumerate(masks):
                layer_colour = style.colour_override or colour
                alpha = style.alpha
                if kind in {'firefly', 'glow_foam', 'radial_glow', 'spark', 'crystal'}:
                    alpha = max(0, alpha - (14 if (segment_index + particle_index) % 2 == 0 else 0))
                alpha = min(252, alpha + alpha_offset)
                fade_in = 0
                if segment_index == 0:
                    fade_in = min(82 if layer_index else 42, max(8, (seg_finish - seg_begin) // 3))
                item = _moving_shape(event, seg_begin, seg_finish, style.path, x0=x0, y0=y0, x1=x1, y1=y1, color=layer_colour, alpha=alpha, scale0=scale0 * style.scale / 100.0, scale1=scale1 * style.scale / 100.0, rotation0=rotation0, rotation1=rotation1, blur=style.blur, border=style.border, outline=layer_colour, fill=style.fill, fade_in=fade_in, fade_out=min(72, max(0, (seg_finish - seg_begin) // 3)) if segment_index == len(points) - 2 else 0, clip=mask_clip, layer_offset=7 + style.layer_delta)
                result.append(_clone(item, effect_field=marker + f":layer:{layer_index}:segment:{segment_index}:edgegrad:{edge_name or 'none'}:{mask_index}"))
    return result

def _particle_kind_for(effect: Effect, model: str, base_kind: str, index: int) -> str:
    if False and index % 4 == 3:
        return 'prism'
    return _v5_particle_kind_for(effect, model, base_kind, index)

def _impact_events(event: DialogueEvent, *, effect: Effect, model: str, phase: str, index: int, begin: int, finish: int, point: tuple[float, float, float, float, float], colour: str, context: EffectContext) -> list[DialogueEvent]:
    mapped = {'aligned_rain': 'rain', 'wind_downpour': 'downpour'}.get(model, model)
    return _v5_impact_events(event, effect=effect, model=mapped, phase=phase, index=index, begin=begin, finish=finish, point=point, colour=colour, context=context)

def _render_particle_model_phase(event: DialogueEvent, begin: int, finish: int, *, phase: str, count: int, effect: Effect, model: str, base_kind: str, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    if count <= 0 or finish <= begin:
        return []
    seed = int(params.get('seed', DEFAULT_PARAMS[effect].get('seed', _legacy_effect_number(effect) * 1009)))
    phase_seed = seed + {'entry': 0, 'hold': 4001, 'exit': 8009}[phase]
    speed_scale = _particle_speed_scale(effect, params)
    result: list[DialogueEvent] = []
    for index in range(count):
        particle_begin, particle_finish = _phase_particle_timing(begin=begin, finish=finish, phase=phase, model=model, index=index, count=count, seed=phase_seed, speed_scale=speed_scale)
        points = _motion_points(model, phase=phase, index=index, count=count, effect=effect, params=params, context=context, seed=phase_seed)
        kind = _particle_kind_for(effect, model, base_kind, index)
        colour = _particle_colour(effect, index)
        result.extend(_emit_piecewise_particle(event, particle_begin, particle_finish, points=points, effect=effect, phase=phase, particle_index=index, kind=kind, colour=colour, context=context))
        result.extend(_impact_events(event, effect=effect, model=model, phase=phase, index=index, begin=particle_begin, finish=particle_finish, point=points[-1], colour=colour, context=context))
    return result

def _render_physical_particle_phase(event: DialogueEvent, begin: int, finish: int, *, phase: str, count: int, effect: Effect, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    transition = SWEEP_TRANSITIONS[effect]
    if transition.particle_model == 'stationary_twinkle':
        return _render_static_flash_phase(event, begin, finish, phase=phase, count=count, effect=effect, kind='crystal', model='stationary_twinkle', params=params, context=context)
    return _render_particle_model_phase(event, begin, finish, phase=phase, count=count, effect=effect, model=transition.particle_model, base_kind=transition.particle_kind, params=params, context=context)

def _localized_ambient_events(generated: Sequence[DialogueEvent], event: DialogueEvent, start: int, end: int, effect: Effect, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    del generated
    transition = SWEEP_TRANSITIONS[effect]
    duration = event.duration_ms
    phases = (('entry', 0, start, transition.entry_particles), ('hold', start, duration - end, transition.hold_particles), ('exit', duration - end, duration, transition.exit_particles))
    result: list[DialogueEvent] = []
    for phase, begin, finish, base_count in phases:
        if finish <= begin:
            continue
        count = _scaled_particle_count(effect, phase, base_count, params)
        result.extend(_render_physical_particle_phase(event, begin, finish, phase=phase, count=count, effect=effect, params=params, context=context))
    return result
_v6_physical_particle_styles = _physical_particle_styles
_v6_particle_colour = _particle_colour
_v6_motion_points = _motion_points
_v6_localized_lyric_events = _localized_lyric_events
_replace_transition(Effect.ICE_CRACK, particle_kind='ice_diamond_large', description_en='Large diamond-shaped ice fragments travel without rotating while the fixed lyric flickers in and out.', description_ja='大きなひし形の氷片を回転させずに移動させ、固定位置の歌詞を点滅で出現・消失させます。')
_replace_transition(Effect.WHIRLPOOL, reveal_mode='radial', sweep_policy='radial_center', description_en='The vortex particles retain their existing spiral motion while a circular centre-out gradient reveals and conceals the lyric.', description_ja='渦粒子の既存の旋回運動は維持し、文字だけを中央から広がる円形グラデーションで出現・消失させます。')
_replace_transition(Effect.MOONLIGHT_CLOUDS, description_en='Non-rotating cloud-light sprites drift at deterministic random brightness levels while the lyric receives two restrained moonlight pulses.', description_ja='回転しない雲光スプライトを個別のランダム輝度で流し、表示中の歌詞を控えめに2回発光させます。')

def _diamond_ice_path(size: int, variant: int) -> str:
    """Return a true rhombus with a slightly varied aspect ratio."""
    height = max(18, int(size))
    width = max(8, round(height * (0.34 + 0.045 * (variant % 4))))
    return _polygon_path(((0, -height), (width, 0), (0, height), (-width, 0)))

def _meteor_composite_path(length: int, width: int, *, inner: bool=False) -> str:
    """Keep the cartoon star and its tail in one drawing coordinate system.

    ASS alignment is based on each drawing's bounding box.  Separate star and
    tail events therefore drift apart even when they share the same ``\\pos``.
    A composite path gives both parts one bounding box and one centre.
    """
    tail_width = max(3, round(width * (0.48 if inner else 1.0)))
    tail = _meteor_tail_path(length, tail_width, core=False)
    outer = width * (1.56 if inner else 2.45)
    inner_radius = width * (0.68 if inner else 1.02)
    star = _star_polygon_path(outer, inner_radius, cx=0, cy=0)
    return tail + ' ' + star

def _physical_particle_styles(kind: str, index: int, effect: Effect) -> tuple[_PhysicalParticleStyle, ...]:
    variant = index % 4
    theme = LOCALIZED_CHOREOGRAPHY[effect]
    if kind == 'cloud_bank' and effect is Effect.MOONLIGHT_CLOUDS:
        return tuple((replace(style, colour_override=None) for style in _v6_physical_particle_styles(kind, index, effect)))
    if kind == 'ice_diamond_large':
        size = (27, 33, 39, 30)[variant]
        path = _diamond_ice_path(size, variant)
        return (_PhysicalParticleStyle(path, True, 1.4, 4.2, 174, 118, theme.glow, -1), _PhysicalParticleStyle(path, False, 0.75, 0.55, 36, 100, '&HFFFFFF&', 0))
    if kind == 'meteor_comic':
        length = (46, 60, 74, 54)[variant]
        width = (5, 6, 8, 6)[variant]
        outer = _meteor_composite_path(length, width, inner=False)
        inner = _meteor_composite_path(length, width, inner=True)
        return (_PhysicalParticleStyle(outer, True, 0.0, 8.5, 212, 122, theme.glow, -2), _PhysicalParticleStyle(inner, True, 0.0, 1.0, 58, 100, '&HFFFFFF&', 0))
    if kind == 'snow' and effect is Effect.SNOWFALL_DEPTH:
        # A same-colour, low-layer shadow softens the otherwise very legible
        # dendritic outline without changing the snowflake silhouette.
        radius = (7, 10, 13, 9)[variant]
        path = _dendritic_snowflake_path(radius, variant)
        return (
            _PhysicalParticleStyle(path, False, 3.0, 5.0, 158, 112, '&HFFFFFF&', -1),
            _PhysicalParticleStyle(path, False, (1.15, 1.35, 1.55, 1.2)[variant], 1.3, 64, 100, '&HFFFFFF&', 0),
        )
    return _v6_physical_particle_styles(kind, index, effect)
_MOONLIGHT_BRIGHTNESS = ('&HFFFFFF&', '&HFFF3E8&', '&HFFE5D2&', '&HFFD6BC&', '&HFFC7A6&', '&HFFB992&')

def _particle_colour(effect: Effect, index: int) -> str:
    if effect is Effect.MOONLIGHT_CLOUDS:
        seed = int(DEFAULT_PARAMS[effect].get('seed', 3907))
        slot = min(len(_MOONLIGHT_BRIGHTNESS) - 1, int(_seed_value(seed, index, 7101) * len(_MOONLIGHT_BRIGHTNESS)))
        return _MOONLIGHT_BRIGHTNESS[slot]
    return _v6_particle_colour(effect, index)

def _motion_points(model: str, *, phase: str, index: int, count: int, effect: Effect, params: Mapping[str, Any], context: EffectContext, seed: int) -> list[tuple[float, float, float, float, float]]:
    points = _v6_motion_points(model, phase=phase, index=index, count=count, effect=effect, params=params, context=context, seed=seed)
    if effect in {Effect.ICE_CRACK, Effect.MOONLIGHT_CLOUDS}:
        return [(t, x, y, scale, 0.0) for t, x, y, scale, _ in points]
    return points

def _moonlight_text_pulses(event: DialogueEvent, start: int, end: int, effect: Effect) -> list[DialogueEvent]:
    hold_begin = start
    hold_finish = event.duration_ms - end
    hold_duration = hold_finish - hold_begin
    if hold_duration < 260:
        return []
    spec = LOCALIZED_CHOREOGRAPHY[effect]
    result: list[DialogueEvent] = []
    pulse_duration = min(280, max(170, round(hold_duration * 0.13)))
    for pulse_index, fraction in enumerate((0.31, 0.69), start=1):
        centre = hold_begin + round(hold_duration * fraction)
        begin = max(hold_begin, centre - pulse_duration // 2)
        finish = min(hold_finish, begin + pulse_duration)
        if finish - begin < 80:
            continue
        result.append(_clone(event, start_ms=event.start_ms + begin, end_ms=event.start_ms + finish, layer=event.layer + 15, effect_field=f'NAT40:{effect.value}:text:hold:moon_pulse:{pulse_index}', text=_add_tags(event.text, _text_style_tags(spec, glow=True) + f'\\1a&H68&\\3a&H18&\\bord6.2\\blur5.4\\fad({min(70, (finish - begin) // 3)},{min(110, (finish - begin) // 2)})')))
    return result

def _localized_lyric_events(event: DialogueEvent, start: int, end: int, effect: Effect, params: Mapping[str, Any], context: EffectContext) -> list[DialogueEvent]:
    result = _v6_localized_lyric_events(event, start, end, effect, params, context)
    if effect is Effect.MOONLIGHT_CLOUDS:
        result.extend(_moonlight_text_pulses(event, start, end, effect))
    return result

def _segment_sprite_rotation(kind: str, dx: float, dy: float, fallback: float) -> float:
    """Map each sprite's local forward axis onto the actual segment vector."""
    if abs(dx) + abs(dy) < 1e-06:
        return fallback
    if kind in {'aligned_rain_streak', 'wind_heavy_rain'}:
        return math.degrees(math.atan2(dx, dy))
    if kind == 'meteor_comic':
        # libass rotates a drawing's local +X axis toward screen-up for
        # positive \frz.  Screen-space motion uses +Y downward, so the angle
        # must be negated.  (+Y-headed rain uses the formula above unchanged.)
        return -math.degrees(math.atan2(dy, dx))
    return fallback

def _meteor_segment_alpha(context: EffectContext, x: float, y: float, *, glow: bool) -> int:
    """Brightness envelope: peak over the lyric, then dissolve below it."""
    box = context.box
    outside_x = max(box.x1 - x, 0.0, x - box.x2)
    centre_y = (box.y1 + box.y2) / 2.0
    vertical_distance = abs(y - centre_y)
    distance = math.hypot(outside_x * 0.55, vertical_distance)
    proximity = max(0.0, 1.0 - distance / max(72.0, box.height * 1.05))
    # Once the head has passed below the line, star and tail extinguish
    # together rather than remaining equally bright to the edge of the clip.
    passed = max(0.0, min(1.0, (y - box.y2) / max(72.0, box.height * 0.95)))
    if glow:
        alpha = 222.0 - 168.0 * proximity + 26.0 * passed
    else:
        alpha = 72.0 - 44.0 * proximity + 174.0 * passed
    return max(0, min(248, round(alpha)))

def _emit_piecewise_particle(event: DialogueEvent, begin: int, finish: int, *, points: Sequence[tuple[float, float, float, float, float]], effect: Effect, phase: str, particle_index: int, kind: str, colour: str, context: EffectContext) -> list[DialogueEvent]:
    if finish <= begin or len(points) < 2:
        return []
    styles = _physical_particle_styles(kind, particle_index, effect)
    scene = _particle_scene_box(context, SWEEP_TRANSITIONS[effect].particle_model)
    duration = finish - begin
    result: list[DialogueEvent] = []
    marker = f'NAT40:{effect.value}:particle:{phase}:{particle_index}'
    edge_name, gradient_slices = _edge_gradient_slices(scene, points[0], points[1])
    for segment_index, (first, second) in enumerate(zip(points, points[1:])):
        t0, x0, y0, scale0, rotation0 = first
        t1, x1, y1, scale1, rotation1 = second
        seg_begin = begin + round(duration * t0)
        seg_finish = begin + round(duration * t1)
        if seg_finish <= seg_begin:
            continue
        aligned_rotation = _segment_sprite_rotation(kind, x1 - x0, y1 - y0, rotation0)
        if kind in {'aligned_rain_streak', 'wind_heavy_rain', 'meteor_comic'}:
            rotation0 = rotation1 = aligned_rotation
        for layer_index, style in enumerate(styles):
            masks = gradient_slices if segment_index == 0 and edge_name is not None and (layer_index == 0) else [(scene, 0)]
            for mask_index, (mask_clip, alpha_offset) in enumerate(masks):
                layer_colour = style.colour_override or colour
                alpha = style.alpha
                extra_tags = ''
                if kind == 'meteor_comic':
                    alpha = _meteor_segment_alpha(context, x0, y0, glow=(layer_index == 0))
                    alpha1 = _meteor_segment_alpha(context, x1, y1, glow=(layer_index == 0))
                    extra_tags = f'\\t(0,{seg_finish - seg_begin},\\1a{_format_alpha(alpha1)}\\3a{_format_alpha(alpha1)})'
                if kind in {'firefly', 'glow_foam', 'radial_glow', 'spark', 'crystal'}:
                    alpha = max(0, alpha - (14 if (segment_index + particle_index) % 2 == 0 else 0))
                if effect is Effect.MOONLIGHT_CLOUDS:
                    seed = int(DEFAULT_PARAMS[effect].get('seed', 3907))
                    brightness_alpha = round((_seed_value(seed, particle_index, 7102) - 0.5) * 70)
                    alpha = max(18, min(242, alpha + brightness_alpha))
                alpha = min(252, alpha + alpha_offset)
                fade_in = 0
                if segment_index == 0:
                    fade_in = min(82 if layer_index else 42, max(8, (seg_finish - seg_begin) // 3))
                item = _moving_shape(event, seg_begin, seg_finish, style.path, x0=x0, y0=y0, x1=x1, y1=y1, color=layer_colour, alpha=alpha, scale0=scale0 * style.scale / 100.0, scale1=scale1 * style.scale / 100.0, rotation0=rotation0, rotation1=rotation1, blur=style.blur, border=style.border, outline=layer_colour, fill=style.fill, fade_in=fade_in, fade_out=min(72, max(0, (seg_finish - seg_begin) // 3)) if segment_index == len(points) - 2 else 0, clip=mask_clip, layer_offset=7 + style.layer_delta, extra_tags=extra_tags)
                result.append(_clone(item, effect_field=marker + f':layer:{layer_index}:segment:{segment_index}:' + f"edgegrad:{edge_name or 'none'}:{mask_index}"))
    return result
FLASH_EFFECTS = frozenset((effect for effect, spec in SWEEP_TRANSITIONS.items() if spec.reveal_mode == 'flash'))
if len(Effect) != 36:
    raise RuntimeError(f'expected 36 effects, found {len(Effect)}')
if set(EFFECT_SPECS) != set(Effect):
    raise RuntimeError('EFFECT_SPECS must cover every Effect')
if set(DEFAULT_PARAMS) != set(Effect):
    raise RuntimeError('DEFAULT_PARAMS must cover every Effect')
if set(_HANDLERS) != set(Effect):
    raise RuntimeError('_HANDLERS must cover every Effect')
