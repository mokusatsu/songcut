"""Immutable cross-family effect registry.

This module deliberately has no dependency on :mod:`ass_lyric_effects.core`.
It is a data boundary for the three effect families that are being merged:
the archived 23-effect catalogue, the current 38-effect implementation, and
the Natural Effects 36 v7 catalogue.  Keeping this boundary independent means
that display order and provenance can evolve without changing the numeric
order of the existing ``Effect`` enum.

The legacy definitions contain the complete metadata needed to construct an
``EffectSpec`` later.  All mappings are frozen at construction time, so a
caller can safely hand a definition to an adapter without accidentally
mutating registry state.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any


LEGACY_FAMILY = "old23"
CURRENT_FAMILY = "lyric40"
NATURAL_FAMILY = "natural36"

LEGACY_SOURCE = "ASS_Effects23_Catalog_Bilingual"
CURRENT_SOURCE = "ass-lyric-effects"
NATURAL_SOURCE = "ASS_Natural_Effects36:v7"


LEGACY23_IDS: tuple[str, ...] = (
    "cut",
    "fad",
    "fade",
    "alpha",
    "zoom",
    "pop",
    "bounce",
    "slide",
    "wipe",
    "blur",
    "rotate",
    "flip",
    "spacing",
    "stretch",
    "outline",
    "glow",
    "flicker",
    "typewriter",
    "karaoke",
    "scanline",
    "distort",
    "glitch",
    "dissolve",
)

CURRENT38_IDS: tuple[str, ...] = (
    "baseline_wave",
    "sidewind",
    "pendulum_row",
    "domino_settle",
    "letter_rain",
    "bubble_rise",
    "center_ripple",
    "edge_knock",
    "orbit_assemble",
    "weave_cross",
    "staircase_flatten",
    "fan_spread",
    "twin_lane_merge",
    "magnet_repel",
    "character_pulse_train",
    "scramble_resolve",
    "chorus_echo",
    "echo_tunnel",
    "mirror_reflection",
    "water_reflection",
    "shadow_march",
    "chromatic_orbit",
    "parallax_chorus",
    "long_exposure",
    "call_response_duet",
    "afterimage_wave",
    "color_wave",
    "aurora_bands",
    "emboss_light",
    "glass_refraction",
    "metallic_shimmer",
    "color_pingpong",
    "spotlight_lens",
    "bracket_embrace",
    "halo_rings",
    "equalizer_bed",
    "constellation_sparks",
    "pulse_frame",
)

NATURAL36_IDS: tuple[str, ...] = (
    "rain_veil",
    "drizzle_mist",
    "cloudburst",
    "crepuscular_rays",
    "snowfall_depth",
    "blizzard_whiteout",
    "diamond_dust",
    "hailstorm",
    "frost_bloom",
    "ice_crack",
    "avalanche",
    "morning_mist",
    "sea_of_clouds",
    "gentle_breeze",
    "gust_front",
    "whirlwind",
    "tornado",
    "sandstorm",
    "heat_haze",
    "ocean_swell",
    "breaking_wave",
    "rising_tide",
    "waterfall",
    "river_current",
    "whirlpool",
    "lava_flow",
    "ember_drift",
    "rainbow_arch",
    "cherry_blossom_storm",
    "falling_leaves",
    "firefly_night",
    "bioluminescent_tide",
    "meteor_shower",
    "solar_eclipse",
    "moonlight_clouds",
    "sunrise_horizon",
)

CATALOG_EFFECT_IDS: tuple[str, ...] = LEGACY23_IDS + CURRENT38_IDS + NATURAL36_IDS


def _freeze(value: Any) -> Any:
    """Recursively freeze simple parameter data used by registry rows."""

    if isinstance(value, Mapping):
        return MappingProxyType({str(key): _freeze(item) for key, item in value.items()})
    if isinstance(value, list):
        return tuple(_freeze(item) for item in value)
    if isinstance(value, tuple):
        return tuple(_freeze(item) for item in value)
    if isinstance(value, set):
        return frozenset(_freeze(item) for item in value)
    return value


def _mapping(values: Mapping[str, Any] | None = None, **kwargs: Any) -> Mapping[str, Any]:
    source: dict[str, Any] = {} if values is None else dict(values)
    source.update(kwargs)
    return _freeze(source)


def _categories(values: Mapping[str, Iterable[str]] | None = None, **kwargs: Iterable[str]) -> Mapping[str, tuple[str, ...]]:
    source: dict[str, Iterable[str]] = {} if values is None else dict(values)
    source.update(kwargs)
    return _freeze({key: tuple(items) for key, items in source.items()})


INTEGRATED_MAJOR_CATEGORIES: tuple[str, ...] = (
    "表示・遷移",
    "文字モーション",
    "変形・タイポグラフィ",
    "多層・空間表現",
    "色・光・材質",
    "マスク・歪み・分解",
    "図形・フレーム装飾",
    "環境・粒子シーン",
)
INTEGRATED_MAJOR_CATEGORY_NAMES_EN: Mapping[str, str] = MappingProxyType(
    {
        "表示・遷移": "Reveal & transition",
        "文字モーション": "Character motion",
        "変形・タイポグラフィ": "Transform & typography",
        "多層・空間表現": "Layering & spatial",
        "色・光・材質": "Colour, light & material",
        "マスク・歪み・分解": "Mask, distortion & fragmentation",
        "図形・フレーム装飾": "Support graphics & frames",
        "環境・粒子シーン": "Environment & particle scene",
    }
)
INTEGRATED_MAJOR_CATEGORIES_EN: tuple[str, ...] = tuple(
    INTEGRATED_MAJOR_CATEGORY_NAMES_EN[name]
    for name in INTEGRATED_MAJOR_CATEGORIES
)
INTEGRATED_SUBCATEGORY_NAMES_EN: Mapping[str, str] = MappingProxyType(
    {
        "カット切替": "Cut switch",
        "フェード・透明度": "Fade & opacity",
        "逐次表示": "Sequential reveal",
        "移動入退場": "Moving entrance & exit",
        "スケール・弾性": "Scale & elasticity",
        "回転・3D変形": "Rotation & 3D transform",
        "文字組み・伸縮": "Typography & stretch",
        "歪み変形": "Warp transform",
        "クリップ・走査": "Clip & scan",
        "グリッチ・断片化": "Glitch & fragmentation",
        "分解・粒子化": "Dissolve & particle breakup",
        "ぼかし・焦点": "Blur & focus",
        "輪郭・発光": "Outline & glow",
        "点滅・閃光": "Flicker & flash",
        "波形・波紋運動": "Wave & ripple motion",
        "方向・落下上昇": "Directional, falling & rising",
        "周期・振り子運動": "Cyclic & pendulum motion",
        "整列・合流": "Alignment & convergence",
        "軌道・集合": "Orbit & assembly",
        "交差・展開・相互作用": "Crossing, spreading & interaction",
        "パルス・位相": "Pulse & phase",
        "文字置換・復元": "Character substitution & restore",
        "複製・コーラス": "Duplication & chorus",
        "残響・残像・奥行き": "Echo, afterimage & depth",
        "反射・鏡像": "Reflection & mirror image",
        "影・投影": "Shadow & projection",
        "色収差レイヤー": "Chromatic aberration layers",
        "色伝播": "Colour propagation",
        "帯状発光": "Luminous bands",
        "陰影・浮彫り": "Shading & emboss",
        "屈折・レンズ": "Refraction & lens",
        "金属・反射光": "Metallic & reflected light",
        "囲み・括弧": "Enclosure & brackets",
        "リング・光輪": "Rings & halo",
        "音響UI": "Audio UI",
        "星座・粒子": "Constellation & particles",
        "フレーム・境界": "Frame & border",
        "降雨・豪雨": "Rain & downpour",
        "降雨・霧": "Drizzle & mist",
        "大気光・光線": "Atmospheric light & rays",
        "降雪・雪流": "Snowfall & snow flow",
        "氷結・結晶": "Frost & crystals",
        "雹・衝突": "Hail & impact",
        "霧・雲": "Mist & clouds",
        "風・流線": "Wind & streamlines",
        "渦・旋回": "Vortex & rotation",
        "砂塵": "Sand & dust",
        "熱・陽炎": "Heat & haze",
        "水流・波・潮": "Currents, waves & tides",
        "火・熱・地表": "Fire, heat & ground",
        "虹・大気光": "Rainbow & atmospheric light",
        "季節・植物粒子": "Seasonal & botanical particles",
        "夜光・生物": "Nocturnal glow & life",
        "夜光・水面": "Nocturnal glow & water surface",
        "天体・天空光": "Celestial & sky light",
    }
)


@dataclass(frozen=True, slots=True)
class EffectClassification:
    """Final cross-family classification adopted for the public API."""

    major_category_en: str
    major_category_ja: str
    subcategory_en: str
    subcategory_ja: str

    def __post_init__(self) -> None:
        if self.major_category_ja not in INTEGRATED_MAJOR_CATEGORIES:
            raise ValueError(f"unknown integrated major category: {self.major_category_ja!r}")
        if not self.subcategory_ja:
            raise ValueError("integrated subcategory cannot be empty")
        if self.major_category_en != INTEGRATED_MAJOR_CATEGORY_NAMES_EN[self.major_category_ja]:
            raise ValueError("major category English name does not match its Japanese name")
        if self.subcategory_en != INTEGRATED_SUBCATEGORY_NAMES_EN.get(self.subcategory_ja):
            raise ValueError("subcategory English name does not match its Japanese name")


def _build_integrated_classifications() -> dict[str, EffectClassification]:
    result: dict[str, EffectClassification] = {}

    def assign(effect_ids: Iterable[str], major_category: str, subcategory: str) -> None:
        for effect_id in effect_ids:
            if effect_id in result:
                raise RuntimeError(f"duplicate integrated classification for {effect_id!r}")
            result[effect_id] = EffectClassification(
                major_category_en=INTEGRATED_MAJOR_CATEGORY_NAMES_EN[major_category],
                major_category_ja=major_category,
                subcategory_en=INTEGRATED_SUBCATEGORY_NAMES_EN[subcategory],
                subcategory_ja=subcategory,
            )

    assign(("cut",), "表示・遷移", "カット切替")
    assign(("fad", "fade", "alpha"), "表示・遷移", "フェード・透明度")
    assign(("typewriter",), "表示・遷移", "逐次表示")
    assign(("slide",), "表示・遷移", "移動入退場")
    assign(("zoom", "pop", "bounce"), "変形・タイポグラフィ", "スケール・弾性")
    assign(("rotate", "flip"), "変形・タイポグラフィ", "回転・3D変形")
    assign(("spacing", "stretch"), "変形・タイポグラフィ", "文字組み・伸縮")
    assign(("distort",), "変形・タイポグラフィ", "歪み変形")
    assign(("wipe", "karaoke", "scanline"), "マスク・歪み・分解", "クリップ・走査")
    assign(("glitch",), "マスク・歪み・分解", "グリッチ・断片化")
    assign(("dissolve",), "マスク・歪み・分解", "分解・粒子化")
    assign(("blur",), "色・光・材質", "ぼかし・焦点")
    assign(("outline", "glow"), "色・光・材質", "輪郭・発光")
    assign(("flicker",), "色・光・材質", "点滅・閃光")

    assign(("baseline_wave", "center_ripple"), "文字モーション", "波形・波紋運動")
    assign(("sidewind", "letter_rain", "bubble_rise", "edge_knock"), "文字モーション", "方向・落下上昇")
    assign(("pendulum_row",), "文字モーション", "周期・振り子運動")
    assign(("domino_settle", "staircase_flatten", "twin_lane_merge"), "文字モーション", "整列・合流")
    assign(("orbit_assemble",), "文字モーション", "軌道・集合")
    assign(("weave_cross", "fan_spread", "magnet_repel"), "文字モーション", "交差・展開・相互作用")
    assign(("character_pulse_train",), "文字モーション", "パルス・位相")
    assign(("scramble_resolve",), "表示・遷移", "文字置換・復元")

    assign(("chorus_echo", "parallax_chorus", "call_response_duet"), "多層・空間表現", "複製・コーラス")
    assign(("echo_tunnel", "long_exposure", "afterimage_wave"), "多層・空間表現", "残響・残像・奥行き")
    assign(("mirror_reflection", "water_reflection"), "多層・空間表現", "反射・鏡像")
    assign(("shadow_march",), "多層・空間表現", "影・投影")
    assign(("chromatic_orbit",), "多層・空間表現", "色収差レイヤー")

    assign(("color_wave", "color_pingpong"), "色・光・材質", "色伝播")
    assign(("aurora_bands",), "色・光・材質", "帯状発光")
    assign(("emboss_light",), "色・光・材質", "陰影・浮彫り")
    assign(("glass_refraction", "spotlight_lens"), "色・光・材質", "屈折・レンズ")
    assign(("metallic_shimmer",), "色・光・材質", "金属・反射光")

    assign(("bracket_embrace",), "図形・フレーム装飾", "囲み・括弧")
    assign(("halo_rings",), "図形・フレーム装飾", "リング・光輪")
    assign(("equalizer_bed",), "図形・フレーム装飾", "音響UI")
    assign(("constellation_sparks",), "図形・フレーム装飾", "星座・粒子")
    assign(("pulse_frame",), "図形・フレーム装飾", "フレーム・境界")

    assign(("rain_veil", "cloudburst"), "環境・粒子シーン", "降雨・豪雨")
    assign(("drizzle_mist",), "環境・粒子シーン", "降雨・霧")
    assign(("crepuscular_rays",), "環境・粒子シーン", "大気光・光線")
    assign(("snowfall_depth", "blizzard_whiteout", "avalanche"), "環境・粒子シーン", "降雪・雪流")
    assign(("diamond_dust", "frost_bloom", "ice_crack"), "環境・粒子シーン", "氷結・結晶")
    assign(("hailstorm",), "環境・粒子シーン", "雹・衝突")
    assign(("morning_mist", "sea_of_clouds"), "環境・粒子シーン", "霧・雲")
    assign(("gentle_breeze", "gust_front"), "環境・粒子シーン", "風・流線")
    assign(("whirlwind", "tornado", "whirlpool"), "環境・粒子シーン", "渦・旋回")
    assign(("sandstorm",), "環境・粒子シーン", "砂塵")
    assign(("heat_haze",), "環境・粒子シーン", "熱・陽炎")
    assign(("ocean_swell", "breaking_wave", "rising_tide", "waterfall", "river_current"), "環境・粒子シーン", "水流・波・潮")
    assign(("lava_flow", "ember_drift"), "環境・粒子シーン", "火・熱・地表")
    assign(("rainbow_arch",), "環境・粒子シーン", "虹・大気光")
    assign(("cherry_blossom_storm", "falling_leaves"), "環境・粒子シーン", "季節・植物粒子")
    assign(("firefly_night",), "環境・粒子シーン", "夜光・生物")
    assign(("bioluminescent_tide",), "環境・粒子シーン", "夜光・水面")
    assign(("meteor_shower", "solar_eclipse", "moonlight_clouds", "sunrise_horizon"), "環境・粒子シーン", "天体・天空光")

    missing = set(CATALOG_EFFECT_IDS).difference(result)
    extra = set(result).difference(CATALOG_EFFECT_IDS)
    if missing or extra or len(result) != len(CATALOG_EFFECT_IDS):
        raise RuntimeError(
            "integrated classification must cover exactly the 97 catalogue IDs; "
            f"missing={sorted(missing)!r}, extra={sorted(extra)!r}"
        )
    used_subcategories = {classification.subcategory_ja for classification in result.values()}
    if used_subcategories != set(INTEGRATED_SUBCATEGORY_NAMES_EN):
        raise RuntimeError("English subcategory names must match the adopted classification exactly")
    return result


EFFECT_CLASSIFICATIONS_BY_ID: Mapping[str, EffectClassification] = MappingProxyType(
    _build_integrated_classifications()
)


@dataclass(frozen=True, slots=True)
class EffectDefinition:
    """One immutable effect row, independent of renderer classification."""

    id: str
    family: str
    source: str
    family_index: int
    display_index: int
    name_en: str
    name_ja: str
    default_params: Mapping[str, Any]
    categorical_params: Mapping[str, tuple[str, ...]]
    context_required: bool
    traits: frozenset[str]
    major_category_en: str
    major_category_ja: str
    subcategory_en: str
    subcategory_ja: str
    classification: str | None = None

    def __post_init__(self) -> None:
        if not self.id:
            raise ValueError("effect id cannot be empty")
        if self.family_index < 1 or self.display_index < 1:
            raise ValueError("effect indexes are one-based positive integers")
        object.__setattr__(self, "default_params", _freeze(self.default_params))
        object.__setattr__(self, "categorical_params", _freeze(self.categorical_params))
        object.__setattr__(self, "traits", frozenset(self.traits))

    @property
    def effect_id(self) -> str:
        """Descriptive alias for callers that prefer ``effect_id`` to ``id``."""

        return self.id

    @property
    def family_local_index(self) -> int:
        return self.family_index

    @property
    def category(self) -> str | None:
        """Classification label; deliberately separate from ``family``."""

        return self.classification

    def as_effect_spec_kwargs(self) -> Mapping[str, Any]:
        """Return immutable kwargs suitable for constructing ``EffectSpec``.

        This adapter is intentionally available for legacy rows only.  The
        current family already owns authoritative specs in ``core.py`` and the
        Natural family is represented as catalogue metadata until its engine
        is integrated.
        """

        if self.family != LEGACY_FAMILY:
            raise ValueError("EffectSpec adaptation is currently defined for legacy23 rows only")
        return _mapping(
            {
                "name_en": self.name_en,
                "name_ja": self.name_ja,
                "default_params": self.default_params,
                "categorical_params": self.categorical_params,
                "context_required": self.context_required,
            }
        )


def _legacy_traits(effect_id: str) -> frozenset[str]:
    traits = {"transition", "whole_line"}
    traits_by_id = {
        "zoom": {"transform"},
        "pop": {"transform"},
        "bounce": {"transform"},
        "rotate": {"transform"},
        "flip": {"transform"},
        "spacing": {"transform"},
        "stretch": {"transform"},
        "distort": {"transform"},
        "outline": {"overlay"},
        "glow": {"overlay", "light_overlay"},
        "typewriter": {"reveal"},
        "karaoke": {"reveal", "geometry"},
        "slide": {"geometry"},
        "wipe": {"reveal", "geometry"},
        "scanline": {"reveal", "geometry"},
        "flicker": {"flicker"},
        "glitch": {"glitch", "geometry"},
        "dissolve": {"particle", "geometry"},
    }
    traits.update(traits_by_id.get(effect_id, ()))
    return frozenset(traits)


_LEGACY_NAMES_EN: dict[str, str] = {
    "cut": "Cut In / Cut Out",
    "fad": "Standard Fade In / Out",
    "fade": "Multi-stage Fade",
    "alpha": "Alpha Animation",
    "zoom": "Zoom In / Out",
    "pop": "Pop In / Out",
    "bounce": "Bounce",
    "slide": "Slide In / Out",
    "wipe": "Wipe / Mask Out",
    "blur": "Blur In / Out",
    "rotate": "Rotate In / Out",
    "flip": "3D Flip In / Out",
    "spacing": "Spacing Converge / Diverge",
    "stretch": "Horizontal / Vertical Stretch",
    "outline": "Fill from Outline",
    "glow": "Glow In / Glow Out",
    "flicker": "Flicker",
    "typewriter": "Typewriter",
    "karaoke": "Karaoke Sweep",
    "scanline": "Scanline",
    "distort": "Distort In / Out",
    "glitch": "Glitch",
    "dissolve": "Dissolve / Particle Out",
}

_LEGACY_NAMES_JA: dict[str, str] = {
    "cut": "カットイン／カットアウト",
    "fad": "通常フェードイン／フェードアウト",
    "fade": "多段階フェード",
    "alpha": "透明度アニメーション",
    "zoom": "ズームイン／ズームアウト",
    "pop": "ポップイン／ポップアウト",
    "bounce": "バウンス表示",
    "slide": "スライドイン／スライドアウト",
    "wipe": "ワイプ表示／マスク消去",
    "blur": "ブラーイン／ブラーアウト",
    "rotate": "回転イン／回転アウト",
    "flip": "3Dフリップイン／フリップアウト",
    "spacing": "文字間隔を広げて出現／収束して消失",
    "stretch": "縦伸び／横伸び表示",
    "outline": "輪郭から塗りが現れる",
    "glow": "グローイン／発光しながら消失",
    "flicker": "点滅／フリッカー",
    "typewriter": "タイプライター表示",
    "karaoke": "カラオケ・スイープ表示",
    "scanline": "スキャンライン表示",
    "distort": "歪みながら出現",
    "glitch": "グリッチ表示",
    "dissolve": "ディゾルブ／粒子消失",
}

_LEGACY_DEFAULTS: dict[str, Mapping[str, Any]] = {
    "cut": _mapping(),
    "fad": _mapping(),
    "fade": _mapping(),
    "alpha": _mapping(),
    "zoom": _mapping({"min_scale": 0}),
    "pop": _mapping({"overshoot": 122}),
    "bounce": _mapping({"peak": 128, "valley": 88, "rebound": 108}),
    "slide": _mapping(),
    "wipe": _mapping(),
    "blur": _mapping({"radius": 14}),
    "rotate": _mapping({"degrees": 120}),
    "flip": _mapping({"degrees": 90}),
    "spacing": _mapping({"spacing": 42}),
    "stretch": _mapping({"min_scale": 0}),
    "outline": _mapping({"border": 4}),
    "glow": _mapping({"radius": 16, "border": 16, "color": "&HFFD742&"}),
    "flicker": _mapping({"interval_ms": 90, "seed": 1701}),
    "typewriter": _mapping(),
    "karaoke": _mapping(),
    "scanline": _mapping({"steps": 24, "softness_ms": 70}),
    "distort": _mapping({"amount": 1.25}),
    "glitch": _mapping({"slices": 28, "intensity": 28, "seed": 2207}),
    "dissolve": _mapping({"columns": 12, "rows": 5, "seed": 2311, "blur": 4}),
}

_CARDINAL = ("left_to_right", "right_to_left", "top_to_bottom", "bottom_to_top")
_HORIZONTAL = ("horizontal", "vertical")
_DIRECTIONAL = {
    "slide": _CARDINAL,
    "wipe": _CARDINAL,
    "rotate": ("clockwise", "counterclockwise"),
    "flip": _HORIZONTAL,
    "stretch": _HORIZONTAL,
    "typewriter": ("left_to_right", "right_to_left"),
    "karaoke": ("left_to_right", "right_to_left"),
    "scanline": _CARDINAL,
    "distort": ("left_to_right", "right_to_left"),
}

_LEGACY_CONTEXT_REQUIRED = frozenset({"slide", "wipe", "karaoke", "scanline", "glitch", "dissolve"})


_CURRENT_NAMES: dict[str, tuple[str, str, str]] = {
    "baseline_wave": ("Baseline Wave", "文字波形", "Character choreography"),
    "sidewind": ("Sidewind", "横風文字列", "Character choreography"),
    "pendulum_row": ("Pendulum Row", "振り子文字列", "Character choreography"),
    "domino_settle": ("Domino Settle", "ドミノ整列", "Character choreography"),
    "letter_rain": ("Letter Rain", "文字の雨", "Character choreography"),
    "bubble_rise": ("Bubble Rise", "泡文字", "Character choreography"),
    "center_ripple": ("Center Ripple", "中央波紋", "Character choreography"),
    "edge_knock": ("Edge Knock", "端からノック", "Character choreography"),
    "orbit_assemble": ("Orbit Assemble", "軌道集合", "Character choreography"),
    "weave_cross": ("Weave Cross", "編み込み交差", "Character choreography"),
    "staircase_flatten": ("Staircase Flatten", "階段整列", "Character choreography"),
    "fan_spread": ("Fan Spread", "扇状展開", "Character choreography"),
    "twin_lane_merge": ("Twin-Lane Merge", "二車線合流", "Character choreography"),
    "magnet_repel": ("Magnet Repel", "磁石反発", "Character choreography"),
    "character_pulse_train": ("Character Pulse Train", "文字パルス列", "Character choreography"),
    "scramble_resolve": ("Scramble Resolve", "文字化け復元", "Character choreography"),
    "chorus_echo": ("Chorus Echo", "コーラス残響", "Echo and layering"),
    "echo_tunnel": ("Echo Tunnel", "残響トンネル", "Echo and layering"),
    "mirror_reflection": ("Mirror Reflection", "鏡面反射", "Echo and layering"),
    "water_reflection": ("Water Reflection", "水面反射", "Echo and layering"),
    "shadow_march": ("Shadow March", "影の行進", "Echo and layering"),
    "chromatic_orbit": ("Chromatic Orbit", "色収差軌道", "Echo and layering"),
    "parallax_chorus": ("Parallax Chorus", "視差コーラス", "Echo and layering"),
    "long_exposure": ("Long Exposure", "長時間露光", "Echo and layering"),
    "call_response_duet": ("Call-and-Response Duet", "掛け合いデュエット", "Echo and layering"),
    "afterimage_wave": ("Afterimage Wave", "残像波", "Echo and layering"),
    "color_wave": ("Colour Wave", "色彩波", "Colour and material"),
    "aurora_bands": ("Aurora Bands", "オーロラ帯", "Colour and material"),
    "emboss_light": ("Emboss Light", "浮彫り照明", "Colour and material"),
    "glass_refraction": ("Glass Refraction", "ガラス屈折", "Colour and material"),
    "metallic_shimmer": ("Metallic Shimmer", "金属光沢", "Colour and material"),
    "color_pingpong": ("Colour Ping-Pong", "交互色往復", "Colour and material"),
    "spotlight_lens": ("Spotlight Lens", "スポットライトレンズ", "Colour and material"),
    "bracket_embrace": ("Bracket Embrace", "括弧抱擁", "Lyric support graphics"),
    "halo_rings": ("Halo Rings", "光輪", "Lyric support graphics"),
    "equalizer_bed": ("Equalizer Bed", "自律イコライザー", "Lyric support graphics"),
    "constellation_sparks": ("Constellation Sparks", "星座スパーク", "Lyric support graphics"),
    "pulse_frame": ("Pulse Frame", "巡回フレーム", "Lyric support graphics"),
}

_CURRENT_DEFAULTS: dict[str, Mapping[str, Any]] = {
    "baseline_wave": _mapping({"direction": "left_to_right", "amplitude": 22, "cycles": 1.7, "phase_spread": 0.9}),
    "sidewind": _mapping({"direction": "left_to_right", "amplitude": 26, "cycles": 1.5, "phase_spread": 0.85}),
    "pendulum_row": _mapping({"direction": "left_to_right", "angle": 14, "cycles": 1.8, "lift": 7}),
    "domino_settle": _mapping({"direction": "left_to_right", "tilt": 72, "offset": 44, "stagger": 0.72}),
    "letter_rain": _mapping({"direction": "left_to_right", "height": 230, "drift": 34, "seed": 501, "stagger": 0.72}),
    "bubble_rise": _mapping({"direction": "left_to_right", "rise": 190, "sway": 20, "seed": 607, "stagger": 0.68}),
    "center_ripple": _mapping({"direction": "center_out", "scale": 24, "lift": 12, "cycles": 1.45}),
    "edge_knock": _mapping({"direction": "left_to_right", "distance": 24, "angle": 7, "cycles": 1.6}),
    "orbit_assemble": _mapping({"direction": "clockwise", "radius": 92, "turns": 0.8, "stagger": 0.38}),
    "weave_cross": _mapping({"direction": "left_to_right", "height": 76, "cross": 34, "stagger": 0.52}),
    "staircase_flatten": _mapping({"direction": "left_to_right", "step_height": 19, "tilt": 8, "stagger": 0.42}),
    "fan_spread": _mapping({"direction": "clockwise", "arc": 68, "radius": 118, "stagger": 0.32}),
    "twin_lane_merge": _mapping({"direction": "horizontal", "distance": 120, "stagger": 0.42}),
    "magnet_repel": _mapping({"direction": "center_out", "distance": 34, "cycles": 1.55, "lift": 8}),
    "character_pulse_train": _mapping({"direction": "left_to_right", "scale": 30, "lift": 16, "cycles": 1.35}),
    "scramble_resolve": _mapping({"direction": "left_to_right", "interval_ms": 90, "seed": 1601, "charset": "アイウエオカキクケコサシスセソ△◇○☆#?"}),
    "chorus_echo": _mapping({"direction": "bottom_to_top", "copies": 3, "distance": 28, "cycles": 1.25}),
    "echo_tunnel": _mapping({"direction": "inward", "layers": 5, "depth": 38, "cycles": 1.1}),
    "mirror_reflection": _mapping({"direction": "below", "bands": 8, "gap": 18, "shimmer": 10}),
    "water_reflection": _mapping({"direction": "left_to_right", "bands": 10, "amplitude": 18, "cycles": 1.45, "gap": 16}),
    "shadow_march": _mapping({"direction": "clockwise", "copies": 6, "radius": 14, "cycles": 1.0}),
    "chromatic_orbit": _mapping({"direction": "clockwise", "radius": 10, "cycles": 1.35}),
    "parallax_chorus": _mapping({"direction": "bottom_to_top", "layers": 3, "distance": 30, "cycles": 0.9}),
    "long_exposure": _mapping({"direction": "left_to_right", "trails": 6, "distance": 42, "cycles": 1.0}),
    "call_response_duet": _mapping({"direction": "horizontal", "distance": 58, "cycles": 1.3}),
    "afterimage_wave": _mapping({"direction": "left_to_right", "amplitude": 18, "cycles": 1.55, "trail": 0.12}),
    "color_wave": _mapping({"direction": "left_to_right", "cycles": 1.2, "palette": ("&H4FD8FF&", "&HFF8BCE&", "&HFFC36A&", "&H9AFFA6&")}),
    "aurora_bands": _mapping({"direction": "left_to_right", "bands": 7, "amplitude": 12, "cycles": 1.0, "palette": ("&H4FD8FF&", "&HFF8BCE&", "&HFFC36A&", "&H9AFFA6&")}),
    "emboss_light": _mapping({"direction": "clockwise", "distance": 4.5, "cycles": 1.1}),
    "glass_refraction": _mapping({"direction": "left_to_right", "slices": 7, "offset": 12, "cycles": 1.25}),
    "metallic_shimmer": _mapping({"direction": "left_to_right", "width": 105, "cycles": 1.15, "color": "&HFFFFFF&"}),
    "color_pingpong": _mapping({"phase": "odd_first", "cycles": 1.5, "color_a": "&H4FD8FF&", "color_b": "&HFF8BCE&"}),
    "spotlight_lens": _mapping({"direction": "left_to_right", "width": 230, "scale": 106, "cycles": 1.0}),
    "bracket_embrace": _mapping({"direction": "horizontal", "distance": 74, "breath": 9, "cycles": 1.15}),
    "halo_rings": _mapping({"direction": "center_out", "rings": 4, "cycles": 1.0, "max_scale": 138}),
    "equalizer_bed": _mapping({"direction": "left_to_right", "bars": 18, "height": 48, "cycles": 1.7, "seed": 3701}),
    "constellation_sparks": _mapping({"direction": "left_to_right", "count": 16, "radius": 56, "seed": 3803, "cycles": 1.25}),
    "pulse_frame": _mapping({"direction": "clockwise", "padding": 30, "thickness": 4, "cycles": 1.25}),
}

_CURRENT_CATEGORIES: dict[str, tuple[str, ...]] = {
    **{effect_id: ("direction",) for effect_id in CURRENT38_IDS[:16]},
    "chorus_echo": ("direction",),
    "echo_tunnel": ("direction",),
    "mirror_reflection": ("direction",),
    "water_reflection": ("direction",),
    "shadow_march": ("direction",),
    "chromatic_orbit": ("direction",),
    "parallax_chorus": ("direction",),
    "long_exposure": ("direction",),
    "call_response_duet": ("direction",),
    "afterimage_wave": ("direction",),
    "color_wave": ("direction",),
    "aurora_bands": ("direction",),
    "emboss_light": ("direction",),
    "glass_refraction": ("direction",),
    "metallic_shimmer": ("direction",),
    "color_pingpong": ("phase",),
    "spotlight_lens": ("direction",),
    "bracket_embrace": ("direction",),
    "halo_rings": ("direction",),
    "equalizer_bed": ("direction",),
    "constellation_sparks": ("direction",),
    "pulse_frame": ("direction",),
}

_CURRENT_CATEGORICAL_VALUES: dict[str, tuple[str, ...]] = {
    **{effect_id: ("left_to_right", "right_to_left") for effect_id in CURRENT38_IDS[:6]},
    "center_ripple": ("center_out", "edges_in"),
    "edge_knock": ("left_to_right", "right_to_left"),
    "orbit_assemble": ("clockwise", "counterclockwise"),
    "weave_cross": ("left_to_right", "right_to_left"),
    "staircase_flatten": ("left_to_right", "right_to_left"),
    "fan_spread": ("clockwise", "counterclockwise"),
    "twin_lane_merge": ("horizontal", "vertical"),
    "magnet_repel": ("center_out", "edges_in"),
    "character_pulse_train": ("left_to_right", "right_to_left"),
    "scramble_resolve": ("left_to_right", "right_to_left"),
    "chorus_echo": _CARDINAL,
    "echo_tunnel": ("inward", "outward"),
    "mirror_reflection": ("above", "below"),
    "water_reflection": ("left_to_right", "right_to_left"),
    "shadow_march": ("clockwise", "counterclockwise"),
    "chromatic_orbit": ("clockwise", "counterclockwise"),
    "parallax_chorus": _CARDINAL,
    "long_exposure": _CARDINAL,
    "call_response_duet": _HORIZONTAL,
    "afterimage_wave": ("left_to_right", "right_to_left"),
    "color_wave": ("left_to_right", "right_to_left"),
    "aurora_bands": _CARDINAL,
    "emboss_light": ("clockwise", "counterclockwise"),
    "glass_refraction": ("left_to_right", "right_to_left"),
    "metallic_shimmer": _CARDINAL,
    "color_pingpong": ("odd_first", "even_first"),
    "spotlight_lens": _CARDINAL,
    "bracket_embrace": _HORIZONTAL,
    "halo_rings": ("center_out", "edges_in"),
    "equalizer_bed": ("left_to_right", "right_to_left"),
    "constellation_sparks": ("left_to_right", "right_to_left"),
    "pulse_frame": ("clockwise", "counterclockwise"),
}


def _current_traits(effect_id: str, classification: str) -> frozenset[str]:
    traits = {"whole_line"}
    if classification == "Character choreography":
        traits.add("character_choreography")
    elif classification == "Echo and layering":
        traits.add("overlay")
    elif classification == "Colour and material":
        traits.update({"overlay", "material"})
    else:
        traits.update({"overlay", "support_graphics"})
    if effect_id in {"mirror_reflection", "water_reflection"}:
        traits.add("reflection")
    if effect_id in {"chorus_echo", "echo_tunnel", "shadow_march", "chromatic_orbit", "parallax_chorus", "long_exposure", "call_response_duet", "afterimage_wave"}:
        traits.add("overlay")
    return frozenset(traits)


_NATURAL_WEATHER = frozenset({
    "rain_veil", "drizzle_mist", "cloudburst", "snowfall_depth", "blizzard_whiteout", "hailstorm", "avalanche",
    "morning_mist", "sea_of_clouds", "gentle_breeze", "gust_front", "whirlwind", "tornado", "sandstorm",
    "ocean_swell", "breaking_wave", "rising_tide", "waterfall", "river_current", "whirlpool", "rainbow_arch",
    "bioluminescent_tide", "moonlight_clouds",
})
_NATURAL_LIGHT_OVERLAY = frozenset({
    "crepuscular_rays", "diamond_dust", "frost_bloom", "ice_crack", "heat_haze", "rainbow_arch", "firefly_night",
    "bioluminescent_tide", "meteor_shower", "solar_eclipse", "moonlight_clouds", "sunrise_horizon",
})
_NATURAL_RADIAL = frozenset({"frost_bloom", "whirlwind", "tornado", "whirlpool"})
_NATURAL_FLASH = frozenset({"diamond_dust", "ice_crack", "firefly_night"})
_NATURAL_FIRE_EARTH = frozenset({"lava_flow", "ember_drift"})
_NATURAL_SEASON = frozenset({"cherry_blossom_storm", "falling_leaves"})
_NATURAL_GROUPS = {
    "rain": frozenset({"rain_veil", "drizzle_mist", "cloudburst", "crepuscular_rays", "rainbow_arch"}),
    "snow_ice": frozenset({"snowfall_depth", "blizzard_whiteout", "diamond_dust", "hailstorm", "frost_bloom", "ice_crack", "avalanche"}),
    "wind_atmosphere": frozenset({"morning_mist", "sea_of_clouds", "gentle_breeze", "gust_front", "whirlwind", "tornado", "sandstorm", "heat_haze"}),
    "water": frozenset({"ocean_swell", "breaking_wave", "rising_tide", "waterfall", "river_current", "whirlpool", "bioluminescent_tide"}),
    "cosmos": frozenset({"meteor_shower", "solar_eclipse", "moonlight_clouds", "sunrise_horizon"}),
}


def _natural_traits(effect_id: str) -> frozenset[str]:
    traits = {"transition", "particle", "whole_line"}
    if effect_id in _NATURAL_WEATHER:
        traits.add("weather")
    if effect_id in _NATURAL_LIGHT_OVERLAY:
        traits.add("light_overlay")
    if effect_id in _NATURAL_RADIAL:
        traits.add("radial")
    if effect_id in _NATURAL_FLASH:
        traits.add("flash")
    if effect_id in _NATURAL_FIRE_EARTH:
        traits.add("fire_earth")
    if effect_id in _NATURAL_SEASON:
        traits.add("season")
    for trait, ids in _NATURAL_GROUPS.items():
        if effect_id in ids:
            traits.add(trait)
    return frozenset(traits)


def _natural_name(effect_id: str) -> tuple[str, str]:
    if effect_id == "rainbow_arch":
        return "Spring Breeze", "春風"
    title = effect_id.replace("_", " ").title()
    return title, title


def _build_definitions() -> dict[str, EffectDefinition]:
    definitions: dict[str, EffectDefinition] = {}
    for family, source, ids in (
        (LEGACY_FAMILY, LEGACY_SOURCE, LEGACY23_IDS),
        (CURRENT_FAMILY, CURRENT_SOURCE, CURRENT38_IDS),
        (NATURAL_FAMILY, NATURAL_SOURCE, NATURAL36_IDS),
    ):
        for family_index, effect_id in enumerate(ids, start=1):
            display_index = CATALOG_EFFECT_IDS.index(effect_id) + 1
            if family == LEGACY_FAMILY:
                names = (_LEGACY_NAMES_EN[effect_id], _LEGACY_NAMES_JA[effect_id], "Transition")
                defaults = _LEGACY_DEFAULTS[effect_id]
                categorical = _categories({"direction": _DIRECTIONAL[effect_id]}) if effect_id in _DIRECTIONAL else _categories()
                context_required = effect_id in _LEGACY_CONTEXT_REQUIRED
                traits = _legacy_traits(effect_id)
            elif family == CURRENT_FAMILY:
                name_en, name_ja, classification = _CURRENT_NAMES[effect_id]
                names = (name_en, name_ja, classification)
                defaults = _CURRENT_DEFAULTS[effect_id]
                categorical = _categories(
                    {name: _CURRENT_CATEGORICAL_VALUES[effect_id] for name in _CURRENT_CATEGORIES.get(effect_id, ())}
                )
                context_required = effect_id != "scramble_resolve"
                traits = _current_traits(effect_id, classification)
            else:
                name_en, name_ja = _natural_name(effect_id)
                names = (name_en, name_ja, None)
                defaults = _mapping()
                categorical = _categories()
                context_required = False
                traits = _natural_traits(effect_id)
            definitions[effect_id] = EffectDefinition(
                id=effect_id,
                family=family,
                source=source,
                family_index=family_index,
                display_index=display_index,
                name_en=names[0],
                name_ja=names[1],
                default_params=defaults,
                categorical_params=categorical,
                context_required=context_required,
                traits=traits,
                major_category_en=EFFECT_CLASSIFICATIONS_BY_ID[effect_id].major_category_en,
                major_category_ja=EFFECT_CLASSIFICATIONS_BY_ID[effect_id].major_category_ja,
                subcategory_en=EFFECT_CLASSIFICATIONS_BY_ID[effect_id].subcategory_en,
                subcategory_ja=EFFECT_CLASSIFICATIONS_BY_ID[effect_id].subcategory_ja,
                classification=names[2],
            )
    return definitions


if len(CATALOG_EFFECT_IDS) != 97 or len(set(CATALOG_EFFECT_IDS)) != len(CATALOG_EFFECT_IDS):
    raise RuntimeError("merged catalogue IDs must contain 97 unique entries")

EFFECT_DEFINITIONS: Mapping[str, EffectDefinition] = MappingProxyType(_build_definitions())
ALL_DEFINITIONS = EFFECT_DEFINITIONS
MERGED_REGISTRY: tuple[EffectDefinition, ...] = tuple(EFFECT_DEFINITIONS[effect_id] for effect_id in CATALOG_EFFECT_IDS)


def _lookup(effect_id: str) -> EffectDefinition:
    if not isinstance(effect_id, str):
        raise TypeError("effect_id must be a string")
    try:
        return EFFECT_DEFINITIONS[effect_id]
    except KeyError as exc:
        raise KeyError(f"unknown merged effect id: {effect_id!r}") from exc


def definition_for(effect_id: str) -> EffectDefinition:
    return _lookup(effect_id)


def registry_entry(effect_id: str) -> EffectDefinition:
    return _lookup(effect_id)


def legacy_definition_for(effect_id: str) -> EffectDefinition:
    definition = _lookup(effect_id)
    if definition.family != LEGACY_FAMILY:
        raise KeyError(f"{effect_id!r} is not a legacy23 effect")
    return definition


def iter_family(family: str) -> tuple[EffectDefinition, ...]:
    if family not in {LEGACY_FAMILY, CURRENT_FAMILY, NATURAL_FAMILY}:
        raise ValueError(f"unknown effect family: {family!r}")
    return tuple(definition for definition in MERGED_REGISTRY if definition.family == family)


def family_for(effect_id: str) -> str:
    return _lookup(effect_id).family


def source_for(effect_id: str) -> str:
    return _lookup(effect_id).source


def family_index_for(effect_id: str) -> int:
    return _lookup(effect_id).family_index


def display_index_for(effect_id: str) -> int:
    return _lookup(effect_id).display_index


def traits_for(effect_id: str) -> frozenset[str]:
    return _lookup(effect_id).traits


def classification_for(effect_id: str) -> str | None:
    """Return the original source classification retained for compatibility."""

    return _lookup(effect_id).classification


def integrated_classification_for(effect_id: str) -> EffectClassification:
    return EFFECT_CLASSIFICATIONS_BY_ID[_lookup(effect_id).id]


def major_category_en_for(effect_id: str) -> str:
    return integrated_classification_for(effect_id).major_category_en


def major_category_ja_for(effect_id: str) -> str:
    return integrated_classification_for(effect_id).major_category_ja


def subcategory_en_for(effect_id: str) -> str:
    return integrated_classification_for(effect_id).subcategory_en


def subcategory_ja_for(effect_id: str) -> str:
    return integrated_classification_for(effect_id).subcategory_ja


def legacy_effect_spec_kwargs(effect_id: str) -> Mapping[str, Any]:
    """Adapter alias for constructing a core ``EffectSpec`` from old data."""

    return legacy_definition_for(effect_id).as_effect_spec_kwargs()


__all__ = [
    "ALL_DEFINITIONS",
    "CATALOG_EFFECT_IDS",
    "CURRENT38_IDS",
    "CURRENT_FAMILY",
    "CURRENT_SOURCE",
    "EFFECT_CLASSIFICATIONS_BY_ID",
    "EFFECT_DEFINITIONS",
    "EffectClassification",
    "EffectDefinition",
    "INTEGRATED_MAJOR_CATEGORIES",
    "INTEGRATED_MAJOR_CATEGORIES_EN",
    "INTEGRATED_MAJOR_CATEGORY_NAMES_EN",
    "INTEGRATED_SUBCATEGORY_NAMES_EN",
    "LEGACY23_IDS",
    "LEGACY_FAMILY",
    "LEGACY_SOURCE",
    "MERGED_REGISTRY",
    "NATURAL36_IDS",
    "NATURAL_FAMILY",
    "NATURAL_SOURCE",
    "classification_for",
    "definition_for",
    "display_index_for",
    "family_for",
    "family_index_for",
    "integrated_classification_for",
    "iter_family",
    "legacy_definition_for",
    "legacy_effect_spec_kwargs",
    "major_category_en_for",
    "major_category_ja_for",
    "registry_entry",
    "source_for",
    "subcategory_en_for",
    "subcategory_ja_for",
    "traits_for",
]
