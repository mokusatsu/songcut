"""Command-line interface for ass-lyric-effects."""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any

from ._version import __version__
from .core import (
    CATALOG_EFFECT_ORDER,
    EFFECT_CLASSIFICATIONS,
    EFFECT_FAMILIES,
    EFFECT_LOCAL_NUMBERS,
    EFFECT_SPECS,
    Effect,
    EffectContext,
    Rect,
    decorate_dialogue,
)


def _value(text: str) -> Any:
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return text


def _param(text: str) -> tuple[str, Any]:
    if "=" not in text:
        raise argparse.ArgumentTypeError("parameter must be KEY=VALUE")
    name, value = text.split("=", 1)
    if not name:
        raise argparse.ArgumentTypeError("parameter name cannot be empty")
    return name, _value(value)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ass-lyric-effects",
        description=(
            "Apply one of 97 merged lyric-oriented effects to one ASS "
            "Dialogue line. No singing-time synchronization is used."
        ),
    )
    parser.add_argument(
        "dialogue",
        nargs="?",
        help="Dialogue line, or '-' to read one line from standard input",
    )
    parser.add_argument("--version", action="version", version=__version__)
    parser.add_argument("--start-ms", type=int)
    parser.add_argument("--end-ms", type=int)
    parser.add_argument(
        "--effect",
        help=(
            "a persistent string effect ID; numeric, display-name, and family "
            "selectors such as old23:1 are convenience inputs only"
        ),
    )
    parser.add_argument(
        "--param",
        action="append",
        default=[],
        type=_param,
        metavar="KEY=VALUE",
        help="effect-specific parameter; repeatable; JSON values are accepted",
    )
    parser.add_argument("--play-res-x", type=int)
    parser.add_argument("--play-res-y", type=int)
    parser.add_argument("--anchor-x", type=int)
    parser.add_argument("--anchor-y", type=int)
    parser.add_argument("--text-box", nargs=4, type=int, metavar=("X1", "Y1", "X2", "Y2"))
    parser.add_argument(
        "--glyph-widths",
        type=_value,
        help="JSON array of relative grapheme widths for exact caller-side layout",
    )
    parser.add_argument("--motion-step-ms", type=int, default=100)
    parser.add_argument(
        "--list-effects",
        action="store_true",
        help="list effect numbers, names, and categorical parameters, then exit",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _parser()
    args = parser.parse_args(argv)
    if args.list_effects:
        api_numbers = {effect: index for index, effect in enumerate(Effect, 1)}
        for display_number, effect in enumerate(CATALOG_EFFECT_ORDER, 1):
            spec = EFFECT_SPECS[effect]
            categories = ", ".join(
                f"{key}={list(values)}" for key, values in spec.categorical_params.items()
            ) or "none"
            family = EFFECT_FAMILIES[effect]
            local_number = EFFECT_LOCAL_NUMBERS[effect]
            classification = EFFECT_CLASSIFICATIONS[effect]
            print(
                f"display={display_number:03d} api={api_numbers[effect]:03d} "
                f"{family}:{local_number:02d} {effect.value} | "
                f"{spec.name_en} / {spec.name_ja} | "
                f"{classification.major_category_en} / {classification.major_category_ja} > "
                f"{classification.subcategory_en} / {classification.subcategory_ja} | "
                f"{categories}"
            )
        return 0

    missing: list[str] = []
    if args.dialogue is None:
        missing.append("dialogue")
    if args.start_ms is None:
        missing.append("--start-ms")
    if args.end_ms is None:
        missing.append("--end-ms")
    if args.effect is None:
        missing.append("--effect")
    if missing:
        parser.error("the following arguments are required: " + ", ".join(missing))

    dialogue = sys.stdin.readline().rstrip("\r\n") if args.dialogue == "-" else args.dialogue
    params = dict(args.param)
    context_values = (
        args.play_res_x,
        args.play_res_y,
        args.anchor_x,
        args.anchor_y,
        args.text_box,
        args.glyph_widths,
    )
    context = None
    if any(value is not None for value in context_values):
        if args.play_res_x is None or args.play_res_y is None:
            parser.error(
                "--play-res-x and --play-res-y are both required when "
                "supplying EffectContext options"
            )
        if args.glyph_widths is not None and not isinstance(args.glyph_widths, list):
            parser.error("--glyph-widths must be a JSON array")
        context = EffectContext(
            play_res_x=args.play_res_x,
            play_res_y=args.play_res_y,
            anchor_x=args.anchor_x,
            anchor_y=args.anchor_y,
            text_box=Rect(*args.text_box) if args.text_box else None,
            glyph_widths=(
                tuple(float(value) for value in args.glyph_widths)
                if args.glyph_widths is not None
                else None
            ),
            motion_step_ms=args.motion_step_ms,
        )
    try:
        lines = decorate_dialogue(
            dialogue,
            args.start_ms,
            args.end_ms,
            args.effect,
            params=params,
            context=context,
        )
    except ValueError as exc:
        parser.exit(2, f"error: {exc}\n")
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
