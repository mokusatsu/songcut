"""Autonomous lyric-oriented Advanced SubStation Alpha effects.

The public API accepts one cut-in/cut-out ``Dialogue:`` line and returns one
or more complete ``Dialogue:`` lines.  These effects do not consume syllable,
word, beat, or audio timing.  Character-level choreography is generated from
the event duration and deterministic parameters only.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, replace
from enum import Enum
import math
from pathlib import Path
import random
import re
import struct
import unicodedata
from typing import Any

import regex
import uharfbuzz as hb

from ._engine_adapters import (
    NATURAL_ALIASES,
    AdapterInputError as _AdapterInputError,
    AdapterParameterError as _AdapterParameterError,
    decorate_legacy as _decorate_legacy,
    decorate_natural as _decorate_natural,
    natural_spec_rows as _natural_spec_rows,
)
from ._merged_registry import (
    CATALOG_EFFECT_IDS,
    CURRENT38_IDS,
    EffectClassification,
    LEGACY23_IDS,
    NATURAL36_IDS,
    definition_for as _merged_definition_for,
)


class EffectError(ValueError):
    """Base error raised for invalid input or unsupported combinations."""


class EffectParameterError(EffectError):
    """Raised when an effect-specific parameter is invalid."""


_GRAPHEME_RE = regex.compile(r"\X")


def _font_table(face: hb.Face, tag: str) -> bytes | None:
    """Return one raw OpenType table, treating missing/corrupt data as absent."""

    try:
        blob = face.reference_table(tag)
        data = blob.data
    except (AttributeError, OSError, TypeError, ValueError):
        return None
    return data if data else None


def _i16(table: bytes | None, offset: int) -> int | None:
    if table is None or offset < 0 or len(table) < offset + 2:
        return None
    return struct.unpack_from(">h", table, offset)[0]


def _u16(table: bytes | None, offset: int) -> int | None:
    if table is None or offset < 0 or len(table) < offset + 2:
        return None
    return struct.unpack_from(">H", table, offset)[0]


def _vertical_metric_height(face: hb.Face) -> int:
    """Return libass's effective ascender-minus-descender in font units.

    ``ass_font.c`` first replaces FreeType's face metrics with signed
    ``OS/2.usWinAscent``/``usWinDescent`` when their sum is non-zero.  If
    those values are unavailable, FreeType supplies hhea or typo metrics and
    finally the ``head`` bounding box.  FT_SIZE_REQUEST_TYPE_REAL_DIM then
    maps that height to the requested ASS FontSize.
    """

    os2 = _font_table(face, "OS/2")
    win_ascent = _u16(os2, 74)
    win_descent = _u16(os2, 76)
    if win_ascent is not None and win_descent is not None:
        # libass deliberately casts these spec-unsigned fields to short for
        # compatibility with VSFilter/GDI's signed behavior.
        signed_height = int(struct.unpack(">h", struct.pack(">H", win_ascent))[0]) + int(
            struct.unpack(">h", struct.pack(">H", win_descent))[0]
        )
        if signed_height > 0:
            return signed_height

    typo_asc = _i16(os2, 68)
    typo_desc = _i16(os2, 70)
    typo_height = (
        None
        if typo_asc is None or typo_desc is None
        else typo_asc - typo_desc
    )
    hhea = _font_table(face, "hhea")
    hhea_asc = _i16(hhea, 4)
    hhea_desc = _i16(hhea, 6)

    # Modern FreeType selects sTypo* when USE_TYPO_METRICS is set; otherwise
    # it starts with hhea and uses typo values only when the former is zero.
    fs_selection = _u16(os2, 62)
    if (
        fs_selection is not None
        and fs_selection & (1 << 7)
        and typo_height
        and typo_height > 0
    ):
        return typo_height
    if hhea_asc is not None and hhea_desc is not None:
        hhea_height = hhea_asc - hhea_desc
        if hhea_height > 0:
            return hhea_height
    if typo_height and typo_height > 0:
        return typo_height

    head = _font_table(face, "head")
    bbox_y_min = _i16(head, 38)
    bbox_y_max = _i16(head, 42)
    if bbox_y_min is not None and bbox_y_max is not None:
        bbox_height = bbox_y_max - bbox_y_min
        if bbox_height > 0:
            return bbox_height
    raise ValueError("font has no usable vertical metrics (OS/2, hhea, or head)")


def split_graphemes(text: str) -> tuple[str, ...]:
    """Split *text* into Unicode extended grapheme clusters.

    Python's normal string iteration yields Unicode code points, which can
    split a user-visible character into multiple pieces (for example a ZWJ
    emoji sequence, a regional-indicator flag, or a base character followed
    by combining marks).  The ``regex`` module's ``\\X`` implementation
    follows the Unicode grapheme-break rules (UAX #29), so every returned
    item is one displayable grapheme cluster.

    The function intentionally performs no ASS override/tag parsing.  Callers
    that process Dialogue text should remove/interpret ASS escapes first and
    then use this helper for the visible text.
    """

    if not isinstance(text, str):
        raise TypeError("text must be a string")
    return tuple(_GRAPHEME_RE.findall(text))


def measure_grapheme_widths(
    text: str,
    font_path: str | Path,
    font_size: float,
    *,
    face_index: int = 0,
) -> tuple[float, ...]:
    """Measure each grapheme cluster's HarfBuzz horizontal advance.

    Each extended grapheme cluster from :func:`split_graphemes` is shaped
    independently with the selected OpenType face.  The resulting HarfBuzz
    ``x_advance`` values (font units) are converted to the requested ASS
    ``font_size`` using libass's ``FT_SIZE_REQUEST_TYPE_REAL_DIM`` scale:
    ``OS/2.usWinAscent + usWinDescent`` is preferred, followed by FreeType-
    compatible hhea/typo/bbox fallbacks.  A cluster with no advance (for
    example an isolated combining mark) is returned as ``0.0`` explicitly;
    callers that lay out text should keep that cluster at the current cursor
    position rather than silently dropping it.  If all clusters have zero
    advance, layout code must reject the result because it has no usable
    extent.

    ``font_path`` may be a string or :class:`~pathlib.Path`.  ``face_index``
    selects a face from a TrueType Collection and defaults to the first face.
    """

    if not isinstance(text, str):
        raise TypeError("text must be a string")
    if isinstance(font_size, bool) or not isinstance(font_size, (int, float)):
        raise TypeError("font_size must be a positive number")
    if not math.isfinite(float(font_size)) or float(font_size) <= 0:
        raise ValueError("font_size must be a positive finite number")
    if isinstance(face_index, bool) or not isinstance(face_index, int):
        raise TypeError("face_index must be a non-negative integer")
    if face_index < 0:
        raise ValueError("face_index must be a non-negative integer")

    font_data = Path(font_path).read_bytes()
    try:
        face = hb.Face(font_data, face_index)
    except Exception as exc:  # uharfbuzz exposes ValueError/TypeError by version
        raise ValueError(f"unable to load font face index {face_index}") from exc
    face_count = getattr(face, "count", None)
    if isinstance(face_count, int) and face_index >= face_count:
        raise ValueError(
            f"font face index {face_index} is out of range (face count {face_count})"
        )
    upem = int(face.upem)
    if upem <= 0:
        raise ValueError("font face has an invalid units-per-em value")

    font = hb.Font(face)
    # Keep HarfBuzz advances in font units; scale exactly once below.  Setting
    # OpenType funcs makes metrics consistent for fonts whose default funcs
    # are not installed by the binding.
    font.scale = (upem, upem)
    try:
        hb.ot_font_set_funcs(font)
    except AttributeError:
        # Older uharfbuzz versions install the funcs automatically.  The
        # explicit call is best-effort and does not affect the metric contract.
        pass

    metric_height = _vertical_metric_height(face)
    if metric_height <= 0:
        raise ValueError("font has no usable positive vertical metric height")
    scale = float(font_size) / metric_height
    widths: list[float] = []
    for cluster in split_graphemes(text):
        buffer = hb.Buffer()
        buffer.add_str(cluster)
        buffer.guess_segment_properties()
        hb.shape(font, buffer)
        advance_units = sum(position.x_advance for position in buffer.glyph_positions)
        width = float(advance_units) * scale
        # Preserve exact zero-advance clusters as 0.0.  Avoid tiny signed
        # residue from unusual fonts while leaving ordinary advances intact.
        widths.append(0.0 if abs(width) < 1e-9 else width)
    return tuple(widths)


class Effect(str, Enum):
    # Enum order backs a convenience numeric selector only. Persisted data must
    # store the string ``Effect.value`` contract from ``stable_ids`` instead.
    # Catalogue display order is the independent ``CATALOG_EFFECT_ORDER``.
    BASELINE_WAVE = "baseline_wave"
    SIDEWIND = "sidewind"
    PENDULUM_ROW = "pendulum_row"
    DOMINO_SETTLE = "domino_settle"
    LETTER_RAIN = "letter_rain"
    BUBBLE_RISE = "bubble_rise"
    CENTER_RIPPLE = "center_ripple"
    EDGE_KNOCK = "edge_knock"
    ORBIT_ASSEMBLE = "orbit_assemble"
    WEAVE_CROSS = "weave_cross"
    STAIRCASE_FLATTEN = "staircase_flatten"
    FAN_SPREAD = "fan_spread"
    TWIN_LANE_MERGE = "twin_lane_merge"
    MAGNET_REPEL = "magnet_repel"
    CHARACTER_PULSE_TRAIN = "character_pulse_train"
    SCRAMBLE_RESOLVE = "scramble_resolve"
    CHORUS_ECHO = "chorus_echo"
    ECHO_TUNNEL = "echo_tunnel"
    MIRROR_REFLECTION = "mirror_reflection"
    WATER_REFLECTION = "water_reflection"
    SHADOW_MARCH = "shadow_march"
    CHROMATIC_ORBIT = "chromatic_orbit"
    PARALLAX_CHORUS = "parallax_chorus"
    LONG_EXPOSURE = "long_exposure"
    CALL_RESPONSE_DUET = "call_response_duet"
    AFTERIMAGE_WAVE = "afterimage_wave"
    COLOR_WAVE = "color_wave"
    AURORA_BANDS = "aurora_bands"
    EMBOSS_LIGHT = "emboss_light"
    GLASS_REFRACTION = "glass_refraction"
    METALLIC_SHIMMER = "metallic_shimmer"
    COLOR_PINGPONG = "color_pingpong"
    SPOTLIGHT_LENS = "spotlight_lens"
    BRACKET_EMBRACE = "bracket_embrace"
    HALO_RINGS = "halo_rings"
    EQUALIZER_BED = "equalizer_bed"
    CONSTELLATION_SPARKS = "constellation_sparks"
    PULSE_FRAME = "pulse_frame"

    # Archived ASS Effects 23 engine.
    CUT = "cut"
    FAD = "fad"
    FADE = "fade"
    ALPHA = "alpha"
    ZOOM = "zoom"
    POP = "pop"
    BOUNCE = "bounce"
    SLIDE = "slide"
    WIPE = "wipe"
    BLUR = "blur"
    ROTATE = "rotate"
    FLIP = "flip"
    SPACING = "spacing"
    STRETCH = "stretch"
    OUTLINE = "outline"
    GLOW = "glow"
    FLICKER = "flicker"
    TYPEWRITER = "typewriter"
    KARAOKE = "karaoke"
    SCANLINE = "scanline"
    DISTORT = "distort"
    GLITCH = "glitch"
    DISSOLVE = "dissolve"

    # ASS Natural Effects 36 v7 engine.
    RAIN_VEIL = "rain_veil"
    DRIZZLE_MIST = "drizzle_mist"
    CLOUDBURST = "cloudburst"
    CREPUSCULAR_RAYS = "crepuscular_rays"
    SNOWFALL_DEPTH = "snowfall_depth"
    BLIZZARD_WHITEOUT = "blizzard_whiteout"
    DIAMOND_DUST = "diamond_dust"
    HAILSTORM = "hailstorm"
    FROST_BLOOM = "frost_bloom"
    ICE_CRACK = "ice_crack"
    AVALANCHE = "avalanche"
    MORNING_MIST = "morning_mist"
    SEA_OF_CLOUDS = "sea_of_clouds"
    GENTLE_BREEZE = "gentle_breeze"
    GUST_FRONT = "gust_front"
    WHIRLWIND = "whirlwind"
    TORNADO = "tornado"
    SANDSTORM = "sandstorm"
    HEAT_HAZE = "heat_haze"
    OCEAN_SWELL = "ocean_swell"
    BREAKING_WAVE = "breaking_wave"
    RISING_TIDE = "rising_tide"
    WATERFALL = "waterfall"
    RIVER_CURRENT = "river_current"
    WHIRLPOOL = "whirlpool"
    LAVA_FLOW = "lava_flow"
    EMBER_DRIFT = "ember_drift"
    RAINBOW_ARCH = "rainbow_arch"
    CHERRY_BLOSSOM_STORM = "cherry_blossom_storm"
    FALLING_LEAVES = "falling_leaves"
    FIREFLY_NIGHT = "firefly_night"
    BIOLUMINESCENT_TIDE = "bioluminescent_tide"
    METEOR_SHOWER = "meteor_shower"
    SOLAR_ECLIPSE = "solar_eclipse"
    MOONLIGHT_CLOUDS = "moonlight_clouds"
    SUNRISE_HORIZON = "sunrise_horizon"


class Direction(str, Enum):
    LEFT_TO_RIGHT = "left_to_right"
    RIGHT_TO_LEFT = "right_to_left"
    TOP_TO_BOTTOM = "top_to_bottom"
    BOTTOM_TO_TOP = "bottom_to_top"
    CLOCKWISE = "clockwise"
    COUNTERCLOCKWISE = "counterclockwise"
    HORIZONTAL = "horizontal"
    VERTICAL = "vertical"
    CENTER_OUT = "center_out"
    EDGES_IN = "edges_in"
    INWARD = "inward"
    OUTWARD = "outward"
    ABOVE = "above"
    BELOW = "below"


class Phase(str, Enum):
    ODD_FIRST = "odd_first"
    EVEN_FIRST = "even_first"


@dataclass(frozen=True)
class EffectSpec:
    name_en: str
    name_ja: str
    category_en: str
    category_ja: str
    description_en: str
    description_ja: str
    default_params: Mapping[str, Any]
    categorical_params: Mapping[str, tuple[str, ...]]
    context_required: bool = True
    major_category_en: str = ""
    major_category_ja: str = ""
    subcategory_en: str = ""
    subcategory_ja: str = ""


_DEFAULT_PALETTE = (
    "&H4FD8FF&",  # warm yellow-orange in ASS BGR
    "&HFF8BCE&",  # pink
    "&HFFC36A&",  # cyan-blue
    "&H9AFFA6&",  # mint
)


EFFECT_SPECS: dict[Effect, EffectSpec] = {
    Effect.BASELINE_WAVE: EffectSpec(
        "Baseline Wave", "文字波形", "Character choreography", "文字の自律運動",
        "Characters undulate vertically with a travelling phase.",
        "文字が進行方向に位相をずらしながら上下へ波打ちます。",
        {"direction": Direction.LEFT_TO_RIGHT, "amplitude": 22, "cycles": 1.7, "phase_spread": 0.9},
        {"direction": (Direction.LEFT_TO_RIGHT.value, Direction.RIGHT_TO_LEFT.value)},
    ),
    Effect.SIDEWIND: EffectSpec(
        "Sidewind", "横風文字列", "Character choreography", "文字の自律運動",
        "A travelling horizontal gust pushes each character independently.",
        "横方向の風が文字ごとに順番に通り抜けるように揺らします。",
        {"direction": Direction.LEFT_TO_RIGHT, "amplitude": 26, "cycles": 1.5, "phase_spread": 0.85},
        {"direction": (Direction.LEFT_TO_RIGHT.value, Direction.RIGHT_TO_LEFT.value)},
    ),
    Effect.PENDULUM_ROW: EffectSpec(
        "Pendulum Row", "振り子文字列", "Character choreography", "文字の自律運動",
        "Every character swings like a pendulum with a phase delay.",
        "各文字が位相差を持つ振り子のように揺れます。",
        {"direction": Direction.LEFT_TO_RIGHT, "angle": 14, "cycles": 1.8, "lift": 7},
        {"direction": (Direction.LEFT_TO_RIGHT.value, Direction.RIGHT_TO_LEFT.value)},
    ),
    Effect.DOMINO_SETTLE: EffectSpec(
        "Domino Settle", "ドミノ整列", "Character choreography", "文字の自律運動",
        "Characters topple into and out of alignment one by one.",
        "文字がドミノのように順番に倒れ込み、整列し、退場時に逆動作します。",
        {"direction": Direction.LEFT_TO_RIGHT, "tilt": 72, "offset": 44, "stagger": 0.72},
        {"direction": (Direction.LEFT_TO_RIGHT.value, Direction.RIGHT_TO_LEFT.value)},
    ),
    Effect.LETTER_RAIN: EffectSpec(
        "Letter Rain", "文字の雨", "Character choreography", "文字の自律運動",
        "Characters fall from different heights and settle in sequence.",
        "文字が異なる高さから雨粒のように降り、順番に定位置へ収まります。",
        {"direction": Direction.LEFT_TO_RIGHT, "height": 230, "drift": 34, "seed": 501, "stagger": 0.72},
        {"direction": (Direction.LEFT_TO_RIGHT.value, Direction.RIGHT_TO_LEFT.value)},
    ),
    Effect.BUBBLE_RISE: EffectSpec(
        "Bubble Rise", "泡文字", "Character choreography", "文字の自律運動",
        "Characters rise from below and continue to float gently.",
        "文字が泡のように下から浮上し、表示中も小さく漂います。",
        {"direction": Direction.LEFT_TO_RIGHT, "rise": 190, "sway": 20, "seed": 607, "stagger": 0.68},
        {"direction": (Direction.LEFT_TO_RIGHT.value, Direction.RIGHT_TO_LEFT.value)},
    ),
    Effect.CENTER_RIPPLE: EffectSpec(
        "Center Ripple", "中央波紋", "Character choreography", "文字の自律運動",
        "A scale-and-lift ripple propagates from the centre or the edges.",
        "拡大と持ち上がりの波紋が中央から外側、または両端から中央へ伝わります。",
        {"direction": Direction.CENTER_OUT, "scale": 24, "lift": 12, "cycles": 1.45},
        {"direction": (Direction.CENTER_OUT.value, Direction.EDGES_IN.value)},
    ),
    Effect.EDGE_KNOCK: EffectSpec(
        "Edge Knock", "端からノック", "Character choreography", "文字の自律運動",
        "A compact knock impulse travels across the line.",
        "短いノックの衝撃が文字列を端から端へ走ります。",
        {"direction": Direction.LEFT_TO_RIGHT, "distance": 24, "angle": 7, "cycles": 1.6},
        {"direction": (Direction.LEFT_TO_RIGHT.value, Direction.RIGHT_TO_LEFT.value)},
    ),
    Effect.ORBIT_ASSEMBLE: EffectSpec(
        "Orbit Assemble", "軌道集合", "Character choreography", "文字の自律運動",
        "Characters follow curved orbital paths into and out of position.",
        "文字が弧を描く軌道から集まり、退場時は同じ向きへほどけます。",
        {"direction": Direction.CLOCKWISE, "radius": 92, "turns": 0.8, "stagger": 0.38},
        {"direction": (Direction.CLOCKWISE.value, Direction.COUNTERCLOCKWISE.value)},
    ),
    Effect.WEAVE_CROSS: EffectSpec(
        "Weave Cross", "編み込み交差", "Character choreography", "文字の自律運動",
        "Odd and even characters cross over and under like woven strands.",
        "奇数文字と偶数文字が上下の経路を交差し、編み目のように合流します。",
        {"direction": Direction.LEFT_TO_RIGHT, "height": 76, "cross": 34, "stagger": 0.52},
        {"direction": (Direction.LEFT_TO_RIGHT.value, Direction.RIGHT_TO_LEFT.value)},
    ),
    Effect.STAIRCASE_FLATTEN: EffectSpec(
        "Staircase Flatten", "階段整列", "Character choreography", "文字の自律運動",
        "A diagonal staircase of characters flattens into a lyric line.",
        "斜めの階段状に並んだ文字が一列へ整い、退場時に再び段差へ戻ります。",
        {"direction": Direction.LEFT_TO_RIGHT, "step_height": 19, "tilt": 8, "stagger": 0.42},
        {"direction": (Direction.LEFT_TO_RIGHT.value, Direction.RIGHT_TO_LEFT.value)},
    ),
    Effect.FAN_SPREAD: EffectSpec(
        "Fan Spread", "扇状展開", "Character choreography", "文字の自律運動",
        "Characters unfold from a fan-shaped arc.",
        "文字が扇の弧から開き、一列へ展開します。",
        {"direction": Direction.CLOCKWISE, "arc": 68, "radius": 118, "stagger": 0.32},
        {"direction": (Direction.CLOCKWISE.value, Direction.COUNTERCLOCKWISE.value)},
    ),
    Effect.TWIN_LANE_MERGE: EffectSpec(
        "Twin-Lane Merge", "二車線合流", "Character choreography", "文字の自律運動",
        "Odd and even characters merge from two opposing lanes.",
        "奇数文字と偶数文字が上下または左右の二経路から合流します。",
        {"direction": Direction.HORIZONTAL, "distance": 120, "stagger": 0.42},
        {"direction": (Direction.HORIZONTAL.value, Direction.VERTICAL.value)},
    ),
    Effect.MAGNET_REPEL: EffectSpec(
        "Magnet Repel", "磁石反発", "Character choreography", "文字の自律運動",
        "A virtual magnet sends a pressure wave through the characters.",
        "仮想的な磁石の圧力波で文字が中央から外へ、または両端から中央へ押し合います。",
        {"direction": Direction.CENTER_OUT, "distance": 34, "cycles": 1.55, "lift": 8},
        {"direction": (Direction.CENTER_OUT.value, Direction.EDGES_IN.value)},
    ),
    Effect.CHARACTER_PULSE_TRAIN: EffectSpec(
        "Character Pulse Train", "文字パルス列", "Character choreography", "文字の自律運動",
        "A crisp enlargement pulse travels character by character.",
        "文字ごとの拡大パルスが一方向へ連続して走ります。",
        {"direction": Direction.LEFT_TO_RIGHT, "scale": 30, "lift": 16, "cycles": 1.35},
        {"direction": (Direction.LEFT_TO_RIGHT.value, Direction.RIGHT_TO_LEFT.value)},
    ),
    Effect.SCRAMBLE_RESOLVE: EffectSpec(
        "Scramble Resolve", "文字化け復元", "Character choreography", "文字の自律運動",
        "A full-length decoy string resolves into the lyric without typing it in.",
        "文字数を保ったダミー文字列が順番に正しい歌詞へ復元します。タイプ表示ではありません。",
        {"direction": Direction.LEFT_TO_RIGHT, "interval_ms": 90, "seed": 1601, "charset": "アイウエオカキクケコサシスセソ△◇○☆#?"},
        {"direction": (Direction.LEFT_TO_RIGHT.value, Direction.RIGHT_TO_LEFT.value)},
        context_required=False,
    ),
    Effect.CHORUS_ECHO: EffectSpec(
        "Chorus Echo", "コーラス残響", "Echo and layering", "残像・ハモリ層",
        "Layered translucent copies breathe behind the main lyric.",
        "半透明の複製字幕が主字幕の背後でずれて呼吸し、コーラスの厚みを表現します。",
        {"direction": Direction.BOTTOM_TO_TOP, "copies": 3, "distance": 28, "cycles": 1.25},
        {"direction": tuple(item.value for item in (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT, Direction.TOP_TO_BOTTOM, Direction.BOTTOM_TO_TOP))},
    ),
    Effect.ECHO_TUNNEL: EffectSpec(
        "Echo Tunnel", "残響トンネル", "Echo and layering", "残像・ハモリ層",
        "Concentric text copies create a tunnel of depth.",
        "同心状の複製字幕が奥行きのある残響トンネルを作ります。",
        {"direction": Direction.INWARD, "layers": 5, "depth": 38, "cycles": 1.1},
        {"direction": (Direction.INWARD.value, Direction.OUTWARD.value)},
    ),
    Effect.MIRROR_REFLECTION: EffectSpec(
        "Mirror Reflection", "鏡面反射", "Echo and layering", "残像・ハモリ層",
        "A banded mirrored lyric appears above or below the original.",
        "原文の上または下に、帯ごとに濃度が変わる鏡面反射を作ります。",
        {"direction": Direction.BELOW, "bands": 8, "gap": 18, "shimmer": 10},
        {"direction": (Direction.ABOVE.value, Direction.BELOW.value)},
    ),
    Effect.WATER_REFLECTION: EffectSpec(
        "Water Reflection", "水面反射", "Echo and layering", "残像・ハモリ層",
        "A mirrored copy is sliced into rippling water bands.",
        "反転した複製字幕を細い帯へ分割し、水面のように横へ揺らします。",
        {"direction": Direction.LEFT_TO_RIGHT, "bands": 10, "amplitude": 18, "cycles": 1.45, "gap": 16},
        {"direction": (Direction.LEFT_TO_RIGHT.value, Direction.RIGHT_TO_LEFT.value)},
    ),
    Effect.SHADOW_MARCH: EffectSpec(
        "Shadow March", "影の行進", "Echo and layering", "残像・ハモリ層",
        "Multiple soft shadow copies march around the lyric.",
        "複数の影字幕が主字幕の周囲を一定方向へ巡回します。",
        {"direction": Direction.CLOCKWISE, "copies": 6, "radius": 14, "cycles": 1.0},
        {"direction": (Direction.CLOCKWISE.value, Direction.COUNTERCLOCKWISE.value)},
    ),
    Effect.CHROMATIC_ORBIT: EffectSpec(
        "Chromatic Orbit", "色収差軌道", "Echo and layering", "残像・ハモリ層",
        "Red, cyan, and magenta copies orbit the white lyric.",
        "赤・シアン・マゼンタの色分離層が白い主字幕の周囲を回ります。",
        {"direction": Direction.CLOCKWISE, "radius": 10, "cycles": 1.35},
        {"direction": (Direction.CLOCKWISE.value, Direction.COUNTERCLOCKWISE.value)},
    ),
    Effect.PARALLAX_CHORUS: EffectSpec(
        "Parallax Chorus", "視差コーラス", "Echo and layering", "残像・ハモリ層",
        "Copies at different depths drift at different speeds.",
        "奥行きの異なる複製字幕が別々の速度で流れ、視差を作ります。",
        {"direction": Direction.BOTTOM_TO_TOP, "layers": 3, "distance": 30, "cycles": 0.9},
        {"direction": tuple(item.value for item in (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT, Direction.TOP_TO_BOTTOM, Direction.BOTTOM_TO_TOP))},
    ),
    Effect.LONG_EXPOSURE: EffectSpec(
        "Long Exposure", "長時間露光", "Echo and layering", "残像・ハモリ層",
        "Delayed translucent copies form a directional long-exposure trail.",
        "遅延した半透明層が移動方向に長時間露光のような尾を作ります。",
        {"direction": Direction.LEFT_TO_RIGHT, "trails": 6, "distance": 42, "cycles": 1.0},
        {"direction": tuple(item.value for item in (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT, Direction.TOP_TO_BOTTOM, Direction.BOTTOM_TO_TOP))},
    ),
    Effect.CALL_RESPONSE_DUET: EffectSpec(
        "Call-and-Response Duet", "掛け合いデュエット", "Echo and layering", "残像・ハモリ層",
        "Two copies alternately answer one another across the main lyric.",
        "主字幕の両側に置いた二つの複製字幕が交互に強調され、掛け合いを表します。",
        {"direction": Direction.HORIZONTAL, "distance": 58, "cycles": 1.3},
        {"direction": (Direction.HORIZONTAL.value, Direction.VERTICAL.value)},
    ),
    Effect.AFTERIMAGE_WAVE: EffectSpec(
        "Afterimage Wave", "残像波", "Echo and layering", "残像・ハモリ層",
        "A character wave leaves two coloured phase-delayed afterimages.",
        "文字波形の後ろに位相の遅れた二色の残像が残ります。",
        {"direction": Direction.LEFT_TO_RIGHT, "amplitude": 18, "cycles": 1.55, "trail": 0.12},
        {"direction": (Direction.LEFT_TO_RIGHT.value, Direction.RIGHT_TO_LEFT.value)},
    ),
    Effect.COLOR_WAVE: EffectSpec(
        "Colour Wave", "色彩波", "Colour and material", "色・質感",
        "A smooth palette wave travels across characters while positions stay fixed.",
        "位置を動かさず、文字ごとの色だけが滑らかな波として伝わります。",
        {"direction": Direction.LEFT_TO_RIGHT, "cycles": 1.2, "palette": _DEFAULT_PALETTE},
        {"direction": (Direction.LEFT_TO_RIGHT.value, Direction.RIGHT_TO_LEFT.value)},
    ),
    Effect.AURORA_BANDS: EffectSpec(
        "Aurora Bands", "オーロラ帯", "Colour and material", "色・質感",
        "Coloured clipped bands drift through the fully visible lyric.",
        "常に読める主字幕の上を、色付きの帯がオーロラのように漂います。",
        {"direction": Direction.LEFT_TO_RIGHT, "bands": 7, "amplitude": 12, "cycles": 1.0, "palette": _DEFAULT_PALETTE},
        {"direction": tuple(item.value for item in (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT, Direction.TOP_TO_BOTTOM, Direction.BOTTOM_TO_TOP))},
    ),
    Effect.EMBOSS_LIGHT: EffectSpec(
        "Emboss Light", "浮彫り照明", "Colour and material", "色・質感",
        "A moving highlight-and-shadow pair makes the lyric look embossed.",
        "ハイライト層と影層が周回し、歌詞を浮彫りのように見せます。",
        {"direction": Direction.CLOCKWISE, "distance": 4.5, "cycles": 1.1},
        {"direction": (Direction.CLOCKWISE.value, Direction.COUNTERCLOCKWISE.value)},
    ),
    Effect.GLASS_REFRACTION: EffectSpec(
        "Glass Refraction", "ガラス屈折", "Colour and material", "色・質感",
        "Regular text slices refract in opposite directions like cut glass.",
        "規則正しい文字帯が互い違いに屈折し、カットガラスのように見えます。",
        {"direction": Direction.LEFT_TO_RIGHT, "slices": 7, "offset": 12, "cycles": 1.25},
        {"direction": (Direction.LEFT_TO_RIGHT.value, Direction.RIGHT_TO_LEFT.value)},
    ),
    Effect.METALLIC_SHIMMER: EffectSpec(
        "Metallic Shimmer", "金属光沢", "Colour and material", "色・質感",
        "A narrow bright reflection travels over an always-visible lyric.",
        "常時表示された歌詞の表面を、細い強い反射光が通過します。",
        {"direction": Direction.LEFT_TO_RIGHT, "width": 105, "cycles": 1.15, "color": "&HFFFFFF&"},
        {"direction": tuple(item.value for item in (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT, Direction.TOP_TO_BOTTOM, Direction.BOTTOM_TO_TOP))},
    ),
    Effect.COLOR_PINGPONG: EffectSpec(
        "Colour Ping-Pong", "交互色往復", "Colour and material", "色・質感",
        "Odd and even characters exchange two colours in opposite phase.",
        "奇数文字と偶数文字が逆位相で二色を交換します。",
        {"phase": Phase.ODD_FIRST, "cycles": 1.5, "color_a": "&H4FD8FF&", "color_b": "&HFF8BCE&"},
        {"phase": (Phase.ODD_FIRST.value, Phase.EVEN_FIRST.value)},
    ),
    Effect.SPOTLIGHT_LENS: EffectSpec(
        "Spotlight Lens", "スポットライトレンズ", "Colour and material", "色・質感",
        "A brighter, slightly magnified lens travels over a dim readable base.",
        "暗めの主字幕を残したまま、明るく少し拡大したレンズ領域が移動します。",
        {"direction": Direction.LEFT_TO_RIGHT, "width": 230, "scale": 106, "cycles": 1.0},
        {"direction": tuple(item.value for item in (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT, Direction.TOP_TO_BOTTOM, Direction.BOTTOM_TO_TOP))},
    ),
    Effect.BRACKET_EMBRACE: EffectSpec(
        "Bracket Embrace", "括弧抱擁", "Lyric support graphics", "歌詞補助図形",
        "Animated brackets approach and gently hold the lyric.",
        "左右または上下の括弧が歌詞へ近づき、包み込むように呼吸します。",
        {"direction": Direction.HORIZONTAL, "distance": 74, "breath": 9, "cycles": 1.15},
        {"direction": (Direction.HORIZONTAL.value, Direction.VERTICAL.value)},
    ),
    Effect.HALO_RINGS: EffectSpec(
        "Halo Rings", "光輪", "Lyric support graphics", "歌詞補助図形",
        "Elliptical rings expand outwards or contract inwards around the lyric.",
        "楕円の光輪が歌詞の周囲で外へ広がる、または内へ収束します。",
        {"direction": Direction.CENTER_OUT, "rings": 4, "cycles": 1.0, "max_scale": 138},
        {"direction": (Direction.CENTER_OUT.value, Direction.EDGES_IN.value)},
    ),
    Effect.EQUALIZER_BED: EffectSpec(
        "Equalizer Bed", "自律イコライザー", "Lyric support graphics", "歌詞補助図形",
        "Decorative bars pulse under the lyric without reading audio.",
        "音声解析なしで、歌詞の下の装飾バーが位相差をつけて脈動します。",
        {"direction": Direction.LEFT_TO_RIGHT, "bars": 18, "height": 48, "cycles": 1.7, "seed": 3701},
        {"direction": (Direction.LEFT_TO_RIGHT.value, Direction.RIGHT_TO_LEFT.value)},
    ),
    Effect.CONSTELLATION_SPARKS: EffectSpec(
        "Constellation Sparks", "星座スパーク", "Lyric support graphics", "歌詞補助図形",
        "Deterministic star sparks light up around the lyric in sequence.",
        "決定論的に配置した星形の光が歌詞の周囲で順番に点灯します。",
        {"direction": Direction.LEFT_TO_RIGHT, "count": 16, "radius": 56, "seed": 3803, "cycles": 1.25},
        {"direction": (Direction.LEFT_TO_RIGHT.value, Direction.RIGHT_TO_LEFT.value)},
    ),
    Effect.PULSE_FRAME: EffectSpec(
        "Pulse Frame", "巡回フレーム", "Lyric support graphics", "歌詞補助図形",
        "Four frame sides light in a circulating order.",
        "歌詞を囲む四辺が順番に発光し、光が周回します。",
        {"direction": Direction.CLOCKWISE, "padding": 30, "thickness": 4, "cycles": 1.25},
        {"direction": (Direction.CLOCKWISE.value, Direction.COUNTERCLOCKWISE.value)},
    ),
}


_LEGACY_CATEGORY_EN = "ASS appearance/disappearance effects"
_LEGACY_CATEGORY_JA = "ASS出現・消失エフェクト"

for _effect_id in LEGACY23_IDS:
    _definition = _merged_definition_for(_effect_id)
    EFFECT_SPECS[Effect(_effect_id)] = EffectSpec(
        name_en=_definition.name_en,
        name_ja=_definition.name_ja,
        category_en=_LEGACY_CATEGORY_EN,
        category_ja=_LEGACY_CATEGORY_JA,
        description_en=(
            f"{_definition.name_en} imported from the archived 23-effect "
            "appearance/disappearance catalogue."
        ),
        description_ja=(
            f"旧23演出カタログから統合した「{_definition.name_ja}」です。"
        ),
        default_params=dict(_definition.default_params),
        categorical_params={
            name: tuple(values)
            for name, values in _definition.categorical_params.items()
        },
        context_required=_definition.context_required,
    )

for _row in _natural_spec_rows():
    EFFECT_SPECS[Effect(_row["id"])] = EffectSpec(
        name_en=_row["name_en"],
        name_ja=_row["name_ja"],
        category_en=_row["category_en"],
        category_ja=_row["category_ja"],
        description_en=_row["description_en"],
        description_ja=_row["description_ja"],
        default_params=dict(_row["default_params"]),
        categorical_params={
            name: tuple(values)
            for name, values in _row["categorical_params"].items()
        },
        context_required=bool(_row["context_required"]),
    )


for _effect, _spec in tuple(EFFECT_SPECS.items()):
    _definition = _merged_definition_for(_effect.value)
    EFFECT_SPECS[_effect] = replace(
        _spec,
        major_category_en=_definition.major_category_en,
        major_category_ja=_definition.major_category_ja,
        subcategory_en=_definition.subcategory_en,
        subcategory_ja=_definition.subcategory_ja,
    )


CATALOG_EFFECT_ORDER: tuple[Effect, ...] = tuple(
    Effect(effect_id) for effect_id in CATALOG_EFFECT_IDS
)
EFFECT_FAMILIES: dict[Effect, str] = {
    Effect(effect_id): _merged_definition_for(effect_id).family
    for effect_id in CATALOG_EFFECT_IDS
}
EFFECT_LOCAL_NUMBERS: dict[Effect, int] = {
    Effect(effect_id): _merged_definition_for(effect_id).family_index
    for effect_id in CATALOG_EFFECT_IDS
}
EFFECT_DISPLAY_NUMBERS: dict[Effect, int] = {
    Effect(effect_id): _merged_definition_for(effect_id).display_index
    for effect_id in CATALOG_EFFECT_IDS
}
EFFECT_TRAITS: dict[Effect, frozenset[str]] = {
    Effect(effect_id): _merged_definition_for(effect_id).traits
    for effect_id in CATALOG_EFFECT_IDS
}
EFFECT_CLASSIFICATIONS: dict[Effect, EffectClassification] = {
    Effect(effect_id): EffectClassification(
        major_category_en=_merged_definition_for(effect_id).major_category_en,
        major_category_ja=_merged_definition_for(effect_id).major_category_ja,
        subcategory_en=_merged_definition_for(effect_id).subcategory_en,
        subcategory_ja=_merged_definition_for(effect_id).subcategory_ja,
    )
    for effect_id in CATALOG_EFFECT_IDS
}
EFFECT_MAJOR_CATEGORIES_EN: dict[Effect, str] = {
    effect: classification.major_category_en
    for effect, classification in EFFECT_CLASSIFICATIONS.items()
}
EFFECT_MAJOR_CATEGORIES_JA: dict[Effect, str] = {
    effect: classification.major_category_ja
    for effect, classification in EFFECT_CLASSIFICATIONS.items()
}
EFFECT_SUBCATEGORIES_EN: dict[Effect, str] = {
    effect: classification.subcategory_en
    for effect, classification in EFFECT_CLASSIFICATIONS.items()
}
EFFECT_SUBCATEGORIES_JA: dict[Effect, str] = {
    effect: classification.subcategory_ja
    for effect, classification in EFFECT_CLASSIFICATIONS.items()
}

_FAMILY_EFFECT_IDS: dict[str, tuple[str, ...]] = {
    "old23": LEGACY23_IDS,
    "legacy23": LEGACY23_IDS,
    "lyric40": CURRENT38_IDS,
    "current38": CURRENT38_IDS,
    "natural36": NATURAL36_IDS,
}


EFFECT_NAMES_EN: dict[Effect, str] = {effect: spec.name_en for effect, spec in EFFECT_SPECS.items()}
EFFECT_NAMES_JA: dict[Effect, str] = {effect: spec.name_ja for effect, spec in EFFECT_SPECS.items()}
DEFAULT_PARAMS: dict[Effect, dict[str, Any]] = {
    effect: dict(spec.default_params) for effect, spec in EFFECT_SPECS.items()
}
CONTEXT_REQUIRED_EFFECTS = frozenset(
    effect for effect, spec in EFFECT_SPECS.items() if spec.context_required
)

# These effects position individual grapheme clusters.  Multiline input is
# rendered as independent line-local layouts on one shared effect timeline.
LINE_LAYOUT_MULTILINE_EFFECTS = frozenset(
    {
        Effect.BASELINE_WAVE,
        Effect.SIDEWIND,
        Effect.PENDULUM_ROW,
        Effect.DOMINO_SETTLE,
        Effect.LETTER_RAIN,
        Effect.BUBBLE_RISE,
        Effect.CENTER_RIPPLE,
        Effect.EDGE_KNOCK,
        Effect.ORBIT_ASSEMBLE,
        Effect.WEAVE_CROSS,
        Effect.STAIRCASE_FLATTEN,
        Effect.FAN_SPREAD,
        Effect.TWIN_LANE_MERGE,
        Effect.MAGNET_REPEL,
        Effect.CHARACTER_PULSE_TRAIN,
        Effect.AFTERIMAGE_WAVE,
        Effect.COLOR_WAVE,
        Effect.COLOR_PINGPONG,
    }
)
SEQUENTIAL_MULTILINE_EFFECTS = frozenset(
    {Effect.TYPEWRITER, Effect.SCRAMBLE_RESOLVE}
)


@dataclass(frozen=True)
class Rect:
    x1: int
    y1: int
    x2: int
    y2: int

    def __post_init__(self) -> None:
        if self.x1 >= self.x2 or self.y1 >= self.y2:
            raise EffectParameterError("Rect requires x1 < x2 and y1 < y2")

    @property
    def width(self) -> int:
        return self.x2 - self.x1

    @property
    def height(self) -> int:
        return self.y2 - self.y1

    @property
    def center(self) -> tuple[float, float]:
        return ((self.x1 + self.x2) / 2, (self.y1 + self.y2) / 2)


@dataclass(frozen=True)
class VisualLineLayout:
    """Exact renderer layout for one non-empty visual line of a multiline lyric.

    Empty ASS ``\\N``/``\\n`` visual lines carry no glyph geometry and therefore
    have no corresponding ``VisualLineLayout``.  Their vertical spacing is
    already reflected in the anchors of the following non-empty lines.
    """

    anchor_x: int
    anchor_y: int
    text_box: Rect
    glyph_widths: tuple[float, ...]

    def __post_init__(self) -> None:
        if (
            isinstance(self.anchor_x, bool)
            or not isinstance(self.anchor_x, int)
            or isinstance(self.anchor_y, bool)
            or not isinstance(self.anchor_y, int)
        ):
            raise EffectParameterError("visual-line anchors must be integers")
        if not self.glyph_widths or any(
            isinstance(value, bool)
            or not isinstance(value, (int, float))
            or not math.isfinite(float(value))
            or value < 0
            for value in self.glyph_widths
        ):
            raise EffectParameterError(
                "visual-line glyph_widths must contain finite non-negative values"
            )
        if sum(float(value) for value in self.glyph_widths) <= 0:
            raise EffectParameterError(
                "visual-line glyph_widths must have a positive total"
            )


@dataclass(frozen=True)
class EffectContext:
    """Geometry and sampling information not present in one Dialogue line.

    ``text_box`` should cover the rendered lyric including outline and shadow.
    Character positions use Unicode grapheme clusters.  A caller with exact
    layout knowledge may pass ``glyph_widths`` in relative units (for example
    the values returned by :func:`measure_grapheme_widths`); its length must
    equal the visible grapheme count.  Zero-width clusters are kept at the
    current cursor position, while at least one positive width is required to
    give the line a usable extent.
    """

    play_res_x: int = 1920
    play_res_y: int = 1080
    anchor_x: int | None = None
    anchor_y: int | None = None
    text_box: Rect | None = None
    offscreen_margin: int = 240
    motion_step_ms: int = 100
    glyph_widths: tuple[float, ...] | None = None
    line_layouts: tuple[VisualLineLayout, ...] | None = None
    strict: bool = True

    def __post_init__(self) -> None:
        if self.play_res_x <= 0 or self.play_res_y <= 0:
            raise EffectParameterError("play_res_x/play_res_y must be positive")
        if self.offscreen_margin < 0:
            raise EffectParameterError("offscreen_margin must be non-negative")
        if not 40 <= self.motion_step_ms <= 500:
            raise EffectParameterError("motion_step_ms must be between 40 and 500")
        if self.text_box is not None and not (
            0 <= self.text_box.x1 < self.text_box.x2 <= self.play_res_x
            and 0 <= self.text_box.y1 < self.text_box.y2 <= self.play_res_y
        ):
            raise EffectParameterError("text_box must be inside PlayRes")
        if self.glyph_widths is not None:
            if not self.glyph_widths or any(
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(float(value))
                or value < 0
                for value in self.glyph_widths
            ):
                raise EffectParameterError(
                    "glyph_widths must contain finite non-negative values"
                )
        if self.line_layouts is not None:
            if not self.line_layouts or any(
                not isinstance(layout, VisualLineLayout)
                for layout in self.line_layouts
            ):
                raise EffectParameterError(
                    "line_layouts must contain VisualLineLayout values"
                )
            for layout in self.line_layouts:
                if not (
                    0 <= layout.text_box.x1 < layout.text_box.x2 <= self.play_res_x
                    and 0 <= layout.text_box.y1 < layout.text_box.y2 <= self.play_res_y
                ):
                    raise EffectParameterError(
                        "visual-line text_box must be inside PlayRes"
                    )
                if not (
                    0 <= layout.anchor_x <= self.play_res_x
                    and 0 <= layout.anchor_y <= self.play_res_y
                ):
                    raise EffectParameterError(
                        "visual-line anchor must be inside PlayRes"
                    )

    @property
    def anchor(self) -> tuple[int, int]:
        return (
            self.play_res_x // 2 if self.anchor_x is None else self.anchor_x,
            self.play_res_y // 2 if self.anchor_y is None else self.anchor_y,
        )

    @property
    def box(self) -> Rect:
        if self.text_box is not None:
            return self.text_box
        anchor_x, anchor_y = self.anchor
        half_width = round(self.play_res_x * 0.31)
        half_height = round(self.play_res_y * 0.10)
        return Rect(
            max(0, anchor_x - half_width),
            max(0, anchor_y - half_height),
            min(self.play_res_x, anchor_x + half_width),
            min(self.play_res_y, anchor_y + half_height),
        )

    def for_visual_line(self, index: int) -> EffectContext:
        """Return a context for one non-empty line-layout index."""

        if self.line_layouts is None:
            raise EffectParameterError(
                "multiline character effects require explicit line_layouts"
            )
        try:
            layout = self.line_layouts[index]
        except IndexError as exc:
            raise EffectParameterError("visual-line layout index is out of range") from exc
        return replace(
            self,
            anchor_x=layout.anchor_x,
            anchor_y=layout.anchor_y,
            text_box=layout.text_box,
            glyph_widths=layout.glyph_widths,
            line_layouts=None,
        )


_TIME_RE = re.compile(r"^\s*(\d+):([0-5]?\d):([0-5]?\d)(?:\.(\d{1,3}))?\s*$")
_DIALOGUE_RE = re.compile(r"^\s*Dialogue\s*:\s*(.*)$", re.IGNORECASE)
_LEADING_OVERRIDE_RE = re.compile(r"^\{([^{}]*)\}")
_OVERRIDE_RE = re.compile(r"\{[^{}]*\}")
_POS_RE = re.compile(r"\\pos\(\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*\)", re.IGNORECASE)
_CONFLICT_RE = re.compile(r"\\(?:fad|fade|t|move|clip|iclip|k|K|kf|ko)(?=[(\d\\])")
_DRAWING_RE = re.compile(r"\\p\s*[1-9]", re.IGNORECASE)


@dataclass(frozen=True)
class DialogueEvent:
    layer: int
    start_ms: int
    end_ms: int
    style: str
    name: str
    margin_l: str
    margin_r: str
    margin_v: str
    effect_field: str
    text: str

    def __post_init__(self) -> None:
        if self.end_ms <= self.start_ms:
            raise EffectError("Dialogue end time must be after start time")

    @property
    def duration_ms(self) -> int:
        return self.end_ms - self.start_ms

    def format(self) -> str:
        return (
            f"Dialogue: {self.layer},{_format_time(self.start_ms)},"
            f"{_format_time(self.end_ms)},{self.style},{self.name},"
            f"{self.margin_l},{self.margin_r},{self.margin_v},"
            f"{self.effect_field},{self.text}"
        )


@dataclass(frozen=True)
class Glyph:
    text: str
    index: int
    count: int
    x: float
    y: float
    width: float
    order_ltr: float
    centre_distance: float
    is_space: bool = False


@dataclass(frozen=True)
class MotionState:
    x: float
    y: float
    scale_x: float = 100.0
    scale_y: float = 100.0
    rotation_z: float = 0.0
    rotation_x: float = 0.0
    rotation_y: float = 0.0
    shear_x: float = 0.0
    shear_y: float = 0.0
    alpha: int = 0
    primary_color: str | None = None
    outline_color: str | None = None
    border: float | None = None
    blur: float | None = None
    shadow: float | None = None


_LYRIC40_CATALOG_MOTION_REFERENCE_MS = 4200


def _periodic_time(t_ms: float) -> float:
    """Return Lyric 40 motion time at the catalogue's original speed.

    The published catalogue renders a 4,200 ms Sample event.  Historically,
    periodic motion normalized time by each Dialogue event's full duration,
    which stretched the same number of cycles across longer events.  Keeping
    the catalogue duration as a fixed reference preserves the existing videos
    while allowing longer events to continue at the same physical speed.
    """
    return t_ms / _LYRIC40_CATALOG_MOTION_REFERENCE_MS


def _parse_time(value: str) -> int:
    match = _TIME_RE.fullmatch(value)
    if not match:
        raise EffectError(f"invalid ASS timestamp: {value!r}")
    hours, minutes, seconds = map(int, match.group(1, 2, 3))
    fraction = match.group(4) or ""
    millis = int((fraction + "000")[:3])
    return ((hours * 60 + minutes) * 60 + seconds) * 1000 + millis


def _format_time(milliseconds: int) -> str:
    if milliseconds < 0:
        raise EffectError("ASS timestamp cannot be negative")
    centiseconds = (milliseconds + 5) // 10
    hours, remainder = divmod(centiseconds, 360_000)
    minutes, remainder = divmod(remainder, 6_000)
    seconds, centis = divmod(remainder, 100)
    return f"{hours}:{minutes:02d}:{seconds:02d}.{centis:02d}"


def parse_dialogue(line: str) -> DialogueEvent:
    """Parse one ASS v4+ ``Dialogue:`` line."""

    if "\n" in line or "\r" in line:
        raise EffectError("exactly one Dialogue line is required")
    match = _DIALOGUE_RE.fullmatch(line)
    if not match:
        raise EffectError("input must begin with 'Dialogue:'")
    fields = match.group(1).split(",", 9)
    if len(fields) != 10:
        raise EffectError(
            "Dialogue line must contain 10 ASS fields; text may contain commas"
        )
    try:
        layer = int(fields[0].strip())
    except ValueError as exc:
        raise EffectError(f"invalid Dialogue layer: {fields[0]!r}") from exc
    return DialogueEvent(
        layer=layer,
        start_ms=_parse_time(fields[1]),
        end_ms=_parse_time(fields[2]),
        style=fields[3].strip(),
        name=fields[4],
        margin_l=fields[5].strip(),
        margin_r=fields[6].strip(),
        margin_v=fields[7].strip(),
        effect_field=fields[8],
        text=fields[9],
    )


def _coerce_effect(value: Effect | str | int) -> Effect:
    if isinstance(value, Effect):
        return value
    effects = list(Effect)
    if isinstance(value, int):
        if 1 <= value <= len(effects):
            return effects[value - 1]
        raise EffectParameterError(f"numeric effect must be in the range 1..{len(effects)}")
    candidate = str(value).strip()
    if candidate.isdecimal():
        return _coerce_effect(int(candidate))
    if ":" in candidate:
        family_name, local_number_text = candidate.lower().split(":", 1)
        family_ids = _FAMILY_EFFECT_IDS.get(family_name)
        if family_ids is not None and local_number_text.isdecimal():
            local_number = int(local_number_text)
            if 1 <= local_number <= len(family_ids):
                return Effect(family_ids[local_number - 1])
            raise EffectParameterError(
                f"family effect number must be in the range 1..{len(family_ids)} "
                f"for {family_name}"
            )
    normalized = candidate.lower().replace("-", "_").replace(" ", "_")
    aliases: dict[str, Effect] = {effect.value: effect for effect in Effect}
    for effect, spec in EFFECT_SPECS.items():
        aliases[spec.name_en.lower().replace("-", "_").replace(" ", "_")] = effect
        aliases[spec.name_ja] = effect
    for alias, effect_id in NATURAL_ALIASES.items():
        aliases[alias] = Effect(effect_id)
        aliases[alias.lower().replace("-", "_").replace(" ", "_")] = Effect(effect_id)
    try:
        if normalized in aliases:
            return aliases[normalized]
        return aliases[candidate]
    except KeyError as exc:
        choices = ", ".join(effect.value for effect in Effect)
        raise EffectParameterError(
            f"unknown effect {value!r}; choose 1..{len(Effect)}, a family selector, "
            f"or one of: {choices}"
        ) from exc


def get_effect_classification(effect: Effect | str | int) -> EffectClassification:
    """Return the adopted major category and subcategory for an effect."""

    return EFFECT_CLASSIFICATIONS[_coerce_effect(effect)]


def _coerce_params(params: Mapping[str, Any] | None) -> dict[str, Any]:
    if params is None:
        return {}
    if not isinstance(params, Mapping):
        raise EffectParameterError("params must be a mapping or None")
    result = dict(params)
    forbidden = {
        "start_direction",
        "end_direction",
        "in_direction",
        "out_direction",
        "enter_direction",
        "exit_direction",
    }
    used_forbidden = forbidden.intersection(result)
    if used_forbidden:
        names = ", ".join(sorted(used_forbidden))
        raise EffectParameterError(
            f"separate start/end directions are not supported: {names}; "
            "use the single 'direction' parameter"
        )
    return result


def _validate_param_names(params: Mapping[str, Any], allowed: set[str]) -> None:
    unknown = set(params) - allowed
    if unknown:
        raise EffectParameterError(
            "unsupported parameter(s): " + ", ".join(sorted(unknown))
        )


def _number(
    params: Mapping[str, Any],
    name: str,
    default: float,
    *,
    minimum: float,
    maximum: float,
) -> float:
    value = params.get(name, default)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise EffectParameterError(f"{name} must be a number")
    value = float(value)
    if not math.isfinite(value) or not minimum <= value <= maximum:
        raise EffectParameterError(
            f"{name} must be between {minimum:g} and {maximum:g}"
        )
    return value


def _integer(
    params: Mapping[str, Any],
    name: str,
    default: int,
    *,
    minimum: int,
    maximum: int,
) -> int:
    value = params.get(name, default)
    if isinstance(value, bool) or not isinstance(value, int):
        raise EffectParameterError(f"{name} must be an integer")
    if not minimum <= value <= maximum:
        raise EffectParameterError(
            f"{name} must be between {minimum} and {maximum}"
        )
    return value


def _string(params: Mapping[str, Any], name: str, default: str) -> str:
    value = params.get(name, default)
    if not isinstance(value, str) or not value:
        raise EffectParameterError(f"{name} must be a non-empty string")
    return value


def _direction(
    params: Mapping[str, Any],
    allowed: Sequence[Direction],
    default: Direction,
) -> Direction:
    raw = params.get("direction", default)
    try:
        direction = raw if isinstance(raw, Direction) else Direction(str(raw))
    except ValueError as exc:
        names = ", ".join(item.value for item in allowed)
        raise EffectParameterError(f"direction must be one of: {names}") from exc
    if direction not in allowed:
        names = ", ".join(item.value for item in allowed)
        raise EffectParameterError(f"direction must be one of: {names}")
    return direction


def _phase(
    params: Mapping[str, Any],
    allowed: Sequence[Phase],
    default: Phase,
) -> Phase:
    raw = params.get("phase", default)
    try:
        phase = raw if isinstance(raw, Phase) else Phase(str(raw))
    except ValueError as exc:
        names = ", ".join(item.value for item in allowed)
        raise EffectParameterError(f"phase must be one of: {names}") from exc
    if phase not in allowed:
        names = ", ".join(item.value for item in allowed)
        raise EffectParameterError(f"phase must be one of: {names}")
    return phase


def _ass_color(value: Any, name: str = "color") -> str:
    text = str(value)
    if not re.fullmatch(r"&H[0-9A-Fa-f]{6}&", text):
        raise EffectParameterError(
            f"{name} must be an ASS BGR value such as '&H4FD8FF&'"
        )
    return text.upper()


def _palette(
    params: Mapping[str, Any],
    name: str,
    default: Sequence[str],
    *,
    minimum: int = 2,
    maximum: int = 12,
) -> tuple[str, ...]:
    raw = params.get(name, default)
    if isinstance(raw, str) or not isinstance(raw, Sequence):
        raise EffectParameterError(f"{name} must be a sequence of ASS colours")
    values = tuple(_ass_color(item, name) for item in raw)
    if not minimum <= len(values) <= maximum:
        raise EffectParameterError(
            f"{name} must contain between {minimum} and {maximum} colours"
        )
    return values


def _fmt(value: float) -> str:
    if abs(value) < 0.0005:
        value = 0.0
    return f"{value:.3f}".rstrip("0").rstrip(".")


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return low if value < low else high if value > high else value


def _smooth(value: float) -> float:
    value = _clamp(value)
    return value * value * (3.0 - 2.0 * value)


def _ease_out_back(value: float, overshoot: float = 1.70158) -> float:
    value = _clamp(value) - 1.0
    return 1.0 + (overshoot + 1.0) * value**3 + overshoot * value**2


def _pulse(value: float, power: float = 2.0) -> float:
    return max(0.0, math.sin(math.pi * _clamp(value))) ** power


def _fractional(value: float) -> float:
    return value - math.floor(value)


def _add_tags(text: str, tags: str) -> str:
    if not tags:
        return text
    match = _LEADING_OVERRIDE_RE.match(text)
    if match:
        return "{" + match.group(1) + tags + "}" + text[match.end() :]
    return "{" + tags + "}" + text


def _remove_position_tags(text: str) -> str:
    def clean(match: re.Match[str]) -> str:
        body = re.sub(r"\\(?:pos|move|org)\([^)]*\)", "", match.group(0))
        return "" if body == "{}" else body

    return _OVERRIDE_RE.sub(clean, text)


def _event_anchor(event: DialogueEvent, context: EffectContext) -> tuple[int, int]:
    match = _POS_RE.search(event.text)
    if match:
        return round(float(match.group(1))), round(float(match.group(2)))
    return context.anchor


def _clone(
    event: DialogueEvent,
    *,
    start_ms: int | None = None,
    end_ms: int | None = None,
    text: str | None = None,
    layer: int | None = None,
) -> DialogueEvent:
    return replace(
        event,
        start_ms=event.start_ms if start_ms is None else start_ms,
        end_ms=event.end_ms if end_ms is None else end_ms,
        text=event.text if text is None else text,
        layer=event.layer if layer is None else layer,
    )


def _split_text_lines(
    text: str,
    *,
    purpose: str,
) -> tuple[str, list[list[str]], list[str]]:
    """Split visible text into UAX #29 tokens grouped by ASS visual line."""

    leading = ""
    match = _LEADING_OVERRIDE_RE.match(text)
    payload = text
    if match:
        leading = match.group(0)
        payload = text[match.end() :]
    if _OVERRIDE_RE.search(payload):
        raise EffectError(
            f"{purpose} does not support inline override blocks; "
            "move static tags to the leading override block"
        )
    if _DRAWING_RE.search(leading):
        raise EffectError(f"{purpose} cannot process ASS vector drawings")

    lines: list[list[str]] = [[]]
    separators: list[str] = []
    plain_start = 0
    index = 0
    while index < len(payload):
        if payload[index] == "\\" and index + 1 < len(payload):
            code = payload[index + 1]
            if code in {"N", "n", "h"}:
                if plain_start < index:
                    lines[-1].extend(split_graphemes(payload[plain_start:index]))
                token = payload[index : index + 2]
                if code == "h":
                    lines[-1].append(token)
                else:
                    separators.append(token)
                    lines.append([])
                index += 2
                plain_start = index
                continue
        index += 1
    if plain_start < len(payload):
        lines[-1].extend(split_graphemes(payload[plain_start:]))
    if not any(lines):
        raise EffectError("Dialogue text must contain visible text")
    return leading, lines, separators


def _split_text(text: str, *, purpose: str) -> tuple[str, list[str]]:
    leading, lines, _separators = _split_text_lines(text, purpose=purpose)
    if len(lines) != 1:
        raise EffectError(f"{purpose} supports one visual line only")
    return leading, lines[0]


def _line_local_events(
    event: DialogueEvent,
    context: EffectContext,
) -> list[tuple[DialogueEvent, EffectContext]] | None:
    """Build exact single-line inputs for multiline character effects."""

    leading, token_lines, _separators = _split_text_lines(
        event.text,
        purpose="multiline character choreography",
    )
    if len(token_lines) == 1:
        return None
    renderable_lines = [tokens for tokens in token_lines if tokens]
    if context.line_layouts is None:
        raise EffectParameterError(
            "multiline character effects require explicit line_layouts; "
            "one VisualLineLayout is required for each non-empty ASS \\N/\\n line"
        )
    if len(context.line_layouts) != len(renderable_lines):
        raise EffectParameterError(
            "line_layouts length must equal the non-empty visual line count "
            f"({len(renderable_lines)})"
        )
    static_leading = _remove_position_tags(leading)
    return [
        (
            replace(event, text=static_leading + "".join(tokens)),
            context.for_visual_line(layout_index),
        )
        for layout_index, tokens in enumerate(renderable_lines)
    ]


def _glyph_weight(token: str) -> float:
    if token == r"\h" or token.isspace():
        return 0.52
    char = token[0]
    width = unicodedata.east_asian_width(char)
    if width in {"W", "F"}:
        return 1.0
    category = unicodedata.category(char)
    if category.startswith("P"):
        return 0.48
    if category.startswith("M"):
        return 0.2
    if char.isdigit():
        return 0.62
    return 0.66


def _layout_glyphs(event: DialogueEvent, context: EffectContext) -> tuple[str, list[Glyph]]:
    leading, tokens = _split_text(event.text, purpose="character choreography")
    # ASS renderers generally honour only one positioning tag. Remove the
    # caller's static \pos from per-glyph copies before inserting \move.
    leading = _remove_position_tags(leading)
    weights = list(context.glyph_widths or tuple(_glyph_weight(token) for token in tokens))
    if len(weights) != len(tokens):
        raise EffectParameterError(
            "glyph_widths length must equal the visible grapheme count "
            f"({len(tokens)})"
        )
    total = sum(weights)
    if total <= 0:
        raise EffectParameterError("glyph widths must have a positive total")
    box = context.box
    anchor_x, anchor_y = _event_anchor(event, context)
    # Keep the box width but centre it on an explicit \pos anchor when present.
    x1 = anchor_x - box.width / 2
    unit = box.width / total
    cursor = x1
    count = len(tokens)
    glyphs: list[Glyph] = []
    for index, (token, weight) in enumerate(zip(tokens, weights, strict=True)):
        width = unit * weight
        x = cursor + width / 2
        order = 0.5 if count == 1 else index / (count - 1)
        centre_distance = 0.0 if count == 1 else abs(index - (count - 1) / 2) / ((count - 1) / 2)
        glyphs.append(
            Glyph(
                text=token,
                index=index,
                count=count,
                x=x,
                y=anchor_y,
                width=width,
                order_ltr=order,
                centre_distance=centre_distance,
                is_space=(token == r"\h" or token.isspace()),
            )
        )
        cursor += width
    return leading, glyphs


def _sample_times(duration_ms: int, step_ms: int) -> list[int]:
    if duration_ms <= 0:
        return [0]
    points = list(range(0, duration_ms, step_ms))
    if not points or points[-1] != duration_ms:
        points.append(duration_ms)
    return points


def _order(glyph: Glyph, direction: Direction) -> float:
    if direction is Direction.LEFT_TO_RIGHT:
        return glyph.order_ltr
    if direction is Direction.RIGHT_TO_LEFT:
        return 1.0 - glyph.order_ltr
    if direction is Direction.CENTER_OUT:
        return glyph.centre_distance
    if direction is Direction.EDGES_IN:
        return 1.0 - glyph.centre_distance
    return glyph.order_ltr


def _stagger_entry(t_ms: float, span_ms: int, order: float, stagger: float) -> float:
    if span_ms <= 0:
        return 1.0
    delay = span_ms * _clamp(stagger, 0.0, 0.95) * _clamp(order)
    active = max(1.0, span_ms - span_ms * _clamp(stagger, 0.0, 0.95))
    return _smooth((t_ms - delay) / active)


def _stagger_exit(
    t_ms: float,
    duration_ms: int,
    span_ms: int,
    order: float,
    stagger: float,
) -> float:
    if span_ms <= 0:
        return 0.0
    local = t_ms - (duration_ms - span_ms)
    delay = span_ms * _clamp(stagger, 0.0, 0.95) * _clamp(order)
    active = max(1.0, span_ms - span_ms * _clamp(stagger, 0.0, 0.95))
    return _smooth((local - delay) / active)


def _presence(
    t_ms: float,
    duration_ms: int,
    start_ms: int,
    end_ms: int,
    *,
    order: float = 0.0,
    stagger: float = 0.0,
) -> tuple[float, float, float]:
    entry = _stagger_entry(t_ms, start_ms, order, stagger)
    exit_progress = _stagger_exit(t_ms, duration_ms, end_ms, order, stagger)
    visible = _clamp(min(entry, 1.0 - exit_progress))
    return entry, exit_progress, visible


def _alpha_from_presence(value: float, *, floor: int = 0) -> int:
    return round(_clamp(1.0 - value) * (255 - floor) + floor)


def _seed_value(seed: int, index: int, lane: int = 0) -> float:
    rng = random.Random(seed * 1_000_003 + index * 9_973 + lane * 7919)
    return rng.random()


def _direction_vector(direction: Direction) -> tuple[float, float]:
    if direction is Direction.LEFT_TO_RIGHT:
        return (1.0, 0.0)
    if direction is Direction.RIGHT_TO_LEFT:
        return (-1.0, 0.0)
    if direction is Direction.TOP_TO_BOTTOM:
        return (0.0, 1.0)
    if direction is Direction.BOTTOM_TO_TOP:
        return (0.0, -1.0)
    raise EffectParameterError(f"{direction.value} is not a cardinal direction")


def _format_alpha(alpha: int) -> str:
    return f"&H{max(0, min(255, int(alpha))):02X}&"


def _state_static_tags(state: MotionState) -> str:
    tags = (
        rf"\fscx{_fmt(state.scale_x)}\fscy{_fmt(state.scale_y)}"
        rf"\frz{_fmt(state.rotation_z)}\frx{_fmt(state.rotation_x)}"
        rf"\fry{_fmt(state.rotation_y)}\fax{_fmt(state.shear_x)}"
        rf"\fay{_fmt(state.shear_y)}\alpha{_format_alpha(state.alpha)}"
    )
    if state.primary_color is not None:
        tags += rf"\1c{state.primary_color}"
    if state.outline_color is not None:
        tags += rf"\3c{state.outline_color}"
    if state.border is not None:
        tags += rf"\bord{_fmt(state.border)}"
    if state.blur is not None:
        tags += rf"\blur{_fmt(state.blur)}"
    if state.shadow is not None:
        tags += rf"\shad{_fmt(state.shadow)}"
    return tags


def _state_transition_tags(state: MotionState) -> str:
    return _state_static_tags(state)


def _animated_text(
    base_text: str,
    state0: MotionState,
    state1: MotionState,
    segment_ms: int,
    *,
    clip0: Rect | None = None,
    clip1: Rect | None = None,
    extra_tags: str = "",
) -> str:
    tags = (
        rf"\an5\move({_fmt(state0.x)},{_fmt(state0.y)},"
        rf"{_fmt(state1.x)},{_fmt(state1.y)},0,{segment_ms})"
        + _state_static_tags(state0)
    )
    if clip0 is not None:
        tags += rf"\clip({clip0.x1},{clip0.y1},{clip0.x2},{clip0.y2})"
    tags += extra_tags
    transition = _state_transition_tags(state1)
    if clip1 is not None:
        transition += rf"\clip({clip1.x1},{clip1.y1},{clip1.x2},{clip1.y2})"
    tags += rf"\t(0,{segment_ms},{transition})"
    return _add_tags(base_text, tags)


GlyphStateFunction = Callable[[Glyph, float, int], MotionState]
LineStateFunction = Callable[[float, int], MotionState]


def _emit_sampled_glyphs(
    event: DialogueEvent,
    context: EffectContext,
    state_fn: GlyphStateFunction,
    *,
    layer_offset: int = 0,
    step_ms: int | None = None,
) -> list[DialogueEvent]:
    leading, glyphs = _layout_glyphs(event, context)
    points = _sample_times(event.duration_ms, step_ms or context.motion_step_ms)
    result: list[DialogueEvent] = []
    for first, second in zip(points, points[1:]):
        segment = second - first
        if segment <= 0:
            continue
        for glyph in glyphs:
            if glyph.is_space:
                continue
            state0 = state_fn(glyph, _periodic_time(first), first)
            state1 = state_fn(glyph, _periodic_time(second), second)
            if state0.alpha >= 255 and state1.alpha >= 255:
                continue
            text = _animated_text(
                leading + glyph.text,
                state0,
                state1,
                segment,
            )
            result.append(
                _clone(
                    event,
                    start_ms=event.start_ms + first,
                    end_ms=event.start_ms + second,
                    text=text,
                    layer=event.layer + layer_offset,
                )
            )
    return result


def _emit_sampled_line(
    event: DialogueEvent,
    context: EffectContext,
    state_fn: LineStateFunction,
    *,
    layer_offset: int = 0,
    step_ms: int | None = None,
    clip_fn: Callable[[float, int], Rect | None] | None = None,
    extra_tags: str = "",
) -> list[DialogueEvent]:
    points = _sample_times(event.duration_ms, step_ms or context.motion_step_ms)
    result: list[DialogueEvent] = []
    base_text = _remove_position_tags(event.text)
    for first, second in zip(points, points[1:]):
        segment = second - first
        if segment <= 0:
            continue
        state0 = state_fn(_periodic_time(first), first)
        state1 = state_fn(_periodic_time(second), second)
        if state0.alpha >= 255 and state1.alpha >= 255:
            continue
        clip0 = clip_fn(_periodic_time(first), first) if clip_fn else None
        clip1 = clip_fn(_periodic_time(second), second) if clip_fn else None
        text = _animated_text(
            base_text,
            state0,
            state1,
            segment,
            clip0=clip0,
            clip1=clip1,
            extra_tags=extra_tags,
        )
        result.append(
            _clone(
                event,
                start_ms=event.start_ms + first,
                end_ms=event.start_ms + second,
                text=text,
                layer=event.layer + layer_offset,
            )
        )
    return result


def _static_line(
    event: DialogueEvent,
    context: EffectContext,
    *,
    layer_offset: int = 0,
    alpha: int = 0,
    color: str | None = None,
    border: float | None = None,
    blur: float | None = None,
    scale: float = 100.0,
    extra_tags: str = "",
) -> DialogueEvent:
    anchor_x, anchor_y = _event_anchor(event, context)
    state = MotionState(
        anchor_x,
        anchor_y,
        scale_x=scale,
        scale_y=scale,
        alpha=alpha,
        primary_color=color,
        border=border,
        blur=blur,
    )
    tags = rf"\an5\pos({_fmt(state.x)},{_fmt(state.y)})" + _state_static_tags(state) + extra_tags
    return _clone(
        event,
        layer=event.layer + layer_offset,
        text=_add_tags(_remove_position_tags(event.text), tags),
    )


def _drawing_event(
    event: DialogueEvent,
    start_rel_ms: int,
    end_rel_ms: int,
    path: str,
    tags: str,
    *,
    layer_offset: int = 0,
) -> DialogueEvent:
    if end_rel_ms <= start_rel_ms:
        raise EffectError("drawing event duration must be positive")
    text = "{" + tags + r"\p1}" + path + r"{\p0}"
    return _clone(
        event,
        start_ms=event.start_ms + start_rel_ms,
        end_ms=event.start_ms + end_rel_ms,
        text=text,
        layer=event.layer + layer_offset,
    )


def _rect_path(rect: Rect) -> str:
    return f"m {rect.x1} {rect.y1} l {rect.x2} {rect.y1} {rect.x2} {rect.y2} {rect.x1} {rect.y2}"


def _line_rect(x1: float, y1: float, x2: float, y2: float, thickness: float) -> Rect:
    if abs(x2 - x1) >= abs(y2 - y1):
        top = round((y1 + y2) / 2 - thickness / 2)
        bottom = max(top + 1, round((y1 + y2) / 2 + thickness / 2))
        return Rect(round(min(x1, x2)), top, max(round(min(x1, x2)) + 1, round(max(x1, x2))), bottom)
    left = round((x1 + x2) / 2 - thickness / 2)
    right = max(left + 1, round((x1 + x2) / 2 + thickness / 2))
    return Rect(left, round(min(y1, y2)), right, max(round(min(y1, y2)) + 1, round(max(y1, y2))))


def _screen_rect(
    context: EffectContext,
    x1: float,
    y1: float,
    x2: float,
    y2: float,
) -> Rect | None:
    """Return the non-empty intersection of a rectangle with PlayRes.

    Animated band effects routinely generate bands that only partly intersect
    the frame.  Constructing ``Rect`` before clipping is unsafe at a screen
    edge because clamping can collapse a band to zero height or width.
    """

    left = max(0, min(context.play_res_x, round(min(x1, x2))))
    top = max(0, min(context.play_res_y, round(min(y1, y2))))
    right = max(0, min(context.play_res_x, round(max(x1, x2))))
    bottom = max(0, min(context.play_res_y, round(max(y1, y2))))
    if left >= right or top >= bottom:
        return None
    return Rect(left, top, right, bottom)


def _parse_color_components(color: str) -> tuple[int, int, int]:
    color = _ass_color(color)
    b = int(color[2:4], 16)
    g = int(color[4:6], 16)
    r = int(color[6:8], 16)
    return r, g, b


def _format_color_components(rgb: tuple[float, float, float]) -> str:
    r, g, b = (max(0, min(255, round(value))) for value in rgb)
    return f"&H{b:02X}{g:02X}{r:02X}&"


def _lerp_color(first: str, second: str, amount: float) -> str:
    amount = _clamp(amount)
    a = _parse_color_components(first)
    b = _parse_color_components(second)
    return _format_color_components(tuple(x + (y - x) * amount for x, y in zip(a, b, strict=True)))


def _palette_color(colors: Sequence[str], position: float) -> str:
    position = _fractional(position) * len(colors)
    index = int(math.floor(position)) % len(colors)
    next_index = (index + 1) % len(colors)
    return _lerp_color(colors[index], colors[next_index], position - math.floor(position))


def _presence_for_line(t_ms: int, duration: int, start: int, end: int) -> float:
    entry = 1.0 if start <= 0 else _smooth(t_ms / start)
    exit_keep = 1.0 if end <= 0 else 1.0 - _smooth((t_ms - (duration - end)) / end)
    return _clamp(min(entry, exit_keep))


# ---------------------------------------------------------------------------
# 01-16: character choreography
# ---------------------------------------------------------------------------


def _effect_baseline_wave(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "amplitude", "cycles", "phase_spread"})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    amplitude = _number(params, "amplitude", 22, minimum=1, maximum=160)
    cycles = _number(params, "cycles", 1.7, minimum=0.1, maximum=12)
    spread = _number(params, "phase_spread", 0.9, minimum=0, maximum=4)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0

    def state(glyph: Glyph, t: float, t_ms: int) -> MotionState:
        _, _, visible = _presence(t_ms, event.duration_ms, start, end)
        phase = 2 * math.pi * (cycles * t - sign * glyph.order_ltr * spread)
        y = glyph.y + amplitude * math.sin(phase) * visible
        y += -sign * amplitude * 1.6 * (1.0 - visible)
        return MotionState(glyph.x, y, alpha=_alpha_from_presence(visible))

    return _emit_sampled_glyphs(event, context, state)


def _effect_sidewind(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "amplitude", "cycles", "phase_spread"})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    amplitude = _number(params, "amplitude", 26, minimum=1, maximum=180)
    cycles = _number(params, "cycles", 1.5, minimum=0.1, maximum=12)
    spread = _number(params, "phase_spread", 0.85, minimum=0, maximum=4)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0

    def state(glyph: Glyph, t: float, t_ms: int) -> MotionState:
        _, _, visible = _presence(t_ms, event.duration_ms, start, end)
        phase = 2 * math.pi * (cycles * t - sign * glyph.order_ltr * spread)
        gust = amplitude * math.sin(phase) * visible
        gust += sign * amplitude * 4.0 * (1.0 - visible)
        y = glyph.y + amplitude * 0.18 * math.sin(phase * 0.55 + glyph.index) * visible
        return MotionState(
            glyph.x + gust,
            y,
            rotation_z=sign * 4.5 * math.sin(phase) * visible,
            shear_x=sign * 0.08 * math.sin(phase) * visible,
            alpha=_alpha_from_presence(visible),
        )

    return _emit_sampled_glyphs(event, context, state)


def _effect_pendulum_row(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "angle", "cycles", "lift"})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    angle = _number(params, "angle", 14, minimum=1, maximum=70)
    cycles = _number(params, "cycles", 1.8, minimum=0.1, maximum=12)
    lift = _number(params, "lift", 7, minimum=0, maximum=60)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0

    def state(glyph: Glyph, t: float, t_ms: int) -> MotionState:
        _, _, visible = _presence(t_ms, event.duration_ms, start, end)
        phase = 2 * math.pi * (cycles * t - sign * glyph.order_ltr * 0.82)
        swing = math.sin(phase)
        return MotionState(
            glyph.x,
            glyph.y + lift * (1.0 - math.cos(phase)) * 0.5 * visible,
            rotation_z=angle * swing * visible + sign * 70 * (1.0 - visible),
            alpha=_alpha_from_presence(visible),
        )

    return _emit_sampled_glyphs(event, context, state)


def _effect_domino_settle(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "tilt", "offset", "stagger"})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    tilt = _number(params, "tilt", 72, minimum=5, maximum=150)
    offset = _number(params, "offset", 44, minimum=1, maximum=240)
    stagger = _number(params, "stagger", 0.72, minimum=0, maximum=0.95)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0

    def state(glyph: Glyph, _t: float, t_ms: int) -> MotionState:
        order = _order(glyph, direction)
        entry, exit_progress, visible = _presence(
            t_ms, event.duration_ms, start, end, order=order, stagger=stagger
        )
        hidden = max(1.0 - _ease_out_back(entry), exit_progress)
        return MotionState(
            glyph.x - sign * offset * hidden * 0.45,
            glyph.y - offset * hidden,
            rotation_z=-sign * tilt * hidden,
            alpha=_alpha_from_presence(visible),
        )

    return _emit_sampled_glyphs(event, context, state)


def _effect_letter_rain(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "height", "drift", "seed", "stagger"})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    height = _number(params, "height", 230, minimum=20, maximum=1000)
    drift = _number(params, "drift", 34, minimum=0, maximum=240)
    seed = _integer(params, "seed", 501, minimum=0, maximum=2**31 - 1)
    stagger = _number(params, "stagger", 0.72, minimum=0, maximum=0.95)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0

    def state(glyph: Glyph, t: float, t_ms: int) -> MotionState:
        order = _order(glyph, direction)
        entry, exit_progress, visible = _presence(
            t_ms, event.duration_ms, start, end, order=order, stagger=stagger
        )
        jitter = 0.55 + _seed_value(seed, glyph.index) * 0.8
        hidden = max(1.0 - _ease_out_back(entry), exit_progress)
        fall_y = (-height * jitter * (1.0 - entry)) + height * 0.78 * exit_progress
        lateral = sign * drift * (0.5 - _seed_value(seed, glyph.index, 1)) * 2.0 * hidden
        settle = 4.0 * math.sin(2 * math.pi * (t * 1.4 + glyph.index * 0.21)) * visible
        return MotionState(
            glyph.x + lateral,
            glyph.y + fall_y + settle,
            rotation_z=sign * (0.5 - _seed_value(seed, glyph.index, 2)) * 38 * hidden,
            alpha=_alpha_from_presence(visible),
        )

    return _emit_sampled_glyphs(event, context, state)


def _effect_bubble_rise(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "rise", "sway", "seed", "stagger"})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    rise = _number(params, "rise", 190, minimum=20, maximum=800)
    sway = _number(params, "sway", 20, minimum=0, maximum=160)
    seed = _integer(params, "seed", 607, minimum=0, maximum=2**31 - 1)
    stagger = _number(params, "stagger", 0.68, minimum=0, maximum=0.95)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0

    def state(glyph: Glyph, t: float, t_ms: int) -> MotionState:
        order = _order(glyph, direction)
        entry, exit_progress, visible = _presence(
            t_ms, event.duration_ms, start, end, order=order, stagger=stagger
        )
        phase = 2 * math.pi * (t * (0.75 + _seed_value(seed, glyph.index) * 0.35) - sign * order * 0.4)
        intro_y = rise * (1.0 - entry)
        outro_y = -rise * 0.65 * exit_progress
        x = glyph.x + sway * math.sin(phase) * visible
        y = glyph.y + intro_y + outro_y + 8 * math.sin(phase * 0.7 + 1.1) * visible
        scale = 82 + 18 * visible + 4 * math.sin(phase) * visible
        return MotionState(x, y, scale_x=scale, scale_y=scale, alpha=_alpha_from_presence(visible))

    return _emit_sampled_glyphs(event, context, state)


def _effect_center_ripple(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "scale", "lift", "cycles"})
    direction = _direction(params, (Direction.CENTER_OUT, Direction.EDGES_IN), Direction.CENTER_OUT)
    scale_amount = _number(params, "scale", 24, minimum=1, maximum=100)
    lift = _number(params, "lift", 12, minimum=0, maximum=80)
    cycles = _number(params, "cycles", 1.45, minimum=0.1, maximum=10)

    def state(glyph: Glyph, t: float, t_ms: int) -> MotionState:
        _, _, visible = _presence(t_ms, event.duration_ms, start, end)
        order = _order(glyph, direction)
        wave = max(0.0, math.sin(2 * math.pi * (cycles * t - order * 0.72))) ** 3
        amount = wave * visible
        scale = 100 + scale_amount * amount
        return MotionState(
            glyph.x,
            glyph.y - lift * amount,
            scale_x=scale,
            scale_y=scale,
            alpha=_alpha_from_presence(visible),
        )

    return _emit_sampled_glyphs(event, context, state)


def _effect_edge_knock(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "distance", "angle", "cycles"})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    distance = _number(params, "distance", 24, minimum=1, maximum=160)
    angle = _number(params, "angle", 7, minimum=0, maximum=45)
    cycles = _number(params, "cycles", 1.6, minimum=0.1, maximum=10)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0

    def state(glyph: Glyph, t: float, t_ms: int) -> MotionState:
        _, _, visible = _presence(t_ms, event.duration_ms, start, end)
        order = _order(glyph, direction)
        impulse = max(0.0, math.sin(2 * math.pi * (cycles * t - order * 0.82))) ** 6
        return MotionState(
            glyph.x + sign * distance * impulse * visible,
            glyph.y - distance * 0.18 * impulse * visible,
            rotation_z=sign * angle * impulse * visible,
            alpha=_alpha_from_presence(visible),
        )

    return _emit_sampled_glyphs(event, context, state)


def _effect_orbit_assemble(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "radius", "turns", "stagger"})
    direction = _direction(params, (Direction.CLOCKWISE, Direction.COUNTERCLOCKWISE), Direction.CLOCKWISE)
    radius = _number(params, "radius", 92, minimum=5, maximum=500)
    turns = _number(params, "turns", 0.8, minimum=0.1, maximum=4)
    stagger = _number(params, "stagger", 0.38, minimum=0, maximum=0.9)
    sign = 1.0 if direction is Direction.CLOCKWISE else -1.0

    def state(glyph: Glyph, _t: float, t_ms: int) -> MotionState:
        order = glyph.order_ltr
        entry, exit_progress, visible = _presence(
            t_ms, event.duration_ms, start, end, order=order, stagger=stagger
        )
        factor = max(1.0 - entry, exit_progress)
        travel = (1.0 - entry) if entry < 1.0 else exit_progress
        theta = sign * (2 * math.pi * turns * travel + glyph.order_ltr * math.pi * 1.25)
        return MotionState(
            glyph.x + radius * factor * math.cos(theta),
            glyph.y + radius * 0.55 * factor * math.sin(theta),
            rotation_z=sign * 75 * factor,
            scale_x=70 + 30 * visible,
            scale_y=70 + 30 * visible,
            alpha=_alpha_from_presence(visible),
        )

    return _emit_sampled_glyphs(event, context, state)


def _effect_weave_cross(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "height", "cross", "stagger"})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    height = _number(params, "height", 76, minimum=5, maximum=300)
    cross = _number(params, "cross", 34, minimum=0, maximum=200)
    stagger = _number(params, "stagger", 0.52, minimum=0, maximum=0.9)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0

    def state(glyph: Glyph, t: float, t_ms: int) -> MotionState:
        order = _order(glyph, direction)
        entry, exit_progress, visible = _presence(
            t_ms, event.duration_ms, start, end, order=order, stagger=stagger
        )
        lane = -1.0 if glyph.index % 2 == 0 else 1.0
        hidden = max(1.0 - entry, exit_progress)
        crossing = math.sin(math.pi * min(1.0, entry)) * (1.0 - exit_progress)
        x = glyph.x - sign * cross * lane * crossing + sign * cross * lane * exit_progress
        y = glyph.y + lane * height * hidden
        y += lane * 6 * math.sin(2 * math.pi * (t * 1.1 + order)) * visible
        return MotionState(
            x,
            y,
            rotation_z=-lane * sign * 16 * hidden,
            alpha=_alpha_from_presence(visible),
        )

    return _emit_sampled_glyphs(event, context, state)


def _effect_staircase_flatten(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "step_height", "tilt", "stagger"})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    step_height = _number(params, "step_height", 19, minimum=1, maximum=100)
    tilt = _number(params, "tilt", 8, minimum=0, maximum=45)
    stagger = _number(params, "stagger", 0.42, minimum=0, maximum=0.9)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0

    def state(glyph: Glyph, _t: float, t_ms: int) -> MotionState:
        order = _order(glyph, direction)
        entry, exit_progress, visible = _presence(
            t_ms, event.duration_ms, start, end, order=order, stagger=stagger
        )
        hidden = max(1.0 - entry, exit_progress)
        step_index = glyph.index if direction is Direction.LEFT_TO_RIGHT else glyph.count - 1 - glyph.index
        centred = step_index - (glyph.count - 1) / 2
        return MotionState(
            glyph.x,
            glyph.y + centred * step_height * hidden,
            rotation_z=sign * centred * tilt * 0.16 * hidden,
            alpha=_alpha_from_presence(visible),
        )

    return _emit_sampled_glyphs(event, context, state)


def _effect_fan_spread(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "arc", "radius", "stagger"})
    direction = _direction(params, (Direction.CLOCKWISE, Direction.COUNTERCLOCKWISE), Direction.CLOCKWISE)
    arc = _number(params, "arc", 68, minimum=5, maximum=180)
    radius = _number(params, "radius", 118, minimum=10, maximum=600)
    stagger = _number(params, "stagger", 0.32, minimum=0, maximum=0.9)
    sign = 1.0 if direction is Direction.CLOCKWISE else -1.0
    anchor_x, anchor_y = _event_anchor(event, context)

    def state(glyph: Glyph, _t: float, t_ms: int) -> MotionState:
        entry, exit_progress, visible = _presence(
            t_ms, event.duration_ms, start, end, order=glyph.order_ltr, stagger=stagger
        )
        hidden = max(1.0 - _ease_out_back(entry), exit_progress)
        angle_deg = sign * (glyph.order_ltr - 0.5) * arc
        theta = math.radians(angle_deg - 90)
        fan_x = anchor_x + radius * math.cos(theta)
        fan_y = anchor_y + radius * math.sin(theta) + radius
        return MotionState(
            glyph.x * (1.0 - hidden) + fan_x * hidden,
            glyph.y * (1.0 - hidden) + fan_y * hidden,
            rotation_z=angle_deg * hidden,
            scale_x=74 + 26 * visible,
            scale_y=74 + 26 * visible,
            alpha=_alpha_from_presence(visible),
        )

    return _emit_sampled_glyphs(event, context, state)


def _effect_twin_lane_merge(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "distance", "stagger"})
    direction = _direction(params, (Direction.HORIZONTAL, Direction.VERTICAL), Direction.HORIZONTAL)
    distance = _number(params, "distance", 120, minimum=5, maximum=600)
    stagger = _number(params, "stagger", 0.42, minimum=0, maximum=0.9)

    def state(glyph: Glyph, _t: float, t_ms: int) -> MotionState:
        order = glyph.order_ltr
        entry, exit_progress, visible = _presence(
            t_ms, event.duration_ms, start, end, order=order, stagger=stagger
        )
        hidden = max(1.0 - entry, exit_progress)
        lane = -1.0 if glyph.index % 2 == 0 else 1.0
        if direction is Direction.HORIZONTAL:
            dx, dy = 0.0, lane * distance * hidden
        else:
            dx, dy = lane * distance * hidden, 0.0
        return MotionState(
            glyph.x + dx,
            glyph.y + dy,
            rotation_z=lane * 10 * hidden,
            alpha=_alpha_from_presence(visible),
        )

    return _emit_sampled_glyphs(event, context, state)


def _effect_magnet_repel(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "distance", "cycles", "lift"})
    direction = _direction(params, (Direction.CENTER_OUT, Direction.EDGES_IN), Direction.CENTER_OUT)
    distance = _number(params, "distance", 34, minimum=1, maximum=180)
    cycles = _number(params, "cycles", 1.55, minimum=0.1, maximum=10)
    lift = _number(params, "lift", 8, minimum=0, maximum=80)

    def state(glyph: Glyph, t: float, t_ms: int) -> MotionState:
        _, _, visible = _presence(t_ms, event.duration_ms, start, end)
        order = _order(glyph, direction)
        pressure = max(0.0, math.sin(2 * math.pi * (cycles * t - order * 0.65))) ** 3
        side = -1.0 if glyph.order_ltr < 0.5 else 1.0
        if direction is Direction.EDGES_IN:
            side *= -1.0
        return MotionState(
            glyph.x + side * distance * pressure * visible,
            glyph.y - lift * pressure * visible,
            scale_x=100 + 8 * pressure * visible,
            scale_y=100 - 4 * pressure * visible,
            alpha=_alpha_from_presence(visible),
        )

    return _emit_sampled_glyphs(event, context, state)


def _effect_character_pulse_train(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "scale", "lift", "cycles"})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    scale_amount = _number(params, "scale", 30, minimum=1, maximum=120)
    lift = _number(params, "lift", 16, minimum=0, maximum=100)
    cycles = _number(params, "cycles", 1.35, minimum=0.1, maximum=10)

    def state(glyph: Glyph, t: float, t_ms: int) -> MotionState:
        _, _, visible = _presence(t_ms, event.duration_ms, start, end)
        order = _order(glyph, direction)
        pulse = max(0.0, math.sin(2 * math.pi * (cycles * t - order * 0.92))) ** 5
        amount = pulse * visible
        return MotionState(
            glyph.x,
            glyph.y - lift * amount,
            scale_x=100 + scale_amount * amount,
            scale_y=100 + scale_amount * amount,
            rotation_z=(glyph.index % 2 * 2 - 1) * 3 * amount,
            alpha=_alpha_from_presence(visible),
        )

    return _emit_sampled_glyphs(event, context, state)


def _effect_scramble_resolve(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    del context
    _validate_param_names(params, {"direction", "interval_ms", "seed", "charset"})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    interval = _integer(params, "interval_ms", 90, minimum=30, maximum=500)
    seed = _integer(params, "seed", 1601, minimum=0, maximum=2**31 - 1)
    charset = _string(params, "charset", "アイウエオカキクケコサシスセソ△◇○☆#?")
    leading, token_lines, separators = _split_text_lines(
        event.text,
        purpose="scramble_resolve",
    )
    ordered_positions: list[tuple[int, int]] = []
    for line_index, tokens in enumerate(token_lines):
        token_indices: Sequence[int] = range(len(tokens))
        if direction is Direction.RIGHT_TO_LEFT:
            token_indices = range(len(tokens) - 1, -1, -1)
        ordered_positions.extend((line_index, index) for index in token_indices)
    rank_by_position = {
        position: rank for rank, position in enumerate(ordered_positions)
    }
    token_count = len(ordered_positions)
    points = _sample_times(event.duration_ms, interval)
    result: list[DialogueEvent] = []

    for frame_index, (first, second) in enumerate(zip(points, points[1:])):
        visible_lines: list[str] = []
        for line_index, tokens in enumerate(token_lines):
            visible_tokens: list[str] = []
            for token_index, token in enumerate(tokens):
                rank = rank_by_position[(line_index, token_index)]
                order = rank / max(1, token_count - 1)
                if token == r"\h" or token.isspace():
                    visible_tokens.append(token)
                    continue
                entry = _stagger_entry(first, start, order, 0.74)
                exit_progress = _stagger_exit(
                    first,
                    event.duration_ms,
                    end,
                    order,
                    0.74,
                )
                resolved = entry >= 0.98 and exit_progress < 0.02
                if resolved:
                    visible_tokens.append(token)
                else:
                    rng = random.Random(
                        seed + frame_index * 104729 + rank * 1009
                    )
                    visible_tokens.append(charset[rng.randrange(len(charset))])
            visible_lines.append("".join(visible_tokens))
        rendered = leading + visible_lines[0]
        for separator, visible_line in zip(
            separators,
            visible_lines[1:],
            strict=True,
        ):
            rendered += separator + visible_line
        result.append(
            _clone(
                event,
                start_ms=event.start_ms + first,
                end_ms=event.start_ms + second,
                text=rendered,
            )
        )
    return result


# ---------------------------------------------------------------------------
# 17-26: echo and layering
# ---------------------------------------------------------------------------


def _effect_chorus_echo(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "copies", "distance", "cycles"})
    direction = _direction(
        params,
        (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT, Direction.TOP_TO_BOTTOM, Direction.BOTTOM_TO_TOP),
        Direction.BOTTOM_TO_TOP,
    )
    copies = _integer(params, "copies", 3, minimum=1, maximum=8)
    distance = _number(params, "distance", 28, minimum=1, maximum=180)
    cycles = _number(params, "cycles", 1.25, minimum=0.1, maximum=8)
    vx, vy = _direction_vector(direction)
    px, py = -vy, vx
    anchor_x, anchor_y = _event_anchor(event, context)
    result: list[DialogueEvent] = []

    for copy_index in range(copies, 0, -1):
        depth = copy_index / copies

        def state(t: float, t_ms: int, *, depth: float = depth, copy_index: int = copy_index) -> MotionState:
            presence = _presence_for_line(t_ms, event.duration_ms, start, end)
            phase = 2 * math.pi * (cycles * t - copy_index * 0.13)
            drift = distance * depth * (0.68 + 0.32 * math.sin(phase))
            side = distance * 0.16 * math.cos(phase) * depth
            visible_alpha = round(122 + 72 * depth)
            alpha = round(255 - presence * (255 - visible_alpha))
            return MotionState(
                anchor_x + vx * drift + px * side,
                anchor_y + vy * drift + py * side,
                scale_x=100 - depth * 4,
                scale_y=100 - depth * 4,
                alpha=alpha,
                primary_color="&HFFC36A&" if copy_index % 2 else "&HFF8BCE&",
                border=3,
                blur=1.5 + depth * 1.5,
            )

        result.extend(_emit_sampled_line(event, context, state, layer_offset=copy_index))
    result.append(_static_line(event, context, layer_offset=copies + 2))
    return result


def _effect_echo_tunnel(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "layers", "depth", "cycles"})
    direction = _direction(params, (Direction.INWARD, Direction.OUTWARD), Direction.INWARD)
    layers = _integer(params, "layers", 5, minimum=2, maximum=10)
    depth = _number(params, "depth", 38, minimum=2, maximum=100)
    cycles = _number(params, "cycles", 1.1, minimum=0.1, maximum=8)
    anchor_x, anchor_y = _event_anchor(event, context)
    result: list[DialogueEvent] = []
    direction_sign = -1.0 if direction is Direction.INWARD else 1.0

    for layer_index in range(layers, 0, -1):
        lane = layer_index / layers

        def state(t: float, t_ms: int, *, lane: float = lane, layer_index: int = layer_index) -> MotionState:
            presence = _presence_for_line(t_ms, event.duration_ms, start, end)
            depth_wave = 0.5 + 0.5 * math.sin(2 * math.pi * (cycles * t - lane * 0.55))
            scale = 100 + direction_sign * depth * lane * (0.62 + 0.38 * depth_wave)
            visible_alpha = round(142 + lane * 82)
            alpha = round(255 - presence * (255 - visible_alpha))
            return MotionState(
                anchor_x,
                anchor_y - direction_sign * lane * 4,
                scale_x=scale,
                scale_y=scale,
                alpha=alpha,
                primary_color="&H9AFFA6&" if layer_index % 2 else "&HFFC36A&",
                blur=0.5 + lane * 2.2,
                border=max(0.0, 3.0 - lane),
            )

        result.extend(_emit_sampled_line(event, context, state, layer_offset=layer_index))
    result.append(_static_line(event, context, layer_offset=layers + 2))
    return result


def _effect_mirror_reflection(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "bands", "gap", "shimmer"})
    direction = _direction(params, (Direction.ABOVE, Direction.BELOW), Direction.BELOW)
    bands = _integer(params, "bands", 8, minimum=2, maximum=30)
    gap = _number(params, "gap", 18, minimum=0, maximum=160)
    shimmer = _number(params, "shimmer", 10, minimum=0, maximum=80)
    anchor_x, anchor_y = _event_anchor(event, context)
    box = context.box
    side = -1.0 if direction is Direction.ABOVE else 1.0
    # Keep the reflected glyphs close to the lyric while leaving a visible gap.
    # The catalogue text box includes generous outline/shadow padding, so using
    # the full box height here makes the reflection look detached.
    reflection_y = anchor_y + side * (box.height * 0.58 + gap)
    region_top = round(reflection_y - box.height / 2)
    region_bottom = round(reflection_y + box.height / 2)
    result: list[DialogueEvent] = [_static_line(event, context, layer_offset=bands + 2)]

    for index in range(bands):
        y1 = region_top + round(box.height * index / bands)
        y2 = region_top + round(box.height * (index + 1) / bands)
        clip = _screen_rect(context, box.x1 - 60, y1, box.x2 + 60, max(y1 + 1, y2))
        if clip is None:
            continue
        distance_ratio = index / max(1, bands - 1)
        if direction is Direction.ABOVE:
            distance_ratio = 1.0 - distance_ratio

        def state(t: float, t_ms: int, *, distance_ratio: float = distance_ratio, reflection_y: float = reflection_y) -> MotionState:
            presence = _presence_for_line(t_ms, event.duration_ms, start, end)
            x_shift = shimmer * math.sin(2 * math.pi * (t * 0.8 + distance_ratio * 0.45))
            visible_alpha = round(112 + 118 * distance_ratio)
            alpha = round(255 - presence * (255 - visible_alpha))
            return MotionState(
                anchor_x + x_shift,
                reflection_y,
                scale_x=100,
                scale_y=100,
                rotation_x=180,
                alpha=alpha,
                primary_color="&HFFC36A&",
                blur=1.0 + distance_ratio * 3.0,
            )

        result.extend(
            _emit_sampled_line(
                event,
                context,
                state,
                layer_offset=index,
                step_ms=max(100, context.motion_step_ms),
                clip_fn=lambda _t, _ms, clip=clip: clip,
            )
        )
    return result


def _effect_water_reflection(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "bands", "amplitude", "cycles", "gap"})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    bands = _integer(params, "bands", 10, minimum=3, maximum=40)
    amplitude = _number(params, "amplitude", 18, minimum=1, maximum=100)
    cycles = _number(params, "cycles", 1.45, minimum=0.1, maximum=8)
    gap = _number(params, "gap", 16, minimum=0, maximum=160)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    anchor_x, anchor_y = _event_anchor(event, context)
    box = context.box
    # Keep the water reflection directly below the lyric without looking detached.
    reflection_y = anchor_y + box.height * 0.58 + gap
    region_top = round(reflection_y - box.height / 2)
    result: list[DialogueEvent] = [_static_line(event, context, layer_offset=bands + 2)]

    for index in range(bands):
        y1 = region_top + round(box.height * index / bands)
        y2 = region_top + round(box.height * (index + 1) / bands)
        clip = _screen_rect(context, box.x1 - 80, y1, box.x2 + 80, max(y1 + 1, y2))
        if clip is None:
            continue
        lane = index / max(1, bands - 1)

        def state(t: float, t_ms: int, *, lane: float = lane) -> MotionState:
            presence = _presence_for_line(t_ms, event.duration_ms, start, end)
            phase = 2 * math.pi * (cycles * t - sign * lane * 0.9)
            x_shift = amplitude * math.sin(phase) * (0.35 + lane * 0.65)
            visible_alpha = round(120 + lane * 118)
            alpha = round(255 - presence * (255 - visible_alpha))
            return MotionState(
                anchor_x + x_shift,
                reflection_y + lane * 3,
                scale_y=100,
                rotation_x=180,
                alpha=alpha,
                primary_color="&HFFC36A&",
                blur=1.2 + lane * 3.2,
            )

        result.extend(
            _emit_sampled_line(
                event,
                context,
                state,
                layer_offset=index,
                clip_fn=lambda _t, _ms, clip=clip: clip,
            )
        )
    return result


def _effect_shadow_march(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "copies", "radius", "cycles"})
    direction = _direction(params, (Direction.CLOCKWISE, Direction.COUNTERCLOCKWISE), Direction.CLOCKWISE)
    copies = _integer(params, "copies", 6, minimum=2, maximum=12)
    radius = _number(params, "radius", 14, minimum=1, maximum=100)
    cycles = _number(params, "cycles", 1.0, minimum=0.1, maximum=8)
    sign = 1.0 if direction is Direction.CLOCKWISE else -1.0
    anchor_x, anchor_y = _event_anchor(event, context)
    result: list[DialogueEvent] = []

    for index in range(copies):
        lane = index / copies

        def state(t: float, t_ms: int, *, lane: float = lane, index: int = index) -> MotionState:
            presence = _presence_for_line(t_ms, event.duration_ms, start, end)
            theta = sign * 2 * math.pi * (cycles * t + lane)
            visible_alpha = round(158 + 70 * lane)
            return MotionState(
                anchor_x + radius * math.cos(theta),
                anchor_y + radius * 0.55 * math.sin(theta),
                alpha=round(255 - presence * (255 - visible_alpha)),
                primary_color="&H101018&",
                outline_color="&H101018&",
                border=5,
                blur=2.5,
            )

        result.extend(_emit_sampled_line(event, context, state, layer_offset=index))
    result.append(_static_line(event, context, layer_offset=copies + 2))
    return result


def _effect_chromatic_orbit(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "radius", "cycles"})
    direction = _direction(params, (Direction.CLOCKWISE, Direction.COUNTERCLOCKWISE), Direction.CLOCKWISE)
    radius = _number(params, "radius", 10, minimum=1, maximum=80)
    cycles = _number(params, "cycles", 1.35, minimum=0.1, maximum=10)
    sign = 1.0 if direction is Direction.CLOCKWISE else -1.0
    anchor_x, anchor_y = _event_anchor(event, context)
    colors = ("&H3030FF&", "&HFFFF40&", "&HFF40FF&")
    result: list[DialogueEvent] = []

    for index, color in enumerate(colors):
        phase_offset = index / len(colors)

        def state(t: float, t_ms: int, *, phase_offset: float = phase_offset, color: str = color) -> MotionState:
            presence = _presence_for_line(t_ms, event.duration_ms, start, end)
            theta = sign * 2 * math.pi * (cycles * t + phase_offset)
            return MotionState(
                anchor_x + radius * math.cos(theta),
                anchor_y + radius * math.sin(theta),
                alpha=round(255 - presence * 150),
                primary_color=color,
                outline_color=color,
                border=1.5,
                blur=0.7,
            )

        result.extend(_emit_sampled_line(event, context, state, layer_offset=index))
    result.append(_static_line(event, context, layer_offset=5, border=3.5))
    return result


def _effect_parallax_chorus(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "layers", "distance", "cycles"})
    direction = _direction(
        params,
        (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT, Direction.TOP_TO_BOTTOM, Direction.BOTTOM_TO_TOP),
        Direction.BOTTOM_TO_TOP,
    )
    layers = _integer(params, "layers", 3, minimum=2, maximum=8)
    distance = _number(params, "distance", 30, minimum=1, maximum=180)
    cycles = _number(params, "cycles", 0.9, minimum=0.1, maximum=8)
    vx, vy = _direction_vector(direction)
    px, py = -vy, vx
    anchor_x, anchor_y = _event_anchor(event, context)
    result: list[DialogueEvent] = []

    for index in range(layers, 0, -1):
        depth = index / layers

        def state(t: float, t_ms: int, *, depth: float = depth, index: int = index) -> MotionState:
            presence = _presence_for_line(t_ms, event.duration_ms, start, end)
            phase = 2 * math.pi * (cycles * t * (0.65 + depth * 0.55) + depth * 0.17)
            along = distance * depth * math.sin(phase)
            cross = distance * 0.14 * depth * math.cos(phase * 0.7)
            visible_alpha = round(118 + depth * 90)
            return MotionState(
                anchor_x + vx * along + px * cross,
                anchor_y + vy * along + py * cross,
                scale_x=100 - depth * 7,
                scale_y=100 - depth * 7,
                alpha=round(255 - presence * (255 - visible_alpha)),
                primary_color="&H9AFFA6&" if index % 2 else "&HFF8BCE&",
                blur=depth * 1.6,
            )

        result.extend(_emit_sampled_line(event, context, state, layer_offset=index))
    result.append(_static_line(event, context, layer_offset=layers + 2))
    return result


def _effect_long_exposure(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "trails", "distance", "cycles"})
    direction = _direction(
        params,
        (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT, Direction.TOP_TO_BOTTOM, Direction.BOTTOM_TO_TOP),
        Direction.LEFT_TO_RIGHT,
    )
    trails = _integer(params, "trails", 6, minimum=2, maximum=14)
    distance = _number(params, "distance", 42, minimum=2, maximum=220)
    cycles = _number(params, "cycles", 1.0, minimum=0.1, maximum=8)
    vx, vy = _direction_vector(direction)
    px, py = -vy, vx
    anchor_x, anchor_y = _event_anchor(event, context)
    result: list[DialogueEvent] = []

    for index in range(trails, 0, -1):
        delay = index / trails * 0.18
        depth = index / trails

        def state(t: float, t_ms: int, *, delay: float = delay, depth: float = depth) -> MotionState:
            presence = _presence_for_line(t_ms, event.duration_ms, start, end)
            phase = 2 * math.pi * cycles * (t - delay)
            along = distance * 0.5 * math.sin(phase)
            cross = distance * 0.18 * math.sin(phase * 2) * (1.0 - depth * 0.4)
            visible_alpha = round(142 + depth * 92)
            return MotionState(
                anchor_x + vx * along + px * cross,
                anchor_y + vy * along + py * cross,
                alpha=round(255 - presence * (255 - visible_alpha)),
                primary_color="&HFFC36A&",
                blur=1 + depth * 2.8,
                scale_x=100 - depth * 2,
                scale_y=100 - depth * 2,
            )

        result.extend(_emit_sampled_line(event, context, state, layer_offset=trails - index))
    result.append(_static_line(event, context, layer_offset=trails + 2))
    return result


def _effect_call_response_duet(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "distance", "cycles"})
    direction = _direction(params, (Direction.HORIZONTAL, Direction.VERTICAL), Direction.HORIZONTAL)
    distance = _number(params, "distance", 58, minimum=2, maximum=240)
    cycles = _number(params, "cycles", 1.3, minimum=0.1, maximum=8)
    anchor_x, anchor_y = _event_anchor(event, context)
    result: list[DialogueEvent] = []

    for voice in (-1, 1):
        color = "&H4FD8FF&" if voice < 0 else "&HFF8BCE&"

        def state(t: float, t_ms: int, *, voice: int = voice, color: str = color) -> MotionState:
            presence = _presence_for_line(t_ms, event.duration_ms, start, end)
            emphasis = 0.5 + 0.5 * math.sin(2 * math.pi * cycles * t + (0 if voice < 0 else math.pi))
            if direction is Direction.HORIZONTAL:
                x, y = anchor_x + voice * distance, anchor_y
            else:
                x, y = anchor_x, anchor_y + voice * distance * 0.68
            visible_alpha = round(176 - emphasis * 110)
            scale = 92 + emphasis * 8
            return MotionState(
                x,
                y,
                scale_x=scale,
                scale_y=scale,
                alpha=round(255 - presence * (255 - visible_alpha)),
                primary_color=color,
                blur=1.2,
                border=2.5,
            )

        result.extend(_emit_sampled_line(event, context, state, layer_offset=voice + 2))
    result.append(_static_line(event, context, layer_offset=5, alpha=25))
    return result


def _effect_afterimage_wave(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "amplitude", "cycles", "trail"})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    amplitude = _number(params, "amplitude", 18, minimum=1, maximum=120)
    cycles = _number(params, "cycles", 1.55, minimum=0.1, maximum=10)
    trail = _number(params, "trail", 0.12, minimum=0.01, maximum=0.8)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    result: list[DialogueEvent] = []
    layers = (
        (2 * trail, "&HFF8BCE&", 190, 0),
        (trail, "&HFFC36A&", 145, 1),
        (0.0, None, 0, 3),
    )

    for phase_delay, color, visible_alpha, layer_offset in layers:
        def state(
            glyph: Glyph,
            t: float,
            t_ms: int,
            *,
            phase_delay: float = phase_delay,
            color: str | None = color,
            visible_alpha: int = visible_alpha,
        ) -> MotionState:
            _, _, visible = _presence(t_ms, event.duration_ms, start, end)
            phase = 2 * math.pi * (cycles * (t - phase_delay) - sign * glyph.order_ltr * 0.82)
            y = glyph.y + amplitude * math.sin(phase) * visible
            alpha = _alpha_from_presence(visible) if color is None else round(255 - visible * (255 - visible_alpha))
            return MotionState(
                glyph.x + phase_delay * 34 * sign,
                y,
                rotation_z=3.5 * math.sin(phase) * visible,
                alpha=alpha,
                primary_color=color,
                outline_color=color,
                blur=0 if color is None else 1.2,
            )

        result.extend(_emit_sampled_glyphs(event, context, state, layer_offset=layer_offset))
    return result


# ---------------------------------------------------------------------------
# 27-33: colour and material
# ---------------------------------------------------------------------------


def _moving_clip(box: Rect, direction: Direction, progress: float, size: float, *, overscan: float = 0.0) -> Rect:
    progress = _fractional(progress)
    if direction in (Direction.RIGHT_TO_LEFT, Direction.BOTTOM_TO_TOP):
        progress = 1.0 - progress
    if direction in (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT):
        centre = box.x1 - size / 2 + progress * (box.width + size)
        x1 = round(centre - size / 2)
        x2 = max(x1 + 1, round(centre + size / 2))
        return Rect(x1, round(box.y1 - overscan), x2, round(box.y2 + overscan))
    centre = box.y1 - size / 2 + progress * (box.height + size)
    y1 = round(centre - size / 2)
    y2 = max(y1 + 1, round(centre + size / 2))
    return Rect(round(box.x1 - overscan), y1, round(box.x2 + overscan), y2)


def _effect_color_wave(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "cycles", "palette"})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    cycles = _number(params, "cycles", 1.2, minimum=0.1, maximum=10)
    colors = _palette(params, "palette", _DEFAULT_PALETTE)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0

    def state(glyph: Glyph, t: float, t_ms: int) -> MotionState:
        _, _, visible = _presence(t_ms, event.duration_ms, start, end)
        color = _palette_color(colors, cycles * t - sign * glyph.order_ltr * 0.82)
        return MotionState(
            glyph.x,
            glyph.y,
            alpha=_alpha_from_presence(visible),
            primary_color=color,
        )

    return _emit_sampled_glyphs(event, context, state, step_ms=max(100, context.motion_step_ms))


def _effect_aurora_bands(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "bands", "amplitude", "cycles", "palette"})
    direction = _direction(
        params,
        (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT, Direction.TOP_TO_BOTTOM, Direction.BOTTOM_TO_TOP),
        Direction.LEFT_TO_RIGHT,
    )
    bands = _integer(params, "bands", 7, minimum=2, maximum=20)
    amplitude = _number(params, "amplitude", 12, minimum=0, maximum=100)
    cycles = _number(params, "cycles", 1.0, minimum=0.1, maximum=8)
    colors = _palette(params, "palette", _DEFAULT_PALETTE)
    anchor_x, anchor_y = _event_anchor(event, context)
    box = context.box
    horizontal = direction in (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT)
    result: list[DialogueEvent] = [_static_line(event, context, layer_offset=0, alpha=48)]
    window_size = (box.width if horizontal else box.height) / max(2.0, bands * 0.62)

    for index in range(bands):
        lane = index / bands
        color = colors[index % len(colors)]

        def state(t: float, t_ms: int, *, lane: float = lane, color: str = color) -> MotionState:
            presence = _presence_for_line(t_ms, event.duration_ms, start, end)
            phase = 2 * math.pi * (cycles * t + lane)
            if horizontal:
                x = anchor_x
                y = anchor_y + amplitude * math.sin(phase)
            else:
                x = anchor_x + amplitude * math.sin(phase)
                y = anchor_y
            return MotionState(
                x,
                y,
                alpha=round(255 - presence * 232),
                primary_color=color,
                outline_color=color,
                border=2.5,
                blur=1.4,
            )

        def clip_fn(t: float, _t_ms: int, *, lane: float = lane) -> Rect:
            return _moving_clip(box, direction, cycles * t + lane, window_size, overscan=18)

        result.extend(
            _emit_sampled_line(
                event,
                context,
                state,
                layer_offset=index + 1,
                clip_fn=clip_fn,
                step_ms=max(100, context.motion_step_ms),
            )
        )
    return result


def _effect_emboss_light(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "distance", "cycles"})
    direction = _direction(params, (Direction.CLOCKWISE, Direction.COUNTERCLOCKWISE), Direction.CLOCKWISE)
    distance = _number(params, "distance", 4.5, minimum=0.5, maximum=30)
    cycles = _number(params, "cycles", 1.1, minimum=0.1, maximum=8)
    sign = 1.0 if direction is Direction.CLOCKWISE else -1.0
    anchor_x, anchor_y = _event_anchor(event, context)
    result: list[DialogueEvent] = []

    for role, color, alpha_visible, phase_shift, layer in (
        ("shadow", "&H101018&", 72, math.pi, 0),
        ("highlight", "&HFFFFFF&", 96, 0.0, 2),
    ):
        def state(
            t: float,
            t_ms: int,
            *,
            color: str = color,
            alpha_visible: int = alpha_visible,
            phase_shift: float = phase_shift,
            role: str = role,
        ) -> MotionState:
            presence = _presence_for_line(t_ms, event.duration_ms, start, end)
            theta = sign * 2 * math.pi * cycles * t + phase_shift
            return MotionState(
                anchor_x + distance * math.cos(theta),
                anchor_y + distance * math.sin(theta),
                alpha=round(255 - presence * (255 - alpha_visible)),
                primary_color=color,
                outline_color=color,
                border=2.2 if role == "highlight" else 4.0,
                blur=0.5 if role == "highlight" else 1.8,
            )

        result.extend(_emit_sampled_line(event, context, state, layer_offset=layer))
    result.append(_static_line(event, context, layer_offset=4, color="&HE8E8E8&", border=2.5))
    return result


def _effect_glass_refraction(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "slices", "offset", "cycles"})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    slices = _integer(params, "slices", 7, minimum=3, maximum=30)
    offset = _number(params, "offset", 12, minimum=1, maximum=100)
    cycles = _number(params, "cycles", 1.25, minimum=0.1, maximum=8)
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    anchor_x, anchor_y = _event_anchor(event, context)
    box = context.box
    result: list[DialogueEvent] = [_static_line(event, context, layer_offset=0, alpha=46)]

    for index in range(slices):
        y1 = box.y1 + round(box.height * index / slices)
        y2 = box.y1 + round(box.height * (index + 1) / slices)
        clip = Rect(box.x1 - 40, y1, box.x2 + 40, max(y1 + 1, y2))
        lane_sign = -1.0 if index % 2 == 0 else 1.0
        lane = index / max(1, slices - 1)
        color = "&HFFC36A&" if index % 2 == 0 else "&HFF8BCE&"

        def state(
            t: float,
            t_ms: int,
            *,
            lane_sign: float = lane_sign,
            lane: float = lane,
            color: str = color,
        ) -> MotionState:
            presence = _presence_for_line(t_ms, event.duration_ms, start, end)
            shift = sign * lane_sign * offset * math.sin(2 * math.pi * (cycles * t + lane * 0.33))
            return MotionState(
                anchor_x + shift,
                anchor_y,
                shear_x=sign * lane_sign * 0.025,
                alpha=round(255 - presence * 224),
                primary_color=color,
                blur=0.7,
            )

        result.extend(
            _emit_sampled_line(
                event,
                context,
                state,
                layer_offset=index + 1,
                clip_fn=lambda _t, _ms, clip=clip: clip,
            )
        )
    return result


def _effect_metallic_shimmer(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "width", "cycles", "color"})
    direction = _direction(
        params,
        (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT, Direction.TOP_TO_BOTTOM, Direction.BOTTOM_TO_TOP),
        Direction.LEFT_TO_RIGHT,
    )
    width = _number(params, "width", 105, minimum=10, maximum=600)
    cycles = _number(params, "cycles", 1.15, minimum=0.1, maximum=8)
    color = _ass_color(params.get("color", "&HFFFFFF&"))
    anchor_x, anchor_y = _event_anchor(event, context)
    box = context.box
    result: list[DialogueEvent] = [_static_line(event, context, layer_offset=0, color="&HC8C8C8&")]

    for band_index, factor in enumerate((1.8, 0.72), start=1):
        local_width = width * factor

        def state(t: float, t_ms: int, *, band_index: int = band_index) -> MotionState:
            presence = _presence_for_line(t_ms, event.duration_ms, start, end)
            visible_alpha = 138 if band_index == 1 else 25
            return MotionState(
                anchor_x,
                anchor_y,
                alpha=round(255 - presence * (255 - visible_alpha)),
                primary_color=color,
                outline_color=color,
                border=2.5,
                blur=4.5 if band_index == 1 else 0.8,
            )

        def clip_fn(t: float, _t_ms: int, *, local_width: float = local_width) -> Rect:
            return _moving_clip(box, direction, cycles * t, local_width, overscan=25)

        result.extend(
            _emit_sampled_line(
                event,
                context,
                state,
                layer_offset=band_index,
                clip_fn=clip_fn,
                step_ms=max(80, context.motion_step_ms),
            )
        )
    return result


def _effect_color_pingpong(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"phase", "cycles", "color_a", "color_b"})
    phase_choice = _phase(params, (Phase.ODD_FIRST, Phase.EVEN_FIRST), Phase.ODD_FIRST)
    cycles = _number(params, "cycles", 1.5, minimum=0.1, maximum=10)
    color_a = _ass_color(params.get("color_a", "&H4FD8FF&"), "color_a")
    color_b = _ass_color(params.get("color_b", "&HFF8BCE&"), "color_b")
    first_parity = 0 if phase_choice is Phase.ODD_FIRST else 1

    def state(glyph: Glyph, t: float, t_ms: int) -> MotionState:
        _, _, visible = _presence(t_ms, event.duration_ms, start, end)
        parity_phase = 0.0 if glyph.index % 2 == first_parity else 0.5
        blend = 0.5 + 0.5 * math.sin(2 * math.pi * (cycles * t + parity_phase))
        return MotionState(
            glyph.x,
            glyph.y,
            scale_x=100 + 4 * blend,
            scale_y=100 + 4 * blend,
            alpha=_alpha_from_presence(visible),
            primary_color=_lerp_color(color_a, color_b, blend),
        )

    return _emit_sampled_glyphs(event, context, state, step_ms=max(100, context.motion_step_ms))


def _effect_spotlight_lens(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "width", "scale", "cycles"})
    direction = _direction(
        params,
        (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT, Direction.TOP_TO_BOTTOM, Direction.BOTTOM_TO_TOP),
        Direction.LEFT_TO_RIGHT,
    )
    width = _number(params, "width", 230, minimum=20, maximum=900)
    scale = _number(params, "scale", 106, minimum=100, maximum=150)
    cycles = _number(params, "cycles", 1.0, minimum=0.1, maximum=8)
    anchor_x, anchor_y = _event_anchor(event, context)
    box = context.box
    result: list[DialogueEvent] = [
        _static_line(event, context, layer_offset=0, alpha=92, color="&H8A8A92&", border=3)
    ]

    def state(t: float, t_ms: int) -> MotionState:
        presence = _presence_for_line(t_ms, event.duration_ms, start, end)
        return MotionState(
            anchor_x,
            anchor_y,
            scale_x=scale,
            scale_y=scale,
            alpha=round(255 - presence * 255),
            primary_color="&HFFFFFF&",
            outline_color="&H4FD8FF&",
            border=4,
            blur=0.5,
        )

    def clip_fn(t: float, _t_ms: int) -> Rect:
        return _moving_clip(box, direction, cycles * t, width, overscan=28)

    result.extend(
        _emit_sampled_line(
            event,
            context,
            state,
            layer_offset=2,
            clip_fn=clip_fn,
            step_ms=max(80, context.motion_step_ms),
        )
    )
    return result


# ---------------------------------------------------------------------------
# 34-38: lyric support graphics
# ---------------------------------------------------------------------------


def _bracket_paths(box: Rect, orientation: Direction) -> tuple[str, str, tuple[float, float], tuple[float, float]]:
    thickness = max(3, round(min(box.width, box.height) * 0.035))
    if orientation is Direction.HORIZONTAL:
        height = max(30, round(box.height * 0.62))
        arm = max(14, round(box.width * 0.045))
        half = height // 2
        left = (
            f"m 0 {-half} l {thickness} {-half} {thickness} {half} 0 {half} "
            f"m 0 {-half} l {arm} {-half} {arm} {-half + thickness} 0 {-half + thickness} "
            f"m 0 {half - thickness} l {arm} {half - thickness} {arm} {half} 0 {half}"
        )
        right = (
            f"m {-thickness} {-half} l 0 {-half} 0 {half} {-thickness} {half} "
            f"m {-arm} {-half} l 0 {-half} 0 {-half + thickness} {-arm} {-half + thickness} "
            f"m {-arm} {half - thickness} l 0 {half - thickness} 0 {half} {-arm} {half}"
        )
        return left, right, (box.x1, (box.y1 + box.y2) / 2), (box.x2, (box.y1 + box.y2) / 2)
    width = max(60, round(box.width * 0.46))
    arm = max(14, round(box.height * 0.14))
    half = width // 2
    top = (
        f"m {-half} 0 l {half} 0 {half} {thickness} {-half} {thickness} "
        f"m {-half} 0 l {-half + thickness} 0 {-half + thickness} {arm} {-half} {arm} "
        f"m {half - thickness} 0 l {half} 0 {half} {arm} {half - thickness} {arm}"
    )
    bottom = (
        f"m {-half} {-thickness} l {half} {-thickness} {half} 0 {-half} 0 "
        f"m {-half} {-arm} l {-half + thickness} {-arm} {-half + thickness} 0 {-half} 0 "
        f"m {half - thickness} {-arm} l {half} {-arm} {half} 0 {half - thickness} 0"
    )
    return top, bottom, ((box.x1 + box.x2) / 2, box.y1), ((box.x1 + box.x2) / 2, box.y2)


def _effect_bracket_embrace(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "distance", "breath", "cycles"})
    direction = _direction(params, (Direction.HORIZONTAL, Direction.VERTICAL), Direction.HORIZONTAL)
    distance = _number(params, "distance", 74, minimum=1, maximum=300)
    breath = _number(params, "breath", 9, minimum=0, maximum=80)
    cycles = _number(params, "cycles", 1.15, minimum=0.1, maximum=8)
    box = context.box
    path_a, path_b, base_a, base_b = _bracket_paths(box, direction)
    points = _sample_times(event.duration_ms, context.motion_step_ms)
    result: list[DialogueEvent] = [_static_line(event, context, layer_offset=3)]

    for first, second in zip(points, points[1:]):
        positions: list[tuple[str, tuple[float, float], int]] = []
        for path, base, side in ((path_a, base_a, -1), (path_b, base_b, 1)):
            def position(t_ms: int, *, base: tuple[float, float] = base, side: int = side) -> tuple[float, float]:
                presence = _presence_for_line(t_ms, event.duration_ms, start, end)
                t = _periodic_time(t_ms)
                extra = distance * (1.0 - presence) + breath * math.sin(2 * math.pi * cycles * t) * presence
                if direction is Direction.HORIZONTAL:
                    return base[0] + side * extra, base[1]
                return base[0], base[1] + side * extra

            x0, y0 = position(first)
            x1, y1 = position(second)
            segment = second - first
            presence0 = _presence_for_line(first, event.duration_ms, start, end)
            tags = (
                rf"\an7\move({_fmt(x0)},{_fmt(y0)},{_fmt(x1)},{_fmt(y1)},0,{segment})"
                rf"\1a{_format_alpha(round(255 - presence0 * 238))}\1c&H4FD8FF&"
                r"\bord0\blur1.2"
            )
            result.append(_drawing_event(event, first, second, path, tags, layer_offset=1))
    return result


def _ellipse_path(rx: int, ry: int) -> str:
    kx = round(rx * 0.5522848)
    ky = round(ry * 0.5522848)
    return (
        f"m {-rx} 0 "
        f"b {-rx} {-ky} {-kx} {-ry} 0 {-ry} "
        f"b {kx} {-ry} {rx} {-ky} {rx} 0 "
        f"b {rx} {ky} {kx} {ry} 0 {ry} "
        f"b {-kx} {ry} {-rx} {ky} {-rx} 0"
    )


def _ellipse_path_at(cx: float, cy: float, rx: int, ry: int) -> str:
    kx = round(rx * 0.5522848)
    ky = round(ry * 0.5522848)
    x = round(cx)
    y = round(cy)
    return (
        f"m {x - rx} {y} "
        f"b {x - rx} {y - ky} {x - kx} {y - ry} {x} {y - ry} "
        f"b {x + kx} {y - ry} {x + rx} {y - ky} {x + rx} {y} "
        f"b {x + rx} {y + ky} {x + kx} {y + ry} {x} {y + ry} "
        f"b {x - kx} {y + ry} {x - rx} {y + ky} {x - rx} {y}"
    )


def _effect_halo_rings(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "rings", "cycles", "max_scale"})
    direction = _direction(params, (Direction.CENTER_OUT, Direction.EDGES_IN), Direction.CENTER_OUT)
    rings = _integer(params, "rings", 4, minimum=2, maximum=10)
    cycles = _number(params, "cycles", 1.0, minimum=0.1, maximum=6)
    max_scale = _number(params, "max_scale", 138, minimum=105, maximum=300)
    box = context.box
    anchor_x, anchor_y = _event_anchor(event, context)
    base_rx = max(20, round(box.width / 2 + 20))
    base_ry = max(12, round(box.height / 2 + 12))
    points = _sample_times(event.duration_ms, context.motion_step_ms)
    result: list[DialogueEvent] = [_static_line(event, context, layer_offset=rings + 2)]

    for ring_index in range(rings):
        offset = ring_index / rings
        color = _DEFAULT_PALETTE[ring_index % len(_DEFAULT_PALETTE)]
        for first, second in zip(points, points[1:]):
            mid = (first + second) / 2
            presence = _presence_for_line(round(mid), event.duration_ms, start, end)
            phase = _fractional(cycles * _periodic_time(mid) + offset)
            if direction is Direction.EDGES_IN:
                phase = 1.0 - phase
            scale = 0.68 + (max_scale / 100 - 0.68) * phase
            rx = max(2, round(base_rx * scale))
            ry = max(2, round(base_ry * scale))
            pulse_alpha = round(42 + 205 * abs(phase - 0.5) * 2)
            alpha = round(255 - presence * (255 - pulse_alpha))
            path = _ellipse_path_at(anchor_x, anchor_y, rx, ry)
            tags = (
                rf"\an7\pos(0,0)\1a&HFF&\3a{_format_alpha(alpha)}"
                rf"\1c{color}\3c{color}\bord3\blur1.8"
            )
            result.append(_drawing_event(event, first, second, path, tags, layer_offset=ring_index))
    return result


def _effect_equalizer_bed(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "bars", "height", "cycles", "seed"})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    bars = _integer(params, "bars", 18, minimum=4, maximum=48)
    height = _number(params, "height", 48, minimum=5, maximum=180)
    cycles = _number(params, "cycles", 1.7, minimum=0.1, maximum=10)
    seed = _integer(params, "seed", 3701, minimum=0, maximum=2**31 - 1)
    box = context.box
    sign = 1.0 if direction is Direction.LEFT_TO_RIGHT else -1.0
    gap = max(2.0, box.width * 0.008)
    bar_width = max(2.0, (box.width - gap * (bars - 1)) / bars)
    baseline = box.y2 + 45
    points = _sample_times(event.duration_ms, max(80, context.motion_step_ms))
    result: list[DialogueEvent] = [_static_line(event, context, layer_offset=2)]

    for first, second in zip(points, points[1:]):
        t = _periodic_time((first + second) / 2)
        presence = _presence_for_line((first + second) // 2, event.duration_ms, start, end)
        alpha = _format_alpha(round(255 - presence * 220))
        for index in range(bars):
            lane = index / max(1, bars - 1)
            jitter = 0.72 + _seed_value(seed, index) * 0.45
            wave = 0.18 + 0.82 * abs(math.sin(2 * math.pi * (cycles * t - sign * lane * 0.72 + _seed_value(seed, index, 1) * 0.18)))
            current_height = max(2, round(height * wave * jitter))
            x1 = round(box.x1 + index * (bar_width + gap))
            x2 = max(x1 + 1, round(x1 + bar_width))
            rect = Rect(x1, round(baseline - current_height), x2, round(baseline))
            color = _DEFAULT_PALETTE[index % len(_DEFAULT_PALETTE)]
            tags = rf"\an7\pos(0,0)\bord0\1c{color}\1a{alpha}\blur0.8"
            result.append(_drawing_event(event, first, second, _rect_path(rect), tags, layer_offset=1))
    return result


def _star_path(outer: int = 9, inner: int = 4, points: int = 4) -> str:
    coords: list[tuple[int, int]] = []
    for index in range(points * 2):
        radius = outer if index % 2 == 0 else inner
        angle = -math.pi / 2 + index * math.pi / points
        coords.append((round(radius * math.cos(angle)), round(radius * math.sin(angle))))
    commands = [f"m {coords[0][0]} {coords[0][1]} l"]
    commands.extend(f"{x} {y}" for x, y in coords[1:])
    return " ".join(commands)


def _effect_constellation_sparks(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "count", "radius", "seed", "cycles"})
    direction = _direction(params, (Direction.LEFT_TO_RIGHT, Direction.RIGHT_TO_LEFT), Direction.LEFT_TO_RIGHT)
    count = _integer(params, "count", 16, minimum=4, maximum=60)
    radius = _number(params, "radius", 56, minimum=10, maximum=220)
    seed = _integer(params, "seed", 3803, minimum=0, maximum=2**31 - 1)
    cycles = _number(params, "cycles", 1.25, minimum=0.1, maximum=6)
    box = context.box
    path = _star_path()
    result: list[DialogueEvent] = [_static_line(event, context, layer_offset=3)]
    period = _LYRIC40_CATALOG_MOTION_REFERENCE_MS / max(1.0, cycles)
    pulse_count = max(1, math.ceil(event.duration_ms / period))

    sparks: list[tuple[float, float, float]] = []
    for index in range(count):
        x = box.x1 + _seed_value(seed, index) * box.width
        above = _seed_value(seed, index, 1) < 0.5
        y = (box.y1 - _seed_value(seed, index, 2) * radius) if above else (box.y2 + _seed_value(seed, index, 2) * radius)
        order = (x - box.x1) / max(1, box.width)
        if direction is Direction.RIGHT_TO_LEFT:
            order = 1.0 - order
        sparks.append((x, y, order))

    for index, (x, y, order) in enumerate(sparks):
        for pulse_index in range(pulse_count + 1):
            centre = (pulse_index + order) * period
            begin = max(0, round(centre - 170))
            finish = min(event.duration_ms, round(centre + 260))
            if finish - begin < 30:
                continue
            local_peak = max(20, min(finish - begin - 10, round((centre - begin))))
            color = _DEFAULT_PALETTE[index % len(_DEFAULT_PALETTE)]
            tags = (
                rf"\an5\pos({_fmt(x)},{_fmt(y)})\fscx45\fscy45\frz{index * 23 % 360}"
                rf"\1c{color}\3c&HFFFFFF&\bord1.5\blur1\alpha&HFF&"
                rf"\t(0,{local_peak},\fscx150\fscy150\alpha&H12&)"
                rf"\t({local_peak},{finish - begin},\fscx70\fscy70\alpha&HFF&)"
            )
            result.append(_drawing_event(event, begin, finish, path, tags, layer_offset=1))
    return result


def _effect_pulse_frame(
    event: DialogueEvent, start: int, end: int, params: Mapping[str, Any], context: EffectContext
) -> list[DialogueEvent]:
    _validate_param_names(params, {"direction", "padding", "thickness", "cycles"})
    direction = _direction(params, (Direction.CLOCKWISE, Direction.COUNTERCLOCKWISE), Direction.CLOCKWISE)
    padding = _number(params, "padding", 30, minimum=2, maximum=160)
    thickness = _number(params, "thickness", 4, minimum=1, maximum=24)
    cycles = _number(params, "cycles", 1.25, minimum=0.1, maximum=8)
    box = context.box
    frame = Rect(round(box.x1 - padding), round(box.y1 - padding), round(box.x2 + padding), round(box.y2 + padding))
    side_rects = (
        _line_rect(frame.x1, frame.y1, frame.x2, frame.y1, thickness),
        _line_rect(frame.x2, frame.y1, frame.x2, frame.y2, thickness),
        _line_rect(frame.x1, frame.y2, frame.x2, frame.y2, thickness),
        _line_rect(frame.x1, frame.y1, frame.x1, frame.y2, thickness),
    )
    if direction is Direction.COUNTERCLOCKWISE:
        side_rects = (side_rects[0], side_rects[3], side_rects[2], side_rects[1])
    points = _sample_times(event.duration_ms, max(80, context.motion_step_ms))
    result: list[DialogueEvent] = [_static_line(event, context, layer_offset=3)]

    for first, second in zip(points, points[1:]):
        t = _periodic_time((first + second) / 2)
        presence = _presence_for_line((first + second) // 2, event.duration_ms, start, end)
        for index, rect in enumerate(side_rects):
            pulse = max(0.0, math.sin(2 * math.pi * (cycles * t - index / 4))) ** 7
            visible_alpha = round(214 - 206 * pulse)
            alpha = round(255 - presence * (255 - visible_alpha))
            color = _DEFAULT_PALETTE[index % len(_DEFAULT_PALETTE)]
            tags = rf"\an7\pos(0,0)\bord0\1c{color}\1a{_format_alpha(alpha)}\blur{_fmt(1 + pulse * 4)}"
            result.append(_drawing_event(event, first, second, _rect_path(rect), tags, layer_offset=1))
    return result


_HANDLERS: dict[
    Effect,
    Callable[[DialogueEvent, int, int, Mapping[str, Any], EffectContext], list[DialogueEvent]],
] = {
    Effect.BASELINE_WAVE: _effect_baseline_wave,
    Effect.SIDEWIND: _effect_sidewind,
    Effect.PENDULUM_ROW: _effect_pendulum_row,
    Effect.DOMINO_SETTLE: _effect_domino_settle,
    Effect.LETTER_RAIN: _effect_letter_rain,
    Effect.BUBBLE_RISE: _effect_bubble_rise,
    Effect.CENTER_RIPPLE: _effect_center_ripple,
    Effect.EDGE_KNOCK: _effect_edge_knock,
    Effect.ORBIT_ASSEMBLE: _effect_orbit_assemble,
    Effect.WEAVE_CROSS: _effect_weave_cross,
    Effect.STAIRCASE_FLATTEN: _effect_staircase_flatten,
    Effect.FAN_SPREAD: _effect_fan_spread,
    Effect.TWIN_LANE_MERGE: _effect_twin_lane_merge,
    Effect.MAGNET_REPEL: _effect_magnet_repel,
    Effect.CHARACTER_PULSE_TRAIN: _effect_character_pulse_train,
    Effect.SCRAMBLE_RESOLVE: _effect_scramble_resolve,
    Effect.CHORUS_ECHO: _effect_chorus_echo,
    Effect.ECHO_TUNNEL: _effect_echo_tunnel,
    Effect.MIRROR_REFLECTION: _effect_mirror_reflection,
    Effect.WATER_REFLECTION: _effect_water_reflection,
    Effect.SHADOW_MARCH: _effect_shadow_march,
    Effect.CHROMATIC_ORBIT: _effect_chromatic_orbit,
    Effect.PARALLAX_CHORUS: _effect_parallax_chorus,
    Effect.LONG_EXPOSURE: _effect_long_exposure,
    Effect.CALL_RESPONSE_DUET: _effect_call_response_duet,
    Effect.AFTERIMAGE_WAVE: _effect_afterimage_wave,
    Effect.COLOR_WAVE: _effect_color_wave,
    Effect.AURORA_BANDS: _effect_aurora_bands,
    Effect.EMBOSS_LIGHT: _effect_emboss_light,
    Effect.GLASS_REFRACTION: _effect_glass_refraction,
    Effect.METALLIC_SHIMMER: _effect_metallic_shimmer,
    Effect.COLOR_PINGPONG: _effect_color_pingpong,
    Effect.SPOTLIGHT_LENS: _effect_spotlight_lens,
    Effect.BRACKET_EMBRACE: _effect_bracket_embrace,
    Effect.HALO_RINGS: _effect_halo_rings,
    Effect.EQUALIZER_BED: _effect_equalizer_bed,
    Effect.CONSTELLATION_SPARKS: _effect_constellation_sparks,
    Effect.PULSE_FRAME: _effect_pulse_frame,
}


def _external_handler(effect_id: str, *, natural: bool) -> Callable[
    [DialogueEvent, int, int, Mapping[str, Any], EffectContext],
    list[DialogueEvent],
]:
    renderer = _decorate_natural if natural else _decorate_legacy

    def render(
        event: DialogueEvent,
        start: int,
        end: int,
        params: Mapping[str, Any],
        context: EffectContext,
    ) -> list[DialogueEvent]:
        try:
            lines = renderer(
                effect_id,
                event.format(),
                start,
                end,
                params=params,
                context=context,
            )
        except _AdapterParameterError as exc:
            raise EffectParameterError(str(exc)) from exc
        except _AdapterInputError as exc:
            raise EffectError(str(exc)) from exc
        return [parse_dialogue(line) for line in lines]

    return render


for _effect_id in LEGACY23_IDS:
    _HANDLERS[Effect(_effect_id)] = _external_handler(_effect_id, natural=False)
for _effect_id in NATURAL36_IDS:
    _HANDLERS[Effect(_effect_id)] = _external_handler(_effect_id, natural=True)


def decorate_dialogue(
    dialogue_line: str,
    start_duration_ms: int,
    end_duration_ms: int,
    effect: Effect | str | int,
    *,
    params: Mapping[str, Any] | None = None,
    context: EffectContext | None = None,
) -> list[str]:
    """Apply one of the merged autonomous lyric effects to a Dialogue event.

    No syllable timing, beat timing, audio analysis, or karaoke timing is
    consumed.  ``start_duration_ms`` and ``end_duration_ms`` only control the
    effect's autonomous introduction and conclusion envelopes.
    """

    event = parse_dialogue(dialogue_line)
    if isinstance(start_duration_ms, bool) or not isinstance(start_duration_ms, int):
        raise EffectParameterError("start_duration_ms must be an integer")
    if isinstance(end_duration_ms, bool) or not isinstance(end_duration_ms, int):
        raise EffectParameterError("end_duration_ms must be an integer")
    if start_duration_ms < 0 or end_duration_ms < 0:
        raise EffectParameterError("effect durations must be non-negative")
    if start_duration_ms + end_duration_ms > event.duration_ms:
        raise EffectParameterError(
            "start_duration_ms + end_duration_ms must not exceed "
            f"the Dialogue duration ({event.duration_ms} ms)"
        )
    selected = _coerce_effect(effect)
    effect_params = _coerce_params(params)
    if selected in CONTEXT_REQUIRED_EFFECTS and context is None:
        raise EffectParameterError(
            f"effect '{selected.value}' requires an explicit EffectContext "
            "because a Dialogue line does not contain PlayRes, anchor, or "
            "rendered lyric bounds"
        )
    render_context = context or EffectContext()

    if _CONFLICT_RE.search(event.text):
        message = (
            "input Dialogue already contains a dynamic tag "
            "(fad/fade/t/move/clip/karaoke); pass a cut-in/cut-out line "
            "containing only static tags"
        )
        if render_context.strict:
            raise EffectError(message)

    line_local_inputs = (
        _line_local_events(event, render_context)
        if selected in LINE_LAYOUT_MULTILINE_EFFECTS
        else None
    )
    if line_local_inputs is None:
        generated = _HANDLERS[selected](
            event,
            start_duration_ms,
            end_duration_ms,
            effect_params,
            render_context,
        )
    else:
        generated = []
        for line_event, line_context in line_local_inputs:
            generated.extend(
                _HANDLERS[selected](
                    line_event,
                    start_duration_ms,
                    end_duration_ms,
                    effect_params,
                    line_context,
                )
            )
    if not generated:
        raise EffectError("effect produced no Dialogue events")
    return [item.format() for item in generated]


if len(Effect) != 97:
    raise RuntimeError(f"expected 97 effects, found {len(Effect)}")
if set(EFFECT_SPECS) != set(Effect):
    raise RuntimeError("EFFECT_SPECS must cover every Effect")
if set(_HANDLERS) != set(Effect):
    raise RuntimeError("_HANDLERS must cover every Effect")
