"""JSON-safe effect catalogue and event-cost estimation.

This module intentionally depends only on the public metadata in ``core``.
The package root re-exports these objects after the v3 package-directory
rename; keeping the implementation here lets that move remain mechanical.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from enum import Enum
import math
from typing import Any

from .core import (
    CATALOG_EFFECT_ORDER,
    DEFAULT_PARAMS,
    EFFECT_DISPLAY_NUMBERS,
    EFFECT_FAMILIES,
    EFFECT_LOCAL_NUMBERS,
    EFFECT_SPECS,
    EFFECT_TRAITS,
    LINE_LAYOUT_MULTILINE_EFFECTS,
    SEQUENTIAL_MULTILINE_EFFECTS,
    Effect,
)
from .stable_ids import EFFECT_ID_SCHEMA_VERSION, PERSISTENT_EFFECT_IDS
from ._version import __version__


CATALOG_SCHEMA_VERSION = "1.0"

PAGES_BASE_URL = "https://mokusatsu.github.io/ASS_Lyric_Effects/"
CATALOG_PAGE_URL_EN = f"{PAGES_BASE_URL}CATALOG_INDEX.html"
CATALOG_PAGE_URL_JA = f"{PAGES_BASE_URL}CATALOG_INDEX.ja.html"

STRICT_INPUT_TAGS = ("fad", "fade", "t", "move", "clip", "iclip", "k", "K", "kf", "ko")
STRICT_INPUT_TAGS_CONTRACT = {
    "policy": "reject",
    "when": "context.strict is true",
    "tags": list(STRICT_INPUT_TAGS),
    "reason_en": "The decorator requires a cut-in/cut-out line containing only static tags.",
    "reason_ja": "デコレーターは静的タグだけを含むカットイン／カットアウト行を入力とします。",
}

SEQUENTIAL_LINE_EFFECT_IDS = frozenset(
    effect.value for effect in SEQUENTIAL_MULTILINE_EFFECTS
)
LINE_LOCAL_SHARED_TIMELINE_EFFECT_IDS = frozenset(
    effect.value for effect in LINE_LAYOUT_MULTILINE_EFFECTS
)


class EventBudgetExceededError(ValueError):
    """Raised when a caller-supplied event budget is exceeded."""

    def __init__(self, effect_id: str, estimated_events: int, budget: int) -> None:
        self.effect_id = effect_id
        self.estimated_events = estimated_events
        self.budget = budget
        super().__init__(
            f"estimated event count {estimated_events} for {effect_id!r} exceeds budget {budget}"
        )


def _json_safe(value: Any) -> Any:
    if isinstance(value, Enum):
        return _json_safe(value.value)
    if isinstance(value, Mapping):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (tuple, list, set, frozenset)):
        return [_json_safe(item) for item in value]
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    raise TypeError(f"catalog value is not JSON-safe: {type(value).__name__}")


_PARAMETER_LABELS_JA = {
    "direction": "方向",
    "phase": "位相",
    "seed": "乱数シード",
    "color": "色",
    "color_a": "色A",
    "color_b": "色B",
    "palette": "カラーパレット",
    "cycles": "周期数",
    "interval_ms": "更新間隔（ミリ秒）",
    "amplitude": "振幅",
    "distance": "距離",
    "radius": "半径",
    "height": "高さ",
    "width": "幅",
    "layers": "レイヤー数",
    "copies": "複製数",
    "bands": "帯数",
    "scale": "拡大率",
    "stagger": "時間差",
    "speed": "速度",
    "amount": "量",
    "angle": "角度",
    "degrees": "角度",
    "tilt": "傾き",
    "lift": "持ち上げ量",
    "rise": "上昇量",
    "drift": "漂流量",
    "sway": "揺れ幅",
    "turns": "回転数",
    "charset": "置換文字集合",
    "spacing": "文字間隔",
    "border": "境界幅",
    "blur": "ぼかし量",
    "softness_ms": "柔らかさ（ミリ秒）",
    "min_scale": "最小拡大率",
    "overshoot": "オーバーシュート",
    "peak": "ピーク",
    "valley": "谷",
    "rebound": "反発",
    "steps": "ステップ数",
    "slices": "分割数",
    "columns": "列数",
    "rows": "行数",
    "intensity": "強度",
    "count": "個数",
    "density": "密度",
    "thickness": "太さ",
    "opacity": "不透明度",
    "padding": "余白",
    "arc": "弧の角度",
    "bars": "バー数",
    "beads": "水滴数",
    "beams": "光線数",
    "bounce": "跳ね返り量",
    "branches": "枝数",
    "breath": "呼吸幅",
    "channels": "流路数",
    "cloud_layers": "雲レイヤー数",
    "cloudlets": "小雲数",
    "clouds": "雲数",
    "corona_rays": "コロナ光線数",
    "cracks": "亀裂数",
    "crest": "波頭の高さ",
    "cross": "交差量",
    "crystals": "結晶数",
    "debris": "破片数",
    "depth": "奥行き",
    "displacement": "変位量",
    "distortion": "歪み量",
    "dust": "光塵数",
    "embers": "火の粉数",
    "far_flakes": "遠景雪片数",
    "fireflies": "蛍数",
    "flares": "フレア数",
    "foam": "泡数",
    "gap": "間隔",
    "glints": "反射光数",
    "glow_layers": "発光レイヤー数",
    "glow_radius": "発光半径",
    "grains": "砂粒数",
    "grass_blades": "草葉数",
    "ground_swirl": "地表の渦数",
    "gust_bands": "突風帯数",
    "gusts": "突風数",
    "impacts": "衝突数",
    "leaves": "葉数",
    "level": "水位",
    "max_scale": "最大拡大率",
    "meteors": "流星数",
    "mist": "霧粒数",
    "mist_bands": "霧帯数",
    "near_flakes": "近景雪片数",
    "offset": "ずれ量",
    "opening": "開口幅",
    "particles": "粒子数",
    "pellets": "氷粒数",
    "petals": "花びら数",
    "phase_spread": "位相差",
    "pillars": "光柱数",
    "powder": "粉雪量",
    "radiant_spread": "放射点の広がり",
    "rays": "光線数",
    "reach": "到達距離",
    "ribbons": "流線数",
    "ring_scale": "リング拡大率",
    "rings": "リング数",
    "ripples": "波紋数",
    "seeds": "浮遊種子数",
    "shards": "破片数",
    "shimmer": "きらめき量",
    "slant": "傾斜量",
    "smoke_bands": "煙帯数",
    "sparkle_cycles": "きらめき周期数",
    "sparkles": "きらめき数",
    "sparks": "火花数",
    "splashes": "飛沫数",
    "spray": "水しぶき数",
    "stars": "星数",
    "step_height": "段差",
    "streaks": "軌跡数",
    "streamlines": "流線数",
    "streams": "水流数",
    "surge": "うねり量",
    "trail": "残像間隔",
    "trails": "残像数",
    "tumble": "回転数",
    "wave_layers": "波レイヤー数",
    "wavelength": "波長",
    "whiteout": "ホワイトアウト強度",
    "wisps": "揺らぎ数",
}


_CHOICE_LABELS: dict[str, tuple[str, str]] = {
    "above": ("Above", "上"),
    "below": ("Below", "下"),
    "bottom_to_top": ("Bottom to top", "下から上"),
    "center_out": ("Center outward", "中央から外側"),
    "clockwise": ("Clockwise", "時計回り"),
    "counterclockwise": ("Counterclockwise", "反時計回り"),
    "edges_in": ("Edges inward", "両端から中央"),
    "even_first": ("Even characters first", "偶数文字から"),
    "horizontal": ("Horizontal", "水平"),
    "inward": ("Inward", "内向き"),
    "left_to_right": ("Left to right", "左から右"),
    "odd_first": ("Odd characters first", "奇数文字から"),
    "outward": ("Outward", "外向き"),
    "right_to_left": ("Right to left", "右から左"),
    "top_to_bottom": ("Top to bottom", "上から下"),
    "vertical": ("Vertical", "垂直"),
}


# Validator bounds mirrored from the three engines.  Tests below exercise
# representative minima/maxima; a future engine cleanup should make this
# table the validator input as well as the public schema source.
_NUMERIC_CONSTRAINTS = {('afterimage_wave', 'amplitude'): ('number', 1, 120),
 ('afterimage_wave', 'cycles'): ('number', 0.1, 10),
 ('afterimage_wave', 'trail'): ('number', 0.01, 0.8),
 ('aurora_bands', 'amplitude'): ('number', 0, 100),
 ('aurora_bands', 'bands'): ('integer', 2, 20),
 ('aurora_bands', 'cycles'): ('number', 0.1, 8),
 ('avalanche', 'debris'): ('integer', 5, 60),
 ('avalanche', 'distance'): ('number', 300, 2800),
 ('avalanche', 'powder'): ('integer', 8, 80),
 ('avalanche', 'seed'): ('integer', 0, 2147483647),
 ('baseline_wave', 'amplitude'): ('number', 1, 160),
 ('baseline_wave', 'cycles'): ('number', 0.1, 12),
 ('baseline_wave', 'phase_spread'): ('number', 0, 4),
 ('bioluminescent_tide', 'foam'): ('integer', 6, 70),
 ('bioluminescent_tide', 'seed'): ('integer', 0, 2147483647),
 ('bioluminescent_tide', 'sparks'): ('integer', 12, 100),
 ('bioluminescent_tide', 'wave_layers'): ('integer', 2, 6),
 ('blizzard_whiteout', 'gust_bands'): ('integer', 2, 10),
 ('blizzard_whiteout', 'seed'): ('integer', 0, 2147483647),
 ('blizzard_whiteout', 'streaks'): ('integer', 20, 180),
 ('blizzard_whiteout', 'whiteout'): ('integer', 10, 90),
 ('blur', 'radius'): ('number', 0.1, 100),
 ('bounce', 'peak'): ('number', 105, 220),
 ('bounce', 'rebound'): ('number', 101, 160),
 ('bounce', 'valley'): ('number', 40, 99),
 ('bracket_embrace', 'breath'): ('number', 0, 80),
 ('bracket_embrace', 'cycles'): ('number', 0.1, 8),
 ('bracket_embrace', 'distance'): ('number', 1, 300),
 ('breaking_wave', 'crest'): ('number', 120, 520),
 ('breaking_wave', 'foam'): ('integer', 8, 80),
 ('breaking_wave', 'seed'): ('integer', 0, 2147483647),
 ('breaking_wave', 'spray'): ('integer', 10, 100),
 ('bubble_rise', 'rise'): ('number', 20, 800),
 ('bubble_rise', 'seed'): ('integer', 0, 2147483647),
 ('bubble_rise', 'stagger'): ('number', 0, 0.95),
 ('bubble_rise', 'sway'): ('number', 0, 160),
 ('call_response_duet', 'cycles'): ('number', 0.1, 8),
 ('call_response_duet', 'distance'): ('number', 2, 240),
 ('center_ripple', 'cycles'): ('number', 0.1, 10),
 ('center_ripple', 'lift'): ('number', 0, 80),
 ('center_ripple', 'scale'): ('number', 1, 100),
 ('character_pulse_train', 'cycles'): ('number', 0.1, 10),
 ('character_pulse_train', 'lift'): ('number', 0, 100),
 ('character_pulse_train', 'scale'): ('number', 1, 120),
 ('cherry_blossom_storm', 'gusts'): ('integer', 1, 8),
 ('cherry_blossom_storm', 'petals'): ('integer', 16, 120),
 ('cherry_blossom_storm', 'seed'): ('integer', 0, 2147483647),
 ('chorus_echo', 'copies'): ('integer', 1, 8),
 ('chorus_echo', 'cycles'): ('number', 0.1, 8),
 ('chorus_echo', 'distance'): ('number', 1, 180),
 ('chromatic_orbit', 'cycles'): ('number', 0.1, 10),
 ('chromatic_orbit', 'radius'): ('number', 1, 80),
 ('cloudburst', 'clouds'): ('integer', 2, 10),
 ('cloudburst', 'density'): ('integer', 24, 180),
 ('cloudburst', 'seed'): ('integer', 0, 2147483647),
 ('cloudburst', 'speed'): ('number', 400, 2600),
 ('cloudburst', 'splashes'): ('integer', 4, 36),
 ('color_pingpong', 'cycles'): ('number', 0.1, 10),
 ('color_wave', 'cycles'): ('number', 0.1, 10),
 ('constellation_sparks', 'count'): ('integer', 4, 60),
 ('constellation_sparks', 'cycles'): ('number', 0.1, 6),
 ('constellation_sparks', 'radius'): ('number', 10, 220),
 ('constellation_sparks', 'seed'): ('integer', 0, 2147483647),
 ('crepuscular_rays', 'dust'): ('integer', 8, 100),
 ('crepuscular_rays', 'opening'): ('number', 70, 500),
 ('crepuscular_rays', 'rays'): ('integer', 3, 20),
 ('crepuscular_rays', 'seed'): ('integer', 0, 2147483647),
 ('diamond_dust', 'crystals'): ('integer', 10, 120),
 ('diamond_dust', 'pillars'): ('integer', 2, 10),
 ('diamond_dust', 'seed'): ('integer', 0, 2147483647),
 ('diamond_dust', 'sparkle_cycles'): ('number', 0.5, 8),
 ('dissolve', 'blur'): ('number', 0, 30),
 ('dissolve', 'columns'): ('integer', 2, 50),
 ('dissolve', 'rows'): ('integer', 2, 30),
 ('dissolve', 'seed'): ('integer', 0, 2147483647),
 ('distort', 'amount'): ('number', 0.05, 5),
 ('domino_settle', 'offset'): ('number', 1, 240),
 ('domino_settle', 'stagger'): ('number', 0, 0.95),
 ('domino_settle', 'tilt'): ('number', 5, 150),
 ('drizzle_mist', 'beads'): ('integer', 4, 50),
 ('drizzle_mist', 'density'): ('integer', 16, 140),
 ('drizzle_mist', 'mist_bands'): ('integer', 2, 10),
 ('drizzle_mist', 'seed'): ('integer', 0, 2147483647),
 ('drizzle_mist', 'speed'): ('number', 120, 1200),
 ('echo_tunnel', 'cycles'): ('number', 0.1, 8),
 ('echo_tunnel', 'depth'): ('number', 2, 100),
 ('echo_tunnel', 'layers'): ('integer', 2, 10),
 ('edge_knock', 'angle'): ('number', 0, 45),
 ('edge_knock', 'cycles'): ('number', 0.1, 10),
 ('edge_knock', 'distance'): ('number', 1, 160),
 ('ember_drift', 'embers'): ('integer', 12, 120),
 ('ember_drift', 'flares'): ('integer', 2, 24),
 ('ember_drift', 'seed'): ('integer', 0, 2147483647),
 ('ember_drift', 'smoke_bands'): ('integer', 2, 10),
 ('emboss_light', 'cycles'): ('number', 0.1, 8),
 ('emboss_light', 'distance'): ('number', 0.5, 30),
 ('equalizer_bed', 'bars'): ('integer', 4, 48),
 ('equalizer_bed', 'cycles'): ('number', 0.1, 10),
 ('equalizer_bed', 'height'): ('number', 5, 180),
 ('equalizer_bed', 'seed'): ('integer', 0, 2147483647),
 ('falling_leaves', 'ground_swirl'): ('integer', 4, 40),
 ('falling_leaves', 'leaves'): ('integer', 10, 90),
 ('falling_leaves', 'seed'): ('integer', 0, 2147483647),
 ('falling_leaves', 'tumble'): ('number', 0.5, 8),
 ('fan_spread', 'arc'): ('number', 5, 180),
 ('fan_spread', 'radius'): ('number', 10, 600),
 ('fan_spread', 'stagger'): ('number', 0, 0.9),
 ('firefly_night', 'fireflies'): ('integer', 8, 70),
 ('firefly_night', 'glow_radius'): ('number', 4, 28),
 ('firefly_night', 'seed'): ('integer', 0, 2147483647),
 ('firefly_night', 'trails'): ('integer', 2, 30),
 ('flicker', 'interval_ms'): ('integer', 20, 1000),
 ('flicker', 'seed'): ('integer', 0, 2147483647),
 ('flip', 'degrees'): ('number', 1, 720),
 ('frost_bloom', 'branches'): ('integer', 6, 32),
 ('frost_bloom', 'depth'): ('integer', 1, 4),
 ('frost_bloom', 'reach'): ('number', 35, 220),
 ('frost_bloom', 'seed'): ('integer', 0, 2147483647),
 ('gentle_breeze', 'grass_blades'): ('integer', 6, 48),
 ('gentle_breeze', 'seed'): ('integer', 0, 2147483647),
 ('gentle_breeze', 'seeds'): ('integer', 3, 36),
 ('gentle_breeze', 'streamlines'): ('integer', 4, 28),
 ('glass_refraction', 'cycles'): ('number', 0.1, 8),
 ('glass_refraction', 'offset'): ('number', 1, 100),
 ('glass_refraction', 'slices'): ('integer', 3, 30),
 ('glitch', 'intensity'): ('number', 1, 300),
 ('glitch', 'seed'): ('integer', 0, 2147483647),
 ('glitch', 'slices'): ('integer', 3, 300),
 ('glow', 'border'): ('number', 0.1, 100),
 ('glow', 'radius'): ('number', 0.1, 100),
 ('gust_front', 'debris'): ('integer', 4, 50),
 ('gust_front', 'displacement'): ('number', 4, 80),
 ('gust_front', 'seed'): ('integer', 0, 2147483647),
 ('gust_front', 'streaks'): ('integer', 8, 90),
 ('hailstorm', 'bounce'): ('number', 10, 180),
 ('hailstorm', 'impacts'): ('integer', 3, 36),
 ('hailstorm', 'pellets'): ('integer', 12, 120),
 ('hailstorm', 'seed'): ('integer', 0, 2147483647),
 ('halo_rings', 'cycles'): ('number', 0.1, 6),
 ('halo_rings', 'max_scale'): ('number', 105, 300),
 ('halo_rings', 'rings'): ('integer', 2, 10),
 ('heat_haze', 'bands'): ('integer', 3, 16),
 ('heat_haze', 'distortion'): ('number', 2, 45),
 ('heat_haze', 'seed'): ('integer', 0, 2147483647),
 ('heat_haze', 'wisps'): ('integer', 4, 40),
 ('ice_crack', 'branches'): ('integer', 5, 24),
 ('ice_crack', 'depth'): ('integer', 1, 4),
 ('ice_crack', 'seed'): ('integer', 0, 2147483647),
 ('ice_crack', 'shards'): ('integer', 4, 40),
 ('lava_flow', 'channels'): ('integer', 2, 10),
 ('lava_flow', 'cracks'): ('integer', 6, 50),
 ('lava_flow', 'embers'): ('integer', 6, 60),
 ('lava_flow', 'seed'): ('integer', 0, 2147483647),
 ('letter_rain', 'drift'): ('number', 0, 240),
 ('letter_rain', 'height'): ('number', 20, 1000),
 ('letter_rain', 'seed'): ('integer', 0, 2147483647),
 ('letter_rain', 'stagger'): ('number', 0, 0.95),
 ('long_exposure', 'cycles'): ('number', 0.1, 8),
 ('long_exposure', 'distance'): ('number', 2, 220),
 ('long_exposure', 'trails'): ('integer', 2, 14),
 ('magnet_repel', 'cycles'): ('number', 0.1, 10),
 ('magnet_repel', 'distance'): ('number', 1, 180),
 ('magnet_repel', 'lift'): ('number', 0, 80),
 ('metallic_shimmer', 'cycles'): ('number', 0.1, 8),
 ('metallic_shimmer', 'width'): ('number', 10, 600),
 ('meteor_shower', 'meteors'): ('integer', 8, 70),
 ('meteor_shower', 'radiant_spread'): ('number', 80, 520),
 ('meteor_shower', 'seed'): ('integer', 0, 2147483647),
 ('meteor_shower', 'stars'): ('integer', 16, 130),
 ('mirror_reflection', 'bands'): ('integer', 2, 30),
 ('mirror_reflection', 'gap'): ('number', 0, 160),
 ('mirror_reflection', 'shimmer'): ('number', 0, 80),
 ('moonlight_clouds', 'beams'): ('integer', 3, 14),
 ('moonlight_clouds', 'cloud_layers'): ('integer', 3, 12),
 ('moonlight_clouds', 'seed'): ('integer', 0, 2147483647),
 ('moonlight_clouds', 'stars'): ('integer', 8, 70),
 ('morning_mist', 'bands'): ('integer', 3, 12),
 ('morning_mist', 'drift'): ('number', 20, 360),
 ('morning_mist', 'opacity'): ('integer', 40, 220),
 ('morning_mist', 'seed'): ('integer', 0, 2147483647),
 ('ocean_swell', 'amplitude'): ('number', 10, 120),
 ('ocean_swell', 'foam'): ('integer', 6, 60),
 ('ocean_swell', 'layers'): ('integer', 2, 8),
 ('ocean_swell', 'wavelength'): ('number', 120, 900),
 ('orbit_assemble', 'radius'): ('number', 5, 500),
 ('orbit_assemble', 'stagger'): ('number', 0, 0.9),
 ('orbit_assemble', 'turns'): ('number', 0.1, 4),
 ('outline', 'border'): ('number', 0.1, 30),
 ('parallax_chorus', 'cycles'): ('number', 0.1, 8),
 ('parallax_chorus', 'distance'): ('number', 1, 180),
 ('parallax_chorus', 'layers'): ('integer', 2, 8),
 ('pendulum_row', 'angle'): ('number', 1, 70),
 ('pendulum_row', 'cycles'): ('number', 0.1, 12),
 ('pendulum_row', 'lift'): ('number', 0, 60),
 ('pop', 'overshoot'): ('number', 101, 200),
 ('pulse_frame', 'cycles'): ('number', 0.1, 8),
 ('pulse_frame', 'padding'): ('number', 2, 160),
 ('pulse_frame', 'thickness'): ('number', 1, 24),
 ('rain_veil', 'density'): ('integer', 12, 120),
 ('rain_veil', 'ripples'): ('integer', 3, 30),
 ('rain_veil', 'seed'): ('integer', 0, 2147483647),
 ('rain_veil', 'slant'): ('number', 0, 260),
 ('rain_veil', 'speed'): ('number', 250, 2200),
 ('rainbow_arch', 'bands'): ('integer', 3, 9),
 ('rainbow_arch', 'radius'): ('number', 120, 620),
 ('rainbow_arch', 'sparkles'): ('integer', 4, 50),
 ('rainbow_arch', 'thickness'): ('number', 3, 28),
 ('rising_tide', 'glints'): ('integer', 4, 60),
 ('rising_tide', 'level'): ('number', 20, 260),
 ('rising_tide', 'seed'): ('integer', 0, 2147483647),
 ('rising_tide', 'surge'): ('number', 10, 220),
 ('river_current', 'foam'): ('integer', 6, 70),
 ('river_current', 'ribbons'): ('integer', 3, 14),
 ('river_current', 'seed'): ('integer', 0, 2147483647),
 ('river_current', 'speed'): ('number', 80, 800),
 ('rotate', 'degrees'): ('number', 1, 1440),
 ('sandstorm', 'bands'): ('integer', 2, 12),
 ('sandstorm', 'grains'): ('integer', 24, 200),
 ('sandstorm', 'seed'): ('integer', 0, 2147483647),
 ('sandstorm', 'speed'): ('number', 180, 1500),
 ('scanline', 'softness_ms'): ('integer', 0, 1000),
 ('scanline', 'steps'): ('integer', 2, 200),
 ('scramble_resolve', 'interval_ms'): ('integer', 30, 500),
 ('scramble_resolve', 'seed'): ('integer', 0, 2147483647),
 ('sea_of_clouds', 'cloudlets'): ('integer', 6, 45),
 ('sea_of_clouds', 'drift'): ('number', 15, 260),
 ('sea_of_clouds', 'layers'): ('integer', 3, 9),
 ('sea_of_clouds', 'seed'): ('integer', 0, 2147483647),
 ('shadow_march', 'copies'): ('integer', 2, 12),
 ('shadow_march', 'cycles'): ('number', 0.1, 8),
 ('shadow_march', 'radius'): ('number', 1, 100),
 ('sidewind', 'amplitude'): ('number', 1, 180),
 ('sidewind', 'cycles'): ('number', 0.1, 12),
 ('sidewind', 'phase_spread'): ('number', 0, 4),
 ('snowfall_depth', 'drift'): ('number', 0, 220),
 ('snowfall_depth', 'far_flakes'): ('integer', 10, 120),
 ('snowfall_depth', 'near_flakes'): ('integer', 4, 50),
 ('snowfall_depth', 'seed'): ('integer', 0, 2147483647),
 ('solar_eclipse', 'corona_rays'): ('integer', 12, 60),
 ('solar_eclipse', 'ring_scale'): ('number', 80, 260),
 ('solar_eclipse', 'stars'): ('integer', 6, 60),
 ('spacing', 'spacing'): ('number', 0.1, 300),
 ('spotlight_lens', 'cycles'): ('number', 0.1, 8),
 ('spotlight_lens', 'scale'): ('number', 100, 150),
 ('spotlight_lens', 'width'): ('number', 20, 900),
 ('staircase_flatten', 'stagger'): ('number', 0, 0.9),
 ('staircase_flatten', 'step_height'): ('number', 1, 100),
 ('staircase_flatten', 'tilt'): ('number', 0, 45),
 ('stretch', 'min_scale'): ('number', 0, 99),
 ('sunrise_horizon', 'glow_layers'): ('integer', 3, 10),
 ('sunrise_horizon', 'mist_bands'): ('integer', 2, 10),
 ('sunrise_horizon', 'rays'): ('integer', 4, 24),
 ('tornado', 'debris'): ('integer', 8, 70),
 ('tornado', 'rings'): ('integer', 6, 24),
 ('tornado', 'seed'): ('integer', 0, 2147483647),
 ('tornado', 'width'): ('number', 120, 560),
 ('twin_lane_merge', 'distance'): ('number', 5, 600),
 ('twin_lane_merge', 'stagger'): ('number', 0, 0.9),
 ('water_reflection', 'amplitude'): ('number', 1, 100),
 ('water_reflection', 'bands'): ('integer', 3, 40),
 ('water_reflection', 'cycles'): ('number', 0.1, 8),
 ('water_reflection', 'gap'): ('number', 0, 160),
 ('waterfall', 'mist'): ('integer', 8, 80),
 ('waterfall', 'seed'): ('integer', 0, 2147483647),
 ('waterfall', 'splashes'): ('integer', 6, 60),
 ('waterfall', 'streams'): ('integer', 5, 36),
 ('weave_cross', 'cross'): ('number', 0, 200),
 ('weave_cross', 'height'): ('number', 5, 300),
 ('weave_cross', 'stagger'): ('number', 0, 0.9),
 ('whirlpool', 'foam'): ('integer', 8, 70),
 ('whirlpool', 'rings'): ('integer', 5, 20),
 ('whirlpool', 'seed'): ('integer', 0, 2147483647),
 ('whirlpool', 'turns'): ('number', 0.5, 5),
 ('whirlwind', 'particles'): ('integer', 8, 90),
 ('whirlwind', 'radius'): ('number', 60, 440),
 ('whirlwind', 'seed'): ('integer', 0, 2147483647),
 ('whirlwind', 'turns'): ('number', 0.4, 5),
 ('zoom', 'min_scale'): ('number', 0, 99)}


def _humanize(name: str) -> str:
    return name.replace("_", " ").title()


def _parameter_kind(name: str, default: Any, choices: Sequence[Any]) -> str:
    if choices:
        return "choice"
    if name == "palette" or isinstance(default, (tuple, list)):
        return "palette"
    if name == "color" or name.startswith("color_"):
        return "color"
    if isinstance(default, bool):
        return "boolean"
    if isinstance(default, int):
        return "integer"
    if isinstance(default, float):
        return "number"
    return "string"


def _parameter_schema(
    effect_id: str, name: str, default: Any, choices: Sequence[Any]
) -> dict[str, Any]:
    json_default = _json_safe(default)
    json_choices = _json_safe(choices)
    constraint = _NUMERIC_CONSTRAINTS.get((effect_id, name))
    kind = constraint[0] if constraint is not None else _parameter_kind(name, default, choices)
    label_en = _humanize(name)
    label_ja = _PARAMETER_LABELS_JA.get(name, label_en)
    choice_labels_en: dict[str, str] = {}
    choice_labels_ja: dict[str, str] = {}
    for value in json_choices:
        if not isinstance(value, str):
            raise TypeError(
                f"choice values must be strings for localized labels: {effect_id}.{name}"
            )
        try:
            choice_label_en, choice_label_ja = _CHOICE_LABELS[value]
        except KeyError as exc:
            raise RuntimeError(
                f"missing localized choice label for {effect_id}.{name}={value!r}"
            ) from exc
        choice_labels_en[value] = choice_label_en
        choice_labels_ja[value] = choice_label_ja
    return {
        "kind": kind,
        "default": json_default,
        "min": None if constraint is None else constraint[1],
        "max": None if constraint is None else constraint[2],
        "step": 1 if kind == "integer" else (0.1 if kind == "number" else None),
        "choices": json_choices,
        "choice_labels_en": choice_labels_en,
        "choice_labels_ja": choice_labels_ja,
        "label_en": label_en,
        "label_ja": label_ja,
        "description_en": f"Controls the {label_en.lower()} parameter.",
        "description_ja": f"{label_ja}パラメータを設定します。",
    }


def _build_parameter_registry() -> dict[str, dict[str, dict[str, Any]]]:
    registry: dict[str, dict[str, dict[str, Any]]] = {}
    for effect in CATALOG_EFFECT_ORDER:
        defaults = DEFAULT_PARAMS[effect]
        categorical = EFFECT_SPECS[effect].categorical_params
        schemas: dict[str, dict[str, Any]] = {}
        for name in dict.fromkeys((*defaults, *categorical)):
            choices = tuple(categorical.get(name, ()))
            if name in defaults:
                default = defaults[name]
            elif choices:
                default = choices[0]
            else:  # Defensive: the key union makes this unreachable.
                default = None
            schemas[name] = _parameter_schema(effect.value, name, default, choices)
        registry[effect.value] = schemas
    return registry


PARAMETER_SCHEMA_REGISTRY = _build_parameter_registry()


_VERY_HIGH_COST_IDS = frozenset({"afterimage_wave", "waterfall", "snowfall_depth"})
_HIGH_COST_IDS = frozenset(
    {
        "glitch",
        "dissolve",
        "equalizer_bed",
        "constellation_sparks",
        "aurora_bands",
        "mirror_reflection",
        "water_reflection",
        *(effect.value for effect in CATALOG_EFFECT_ORDER[61:]),
    }
)
_MEDIUM_COST_IDS = frozenset(
    {
        *LINE_LOCAL_SHARED_TIMELINE_EFFECT_IDS,
        *SEQUENTIAL_LINE_EFFECT_IDS,
        "scanline",
        "chorus_echo",
        "echo_tunnel",
        "shadow_march",
        "chromatic_orbit",
        "parallax_chorus",
        "long_exposure",
        "call_response_duet",
        "glass_refraction",
        "emboss_light",
        "metallic_shimmer",
        "bracket_embrace",
        "halo_rings",
        "pulse_frame",
    }
)


def _cost_class(effect_id: str) -> str:
    if effect_id in _VERY_HIGH_COST_IDS:
        return "very_high"
    if effect_id in _HIGH_COST_IDS:
        return "high"
    if effect_id in _MEDIUM_COST_IDS:
        return "medium"
    return "low"


def _multiline_mode(effect_id: str) -> str:
    if effect_id in SEQUENTIAL_LINE_EFFECT_IDS:
        return "sequential_lines"
    if effect_id in LINE_LOCAL_SHARED_TIMELINE_EFFECT_IDS:
        return "line_local_shared_timeline"
    return "native"


def _effect_record(effect: Effect) -> dict[str, Any]:
    spec = EFFECT_SPECS[effect]
    display_number = EFFECT_DISPLAY_NUMBERS[effect]
    return {
        "effect_id": effect.value,
        "stable_effect_id": True,
        "name_en": spec.name_en,
        "name_ja": spec.name_ja,
        "description_en": spec.description_en,
        "description_ja": spec.description_ja,
        "major_category_en": spec.major_category_en,
        "major_category_ja": spec.major_category_ja,
        "subcategory_en": spec.subcategory_en,
        "subcategory_ja": spec.subcategory_ja,
        "family": EFFECT_FAMILIES[effect],
        "display_number": display_number,
        "family_local_number": EFFECT_LOCAL_NUMBERS[effect],
        "traits": sorted(EFFECT_TRAITS[effect]),
        "preview_url": (
            f"{PAGES_BASE_URL}preview/{display_number:03d}_{effect.value}.mp4"
        ),
        "catalog_page_url_en": f"{CATALOG_PAGE_URL_EN}#effect-{display_number:03d}",
        "catalog_page_url_ja": f"{CATALOG_PAGE_URL_JA}#effect-{display_number:03d}",
        "parameters": _json_safe(PARAMETER_SCHEMA_REGISTRY[effect.value]),
        "capabilities": {
            "requires_context": bool(spec.context_required),
            "multiline_mode": _multiline_mode(effect.value),
            "cost_class": _cost_class(effect.value),
            "strict_input_tags": _json_safe(STRICT_INPUT_TAGS_CONTRACT),
        },
    }


def get_effect_catalog() -> dict[str, Any]:
    """Return a fresh, fully JSON-serializable catalogue for all 97 effects."""

    effects = [_effect_record(effect) for effect in CATALOG_EFFECT_ORDER]
    if frozenset(entry["effect_id"] for entry in effects) != PERSISTENT_EFFECT_IDS:
        raise RuntimeError("effect catalogue does not match the persistent ID snapshot")
    return {
        "package": "ass-lyric-effects",
        "version": __version__,
        "schema_version": CATALOG_SCHEMA_VERSION,
        "pages": {
            "base_url": PAGES_BASE_URL,
            "catalog_page_url_en": CATALOG_PAGE_URL_EN,
            "catalog_page_url_ja": CATALOG_PAGE_URL_JA,
        },
        "stable_id_contract": {
            "field": "effect_id",
            "source": "Effect.value",
            "id_schema_version": EFFECT_ID_SCHEMA_VERSION,
            "display_number_is_stable_id": False,
            "family_local_number_is_stable_id": False,
            "numeric_selector_is_stable_id": False,
        },
        "multiline_context_contract": {
            "line_separator_tags": [r"\N", r"\n"],
            "line_layout_fields": [
                "anchor_x",
                "anchor_y",
                "text_box",
                "glyph_widths",
            ],
            "glyph_unit": "unicode_grapheme_cluster_uax29",
            "glyph_width_source": "harfbuzz_actual_font_advance",
            "zero_advance_allowed": True,
            "positive_total_required_per_non_empty_line": True,
            "empty_visual_line_policy": "preserve_separator_no_layout_no_events",
            "implicit_width_estimation": False,
        },
        "effects": effects,
    }


def _resolve_stable_effect(effect: Effect | str) -> Effect:
    if isinstance(effect, Effect):
        return effect
    if not isinstance(effect, str):
        raise TypeError("effect must be an Effect or stable string effect_id")
    try:
        return Effect(effect)
    except ValueError as exc:
        raise ValueError(f"unknown stable effect_id: {effect!r}") from exc


def _positive_integer(value: Any, name: str, *, allow_zero: bool = False) -> int:
    minimum = 0 if allow_zero else 1
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        qualifier = "non-negative" if allow_zero else "positive"
        raise ValueError(f"{name} must be a {qualifier} integer")
    return value


def estimate_event_count(
    effect: Effect | str,
    duration_ms: int,
    *,
    grapheme_count: int = 1,
    line_count: int = 1,
    params: Mapping[str, Any] | None = None,
    budget: int | None = None,
) -> dict[str, Any]:
    """Return a conservative event-count estimate without enforcing a default cap.

    The estimate is intentionally identified as a formula, not an exact count.
    It is suitable for pre-flight UI warnings.  Rendered event counts remain the
    authority because individual engines may change their internal sampling.
    """

    resolved = _resolve_stable_effect(effect)
    duration = _positive_integer(duration_ms, "duration_ms", allow_zero=True)
    graphemes = _positive_integer(grapheme_count, "grapheme_count", allow_zero=True)
    lines = _positive_integer(line_count, "line_count")
    if params is not None and not isinstance(params, Mapping):
        raise TypeError("params must be a mapping or None")
    schemas = PARAMETER_SCHEMA_REGISTRY[resolved.value]
    supplied = {} if params is None else dict(params)
    unknown = sorted(set(supplied) - set(schemas))
    if unknown:
        raise ValueError("unknown parameter(s): " + ", ".join(unknown))
    merged = {name: schema["default"] for name, schema in schemas.items()}
    merged.update(_json_safe(supplied))

    # 100 ms mirrors the package's default motion sampling.  Numeric load
    # accounts for particle/layer controls while excluding seeds and timing
    # values that do not multiply output rows.
    steps = max(1, math.ceil(duration / 100)) if duration else 1
    numeric_load = 0.0
    for name, value in merged.items():
        if name == "seed" or name.endswith("_ms") or isinstance(value, bool):
            continue
        if isinstance(value, (int, float)) and math.isfinite(float(value)):
            numeric_load += min(abs(float(value)), 5000.0)

    cost_class = _cost_class(resolved.value)
    if cost_class == "low":
        estimated = lines * max(1, 4 + graphemes + math.ceil(numeric_load / 4))
    elif cost_class == "medium":
        estimated = lines * max(1, 12 + steps * max(2, graphemes * 2) + math.ceil(numeric_load))
    elif cost_class == "high":
        estimated = lines * max(
            1, 32 + steps * (graphemes + 12) + math.ceil(numeric_load * 2)
        )
    else:
        estimated = lines * max(
            1, 64 + steps * (graphemes * 8 + 32) + math.ceil(numeric_load * 3)
        )

    if budget is not None:
        checked_budget = _positive_integer(budget, "budget", allow_zero=True)
        if estimated > checked_budget:
            raise EventBudgetExceededError(resolved.value, estimated, checked_budget)

    return {
        "effect_id": resolved.value,
        "estimated_events": int(estimated),
        "cost_class": cost_class,
        "precision": "conservative_formula",
        "basis": {
            "duration_ms": duration,
            "motion_step_ms": 100,
            "grapheme_count": graphemes,
            "line_count": lines,
            "numeric_parameter_load": numeric_load,
        },
        "budget": budget,
        "within_budget": None if budget is None else True,
    }


__all__ = [
    "CATALOG_PAGE_URL_EN",
    "CATALOG_PAGE_URL_JA",
    "CATALOG_SCHEMA_VERSION",
    "EventBudgetExceededError",
    "LINE_LOCAL_SHARED_TIMELINE_EFFECT_IDS",
    "PAGES_BASE_URL",
    "PARAMETER_SCHEMA_REGISTRY",
    "SEQUENTIAL_LINE_EFFECT_IDS",
    "STRICT_INPUT_TAGS",
    "STRICT_INPUT_TAGS_CONTRACT",
    "estimate_event_count",
    "get_effect_catalog",
]
