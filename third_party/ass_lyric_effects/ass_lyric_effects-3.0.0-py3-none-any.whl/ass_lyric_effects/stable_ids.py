"""Persistent identifiers for saved effect selections.

The members of :data:`PERSISTENT_EFFECT_IDS` are the only identifiers that a
host application should store.  Display numbers, Python Enum ordinals, and
family-local numbers are presentation conveniences and may be reordered.
"""

from __future__ import annotations


EFFECT_ID_SCHEMA_VERSION = 1

# This literal snapshot is intentionally independent from Effect declaration
# order and catalogue display order.  Removing, renaming, or reusing any value
# is a breaking data-contract change and requires an explicit migration design.
PERSISTENT_EFFECT_IDS: frozenset[str] = frozenset(
    {
        "cut",
        "fad",
        "fade",
        "alpha",
        "zoom",
        "pop",
        "bounce",
        "slide",
        "wipe",
        "blur",
        "rotate",
        "flip",
        "spacing",
        "stretch",
        "outline",
        "glow",
        "flicker",
        "typewriter",
        "karaoke",
        "scanline",
        "distort",
        "glitch",
        "dissolve",
        "baseline_wave",
        "sidewind",
        "pendulum_row",
        "domino_settle",
        "letter_rain",
        "bubble_rise",
        "center_ripple",
        "edge_knock",
        "orbit_assemble",
        "weave_cross",
        "staircase_flatten",
        "fan_spread",
        "twin_lane_merge",
        "magnet_repel",
        "character_pulse_train",
        "scramble_resolve",
        "chorus_echo",
        "echo_tunnel",
        "mirror_reflection",
        "water_reflection",
        "shadow_march",
        "chromatic_orbit",
        "parallax_chorus",
        "long_exposure",
        "call_response_duet",
        "afterimage_wave",
        "color_wave",
        "aurora_bands",
        "emboss_light",
        "glass_refraction",
        "metallic_shimmer",
        "color_pingpong",
        "spotlight_lens",
        "bracket_embrace",
        "halo_rings",
        "equalizer_bed",
        "constellation_sparks",
        "pulse_frame",
        "rain_veil",
        "drizzle_mist",
        "cloudburst",
        "crepuscular_rays",
        "snowfall_depth",
        "blizzard_whiteout",
        "diamond_dust",
        "hailstorm",
        "frost_bloom",
        "ice_crack",
        "avalanche",
        "morning_mist",
        "sea_of_clouds",
        "gentle_breeze",
        "gust_front",
        "whirlwind",
        "tornado",
        "sandstorm",
        "heat_haze",
        "ocean_swell",
        "breaking_wave",
        "rising_tide",
        "waterfall",
        "river_current",
        "whirlpool",
        "lava_flow",
        "ember_drift",
        "rainbow_arch",
        "cherry_blossom_storm",
        "falling_leaves",
        "firefly_night",
        "bioluminescent_tide",
        "meteor_shower",
        "solar_eclipse",
        "moonlight_clouds",
        "sunrise_horizon",
    }
)


def is_persistent_effect_id(value: object) -> bool:
    """Return whether *value* is a stable serialized effect identifier."""

    return isinstance(value, str) and value in PERSISTENT_EFFECT_IDS


__all__ = [
    "EFFECT_ID_SCHEMA_VERSION",
    "PERSISTENT_EFFECT_IDS",
    "is_persistent_effect_id",
]
