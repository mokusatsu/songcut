"""Single source of truth for the installed package version."""

__version__ = "3.0.0"

__all__ = ["__version__"]
