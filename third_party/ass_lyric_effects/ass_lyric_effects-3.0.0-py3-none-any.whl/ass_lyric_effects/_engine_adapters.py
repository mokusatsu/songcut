"""Adapters for the private legacy and Natural effect engines.

The package's public ``core`` module owns the canonical context and error
types.  The two vendored engines intentionally keep their own copies of
those types, so this module is the small boundary that translates between
them.  Engine imports are kept inside the call sites: importing this module
while ``core`` is still initialising must not import either vendored engine.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from enum import Enum
import importlib
from typing import Any


class AdapterError(ValueError):
    """Base class for errors raised by an engine adapter."""


class AdapterInputError(AdapterError):
    """The input Dialogue event was rejected by a vendored engine."""


class AdapterParameterError(AdapterError):
    """The effect selector, parameters, or rendering context is invalid."""


# Natural v7 renames the old ``Rainbow Arch`` row to ``Spring Breeze`` while
# retaining the stable engine id.  Keep this mapping as ordinary strings so
# catalogue/registry code never has to import the Natural ``Effect`` enum.
NATURAL_ALIASES: dict[str, str] = {
    "spring_breeze": "rainbow_arch",
    "Rainbow Arch": "rainbow_arch",
    "虹": "rainbow_arch",
    "春風": "rainbow_arch",
}


_MISSING = object()


def _load_legacy_engine() -> Any:
    """Import and return the vendored 23-effect engine lazily."""

    return importlib.import_module(f"{__package__}._legacy23_engine")


def _load_natural_engine() -> Any:
    """Import and return the vendored 36-effect engine lazily."""

    return importlib.import_module(f"{__package__}._natural36_engine")


def _context_attr(context: Any, name: str, default: Any = _MISSING) -> Any:
    if context is None:
        return None if default is _MISSING else default
    try:
        return getattr(context, name)
    except AttributeError:
        if default is not _MISSING:
            return default
        raise AdapterParameterError(
            f"context is missing required attribute {name!r}"
        ) from None
    except Exception as exc:  # pragma: no cover - unusual property failures
        raise AdapterParameterError(
            f"unable to read context attribute {name!r}"
        ) from exc


def _rect_for_engine(rect: Any, engine: Any) -> Any:
    """Copy a central/duck-typed rectangle into an engine ``Rect``."""

    if rect is None:
        return None
    try:
        values = tuple(getattr(rect, name) for name in ("x1", "y1", "x2", "y2"))
    except AttributeError:
        # A four-item tuple/list is convenient for callers that do not use the
        # public ``Rect`` dataclass.  Strings are deliberately excluded.
        if isinstance(rect, Sequence) and not isinstance(rect, (str, bytes)):
            try:
                values = tuple(rect)
            except Exception as exc:  # pragma: no cover - hostile iterables
                raise AdapterParameterError("context.text_box must be a rectangle") from exc
        else:
            raise AdapterParameterError(
                "context.text_box must expose x1, y1, x2, and y2"
            ) from None
    except Exception as exc:  # pragma: no cover - unusual property failures
        raise AdapterParameterError("unable to read context.text_box") from exc
    if len(values) != 4:
        raise AdapterParameterError("context.text_box must contain four coordinates")
    try:
        return engine.Rect(*values)
    except (TypeError, ValueError) as exc:
        raise AdapterParameterError(f"invalid context.text_box: {exc}") from exc


def _engine_context(context: Any, engine: Any, *, natural: bool) -> Any:
    """Build an internal engine context from a central duck-typed context."""

    if context is None:
        return None

    values: dict[str, Any] = {
        "play_res_x": _context_attr(context, "play_res_x", 1920),
        "play_res_y": _context_attr(context, "play_res_y", 1080),
        "anchor_x": _context_attr(context, "anchor_x", None),
        "anchor_y": _context_attr(context, "anchor_y", None),
        "text_box": _rect_for_engine(
            _context_attr(context, "text_box", None), engine
        ),
        "offscreen_margin": _context_attr(context, "offscreen_margin", 240),
        "strict": _context_attr(context, "strict", True),
    }
    if natural:
        values["motion_step_ms"] = _context_attr(context, "motion_step_ms", 100)
        widths = _context_attr(context, "glyph_widths", None)
        if widths is not None:
            try:
                # Do not filter or truth-test this sequence: 0.0 is a valid
                # combining/mark-only cluster width and must be preserved.
                values["glyph_widths"] = tuple(widths)
            except (TypeError, ValueError) as exc:
                raise AdapterParameterError(
                    "context.glyph_widths must be an iterable of widths"
                ) from exc
        else:
            values["glyph_widths"] = None
    try:
        return engine.EffectContext(**values)
    except getattr(engine, "EffectParameterError", ValueError) as exc:
        raise AdapterParameterError(str(exc)) from exc
    except (TypeError, ValueError) as exc:
        raise AdapterParameterError(str(exc)) from exc


def legacy_context(context: Any) -> Any:
    """Translate a central context to ``_legacy23_engine.EffectContext``.

    The legacy engine predates measured grapheme widths and motion sampling;
    those central fields are intentionally ignored.
    """

    engine = _load_legacy_engine()
    return _engine_context(context, engine, natural=False)


def natural_context(context: Any) -> Any:
    """Translate a central context to ``_natural36_engine.EffectContext``."""

    engine = _load_natural_engine()
    return _engine_context(context, engine, natural=True)


def _require_effect_id(effect_id: Any) -> str:
    if not isinstance(effect_id, str):
        raise AdapterParameterError("effect_id must be a string")
    value = effect_id.strip()
    if not value:
        raise AdapterParameterError("effect_id must be a non-empty string")
    return value


def _natural_effect_id(effect_id: str) -> str:
    value = _require_effect_id(effect_id)
    if value in NATURAL_ALIASES:
        return NATURAL_ALIASES[value]
    normalized = value.lower().replace("-", "_").replace(" ", "_")
    # Alias rows intentionally retain their display spelling in the public
    # mapping, but lookup is forgiving for CLI/registry callers.
    for alias, canonical in NATURAL_ALIASES.items():
        if alias.lower().replace("-", "_").replace(" ", "_") == normalized:
            return canonical
    return value


def _call_engine(
    engine: Any,
    effect_id: str,
    dialogue_line: str,
    start_ms: int,
    end_ms: int,
    *,
    params: Mapping[str, Any] | None,
    context: Any,
) -> list[str]:
    """Call an engine and map its private exception hierarchy."""

    # ``Direction`` and ``Phase`` values commonly originate from the public
    # core (or another registry) and are not instances of the vendored
    # engine's Enum classes.  Passing them through as-is makes ``str(value)``
    # produce ``"Direction.LEFT_TO_RIGHT"`` on Python 3.10+, so normalize all
    # enum-bearing parameter structures at the boundary.
    normalized_params = None if params is None else _plain(params)
    try:
        result = engine.decorate_dialogue(
            dialogue_line,
            start_ms,
            end_ms,
            effect_id,
            params=normalized_params,
            context=context,
        )
    except engine.EffectParameterError as exc:
        raise AdapterParameterError(str(exc)) from exc
    except engine.EffectError as exc:
        raise AdapterInputError(str(exc)) from exc
    return result


def decorate_legacy(
    effect_id: str,
    dialogue_line: str,
    start_ms: int,
    end_ms: int,
    *,
    params: Mapping[str, Any] | None = None,
    context: Any = None,
) -> list[str]:
    """Render one legacy effect selected by its stable string id."""

    engine = _load_legacy_engine()
    selected = _require_effect_id(effect_id)
    translated = _engine_context(context, engine, natural=False)
    return _call_engine(
        engine,
        selected,
        dialogue_line,
        start_ms,
        end_ms,
        params=params,
        context=translated,
    )


def decorate_natural(
    effect_id: str,
    dialogue_line: str,
    start_ms: int,
    end_ms: int,
    *,
    params: Mapping[str, Any] | None = None,
    context: Any = None,
) -> list[str]:
    """Render one Natural effect selected by its stable string id/alias."""

    engine = _load_natural_engine()
    selected = _natural_effect_id(effect_id)
    translated = _engine_context(context, engine, natural=True)
    return _call_engine(
        engine,
        selected,
        dialogue_line,
        start_ms,
        end_ms,
        params=params,
        context=translated,
    )


def _plain(value: Any) -> Any:
    """Recursively remove Enum/dataclass-ish values from Natural metadata."""

    if isinstance(value, Enum):
        return _plain(value.value)
    if isinstance(value, Mapping):
        return {_plain(key): _plain(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return tuple(_plain(item) for item in value)
    if isinstance(value, list):
        return [_plain(item) for item in value]
    if isinstance(value, set):
        items = [_plain(item) for item in value]
        return tuple(sorted(items, key=repr))
    return value


def natural_spec_rows() -> tuple[dict[str, Any], ...]:
    """Return Natural metadata rows with primitive ids and parameter values."""

    engine = _load_natural_engine()
    rows: list[dict[str, Any]] = []
    for effect in engine.Effect:
        spec = engine.EFFECT_SPECS[effect]
        rows.append(
            {
                "id": str(effect.value),
                "name_en": str(spec.name_en),
                "name_ja": str(spec.name_ja),
                "category_en": str(spec.category_en),
                "category_ja": str(spec.category_ja),
                "description_en": str(spec.description_en),
                "description_ja": str(spec.description_ja),
                "default_params": _plain(spec.default_params),
                "categorical_params": _plain(spec.categorical_params),
                "context_required": bool(spec.context_required),
            }
        )
    return tuple(rows)


# Compatibility spellings make the conversion functions discoverable without
# exposing any vendored classes or importing ``core``.
to_legacy_context = legacy_context
to_natural_context = natural_context


__all__ = [
    "AdapterError",
    "AdapterInputError",
    "AdapterParameterError",
    "NATURAL_ALIASES",
    "decorate_legacy",
    "decorate_natural",
    "legacy_context",
    "natural_context",
    "natural_spec_rows",
    "to_legacy_context",
    "to_natural_context",
]
